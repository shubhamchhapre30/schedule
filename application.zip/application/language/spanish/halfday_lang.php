<?php
	
	$lang['halfday.CHOOSE_YOUR_OPTION'] = 'ELIJE TU OPCIÓN';
	$lang['halfday.CHOOSE_YOUR_WEEK'] = 'ELIJE TU DÍA (S)';
	$lang['halfday.Menu'] = 'Menu';
	$lang['halfday.Nutritional_info'] = 'Información Nutricional';
	$lang['halfday.CHOOSE_PAYMENT_METHOD_THEN_REALIZES_PURCHASE'] = 'Elije tu método de pago y finaliza tu compra';
	$lang['halfday.Card'] = 'Tarjeta';
	$lang['halfday.Spot_motoconcho'] = 'Cash al pick up';
	$lang['halfday.Bank_Transferencai'] = 'Transferencia Bancaria';	
	$lang['halfday.Summary_of_Your_Order'] = 'Resumen de Tu Orden';
	$lang['halfday.Date'] = 'Fecha';
	$lang['halfday.Product'] = 'Producto';
	$lang['halfday.Price'] = 'Precio';
	$lang['halfday.Total_price'] = 'Precio Total';
	$lang['halfday.Shipping'] = 'Shipping';
	$lang['halfday.Quantity'] = 'Cantidad';
	$lang['halfday.Send'] = 'Enviar';
	$lang['halfday.If_you_have_a_Discount_Coupon_enter_it_here'] = 'Si tienes un cupón descuento, introdúce el código aquí';
	$lang['halfday.If_You_Have_A_eGift_Voucher_enter_it_here'] = 'Si tienes un bono regalo, ingresa el código aquí';
	$lang['halfday.Gift_Voucher'] = 'Bono Regalo';
	$lang['halfday.Discount'] = 'Descuento Aplicado';
	$lang['halfday.Total_Purchase'] = 'Total Compra';
	$lang['halfday.Checkout'] = 'Finalizar Pedido';
	$lang['halfday.Please_Enter_Proper_gift_coupan_name'] = 'Por favor introduce un código de Bono Regalo correcto';
	$lang['halfday.This_eGift_Voucher_Code_Not_Vaolid_for_You'] = 'El código del bono regalo insertado no es válido, por favor comprueba.';
	$lang['halfday.Please_Enter_Proper_Discount_Coupon_Code'] = 'Por favor introduce un código de cupón descuento correcto.';
	$lang['halfday.This_Discount_Coupon_Code_Not_Vaolid_for_You'] = 'Este código de cupón de descuento no es válido, por favor comprueba.';
	$lang['halfday.no_data_found'] = 'No se encontraron datos';
	$lang['halfday.menu_booked'] = 'Su menú ha sido reservado con éxito.';
	$lang['halfday.msg_menuselect_option'] = 'Selecciona un plato principal y un acompañamiento.';
	$lang['halfday.You_can_not_select_more_than_two_lunch'] = 'Selecciona solo un plato principal y un acompañamiento.';
	$lang['halfday.Please_Select_one_Main_Lunch_and_one_Alternative_Side_Dish'] = 'Selecciona solo un plato principal y un acompañamiento.';
	$lang['halfday.Please_Select_Atleast_two_lunch'] = 'Selecciona por lo menos un plato principal y un acompañamiento.';
?>