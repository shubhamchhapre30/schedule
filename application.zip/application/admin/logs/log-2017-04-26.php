<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-04-26 07:59:36 --> Config Class Initialized
INFO - 2017-04-26 07:59:36 --> Hooks Class Initialized
DEBUG - 2017-04-26 07:59:36 --> UTF-8 Support Enabled
INFO - 2017-04-26 07:59:36 --> Utf8 Class Initialized
INFO - 2017-04-26 07:59:36 --> URI Class Initialized
DEBUG - 2017-04-26 07:59:36 --> No URI present. Default controller set.
INFO - 2017-04-26 07:59:36 --> Router Class Initialized
INFO - 2017-04-26 07:59:36 --> Output Class Initialized
INFO - 2017-04-26 07:59:36 --> Security Class Initialized
DEBUG - 2017-04-26 07:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 07:59:36 --> Input Class Initialized
INFO - 2017-04-26 07:59:36 --> Language Class Initialized
INFO - 2017-04-26 07:59:36 --> Loader Class Initialized
INFO - 2017-04-26 07:59:36 --> Helper loaded: url_helper
INFO - 2017-04-26 07:59:36 --> Helper loaded: form_helper
INFO - 2017-04-26 07:59:36 --> Helper loaded: html_helper
INFO - 2017-04-26 07:59:36 --> Helper loaded: custom_helper
INFO - 2017-04-26 07:59:36 --> Helper loaded: cache_helper
INFO - 2017-04-26 07:59:36 --> Database Driver Class Initialized
INFO - 2017-04-26 07:59:36 --> Parser Class Initialized
DEBUG - 2017-04-26 07:59:36 --> Session Class Initialized
INFO - 2017-04-26 07:59:36 --> Helper loaded: string_helper
ERROR - 2017-04-26 07:59:36 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-26 07:59:36 --> Session routines successfully run
INFO - 2017-04-26 07:59:36 --> Form Validation Class Initialized
INFO - 2017-04-26 07:59:36 --> Controller Class Initialized
INFO - 2017-04-26 07:59:36 --> Model Class Initialized
INFO - 2017-04-26 07:59:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-26 07:59:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 07:59:36 --> Final output sent to browser
DEBUG - 2017-04-26 07:59:36 --> Total execution time: 0.3598
INFO - 2017-04-26 07:59:45 --> Config Class Initialized
INFO - 2017-04-26 07:59:45 --> Hooks Class Initialized
DEBUG - 2017-04-26 07:59:45 --> UTF-8 Support Enabled
INFO - 2017-04-26 07:59:45 --> Utf8 Class Initialized
INFO - 2017-04-26 07:59:45 --> URI Class Initialized
DEBUG - 2017-04-26 07:59:45 --> No URI present. Default controller set.
INFO - 2017-04-26 07:59:45 --> Router Class Initialized
INFO - 2017-04-26 07:59:45 --> Output Class Initialized
INFO - 2017-04-26 07:59:45 --> Security Class Initialized
DEBUG - 2017-04-26 07:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 07:59:45 --> Input Class Initialized
INFO - 2017-04-26 07:59:45 --> Language Class Initialized
INFO - 2017-04-26 07:59:45 --> Loader Class Initialized
INFO - 2017-04-26 07:59:45 --> Helper loaded: url_helper
INFO - 2017-04-26 07:59:45 --> Helper loaded: form_helper
INFO - 2017-04-26 07:59:45 --> Helper loaded: html_helper
INFO - 2017-04-26 07:59:45 --> Helper loaded: custom_helper
INFO - 2017-04-26 07:59:45 --> Helper loaded: cache_helper
INFO - 2017-04-26 07:59:45 --> Database Driver Class Initialized
INFO - 2017-04-26 07:59:45 --> Parser Class Initialized
DEBUG - 2017-04-26 07:59:45 --> Session Class Initialized
INFO - 2017-04-26 07:59:45 --> Helper loaded: string_helper
ERROR - 2017-04-26 07:59:45 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-26 07:59:45 --> Session routines successfully run
INFO - 2017-04-26 07:59:45 --> Form Validation Class Initialized
INFO - 2017-04-26 07:59:45 --> Controller Class Initialized
INFO - 2017-04-26 07:59:45 --> Model Class Initialized
INFO - 2017-04-26 07:59:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-26 07:59:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 07:59:46 --> Final output sent to browser
DEBUG - 2017-04-26 07:59:46 --> Total execution time: 0.8633
INFO - 2017-04-26 08:00:13 --> Config Class Initialized
INFO - 2017-04-26 08:00:13 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:00:13 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:00:13 --> Utf8 Class Initialized
INFO - 2017-04-26 08:00:13 --> URI Class Initialized
INFO - 2017-04-26 08:00:13 --> Router Class Initialized
INFO - 2017-04-26 08:00:13 --> Output Class Initialized
INFO - 2017-04-26 08:00:13 --> Security Class Initialized
DEBUG - 2017-04-26 08:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:00:13 --> Input Class Initialized
INFO - 2017-04-26 08:00:13 --> Language Class Initialized
INFO - 2017-04-26 08:00:13 --> Loader Class Initialized
INFO - 2017-04-26 08:00:13 --> Helper loaded: url_helper
INFO - 2017-04-26 08:00:13 --> Helper loaded: form_helper
INFO - 2017-04-26 08:00:13 --> Helper loaded: html_helper
INFO - 2017-04-26 08:00:13 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:00:13 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:00:13 --> Database Driver Class Initialized
INFO - 2017-04-26 08:00:13 --> Parser Class Initialized
DEBUG - 2017-04-26 08:00:13 --> Session Class Initialized
INFO - 2017-04-26 08:00:13 --> Helper loaded: string_helper
ERROR - 2017-04-26 08:00:13 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-26 08:00:13 --> Session routines successfully run
INFO - 2017-04-26 08:00:13 --> Form Validation Class Initialized
INFO - 2017-04-26 08:00:13 --> Controller Class Initialized
INFO - 2017-04-26 08:00:13 --> Model Class Initialized
INFO - 2017-04-26 08:00:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-04-26 08:00:16 --> Config Class Initialized
INFO - 2017-04-26 08:00:16 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:00:16 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:00:16 --> Utf8 Class Initialized
INFO - 2017-04-26 08:00:16 --> URI Class Initialized
INFO - 2017-04-26 08:00:16 --> Router Class Initialized
INFO - 2017-04-26 08:00:16 --> Output Class Initialized
INFO - 2017-04-26 08:00:16 --> Security Class Initialized
DEBUG - 2017-04-26 08:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:00:16 --> Input Class Initialized
INFO - 2017-04-26 08:00:16 --> Language Class Initialized
INFO - 2017-04-26 08:00:16 --> Loader Class Initialized
INFO - 2017-04-26 08:00:16 --> Helper loaded: url_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: form_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: html_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:00:16 --> Database Driver Class Initialized
INFO - 2017-04-26 08:00:16 --> Parser Class Initialized
DEBUG - 2017-04-26 08:00:16 --> Session Class Initialized
INFO - 2017-04-26 08:00:16 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:00:16 --> Session routines successfully run
INFO - 2017-04-26 08:00:16 --> Form Validation Class Initialized
INFO - 2017-04-26 08:00:16 --> Controller Class Initialized
INFO - 2017-04-26 08:00:16 --> Model Class Initialized
INFO - 2017-04-26 08:00:16 --> Config Class Initialized
INFO - 2017-04-26 08:00:16 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:00:16 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:00:16 --> Utf8 Class Initialized
INFO - 2017-04-26 08:00:16 --> URI Class Initialized
INFO - 2017-04-26 08:00:16 --> Router Class Initialized
INFO - 2017-04-26 08:00:16 --> Output Class Initialized
INFO - 2017-04-26 08:00:16 --> Security Class Initialized
DEBUG - 2017-04-26 08:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:00:16 --> Input Class Initialized
INFO - 2017-04-26 08:00:16 --> Language Class Initialized
INFO - 2017-04-26 08:00:16 --> Loader Class Initialized
INFO - 2017-04-26 08:00:16 --> Helper loaded: url_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: form_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: html_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:00:16 --> Database Driver Class Initialized
INFO - 2017-04-26 08:00:16 --> Parser Class Initialized
DEBUG - 2017-04-26 08:00:16 --> Session Class Initialized
INFO - 2017-04-26 08:00:16 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:00:16 --> Session routines successfully run
INFO - 2017-04-26 08:00:16 --> Form Validation Class Initialized
INFO - 2017-04-26 08:00:16 --> Controller Class Initialized
INFO - 2017-04-26 08:00:16 --> Model Class Initialized
INFO - 2017-04-26 08:00:16 --> Config Class Initialized
INFO - 2017-04-26 08:00:16 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:00:16 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:00:16 --> Utf8 Class Initialized
INFO - 2017-04-26 08:00:16 --> URI Class Initialized
INFO - 2017-04-26 08:00:16 --> Router Class Initialized
INFO - 2017-04-26 08:00:16 --> Output Class Initialized
INFO - 2017-04-26 08:00:16 --> Security Class Initialized
DEBUG - 2017-04-26 08:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:00:16 --> Input Class Initialized
INFO - 2017-04-26 08:00:16 --> Language Class Initialized
INFO - 2017-04-26 08:00:16 --> Loader Class Initialized
INFO - 2017-04-26 08:00:16 --> Helper loaded: url_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: form_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: html_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:00:16 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:00:16 --> Database Driver Class Initialized
INFO - 2017-04-26 08:00:16 --> Parser Class Initialized
DEBUG - 2017-04-26 08:00:16 --> Session Class Initialized
INFO - 2017-04-26 08:00:16 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:00:16 --> Session routines successfully run
INFO - 2017-04-26 08:00:16 --> Form Validation Class Initialized
INFO - 2017-04-26 08:00:16 --> Controller Class Initialized
DEBUG - 2017-04-26 08:00:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:00:16 --> Model Class Initialized
DEBUG - 2017-04-26 08:00:16 --> Pagination Class Initialized
INFO - 2017-04-26 08:00:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:00:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:00:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-26 08:00:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:00:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:00:16 --> Final output sent to browser
DEBUG - 2017-04-26 08:00:16 --> Total execution time: 0.3990
INFO - 2017-04-26 08:00:48 --> Config Class Initialized
INFO - 2017-04-26 08:00:48 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:00:48 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:00:48 --> Utf8 Class Initialized
INFO - 2017-04-26 08:00:48 --> URI Class Initialized
INFO - 2017-04-26 08:00:48 --> Router Class Initialized
INFO - 2017-04-26 08:00:48 --> Output Class Initialized
INFO - 2017-04-26 08:00:48 --> Security Class Initialized
DEBUG - 2017-04-26 08:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:00:48 --> Input Class Initialized
INFO - 2017-04-26 08:00:48 --> Language Class Initialized
INFO - 2017-04-26 08:00:48 --> Loader Class Initialized
INFO - 2017-04-26 08:00:48 --> Helper loaded: url_helper
INFO - 2017-04-26 08:00:48 --> Helper loaded: form_helper
INFO - 2017-04-26 08:00:48 --> Helper loaded: html_helper
INFO - 2017-04-26 08:00:48 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:00:48 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:00:48 --> Database Driver Class Initialized
INFO - 2017-04-26 08:00:49 --> Parser Class Initialized
DEBUG - 2017-04-26 08:00:49 --> Session Class Initialized
INFO - 2017-04-26 08:00:49 --> Helper loaded: string_helper
ERROR - 2017-04-26 08:00:49 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-26 08:00:49 --> Session routines successfully run
INFO - 2017-04-26 08:00:49 --> Form Validation Class Initialized
INFO - 2017-04-26 08:00:49 --> Controller Class Initialized
INFO - 2017-04-26 08:00:49 --> Model Class Initialized
INFO - 2017-04-26 08:00:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-04-26 08:00:54 --> Config Class Initialized
INFO - 2017-04-26 08:00:54 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:00:54 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:00:54 --> Utf8 Class Initialized
INFO - 2017-04-26 08:00:54 --> URI Class Initialized
INFO - 2017-04-26 08:00:54 --> Router Class Initialized
INFO - 2017-04-26 08:00:54 --> Output Class Initialized
INFO - 2017-04-26 08:00:54 --> Security Class Initialized
DEBUG - 2017-04-26 08:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:00:54 --> Input Class Initialized
INFO - 2017-04-26 08:00:54 --> Language Class Initialized
INFO - 2017-04-26 08:00:54 --> Loader Class Initialized
INFO - 2017-04-26 08:00:54 --> Helper loaded: url_helper
INFO - 2017-04-26 08:00:54 --> Helper loaded: form_helper
INFO - 2017-04-26 08:00:54 --> Helper loaded: html_helper
INFO - 2017-04-26 08:00:54 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:00:54 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:00:54 --> Database Driver Class Initialized
INFO - 2017-04-26 08:00:55 --> Parser Class Initialized
DEBUG - 2017-04-26 08:00:55 --> Session Class Initialized
INFO - 2017-04-26 08:00:55 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:00:55 --> Session routines successfully run
INFO - 2017-04-26 08:00:55 --> Form Validation Class Initialized
INFO - 2017-04-26 08:00:55 --> Controller Class Initialized
INFO - 2017-04-26 08:00:55 --> Model Class Initialized
INFO - 2017-04-26 08:00:55 --> Config Class Initialized
INFO - 2017-04-26 08:00:55 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:00:55 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:00:55 --> Utf8 Class Initialized
INFO - 2017-04-26 08:00:55 --> URI Class Initialized
INFO - 2017-04-26 08:00:55 --> Router Class Initialized
INFO - 2017-04-26 08:00:55 --> Output Class Initialized
INFO - 2017-04-26 08:00:55 --> Security Class Initialized
DEBUG - 2017-04-26 08:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:00:55 --> Input Class Initialized
INFO - 2017-04-26 08:00:55 --> Language Class Initialized
INFO - 2017-04-26 08:00:55 --> Loader Class Initialized
INFO - 2017-04-26 08:00:55 --> Helper loaded: url_helper
INFO - 2017-04-26 08:00:55 --> Helper loaded: form_helper
INFO - 2017-04-26 08:00:55 --> Helper loaded: html_helper
INFO - 2017-04-26 08:00:55 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:00:55 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:00:55 --> Database Driver Class Initialized
INFO - 2017-04-26 08:00:55 --> Parser Class Initialized
DEBUG - 2017-04-26 08:00:55 --> Session Class Initialized
INFO - 2017-04-26 08:00:55 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:00:55 --> Session routines successfully run
INFO - 2017-04-26 08:00:55 --> Form Validation Class Initialized
INFO - 2017-04-26 08:00:55 --> Controller Class Initialized
INFO - 2017-04-26 08:00:55 --> Model Class Initialized
INFO - 2017-04-26 08:00:55 --> Config Class Initialized
INFO - 2017-04-26 08:00:55 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:00:55 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:00:55 --> Utf8 Class Initialized
INFO - 2017-04-26 08:00:55 --> URI Class Initialized
INFO - 2017-04-26 08:00:55 --> Router Class Initialized
INFO - 2017-04-26 08:00:55 --> Output Class Initialized
INFO - 2017-04-26 08:00:55 --> Security Class Initialized
DEBUG - 2017-04-26 08:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:00:55 --> Input Class Initialized
INFO - 2017-04-26 08:00:55 --> Language Class Initialized
INFO - 2017-04-26 08:00:55 --> Loader Class Initialized
INFO - 2017-04-26 08:00:55 --> Helper loaded: url_helper
INFO - 2017-04-26 08:00:55 --> Helper loaded: form_helper
INFO - 2017-04-26 08:00:55 --> Helper loaded: html_helper
INFO - 2017-04-26 08:00:55 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:00:55 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:00:55 --> Database Driver Class Initialized
INFO - 2017-04-26 08:00:55 --> Parser Class Initialized
DEBUG - 2017-04-26 08:00:55 --> Session Class Initialized
INFO - 2017-04-26 08:00:55 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:00:55 --> Session routines successfully run
INFO - 2017-04-26 08:00:55 --> Form Validation Class Initialized
INFO - 2017-04-26 08:00:55 --> Controller Class Initialized
DEBUG - 2017-04-26 08:00:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:00:55 --> Model Class Initialized
DEBUG - 2017-04-26 08:00:55 --> Pagination Class Initialized
INFO - 2017-04-26 08:00:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:00:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:00:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-26 08:00:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:00:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:00:55 --> Final output sent to browser
DEBUG - 2017-04-26 08:00:55 --> Total execution time: 0.1886
INFO - 2017-04-26 08:02:31 --> Config Class Initialized
INFO - 2017-04-26 08:02:31 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:02:31 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:02:31 --> Utf8 Class Initialized
INFO - 2017-04-26 08:02:31 --> URI Class Initialized
INFO - 2017-04-26 08:02:31 --> Router Class Initialized
INFO - 2017-04-26 08:02:31 --> Output Class Initialized
INFO - 2017-04-26 08:02:31 --> Security Class Initialized
DEBUG - 2017-04-26 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:02:31 --> Input Class Initialized
INFO - 2017-04-26 08:02:31 --> Language Class Initialized
INFO - 2017-04-26 08:02:31 --> Loader Class Initialized
INFO - 2017-04-26 08:02:31 --> Helper loaded: url_helper
INFO - 2017-04-26 08:02:31 --> Helper loaded: form_helper
INFO - 2017-04-26 08:02:31 --> Helper loaded: html_helper
INFO - 2017-04-26 08:02:31 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:02:31 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:02:31 --> Database Driver Class Initialized
INFO - 2017-04-26 08:02:31 --> Parser Class Initialized
DEBUG - 2017-04-26 08:02:31 --> Session Class Initialized
INFO - 2017-04-26 08:02:31 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:02:31 --> Session routines successfully run
INFO - 2017-04-26 08:02:31 --> Form Validation Class Initialized
INFO - 2017-04-26 08:02:31 --> Controller Class Initialized
DEBUG - 2017-04-26 08:02:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:02:31 --> Model Class Initialized
DEBUG - 2017-04-26 08:02:31 --> Pagination Class Initialized
INFO - 2017-04-26 08:02:31 --> Config Class Initialized
INFO - 2017-04-26 08:02:31 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:02:31 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:02:31 --> Utf8 Class Initialized
INFO - 2017-04-26 08:02:31 --> URI Class Initialized
INFO - 2017-04-26 08:02:31 --> Router Class Initialized
INFO - 2017-04-26 08:02:31 --> Output Class Initialized
INFO - 2017-04-26 08:02:31 --> Security Class Initialized
DEBUG - 2017-04-26 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:02:31 --> Input Class Initialized
INFO - 2017-04-26 08:02:31 --> Language Class Initialized
INFO - 2017-04-26 08:02:31 --> Loader Class Initialized
INFO - 2017-04-26 08:02:31 --> Helper loaded: url_helper
INFO - 2017-04-26 08:02:31 --> Helper loaded: form_helper
INFO - 2017-04-26 08:02:31 --> Helper loaded: html_helper
INFO - 2017-04-26 08:02:31 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:02:31 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:02:31 --> Database Driver Class Initialized
INFO - 2017-04-26 08:02:31 --> Parser Class Initialized
DEBUG - 2017-04-26 08:02:31 --> Session Class Initialized
INFO - 2017-04-26 08:02:31 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:02:31 --> Session routines successfully run
INFO - 2017-04-26 08:02:31 --> Form Validation Class Initialized
INFO - 2017-04-26 08:02:31 --> Controller Class Initialized
DEBUG - 2017-04-26 08:02:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:02:31 --> Model Class Initialized
DEBUG - 2017-04-26 08:02:31 --> Pagination Class Initialized
INFO - 2017-04-26 08:02:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:02:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:02:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:02:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:02:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:02:34 --> Final output sent to browser
DEBUG - 2017-04-26 08:02:34 --> Total execution time: 3.3493
INFO - 2017-04-26 08:02:37 --> Config Class Initialized
INFO - 2017-04-26 08:02:37 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:02:37 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:02:37 --> Utf8 Class Initialized
INFO - 2017-04-26 08:02:37 --> URI Class Initialized
INFO - 2017-04-26 08:02:37 --> Router Class Initialized
INFO - 2017-04-26 08:02:37 --> Output Class Initialized
INFO - 2017-04-26 08:02:37 --> Security Class Initialized
DEBUG - 2017-04-26 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:02:37 --> Input Class Initialized
INFO - 2017-04-26 08:02:37 --> Language Class Initialized
INFO - 2017-04-26 08:02:37 --> Loader Class Initialized
INFO - 2017-04-26 08:02:37 --> Helper loaded: url_helper
INFO - 2017-04-26 08:02:37 --> Helper loaded: form_helper
INFO - 2017-04-26 08:02:37 --> Helper loaded: html_helper
INFO - 2017-04-26 08:02:37 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:02:37 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:02:37 --> Database Driver Class Initialized
INFO - 2017-04-26 08:02:37 --> Parser Class Initialized
DEBUG - 2017-04-26 08:02:37 --> Session Class Initialized
INFO - 2017-04-26 08:02:37 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:02:37 --> Session routines successfully run
INFO - 2017-04-26 08:02:37 --> Form Validation Class Initialized
INFO - 2017-04-26 08:02:37 --> Controller Class Initialized
DEBUG - 2017-04-26 08:02:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:02:37 --> Model Class Initialized
DEBUG - 2017-04-26 08:02:37 --> Pagination Class Initialized
INFO - 2017-04-26 08:02:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:02:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:02:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-26 08:02:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:02:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:02:38 --> Final output sent to browser
DEBUG - 2017-04-26 08:02:38 --> Total execution time: 0.4572
INFO - 2017-04-26 08:02:38 --> Config Class Initialized
INFO - 2017-04-26 08:02:38 --> Config Class Initialized
INFO - 2017-04-26 08:02:38 --> Hooks Class Initialized
INFO - 2017-04-26 08:02:38 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:02:38 --> UTF-8 Support Enabled
DEBUG - 2017-04-26 08:02:38 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:02:38 --> Utf8 Class Initialized
INFO - 2017-04-26 08:02:38 --> Utf8 Class Initialized
INFO - 2017-04-26 08:02:38 --> URI Class Initialized
INFO - 2017-04-26 08:02:38 --> URI Class Initialized
INFO - 2017-04-26 08:02:39 --> Router Class Initialized
INFO - 2017-04-26 08:02:39 --> Router Class Initialized
INFO - 2017-04-26 08:02:39 --> Output Class Initialized
INFO - 2017-04-26 08:02:39 --> Output Class Initialized
INFO - 2017-04-26 08:02:39 --> Security Class Initialized
INFO - 2017-04-26 08:02:39 --> Security Class Initialized
DEBUG - 2017-04-26 08:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-26 08:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:02:39 --> Input Class Initialized
INFO - 2017-04-26 08:02:39 --> Input Class Initialized
INFO - 2017-04-26 08:02:39 --> Language Class Initialized
INFO - 2017-04-26 08:02:39 --> Language Class Initialized
ERROR - 2017-04-26 08:02:39 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-26 08:02:39 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:02:40 --> Config Class Initialized
INFO - 2017-04-26 08:02:40 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:02:40 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:02:40 --> Utf8 Class Initialized
INFO - 2017-04-26 08:02:40 --> URI Class Initialized
INFO - 2017-04-26 08:02:40 --> Router Class Initialized
INFO - 2017-04-26 08:02:40 --> Output Class Initialized
INFO - 2017-04-26 08:02:40 --> Security Class Initialized
DEBUG - 2017-04-26 08:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:02:40 --> Input Class Initialized
INFO - 2017-04-26 08:02:40 --> Language Class Initialized
ERROR - 2017-04-26 08:02:40 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:02:40 --> Config Class Initialized
INFO - 2017-04-26 08:02:40 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:02:40 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:02:40 --> Utf8 Class Initialized
INFO - 2017-04-26 08:02:40 --> URI Class Initialized
INFO - 2017-04-26 08:02:40 --> Router Class Initialized
INFO - 2017-04-26 08:02:40 --> Output Class Initialized
INFO - 2017-04-26 08:02:40 --> Security Class Initialized
DEBUG - 2017-04-26 08:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:02:40 --> Input Class Initialized
INFO - 2017-04-26 08:02:40 --> Language Class Initialized
ERROR - 2017-04-26 08:02:40 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:04:41 --> Config Class Initialized
INFO - 2017-04-26 08:04:41 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:04:41 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:04:41 --> Utf8 Class Initialized
INFO - 2017-04-26 08:04:41 --> URI Class Initialized
INFO - 2017-04-26 08:04:41 --> Router Class Initialized
INFO - 2017-04-26 08:04:41 --> Output Class Initialized
INFO - 2017-04-26 08:04:41 --> Security Class Initialized
DEBUG - 2017-04-26 08:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:04:41 --> Input Class Initialized
INFO - 2017-04-26 08:04:41 --> Language Class Initialized
INFO - 2017-04-26 08:04:41 --> Loader Class Initialized
INFO - 2017-04-26 08:04:41 --> Helper loaded: url_helper
INFO - 2017-04-26 08:04:41 --> Helper loaded: form_helper
INFO - 2017-04-26 08:04:41 --> Helper loaded: html_helper
INFO - 2017-04-26 08:04:41 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:04:41 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:04:41 --> Database Driver Class Initialized
INFO - 2017-04-26 08:04:41 --> Parser Class Initialized
DEBUG - 2017-04-26 08:04:41 --> Session Class Initialized
INFO - 2017-04-26 08:04:41 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:04:41 --> Session routines successfully run
INFO - 2017-04-26 08:04:41 --> Form Validation Class Initialized
INFO - 2017-04-26 08:04:41 --> Controller Class Initialized
DEBUG - 2017-04-26 08:04:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:04:41 --> Model Class Initialized
DEBUG - 2017-04-26 08:04:41 --> Pagination Class Initialized
INFO - 2017-04-26 08:04:41 --> Config Class Initialized
INFO - 2017-04-26 08:04:41 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:04:41 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:04:41 --> Utf8 Class Initialized
INFO - 2017-04-26 08:04:41 --> URI Class Initialized
INFO - 2017-04-26 08:04:41 --> Router Class Initialized
INFO - 2017-04-26 08:04:41 --> Output Class Initialized
INFO - 2017-04-26 08:04:41 --> Security Class Initialized
DEBUG - 2017-04-26 08:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:04:41 --> Input Class Initialized
INFO - 2017-04-26 08:04:41 --> Language Class Initialized
INFO - 2017-04-26 08:04:41 --> Loader Class Initialized
INFO - 2017-04-26 08:04:41 --> Helper loaded: url_helper
INFO - 2017-04-26 08:04:41 --> Helper loaded: form_helper
INFO - 2017-04-26 08:04:41 --> Helper loaded: html_helper
INFO - 2017-04-26 08:04:41 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:04:41 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:04:41 --> Database Driver Class Initialized
INFO - 2017-04-26 08:04:41 --> Parser Class Initialized
DEBUG - 2017-04-26 08:04:41 --> Session Class Initialized
INFO - 2017-04-26 08:04:41 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:04:41 --> Session routines successfully run
INFO - 2017-04-26 08:04:41 --> Form Validation Class Initialized
INFO - 2017-04-26 08:04:41 --> Controller Class Initialized
DEBUG - 2017-04-26 08:04:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:04:41 --> Model Class Initialized
DEBUG - 2017-04-26 08:04:41 --> Pagination Class Initialized
INFO - 2017-04-26 08:04:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:04:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:04:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:04:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:04:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:04:45 --> Final output sent to browser
DEBUG - 2017-04-26 08:04:45 --> Total execution time: 4.2205
INFO - 2017-04-26 08:07:57 --> Config Class Initialized
INFO - 2017-04-26 08:07:57 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:07:57 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:07:57 --> Utf8 Class Initialized
INFO - 2017-04-26 08:07:57 --> URI Class Initialized
INFO - 2017-04-26 08:07:57 --> Router Class Initialized
INFO - 2017-04-26 08:07:57 --> Output Class Initialized
INFO - 2017-04-26 08:07:57 --> Security Class Initialized
DEBUG - 2017-04-26 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:07:57 --> Input Class Initialized
INFO - 2017-04-26 08:07:57 --> Language Class Initialized
INFO - 2017-04-26 08:07:57 --> Loader Class Initialized
INFO - 2017-04-26 08:07:57 --> Helper loaded: url_helper
INFO - 2017-04-26 08:07:57 --> Helper loaded: form_helper
INFO - 2017-04-26 08:07:57 --> Helper loaded: html_helper
INFO - 2017-04-26 08:07:57 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:07:57 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:07:57 --> Database Driver Class Initialized
INFO - 2017-04-26 08:07:57 --> Parser Class Initialized
DEBUG - 2017-04-26 08:07:57 --> Session Class Initialized
INFO - 2017-04-26 08:07:57 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:07:57 --> Session routines successfully run
INFO - 2017-04-26 08:07:57 --> Form Validation Class Initialized
INFO - 2017-04-26 08:07:57 --> Controller Class Initialized
DEBUG - 2017-04-26 08:07:57 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:07:57 --> Model Class Initialized
DEBUG - 2017-04-26 08:07:57 --> Pagination Class Initialized
INFO - 2017-04-26 08:07:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:07:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:07:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-26 08:07:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:07:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:07:57 --> Final output sent to browser
DEBUG - 2017-04-26 08:07:57 --> Total execution time: 0.2411
INFO - 2017-04-26 08:07:57 --> Config Class Initialized
INFO - 2017-04-26 08:07:57 --> Config Class Initialized
INFO - 2017-04-26 08:07:57 --> Hooks Class Initialized
INFO - 2017-04-26 08:07:57 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:07:57 --> UTF-8 Support Enabled
DEBUG - 2017-04-26 08:07:57 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:07:57 --> Utf8 Class Initialized
INFO - 2017-04-26 08:07:57 --> Utf8 Class Initialized
INFO - 2017-04-26 08:07:57 --> URI Class Initialized
INFO - 2017-04-26 08:07:57 --> URI Class Initialized
INFO - 2017-04-26 08:07:57 --> Router Class Initialized
INFO - 2017-04-26 08:07:57 --> Router Class Initialized
INFO - 2017-04-26 08:07:57 --> Output Class Initialized
INFO - 2017-04-26 08:07:57 --> Output Class Initialized
INFO - 2017-04-26 08:07:57 --> Security Class Initialized
INFO - 2017-04-26 08:07:57 --> Security Class Initialized
DEBUG - 2017-04-26 08:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-26 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:07:57 --> Input Class Initialized
INFO - 2017-04-26 08:07:57 --> Input Class Initialized
INFO - 2017-04-26 08:07:57 --> Language Class Initialized
INFO - 2017-04-26 08:07:57 --> Language Class Initialized
ERROR - 2017-04-26 08:07:57 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-26 08:07:57 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:07:58 --> Config Class Initialized
INFO - 2017-04-26 08:07:58 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:07:58 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:07:58 --> Utf8 Class Initialized
INFO - 2017-04-26 08:07:58 --> URI Class Initialized
INFO - 2017-04-26 08:07:58 --> Router Class Initialized
INFO - 2017-04-26 08:07:58 --> Output Class Initialized
INFO - 2017-04-26 08:07:58 --> Security Class Initialized
DEBUG - 2017-04-26 08:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:07:58 --> Input Class Initialized
INFO - 2017-04-26 08:07:58 --> Language Class Initialized
ERROR - 2017-04-26 08:07:58 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:07:58 --> Config Class Initialized
INFO - 2017-04-26 08:07:58 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:07:58 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:07:58 --> Utf8 Class Initialized
INFO - 2017-04-26 08:07:58 --> URI Class Initialized
INFO - 2017-04-26 08:07:58 --> Router Class Initialized
INFO - 2017-04-26 08:07:58 --> Output Class Initialized
INFO - 2017-04-26 08:07:58 --> Security Class Initialized
DEBUG - 2017-04-26 08:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:07:58 --> Input Class Initialized
INFO - 2017-04-26 08:07:58 --> Language Class Initialized
ERROR - 2017-04-26 08:07:58 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:07:59 --> Config Class Initialized
INFO - 2017-04-26 08:07:59 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:07:59 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:07:59 --> Utf8 Class Initialized
INFO - 2017-04-26 08:07:59 --> URI Class Initialized
INFO - 2017-04-26 08:07:59 --> Router Class Initialized
INFO - 2017-04-26 08:07:59 --> Output Class Initialized
INFO - 2017-04-26 08:07:59 --> Security Class Initialized
DEBUG - 2017-04-26 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:08:00 --> Input Class Initialized
INFO - 2017-04-26 08:08:00 --> Language Class Initialized
INFO - 2017-04-26 08:08:00 --> Loader Class Initialized
INFO - 2017-04-26 08:08:00 --> Helper loaded: url_helper
INFO - 2017-04-26 08:08:00 --> Helper loaded: form_helper
INFO - 2017-04-26 08:08:00 --> Helper loaded: html_helper
INFO - 2017-04-26 08:08:00 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:08:00 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:08:00 --> Database Driver Class Initialized
INFO - 2017-04-26 08:08:00 --> Parser Class Initialized
DEBUG - 2017-04-26 08:08:00 --> Session Class Initialized
INFO - 2017-04-26 08:08:00 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:08:00 --> Session routines successfully run
INFO - 2017-04-26 08:08:00 --> Form Validation Class Initialized
INFO - 2017-04-26 08:08:00 --> Controller Class Initialized
DEBUG - 2017-04-26 08:08:00 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:08:00 --> Model Class Initialized
DEBUG - 2017-04-26 08:08:00 --> Pagination Class Initialized
INFO - 2017-04-26 08:08:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:08:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:08:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:08:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:08:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:08:03 --> Final output sent to browser
DEBUG - 2017-04-26 08:08:03 --> Total execution time: 3.5750
INFO - 2017-04-26 08:08:34 --> Config Class Initialized
INFO - 2017-04-26 08:08:34 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:08:34 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:08:34 --> Utf8 Class Initialized
INFO - 2017-04-26 08:08:34 --> URI Class Initialized
INFO - 2017-04-26 08:08:34 --> Router Class Initialized
INFO - 2017-04-26 08:08:34 --> Output Class Initialized
INFO - 2017-04-26 08:08:34 --> Security Class Initialized
DEBUG - 2017-04-26 08:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:08:34 --> Input Class Initialized
INFO - 2017-04-26 08:08:34 --> Language Class Initialized
INFO - 2017-04-26 08:08:34 --> Loader Class Initialized
INFO - 2017-04-26 08:08:34 --> Helper loaded: url_helper
INFO - 2017-04-26 08:08:34 --> Helper loaded: form_helper
INFO - 2017-04-26 08:08:34 --> Helper loaded: html_helper
INFO - 2017-04-26 08:08:34 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:08:34 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:08:34 --> Database Driver Class Initialized
INFO - 2017-04-26 08:08:34 --> Parser Class Initialized
DEBUG - 2017-04-26 08:08:34 --> Session Class Initialized
INFO - 2017-04-26 08:08:35 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:08:35 --> Session routines successfully run
INFO - 2017-04-26 08:08:35 --> Form Validation Class Initialized
INFO - 2017-04-26 08:08:35 --> Controller Class Initialized
DEBUG - 2017-04-26 08:08:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:08:35 --> Model Class Initialized
DEBUG - 2017-04-26 08:08:35 --> Pagination Class Initialized
INFO - 2017-04-26 08:08:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:08:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:08:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:08:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:08:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:08:38 --> Final output sent to browser
DEBUG - 2017-04-26 08:08:38 --> Total execution time: 3.3155
INFO - 2017-04-26 08:20:27 --> Config Class Initialized
INFO - 2017-04-26 08:20:27 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:20:27 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:20:27 --> Utf8 Class Initialized
INFO - 2017-04-26 08:20:27 --> URI Class Initialized
INFO - 2017-04-26 08:20:27 --> Router Class Initialized
INFO - 2017-04-26 08:20:27 --> Output Class Initialized
INFO - 2017-04-26 08:20:27 --> Security Class Initialized
DEBUG - 2017-04-26 08:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:20:27 --> Input Class Initialized
INFO - 2017-04-26 08:20:27 --> Language Class Initialized
INFO - 2017-04-26 08:20:28 --> Loader Class Initialized
INFO - 2017-04-26 08:20:28 --> Helper loaded: url_helper
INFO - 2017-04-26 08:20:28 --> Helper loaded: form_helper
INFO - 2017-04-26 08:20:28 --> Helper loaded: html_helper
INFO - 2017-04-26 08:20:28 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:20:28 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:20:28 --> Database Driver Class Initialized
INFO - 2017-04-26 08:20:28 --> Parser Class Initialized
DEBUG - 2017-04-26 08:20:28 --> Session Class Initialized
INFO - 2017-04-26 08:20:28 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:20:28 --> Session routines successfully run
INFO - 2017-04-26 08:20:28 --> Form Validation Class Initialized
INFO - 2017-04-26 08:20:28 --> Controller Class Initialized
DEBUG - 2017-04-26 08:20:28 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:20:28 --> Model Class Initialized
DEBUG - 2017-04-26 08:20:28 --> Pagination Class Initialized
INFO - 2017-04-26 08:20:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:20:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:20:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-26 08:20:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:20:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:20:28 --> Final output sent to browser
DEBUG - 2017-04-26 08:20:28 --> Total execution time: 0.3653
INFO - 2017-04-26 08:20:29 --> Config Class Initialized
INFO - 2017-04-26 08:20:29 --> Config Class Initialized
INFO - 2017-04-26 08:20:29 --> Hooks Class Initialized
INFO - 2017-04-26 08:20:29 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:20:29 --> UTF-8 Support Enabled
DEBUG - 2017-04-26 08:20:29 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:20:29 --> Utf8 Class Initialized
INFO - 2017-04-26 08:20:29 --> Utf8 Class Initialized
INFO - 2017-04-26 08:20:29 --> URI Class Initialized
INFO - 2017-04-26 08:20:29 --> URI Class Initialized
INFO - 2017-04-26 08:20:29 --> Router Class Initialized
INFO - 2017-04-26 08:20:29 --> Router Class Initialized
INFO - 2017-04-26 08:20:29 --> Output Class Initialized
INFO - 2017-04-26 08:20:29 --> Output Class Initialized
INFO - 2017-04-26 08:20:29 --> Security Class Initialized
INFO - 2017-04-26 08:20:29 --> Security Class Initialized
DEBUG - 2017-04-26 08:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-26 08:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:20:29 --> Input Class Initialized
INFO - 2017-04-26 08:20:29 --> Input Class Initialized
INFO - 2017-04-26 08:20:29 --> Language Class Initialized
INFO - 2017-04-26 08:20:29 --> Language Class Initialized
ERROR - 2017-04-26 08:20:29 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-26 08:20:29 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:20:29 --> Config Class Initialized
INFO - 2017-04-26 08:20:29 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:20:29 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:20:29 --> Utf8 Class Initialized
INFO - 2017-04-26 08:20:29 --> URI Class Initialized
INFO - 2017-04-26 08:20:29 --> Router Class Initialized
INFO - 2017-04-26 08:20:29 --> Output Class Initialized
INFO - 2017-04-26 08:20:29 --> Security Class Initialized
DEBUG - 2017-04-26 08:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:20:29 --> Input Class Initialized
INFO - 2017-04-26 08:20:29 --> Language Class Initialized
ERROR - 2017-04-26 08:20:29 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:20:29 --> Config Class Initialized
INFO - 2017-04-26 08:20:29 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:20:29 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:20:29 --> Utf8 Class Initialized
INFO - 2017-04-26 08:20:29 --> URI Class Initialized
INFO - 2017-04-26 08:20:29 --> Router Class Initialized
INFO - 2017-04-26 08:20:29 --> Output Class Initialized
INFO - 2017-04-26 08:20:29 --> Security Class Initialized
DEBUG - 2017-04-26 08:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:20:29 --> Input Class Initialized
INFO - 2017-04-26 08:20:29 --> Language Class Initialized
ERROR - 2017-04-26 08:20:29 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:20:30 --> Config Class Initialized
INFO - 2017-04-26 08:20:30 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:20:30 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:20:30 --> Utf8 Class Initialized
INFO - 2017-04-26 08:20:30 --> URI Class Initialized
INFO - 2017-04-26 08:20:30 --> Router Class Initialized
INFO - 2017-04-26 08:20:30 --> Output Class Initialized
INFO - 2017-04-26 08:20:31 --> Security Class Initialized
DEBUG - 2017-04-26 08:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:20:31 --> Input Class Initialized
INFO - 2017-04-26 08:20:31 --> Language Class Initialized
INFO - 2017-04-26 08:20:31 --> Loader Class Initialized
INFO - 2017-04-26 08:20:31 --> Helper loaded: url_helper
INFO - 2017-04-26 08:20:31 --> Helper loaded: form_helper
INFO - 2017-04-26 08:20:31 --> Helper loaded: html_helper
INFO - 2017-04-26 08:20:31 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:20:31 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:20:31 --> Database Driver Class Initialized
INFO - 2017-04-26 08:20:31 --> Parser Class Initialized
DEBUG - 2017-04-26 08:20:31 --> Session Class Initialized
INFO - 2017-04-26 08:20:31 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:20:31 --> Session routines successfully run
INFO - 2017-04-26 08:20:31 --> Form Validation Class Initialized
INFO - 2017-04-26 08:20:31 --> Controller Class Initialized
DEBUG - 2017-04-26 08:20:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:20:31 --> Model Class Initialized
DEBUG - 2017-04-26 08:20:31 --> Pagination Class Initialized
INFO - 2017-04-26 08:20:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:20:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:20:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:20:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:20:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:20:34 --> Final output sent to browser
DEBUG - 2017-04-26 08:20:34 --> Total execution time: 4.0256
INFO - 2017-04-26 08:22:31 --> Config Class Initialized
INFO - 2017-04-26 08:22:31 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:22:31 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:22:31 --> Utf8 Class Initialized
INFO - 2017-04-26 08:22:31 --> URI Class Initialized
INFO - 2017-04-26 08:22:31 --> Router Class Initialized
INFO - 2017-04-26 08:22:31 --> Output Class Initialized
INFO - 2017-04-26 08:22:31 --> Security Class Initialized
DEBUG - 2017-04-26 08:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:22:31 --> Input Class Initialized
INFO - 2017-04-26 08:22:31 --> Language Class Initialized
INFO - 2017-04-26 08:22:31 --> Loader Class Initialized
INFO - 2017-04-26 08:22:31 --> Helper loaded: url_helper
INFO - 2017-04-26 08:22:31 --> Helper loaded: form_helper
INFO - 2017-04-26 08:22:31 --> Helper loaded: html_helper
INFO - 2017-04-26 08:22:32 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:22:32 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:22:32 --> Database Driver Class Initialized
INFO - 2017-04-26 08:22:32 --> Parser Class Initialized
DEBUG - 2017-04-26 08:22:32 --> Session Class Initialized
INFO - 2017-04-26 08:22:32 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:22:32 --> Session routines successfully run
INFO - 2017-04-26 08:22:32 --> Form Validation Class Initialized
INFO - 2017-04-26 08:22:32 --> Controller Class Initialized
DEBUG - 2017-04-26 08:22:32 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:22:32 --> Model Class Initialized
DEBUG - 2017-04-26 08:22:32 --> Pagination Class Initialized
INFO - 2017-04-26 08:22:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:22:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:22:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:22:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:22:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:22:35 --> Final output sent to browser
DEBUG - 2017-04-26 08:22:35 --> Total execution time: 3.1483
INFO - 2017-04-26 08:22:37 --> Config Class Initialized
INFO - 2017-04-26 08:22:37 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:22:37 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:22:37 --> Utf8 Class Initialized
INFO - 2017-04-26 08:22:37 --> URI Class Initialized
DEBUG - 2017-04-26 08:22:37 --> No URI present. Default controller set.
INFO - 2017-04-26 08:22:37 --> Router Class Initialized
INFO - 2017-04-26 08:22:37 --> Output Class Initialized
INFO - 2017-04-26 08:22:37 --> Security Class Initialized
DEBUG - 2017-04-26 08:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:22:37 --> Input Class Initialized
INFO - 2017-04-26 08:22:37 --> Language Class Initialized
INFO - 2017-04-26 08:22:37 --> Loader Class Initialized
INFO - 2017-04-26 08:22:37 --> Helper loaded: url_helper
INFO - 2017-04-26 08:22:37 --> Helper loaded: form_helper
INFO - 2017-04-26 08:22:37 --> Helper loaded: html_helper
INFO - 2017-04-26 08:22:37 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:22:37 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:22:37 --> Database Driver Class Initialized
INFO - 2017-04-26 08:22:37 --> Parser Class Initialized
DEBUG - 2017-04-26 08:22:37 --> Session Class Initialized
INFO - 2017-04-26 08:22:37 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:22:37 --> Session routines successfully run
INFO - 2017-04-26 08:22:37 --> Form Validation Class Initialized
INFO - 2017-04-26 08:22:37 --> Controller Class Initialized
INFO - 2017-04-26 08:22:37 --> Model Class Initialized
INFO - 2017-04-26 08:22:37 --> Config Class Initialized
INFO - 2017-04-26 08:22:37 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:22:37 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:22:37 --> Utf8 Class Initialized
INFO - 2017-04-26 08:22:37 --> URI Class Initialized
INFO - 2017-04-26 08:22:37 --> Router Class Initialized
INFO - 2017-04-26 08:22:37 --> Output Class Initialized
INFO - 2017-04-26 08:22:37 --> Security Class Initialized
DEBUG - 2017-04-26 08:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:22:37 --> Input Class Initialized
INFO - 2017-04-26 08:22:37 --> Language Class Initialized
INFO - 2017-04-26 08:22:37 --> Loader Class Initialized
INFO - 2017-04-26 08:22:38 --> Helper loaded: url_helper
INFO - 2017-04-26 08:22:38 --> Helper loaded: form_helper
INFO - 2017-04-26 08:22:38 --> Helper loaded: html_helper
INFO - 2017-04-26 08:22:38 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:22:38 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:22:38 --> Database Driver Class Initialized
INFO - 2017-04-26 08:22:38 --> Parser Class Initialized
DEBUG - 2017-04-26 08:22:38 --> Session Class Initialized
INFO - 2017-04-26 08:22:38 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:22:38 --> Session routines successfully run
INFO - 2017-04-26 08:22:38 --> Form Validation Class Initialized
INFO - 2017-04-26 08:22:38 --> Controller Class Initialized
DEBUG - 2017-04-26 08:22:38 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:22:38 --> Model Class Initialized
DEBUG - 2017-04-26 08:22:38 --> Pagination Class Initialized
INFO - 2017-04-26 08:22:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:22:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:22:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-26 08:22:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:22:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:22:38 --> Final output sent to browser
DEBUG - 2017-04-26 08:22:38 --> Total execution time: 0.3489
INFO - 2017-04-26 08:22:41 --> Config Class Initialized
INFO - 2017-04-26 08:22:41 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:22:41 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:22:41 --> Utf8 Class Initialized
INFO - 2017-04-26 08:22:41 --> URI Class Initialized
DEBUG - 2017-04-26 08:22:41 --> No URI present. Default controller set.
INFO - 2017-04-26 08:22:41 --> Router Class Initialized
INFO - 2017-04-26 08:22:41 --> Output Class Initialized
INFO - 2017-04-26 08:22:41 --> Security Class Initialized
DEBUG - 2017-04-26 08:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:22:41 --> Input Class Initialized
INFO - 2017-04-26 08:22:41 --> Language Class Initialized
INFO - 2017-04-26 08:22:41 --> Loader Class Initialized
INFO - 2017-04-26 08:22:41 --> Helper loaded: url_helper
INFO - 2017-04-26 08:22:41 --> Helper loaded: form_helper
INFO - 2017-04-26 08:22:41 --> Helper loaded: html_helper
INFO - 2017-04-26 08:22:41 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:22:41 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:22:41 --> Database Driver Class Initialized
INFO - 2017-04-26 08:22:41 --> Parser Class Initialized
DEBUG - 2017-04-26 08:22:41 --> Session Class Initialized
INFO - 2017-04-26 08:22:41 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:22:41 --> Session routines successfully run
INFO - 2017-04-26 08:22:41 --> Form Validation Class Initialized
INFO - 2017-04-26 08:22:41 --> Controller Class Initialized
INFO - 2017-04-26 08:22:41 --> Model Class Initialized
INFO - 2017-04-26 08:22:41 --> Config Class Initialized
INFO - 2017-04-26 08:22:41 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:22:41 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:22:41 --> Utf8 Class Initialized
INFO - 2017-04-26 08:22:41 --> URI Class Initialized
INFO - 2017-04-26 08:22:41 --> Router Class Initialized
INFO - 2017-04-26 08:22:41 --> Output Class Initialized
INFO - 2017-04-26 08:22:41 --> Security Class Initialized
DEBUG - 2017-04-26 08:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:22:41 --> Input Class Initialized
INFO - 2017-04-26 08:22:41 --> Language Class Initialized
INFO - 2017-04-26 08:22:41 --> Loader Class Initialized
INFO - 2017-04-26 08:22:41 --> Helper loaded: url_helper
INFO - 2017-04-26 08:22:41 --> Helper loaded: form_helper
INFO - 2017-04-26 08:22:41 --> Helper loaded: html_helper
INFO - 2017-04-26 08:22:41 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:22:41 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:22:41 --> Database Driver Class Initialized
INFO - 2017-04-26 08:22:41 --> Parser Class Initialized
DEBUG - 2017-04-26 08:22:41 --> Session Class Initialized
INFO - 2017-04-26 08:22:41 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:22:41 --> Session routines successfully run
INFO - 2017-04-26 08:22:41 --> Form Validation Class Initialized
INFO - 2017-04-26 08:22:41 --> Controller Class Initialized
DEBUG - 2017-04-26 08:22:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:22:41 --> Model Class Initialized
DEBUG - 2017-04-26 08:22:41 --> Pagination Class Initialized
INFO - 2017-04-26 08:22:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:22:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:22:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-26 08:22:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:22:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:22:41 --> Final output sent to browser
DEBUG - 2017-04-26 08:22:41 --> Total execution time: 0.2090
INFO - 2017-04-26 08:22:42 --> Config Class Initialized
INFO - 2017-04-26 08:22:42 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:22:42 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:22:42 --> Utf8 Class Initialized
INFO - 2017-04-26 08:22:42 --> URI Class Initialized
DEBUG - 2017-04-26 08:22:42 --> No URI present. Default controller set.
INFO - 2017-04-26 08:22:42 --> Router Class Initialized
INFO - 2017-04-26 08:22:42 --> Output Class Initialized
INFO - 2017-04-26 08:22:42 --> Security Class Initialized
DEBUG - 2017-04-26 08:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:22:42 --> Input Class Initialized
INFO - 2017-04-26 08:22:42 --> Language Class Initialized
INFO - 2017-04-26 08:22:42 --> Loader Class Initialized
INFO - 2017-04-26 08:22:42 --> Helper loaded: url_helper
INFO - 2017-04-26 08:22:42 --> Helper loaded: form_helper
INFO - 2017-04-26 08:22:42 --> Helper loaded: html_helper
INFO - 2017-04-26 08:22:42 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:22:42 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:22:42 --> Database Driver Class Initialized
INFO - 2017-04-26 08:22:42 --> Parser Class Initialized
DEBUG - 2017-04-26 08:22:42 --> Session Class Initialized
INFO - 2017-04-26 08:22:42 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:22:42 --> Session routines successfully run
INFO - 2017-04-26 08:22:42 --> Form Validation Class Initialized
INFO - 2017-04-26 08:22:42 --> Controller Class Initialized
INFO - 2017-04-26 08:22:42 --> Model Class Initialized
INFO - 2017-04-26 08:22:42 --> Config Class Initialized
INFO - 2017-04-26 08:22:42 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:22:42 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:22:42 --> Utf8 Class Initialized
INFO - 2017-04-26 08:22:42 --> URI Class Initialized
INFO - 2017-04-26 08:22:42 --> Router Class Initialized
INFO - 2017-04-26 08:22:42 --> Output Class Initialized
INFO - 2017-04-26 08:22:42 --> Security Class Initialized
DEBUG - 2017-04-26 08:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:22:42 --> Input Class Initialized
INFO - 2017-04-26 08:22:42 --> Language Class Initialized
INFO - 2017-04-26 08:22:42 --> Loader Class Initialized
INFO - 2017-04-26 08:22:42 --> Helper loaded: url_helper
INFO - 2017-04-26 08:22:42 --> Helper loaded: form_helper
INFO - 2017-04-26 08:22:42 --> Helper loaded: html_helper
INFO - 2017-04-26 08:22:42 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:22:42 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:22:42 --> Database Driver Class Initialized
INFO - 2017-04-26 08:22:43 --> Parser Class Initialized
DEBUG - 2017-04-26 08:22:43 --> Session Class Initialized
INFO - 2017-04-26 08:22:43 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:22:43 --> Session routines successfully run
INFO - 2017-04-26 08:22:43 --> Form Validation Class Initialized
INFO - 2017-04-26 08:22:43 --> Controller Class Initialized
DEBUG - 2017-04-26 08:22:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:22:43 --> Model Class Initialized
DEBUG - 2017-04-26 08:22:43 --> Pagination Class Initialized
INFO - 2017-04-26 08:22:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:22:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:22:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-26 08:22:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:22:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:22:43 --> Final output sent to browser
DEBUG - 2017-04-26 08:22:43 --> Total execution time: 0.2145
INFO - 2017-04-26 08:23:07 --> Config Class Initialized
INFO - 2017-04-26 08:23:07 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:23:07 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:23:07 --> Utf8 Class Initialized
INFO - 2017-04-26 08:23:07 --> URI Class Initialized
INFO - 2017-04-26 08:23:07 --> Router Class Initialized
INFO - 2017-04-26 08:23:07 --> Output Class Initialized
INFO - 2017-04-26 08:23:07 --> Security Class Initialized
DEBUG - 2017-04-26 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:23:07 --> Input Class Initialized
INFO - 2017-04-26 08:23:07 --> Language Class Initialized
INFO - 2017-04-26 08:23:07 --> Loader Class Initialized
INFO - 2017-04-26 08:23:07 --> Helper loaded: url_helper
INFO - 2017-04-26 08:23:07 --> Helper loaded: form_helper
INFO - 2017-04-26 08:23:07 --> Helper loaded: html_helper
INFO - 2017-04-26 08:23:07 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:23:07 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:23:07 --> Database Driver Class Initialized
INFO - 2017-04-26 08:23:07 --> Parser Class Initialized
DEBUG - 2017-04-26 08:23:07 --> Session Class Initialized
INFO - 2017-04-26 08:23:07 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:23:07 --> Session routines successfully run
INFO - 2017-04-26 08:23:07 --> Form Validation Class Initialized
INFO - 2017-04-26 08:23:07 --> Controller Class Initialized
DEBUG - 2017-04-26 08:23:07 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:23:07 --> Model Class Initialized
DEBUG - 2017-04-26 08:23:07 --> Pagination Class Initialized
INFO - 2017-04-26 08:23:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:23:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:23:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-26 08:23:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:23:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:23:07 --> Final output sent to browser
DEBUG - 2017-04-26 08:23:07 --> Total execution time: 0.2569
INFO - 2017-04-26 08:23:08 --> Config Class Initialized
INFO - 2017-04-26 08:23:08 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:23:08 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:23:08 --> Utf8 Class Initialized
INFO - 2017-04-26 08:23:08 --> URI Class Initialized
INFO - 2017-04-26 08:23:08 --> Router Class Initialized
INFO - 2017-04-26 08:23:08 --> Output Class Initialized
INFO - 2017-04-26 08:23:08 --> Security Class Initialized
DEBUG - 2017-04-26 08:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:23:08 --> Input Class Initialized
INFO - 2017-04-26 08:23:09 --> Language Class Initialized
INFO - 2017-04-26 08:23:09 --> Loader Class Initialized
INFO - 2017-04-26 08:23:09 --> Helper loaded: url_helper
INFO - 2017-04-26 08:23:09 --> Helper loaded: form_helper
INFO - 2017-04-26 08:23:09 --> Helper loaded: html_helper
INFO - 2017-04-26 08:23:09 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:23:09 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:23:09 --> Database Driver Class Initialized
INFO - 2017-04-26 08:23:09 --> Parser Class Initialized
DEBUG - 2017-04-26 08:23:09 --> Session Class Initialized
INFO - 2017-04-26 08:23:09 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:23:09 --> Session routines successfully run
INFO - 2017-04-26 08:23:09 --> Form Validation Class Initialized
INFO - 2017-04-26 08:23:09 --> Controller Class Initialized
DEBUG - 2017-04-26 08:23:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:23:09 --> Model Class Initialized
DEBUG - 2017-04-26 08:23:09 --> Pagination Class Initialized
ERROR - 2017-04-26 08:23:09 --> Severity: Notice --> Undefined variable: limit C:\xampp\htdocs\schedullo\application\admin\controllers\Company.php 1206
ERROR - 2017-04-26 08:23:09 --> Severity: Notice --> Undefined variable: limit C:\xampp\htdocs\schedullo\application\admin\controllers\Company.php 1209
ERROR - 2017-04-26 08:23:09 --> Severity: Notice --> Undefined variable: offset C:\xampp\htdocs\schedullo\application\admin\controllers\Company.php 1213
ERROR - 2017-04-26 08:23:09 --> Severity: Notice --> Undefined variable: limit C:\xampp\htdocs\schedullo\application\admin\controllers\Company.php 1213
ERROR - 2017-04-26 08:23:09 --> Severity: Notice --> Undefined variable: msg C:\xampp\htdocs\schedullo\application\admin\controllers\Company.php 1214
ERROR - 2017-04-26 08:23:09 --> Severity: Notice --> Undefined variable: offset C:\xampp\htdocs\schedullo\application\admin\controllers\Company.php 1216
ERROR - 2017-04-26 08:23:09 --> Severity: Notice --> Undefined variable: limit C:\xampp\htdocs\schedullo\application\admin\controllers\Company.php 1224
INFO - 2017-04-26 08:23:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:23:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:23:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:23:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:23:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:23:14 --> Final output sent to browser
DEBUG - 2017-04-26 08:23:14 --> Total execution time: 5.6963
INFO - 2017-04-26 08:23:54 --> Config Class Initialized
INFO - 2017-04-26 08:23:54 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:23:54 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:23:54 --> Utf8 Class Initialized
INFO - 2017-04-26 08:23:54 --> URI Class Initialized
INFO - 2017-04-26 08:23:54 --> Router Class Initialized
INFO - 2017-04-26 08:23:54 --> Output Class Initialized
INFO - 2017-04-26 08:23:54 --> Security Class Initialized
DEBUG - 2017-04-26 08:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:23:54 --> Input Class Initialized
INFO - 2017-04-26 08:23:54 --> Language Class Initialized
INFO - 2017-04-26 08:23:54 --> Loader Class Initialized
INFO - 2017-04-26 08:23:54 --> Helper loaded: url_helper
INFO - 2017-04-26 08:23:54 --> Helper loaded: form_helper
INFO - 2017-04-26 08:23:54 --> Helper loaded: html_helper
INFO - 2017-04-26 08:23:54 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:23:54 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:23:54 --> Database Driver Class Initialized
INFO - 2017-04-26 08:23:54 --> Parser Class Initialized
DEBUG - 2017-04-26 08:23:54 --> Session Class Initialized
INFO - 2017-04-26 08:23:54 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:23:54 --> Session routines successfully run
INFO - 2017-04-26 08:23:54 --> Form Validation Class Initialized
INFO - 2017-04-26 08:23:54 --> Controller Class Initialized
DEBUG - 2017-04-26 08:23:54 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:23:55 --> Model Class Initialized
DEBUG - 2017-04-26 08:23:55 --> Pagination Class Initialized
INFO - 2017-04-26 08:23:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:23:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:23:57 --> Config Class Initialized
INFO - 2017-04-26 08:23:57 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:23:57 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:23:57 --> Utf8 Class Initialized
INFO - 2017-04-26 08:23:57 --> URI Class Initialized
DEBUG - 2017-04-26 08:23:57 --> No URI present. Default controller set.
INFO - 2017-04-26 08:23:57 --> Router Class Initialized
INFO - 2017-04-26 08:23:57 --> Output Class Initialized
INFO - 2017-04-26 08:23:57 --> Security Class Initialized
DEBUG - 2017-04-26 08:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:23:57 --> Input Class Initialized
INFO - 2017-04-26 08:23:57 --> Language Class Initialized
INFO - 2017-04-26 08:23:57 --> Loader Class Initialized
INFO - 2017-04-26 08:23:57 --> Helper loaded: url_helper
INFO - 2017-04-26 08:23:57 --> Helper loaded: form_helper
INFO - 2017-04-26 08:23:57 --> Helper loaded: html_helper
INFO - 2017-04-26 08:23:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:23:57 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:23:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:23:57 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:23:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:23:58 --> Database Driver Class Initialized
INFO - 2017-04-26 08:23:58 --> Final output sent to browser
DEBUG - 2017-04-26 08:23:58 --> Total execution time: 3.4966
INFO - 2017-04-26 08:23:58 --> Parser Class Initialized
DEBUG - 2017-04-26 08:23:58 --> Session Class Initialized
INFO - 2017-04-26 08:23:58 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:23:58 --> Session routines successfully run
INFO - 2017-04-26 08:23:58 --> Form Validation Class Initialized
INFO - 2017-04-26 08:23:58 --> Controller Class Initialized
INFO - 2017-04-26 08:23:58 --> Model Class Initialized
INFO - 2017-04-26 08:23:58 --> Config Class Initialized
INFO - 2017-04-26 08:23:58 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:23:58 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:23:58 --> Utf8 Class Initialized
INFO - 2017-04-26 08:23:58 --> URI Class Initialized
INFO - 2017-04-26 08:23:58 --> Router Class Initialized
INFO - 2017-04-26 08:23:58 --> Output Class Initialized
INFO - 2017-04-26 08:23:58 --> Security Class Initialized
DEBUG - 2017-04-26 08:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:23:58 --> Input Class Initialized
INFO - 2017-04-26 08:23:58 --> Language Class Initialized
INFO - 2017-04-26 08:23:58 --> Loader Class Initialized
INFO - 2017-04-26 08:23:58 --> Helper loaded: url_helper
INFO - 2017-04-26 08:23:58 --> Helper loaded: form_helper
INFO - 2017-04-26 08:23:58 --> Helper loaded: html_helper
INFO - 2017-04-26 08:23:58 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:23:58 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:23:58 --> Database Driver Class Initialized
INFO - 2017-04-26 08:23:58 --> Parser Class Initialized
DEBUG - 2017-04-26 08:23:58 --> Session Class Initialized
INFO - 2017-04-26 08:23:58 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:23:58 --> Session routines successfully run
INFO - 2017-04-26 08:23:58 --> Form Validation Class Initialized
INFO - 2017-04-26 08:23:58 --> Controller Class Initialized
DEBUG - 2017-04-26 08:23:58 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:23:58 --> Model Class Initialized
DEBUG - 2017-04-26 08:23:58 --> Pagination Class Initialized
INFO - 2017-04-26 08:23:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:23:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:23:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-26 08:23:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:23:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:23:58 --> Final output sent to browser
DEBUG - 2017-04-26 08:23:58 --> Total execution time: 0.2835
INFO - 2017-04-26 08:24:00 --> Config Class Initialized
INFO - 2017-04-26 08:24:00 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:24:00 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:24:00 --> Utf8 Class Initialized
INFO - 2017-04-26 08:24:00 --> URI Class Initialized
INFO - 2017-04-26 08:24:00 --> Router Class Initialized
INFO - 2017-04-26 08:24:00 --> Output Class Initialized
INFO - 2017-04-26 08:24:00 --> Security Class Initialized
DEBUG - 2017-04-26 08:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:24:00 --> Input Class Initialized
INFO - 2017-04-26 08:24:00 --> Language Class Initialized
INFO - 2017-04-26 08:24:00 --> Loader Class Initialized
INFO - 2017-04-26 08:24:00 --> Helper loaded: url_helper
INFO - 2017-04-26 08:24:00 --> Helper loaded: form_helper
INFO - 2017-04-26 08:24:00 --> Helper loaded: html_helper
INFO - 2017-04-26 08:24:00 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:24:00 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:24:00 --> Database Driver Class Initialized
INFO - 2017-04-26 08:24:00 --> Parser Class Initialized
DEBUG - 2017-04-26 08:24:00 --> Session Class Initialized
INFO - 2017-04-26 08:24:00 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:24:00 --> Session routines successfully run
INFO - 2017-04-26 08:24:00 --> Form Validation Class Initialized
INFO - 2017-04-26 08:24:00 --> Controller Class Initialized
DEBUG - 2017-04-26 08:24:00 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:24:00 --> Model Class Initialized
DEBUG - 2017-04-26 08:24:00 --> Pagination Class Initialized
INFO - 2017-04-26 08:24:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:24:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:24:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-26 08:24:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:24:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:24:00 --> Final output sent to browser
DEBUG - 2017-04-26 08:24:00 --> Total execution time: 0.2950
INFO - 2017-04-26 08:24:02 --> Config Class Initialized
INFO - 2017-04-26 08:24:02 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:24:02 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:24:03 --> Utf8 Class Initialized
INFO - 2017-04-26 08:24:03 --> URI Class Initialized
INFO - 2017-04-26 08:24:03 --> Router Class Initialized
INFO - 2017-04-26 08:24:03 --> Output Class Initialized
INFO - 2017-04-26 08:24:03 --> Security Class Initialized
DEBUG - 2017-04-26 08:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:24:03 --> Input Class Initialized
INFO - 2017-04-26 08:24:03 --> Language Class Initialized
INFO - 2017-04-26 08:24:03 --> Loader Class Initialized
INFO - 2017-04-26 08:24:03 --> Helper loaded: url_helper
INFO - 2017-04-26 08:24:03 --> Helper loaded: form_helper
INFO - 2017-04-26 08:24:03 --> Helper loaded: html_helper
INFO - 2017-04-26 08:24:03 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:24:03 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:24:03 --> Database Driver Class Initialized
INFO - 2017-04-26 08:24:03 --> Parser Class Initialized
DEBUG - 2017-04-26 08:24:03 --> Session Class Initialized
INFO - 2017-04-26 08:24:03 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:24:03 --> Session routines successfully run
INFO - 2017-04-26 08:24:03 --> Form Validation Class Initialized
INFO - 2017-04-26 08:24:03 --> Controller Class Initialized
DEBUG - 2017-04-26 08:24:03 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:24:03 --> Model Class Initialized
DEBUG - 2017-04-26 08:24:03 --> Pagination Class Initialized
INFO - 2017-04-26 08:24:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:24:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:24:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:24:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:24:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:24:06 --> Final output sent to browser
DEBUG - 2017-04-26 08:24:06 --> Total execution time: 3.5590
INFO - 2017-04-26 08:26:20 --> Config Class Initialized
INFO - 2017-04-26 08:26:20 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:26:20 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:26:20 --> Utf8 Class Initialized
INFO - 2017-04-26 08:26:20 --> URI Class Initialized
INFO - 2017-04-26 08:26:20 --> Router Class Initialized
INFO - 2017-04-26 08:26:20 --> Output Class Initialized
INFO - 2017-04-26 08:26:20 --> Security Class Initialized
DEBUG - 2017-04-26 08:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:26:20 --> Input Class Initialized
INFO - 2017-04-26 08:26:20 --> Language Class Initialized
INFO - 2017-04-26 08:26:20 --> Loader Class Initialized
INFO - 2017-04-26 08:26:20 --> Helper loaded: url_helper
INFO - 2017-04-26 08:26:20 --> Helper loaded: form_helper
INFO - 2017-04-26 08:26:20 --> Helper loaded: html_helper
INFO - 2017-04-26 08:26:20 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:26:20 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:26:20 --> Database Driver Class Initialized
INFO - 2017-04-26 08:26:20 --> Parser Class Initialized
DEBUG - 2017-04-26 08:26:20 --> Session Class Initialized
INFO - 2017-04-26 08:26:20 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:26:20 --> Session routines successfully run
INFO - 2017-04-26 08:26:20 --> Form Validation Class Initialized
INFO - 2017-04-26 08:26:20 --> Controller Class Initialized
DEBUG - 2017-04-26 08:26:20 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:26:20 --> Model Class Initialized
DEBUG - 2017-04-26 08:26:20 --> Pagination Class Initialized
INFO - 2017-04-26 08:26:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:26:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 4
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 90
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 101
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 131
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: company_email C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 138
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: company_address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 146
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: company_phoneno C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 156
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 174
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 174
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 174
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 181
ERROR - 2017-04-26 08:26:20 --> Severity: Notice --> Undefined variable: chargify_subscriptions_ID C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 186
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:21 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 251
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_timezone C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 313
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 320
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 323
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 324
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 325
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 326
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 327
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 328
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 329
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: prev_profile_image C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 346
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: prev_profile_image C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 353
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: first_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 374
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 381
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 388
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 401
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 402
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 407
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 444
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: user_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 445
ERROR - 2017-04-26 08:26:22 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 446
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 447
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 449
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 451
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 453
INFO - 2017-04-26 08:26:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:26:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:26:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:26:23 --> Final output sent to browser
DEBUG - 2017-04-26 08:26:23 --> Total execution time: 2.7393
INFO - 2017-04-26 08:26:23 --> Config Class Initialized
INFO - 2017-04-26 08:26:23 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:26:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:26:23 --> Config Class Initialized
INFO - 2017-04-26 08:26:23 --> Utf8 Class Initialized
INFO - 2017-04-26 08:26:23 --> Hooks Class Initialized
INFO - 2017-04-26 08:26:23 --> URI Class Initialized
DEBUG - 2017-04-26 08:26:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:26:23 --> Router Class Initialized
INFO - 2017-04-26 08:26:23 --> Utf8 Class Initialized
INFO - 2017-04-26 08:26:23 --> URI Class Initialized
INFO - 2017-04-26 08:26:23 --> Output Class Initialized
INFO - 2017-04-26 08:26:23 --> Router Class Initialized
INFO - 2017-04-26 08:26:23 --> Security Class Initialized
INFO - 2017-04-26 08:26:23 --> Output Class Initialized
DEBUG - 2017-04-26 08:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:26:23 --> Security Class Initialized
INFO - 2017-04-26 08:26:23 --> Input Class Initialized
INFO - 2017-04-26 08:26:23 --> Language Class Initialized
DEBUG - 2017-04-26 08:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-04-26 08:26:23 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:26:23 --> Input Class Initialized
INFO - 2017-04-26 08:26:23 --> Language Class Initialized
ERROR - 2017-04-26 08:26:23 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:26:23 --> Config Class Initialized
INFO - 2017-04-26 08:26:23 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:26:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:26:23 --> Utf8 Class Initialized
INFO - 2017-04-26 08:26:23 --> URI Class Initialized
INFO - 2017-04-26 08:26:23 --> Router Class Initialized
INFO - 2017-04-26 08:26:23 --> Output Class Initialized
INFO - 2017-04-26 08:26:23 --> Security Class Initialized
DEBUG - 2017-04-26 08:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:26:23 --> Input Class Initialized
INFO - 2017-04-26 08:26:23 --> Language Class Initialized
INFO - 2017-04-26 08:26:23 --> Loader Class Initialized
INFO - 2017-04-26 08:26:23 --> Helper loaded: url_helper
INFO - 2017-04-26 08:26:23 --> Helper loaded: form_helper
INFO - 2017-04-26 08:26:23 --> Helper loaded: html_helper
INFO - 2017-04-26 08:26:23 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:26:23 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:26:23 --> Database Driver Class Initialized
INFO - 2017-04-26 08:26:23 --> Parser Class Initialized
DEBUG - 2017-04-26 08:26:23 --> Session Class Initialized
INFO - 2017-04-26 08:26:23 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:26:23 --> Session routines successfully run
INFO - 2017-04-26 08:26:23 --> Form Validation Class Initialized
INFO - 2017-04-26 08:26:23 --> Controller Class Initialized
DEBUG - 2017-04-26 08:26:23 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:26:23 --> Model Class Initialized
DEBUG - 2017-04-26 08:26:23 --> Pagination Class Initialized
INFO - 2017-04-26 08:26:23 --> Config Class Initialized
INFO - 2017-04-26 08:26:23 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:26:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:26:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:26:23 --> Utf8 Class Initialized
INFO - 2017-04-26 08:26:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:26:23 --> URI Class Initialized
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 4
INFO - 2017-04-26 08:26:23 --> Router Class Initialized
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 90
INFO - 2017-04-26 08:26:23 --> Output Class Initialized
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 101
INFO - 2017-04-26 08:26:23 --> Security Class Initialized
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 131
DEBUG - 2017-04-26 08:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: company_email C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 138
INFO - 2017-04-26 08:26:23 --> Input Class Initialized
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: company_address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 146
INFO - 2017-04-26 08:26:23 --> Language Class Initialized
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: company_phoneno C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 156
ERROR - 2017-04-26 08:26:23 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 174
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 174
INFO - 2017-04-26 08:26:23 --> Config Class Initialized
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 174
INFO - 2017-04-26 08:26:23 --> Hooks Class Initialized
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 181
DEBUG - 2017-04-26 08:26:23 --> UTF-8 Support Enabled
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: chargify_subscriptions_ID C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 186
INFO - 2017-04-26 08:26:23 --> Utf8 Class Initialized
INFO - 2017-04-26 08:26:23 --> URI Class Initialized
ERROR - 2017-04-26 08:26:23 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
INFO - 2017-04-26 08:26:23 --> Router Class Initialized
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
INFO - 2017-04-26 08:26:24 --> Output Class Initialized
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
INFO - 2017-04-26 08:26:24 --> Security Class Initialized
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
DEBUG - 2017-04-26 08:26:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
INFO - 2017-04-26 08:26:24 --> Input Class Initialized
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
INFO - 2017-04-26 08:26:24 --> Language Class Initialized
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:24 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: plan_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 231
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 251
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: company_timezone C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 313
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 320
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 323
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 324
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 325
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 326
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 327
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 328
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: company_date_format C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 329
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: prev_profile_image C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 346
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: prev_profile_image C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 353
ERROR - 2017-04-26 08:26:25 --> Severity: Notice --> Undefined variable: first_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 374
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 381
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 388
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 401
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 402
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 407
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 444
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: user_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 445
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 446
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 447
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 449
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 451
ERROR - 2017-04-26 08:26:26 --> Severity: Notice --> Undefined variable: company_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 453
INFO - 2017-04-26 08:26:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:26:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:26:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:26:26 --> Final output sent to browser
DEBUG - 2017-04-26 08:26:26 --> Total execution time: 2.5745
INFO - 2017-04-26 08:26:26 --> Config Class Initialized
INFO - 2017-04-26 08:26:26 --> Config Class Initialized
INFO - 2017-04-26 08:26:26 --> Hooks Class Initialized
INFO - 2017-04-26 08:26:26 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:26:26 --> UTF-8 Support Enabled
DEBUG - 2017-04-26 08:26:26 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:26:26 --> Utf8 Class Initialized
INFO - 2017-04-26 08:26:26 --> Utf8 Class Initialized
INFO - 2017-04-26 08:26:26 --> URI Class Initialized
INFO - 2017-04-26 08:26:26 --> URI Class Initialized
INFO - 2017-04-26 08:26:26 --> Router Class Initialized
INFO - 2017-04-26 08:26:26 --> Router Class Initialized
INFO - 2017-04-26 08:26:26 --> Output Class Initialized
INFO - 2017-04-26 08:26:26 --> Output Class Initialized
INFO - 2017-04-26 08:26:26 --> Security Class Initialized
INFO - 2017-04-26 08:26:26 --> Security Class Initialized
DEBUG - 2017-04-26 08:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-26 08:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:26:26 --> Input Class Initialized
INFO - 2017-04-26 08:26:26 --> Input Class Initialized
INFO - 2017-04-26 08:26:26 --> Language Class Initialized
INFO - 2017-04-26 08:26:26 --> Language Class Initialized
ERROR - 2017-04-26 08:26:26 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-26 08:26:26 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:30:25 --> Config Class Initialized
INFO - 2017-04-26 08:30:25 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:30:25 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:30:25 --> Utf8 Class Initialized
INFO - 2017-04-26 08:30:25 --> URI Class Initialized
INFO - 2017-04-26 08:30:25 --> Router Class Initialized
INFO - 2017-04-26 08:30:25 --> Output Class Initialized
INFO - 2017-04-26 08:30:25 --> Security Class Initialized
DEBUG - 2017-04-26 08:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:30:25 --> Input Class Initialized
INFO - 2017-04-26 08:30:25 --> Language Class Initialized
INFO - 2017-04-26 08:30:25 --> Loader Class Initialized
INFO - 2017-04-26 08:30:25 --> Helper loaded: url_helper
INFO - 2017-04-26 08:30:25 --> Helper loaded: form_helper
INFO - 2017-04-26 08:30:25 --> Helper loaded: html_helper
INFO - 2017-04-26 08:30:25 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:30:25 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:30:25 --> Database Driver Class Initialized
INFO - 2017-04-26 08:30:25 --> Parser Class Initialized
DEBUG - 2017-04-26 08:30:25 --> Session Class Initialized
INFO - 2017-04-26 08:30:25 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:30:25 --> Session routines successfully run
INFO - 2017-04-26 08:30:25 --> Form Validation Class Initialized
INFO - 2017-04-26 08:30:25 --> Controller Class Initialized
DEBUG - 2017-04-26 08:30:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:30:25 --> Model Class Initialized
DEBUG - 2017-04-26 08:30:25 --> Pagination Class Initialized
INFO - 2017-04-26 08:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: search_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 23
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: search_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 25
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 59
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 60
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 61
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 69
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 69
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 113
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:25 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:26 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:27 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:27 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:27 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:27 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:28 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:28 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:28 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:28 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:28 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:28 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:28 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:29 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:29 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 172
ERROR - 2017-04-26 08:30:29 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
ERROR - 2017-04-26 08:30:29 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 176
INFO - 2017-04-26 08:30:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:30:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:30:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:30:29 --> Final output sent to browser
DEBUG - 2017-04-26 08:30:29 --> Total execution time: 4.0880
INFO - 2017-04-26 08:38:54 --> Config Class Initialized
INFO - 2017-04-26 08:38:54 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:38:54 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:38:54 --> Utf8 Class Initialized
INFO - 2017-04-26 08:38:54 --> URI Class Initialized
INFO - 2017-04-26 08:38:54 --> Router Class Initialized
INFO - 2017-04-26 08:38:54 --> Output Class Initialized
INFO - 2017-04-26 08:38:54 --> Security Class Initialized
DEBUG - 2017-04-26 08:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:38:54 --> Input Class Initialized
INFO - 2017-04-26 08:38:54 --> Language Class Initialized
INFO - 2017-04-26 08:38:54 --> Loader Class Initialized
INFO - 2017-04-26 08:38:54 --> Helper loaded: url_helper
INFO - 2017-04-26 08:38:54 --> Helper loaded: form_helper
INFO - 2017-04-26 08:38:54 --> Helper loaded: html_helper
INFO - 2017-04-26 08:38:54 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:38:54 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:38:54 --> Database Driver Class Initialized
INFO - 2017-04-26 08:38:54 --> Parser Class Initialized
DEBUG - 2017-04-26 08:38:54 --> Session Class Initialized
INFO - 2017-04-26 08:38:54 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:38:54 --> Session routines successfully run
INFO - 2017-04-26 08:38:54 --> Form Validation Class Initialized
INFO - 2017-04-26 08:38:54 --> Controller Class Initialized
DEBUG - 2017-04-26 08:38:54 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:38:54 --> Model Class Initialized
DEBUG - 2017-04-26 08:38:54 --> Pagination Class Initialized
INFO - 2017-04-26 08:38:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:38:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:38:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:38:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:38:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:38:57 --> Final output sent to browser
DEBUG - 2017-04-26 08:38:57 --> Total execution time: 3.1941
INFO - 2017-04-26 08:39:19 --> Config Class Initialized
INFO - 2017-04-26 08:39:19 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:39:19 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:39:19 --> Utf8 Class Initialized
INFO - 2017-04-26 08:39:19 --> URI Class Initialized
INFO - 2017-04-26 08:39:19 --> Router Class Initialized
INFO - 2017-04-26 08:39:19 --> Output Class Initialized
INFO - 2017-04-26 08:39:19 --> Security Class Initialized
DEBUG - 2017-04-26 08:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:39:20 --> Input Class Initialized
INFO - 2017-04-26 08:39:20 --> Language Class Initialized
INFO - 2017-04-26 08:39:20 --> Loader Class Initialized
INFO - 2017-04-26 08:39:20 --> Helper loaded: url_helper
INFO - 2017-04-26 08:39:20 --> Helper loaded: form_helper
INFO - 2017-04-26 08:39:20 --> Helper loaded: html_helper
INFO - 2017-04-26 08:39:20 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:39:20 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:39:20 --> Database Driver Class Initialized
INFO - 2017-04-26 08:39:20 --> Parser Class Initialized
DEBUG - 2017-04-26 08:39:20 --> Session Class Initialized
INFO - 2017-04-26 08:39:20 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:39:20 --> Session routines successfully run
INFO - 2017-04-26 08:39:20 --> Form Validation Class Initialized
INFO - 2017-04-26 08:39:20 --> Controller Class Initialized
DEBUG - 2017-04-26 08:39:20 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:39:20 --> Model Class Initialized
DEBUG - 2017-04-26 08:39:20 --> Pagination Class Initialized
INFO - 2017-04-26 08:39:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:39:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:39:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:39:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:39:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:39:22 --> Final output sent to browser
DEBUG - 2017-04-26 08:39:22 --> Total execution time: 3.0649
INFO - 2017-04-26 08:40:32 --> Config Class Initialized
INFO - 2017-04-26 08:40:32 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:40:32 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:40:32 --> Utf8 Class Initialized
INFO - 2017-04-26 08:40:32 --> URI Class Initialized
INFO - 2017-04-26 08:40:32 --> Router Class Initialized
INFO - 2017-04-26 08:40:32 --> Output Class Initialized
INFO - 2017-04-26 08:40:32 --> Security Class Initialized
DEBUG - 2017-04-26 08:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:40:32 --> Input Class Initialized
INFO - 2017-04-26 08:40:32 --> Language Class Initialized
INFO - 2017-04-26 08:40:32 --> Loader Class Initialized
INFO - 2017-04-26 08:40:32 --> Helper loaded: url_helper
INFO - 2017-04-26 08:40:32 --> Helper loaded: form_helper
INFO - 2017-04-26 08:40:32 --> Helper loaded: html_helper
INFO - 2017-04-26 08:40:32 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:40:32 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:40:32 --> Database Driver Class Initialized
INFO - 2017-04-26 08:40:32 --> Parser Class Initialized
DEBUG - 2017-04-26 08:40:32 --> Session Class Initialized
INFO - 2017-04-26 08:40:32 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:40:32 --> Session routines successfully run
INFO - 2017-04-26 08:40:32 --> Form Validation Class Initialized
INFO - 2017-04-26 08:40:32 --> Controller Class Initialized
DEBUG - 2017-04-26 08:40:32 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:40:32 --> Model Class Initialized
DEBUG - 2017-04-26 08:40:32 --> Pagination Class Initialized
INFO - 2017-04-26 08:40:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:40:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:40:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:40:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:40:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:40:35 --> Final output sent to browser
DEBUG - 2017-04-26 08:40:35 --> Total execution time: 3.1409
INFO - 2017-04-26 08:41:27 --> Config Class Initialized
INFO - 2017-04-26 08:41:27 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:41:27 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:41:27 --> Utf8 Class Initialized
INFO - 2017-04-26 08:41:27 --> URI Class Initialized
INFO - 2017-04-26 08:41:27 --> Router Class Initialized
INFO - 2017-04-26 08:41:27 --> Output Class Initialized
INFO - 2017-04-26 08:41:27 --> Security Class Initialized
DEBUG - 2017-04-26 08:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:41:27 --> Input Class Initialized
INFO - 2017-04-26 08:41:27 --> Language Class Initialized
INFO - 2017-04-26 08:41:27 --> Loader Class Initialized
INFO - 2017-04-26 08:41:27 --> Helper loaded: url_helper
INFO - 2017-04-26 08:41:27 --> Helper loaded: form_helper
INFO - 2017-04-26 08:41:27 --> Helper loaded: html_helper
INFO - 2017-04-26 08:41:27 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:41:27 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:41:27 --> Database Driver Class Initialized
INFO - 2017-04-26 08:41:27 --> Parser Class Initialized
DEBUG - 2017-04-26 08:41:27 --> Session Class Initialized
INFO - 2017-04-26 08:41:27 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:41:27 --> Session routines successfully run
INFO - 2017-04-26 08:41:27 --> Form Validation Class Initialized
INFO - 2017-04-26 08:41:27 --> Controller Class Initialized
DEBUG - 2017-04-26 08:41:27 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:41:27 --> Model Class Initialized
DEBUG - 2017-04-26 08:41:27 --> Pagination Class Initialized
INFO - 2017-04-26 08:41:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:41:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:41:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:41:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:41:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:41:30 --> Final output sent to browser
DEBUG - 2017-04-26 08:41:30 --> Total execution time: 3.2136
INFO - 2017-04-26 08:41:50 --> Config Class Initialized
INFO - 2017-04-26 08:41:50 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:41:50 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:41:50 --> Utf8 Class Initialized
INFO - 2017-04-26 08:41:50 --> URI Class Initialized
INFO - 2017-04-26 08:41:50 --> Router Class Initialized
INFO - 2017-04-26 08:41:50 --> Output Class Initialized
INFO - 2017-04-26 08:41:50 --> Security Class Initialized
DEBUG - 2017-04-26 08:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:41:50 --> Input Class Initialized
INFO - 2017-04-26 08:41:50 --> Language Class Initialized
INFO - 2017-04-26 08:41:50 --> Loader Class Initialized
INFO - 2017-04-26 08:41:50 --> Helper loaded: url_helper
INFO - 2017-04-26 08:41:50 --> Helper loaded: form_helper
INFO - 2017-04-26 08:41:50 --> Helper loaded: html_helper
INFO - 2017-04-26 08:41:50 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:41:50 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:41:50 --> Database Driver Class Initialized
INFO - 2017-04-26 08:41:50 --> Parser Class Initialized
DEBUG - 2017-04-26 08:41:50 --> Session Class Initialized
INFO - 2017-04-26 08:41:50 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:41:50 --> Session routines successfully run
INFO - 2017-04-26 08:41:50 --> Form Validation Class Initialized
INFO - 2017-04-26 08:41:50 --> Controller Class Initialized
DEBUG - 2017-04-26 08:41:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:41:50 --> Model Class Initialized
DEBUG - 2017-04-26 08:41:50 --> Pagination Class Initialized
INFO - 2017-04-26 08:41:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:41:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:41:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:41:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:41:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:41:53 --> Final output sent to browser
DEBUG - 2017-04-26 08:41:53 --> Total execution time: 3.1251
INFO - 2017-04-26 08:42:39 --> Config Class Initialized
INFO - 2017-04-26 08:42:39 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:42:39 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:42:39 --> Utf8 Class Initialized
INFO - 2017-04-26 08:42:39 --> URI Class Initialized
INFO - 2017-04-26 08:42:39 --> Router Class Initialized
INFO - 2017-04-26 08:42:39 --> Output Class Initialized
INFO - 2017-04-26 08:42:39 --> Security Class Initialized
DEBUG - 2017-04-26 08:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:42:39 --> Input Class Initialized
INFO - 2017-04-26 08:42:39 --> Language Class Initialized
INFO - 2017-04-26 08:42:39 --> Loader Class Initialized
INFO - 2017-04-26 08:42:39 --> Helper loaded: url_helper
INFO - 2017-04-26 08:42:39 --> Helper loaded: form_helper
INFO - 2017-04-26 08:42:39 --> Helper loaded: html_helper
INFO - 2017-04-26 08:42:39 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:42:39 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:42:39 --> Database Driver Class Initialized
INFO - 2017-04-26 08:42:39 --> Parser Class Initialized
DEBUG - 2017-04-26 08:42:39 --> Session Class Initialized
INFO - 2017-04-26 08:42:39 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:42:39 --> Session routines successfully run
INFO - 2017-04-26 08:42:39 --> Form Validation Class Initialized
INFO - 2017-04-26 08:42:39 --> Controller Class Initialized
DEBUG - 2017-04-26 08:42:39 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:42:39 --> Model Class Initialized
DEBUG - 2017-04-26 08:42:39 --> Pagination Class Initialized
INFO - 2017-04-26 08:42:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:42:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:42:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:42:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:42:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:42:42 --> Final output sent to browser
DEBUG - 2017-04-26 08:42:42 --> Total execution time: 3.0645
INFO - 2017-04-26 08:42:55 --> Config Class Initialized
INFO - 2017-04-26 08:42:55 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:42:55 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:42:55 --> Utf8 Class Initialized
INFO - 2017-04-26 08:42:55 --> URI Class Initialized
INFO - 2017-04-26 08:42:55 --> Router Class Initialized
INFO - 2017-04-26 08:42:56 --> Output Class Initialized
INFO - 2017-04-26 08:42:56 --> Security Class Initialized
DEBUG - 2017-04-26 08:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:42:56 --> Input Class Initialized
INFO - 2017-04-26 08:42:56 --> Language Class Initialized
INFO - 2017-04-26 08:42:56 --> Loader Class Initialized
INFO - 2017-04-26 08:42:56 --> Helper loaded: url_helper
INFO - 2017-04-26 08:42:56 --> Helper loaded: form_helper
INFO - 2017-04-26 08:42:56 --> Helper loaded: html_helper
INFO - 2017-04-26 08:42:56 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:42:56 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:42:56 --> Database Driver Class Initialized
INFO - 2017-04-26 08:42:56 --> Parser Class Initialized
DEBUG - 2017-04-26 08:42:56 --> Session Class Initialized
INFO - 2017-04-26 08:42:56 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:42:56 --> Session routines successfully run
INFO - 2017-04-26 08:42:56 --> Form Validation Class Initialized
INFO - 2017-04-26 08:42:56 --> Controller Class Initialized
DEBUG - 2017-04-26 08:42:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:42:56 --> Model Class Initialized
DEBUG - 2017-04-26 08:42:56 --> Pagination Class Initialized
INFO - 2017-04-26 08:42:56 --> Config Class Initialized
INFO - 2017-04-26 08:42:56 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:42:56 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:42:56 --> Utf8 Class Initialized
INFO - 2017-04-26 08:42:56 --> URI Class Initialized
INFO - 2017-04-26 08:42:56 --> Router Class Initialized
INFO - 2017-04-26 08:42:56 --> Output Class Initialized
INFO - 2017-04-26 08:42:56 --> Security Class Initialized
DEBUG - 2017-04-26 08:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:42:56 --> Input Class Initialized
INFO - 2017-04-26 08:42:56 --> Language Class Initialized
INFO - 2017-04-26 08:42:56 --> Loader Class Initialized
INFO - 2017-04-26 08:42:56 --> Helper loaded: url_helper
INFO - 2017-04-26 08:42:56 --> Helper loaded: form_helper
INFO - 2017-04-26 08:42:56 --> Helper loaded: html_helper
INFO - 2017-04-26 08:42:56 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:42:56 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:42:56 --> Database Driver Class Initialized
INFO - 2017-04-26 08:42:56 --> Parser Class Initialized
DEBUG - 2017-04-26 08:42:56 --> Session Class Initialized
INFO - 2017-04-26 08:42:56 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:42:56 --> Session routines successfully run
INFO - 2017-04-26 08:42:56 --> Form Validation Class Initialized
INFO - 2017-04-26 08:42:56 --> Controller Class Initialized
DEBUG - 2017-04-26 08:42:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:42:56 --> Model Class Initialized
DEBUG - 2017-04-26 08:42:56 --> Pagination Class Initialized
INFO - 2017-04-26 08:42:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:42:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:42:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:42:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:42:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:42:59 --> Final output sent to browser
DEBUG - 2017-04-26 08:42:59 --> Total execution time: 3.0294
INFO - 2017-04-26 08:43:50 --> Config Class Initialized
INFO - 2017-04-26 08:43:50 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:43:50 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:43:50 --> Utf8 Class Initialized
INFO - 2017-04-26 08:43:50 --> URI Class Initialized
INFO - 2017-04-26 08:43:50 --> Router Class Initialized
INFO - 2017-04-26 08:43:50 --> Output Class Initialized
INFO - 2017-04-26 08:43:50 --> Security Class Initialized
DEBUG - 2017-04-26 08:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:43:50 --> Input Class Initialized
INFO - 2017-04-26 08:43:50 --> Language Class Initialized
INFO - 2017-04-26 08:43:50 --> Loader Class Initialized
INFO - 2017-04-26 08:43:50 --> Helper loaded: url_helper
INFO - 2017-04-26 08:43:50 --> Helper loaded: form_helper
INFO - 2017-04-26 08:43:50 --> Helper loaded: html_helper
INFO - 2017-04-26 08:43:50 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:43:50 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:43:50 --> Database Driver Class Initialized
INFO - 2017-04-26 08:43:51 --> Parser Class Initialized
DEBUG - 2017-04-26 08:43:51 --> Session Class Initialized
INFO - 2017-04-26 08:43:51 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:43:51 --> Session routines successfully run
INFO - 2017-04-26 08:43:51 --> Form Validation Class Initialized
INFO - 2017-04-26 08:43:51 --> Controller Class Initialized
DEBUG - 2017-04-26 08:43:51 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:43:51 --> Model Class Initialized
DEBUG - 2017-04-26 08:43:51 --> Pagination Class Initialized
INFO - 2017-04-26 08:43:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:43:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:43:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:43:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:43:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:43:54 --> Final output sent to browser
DEBUG - 2017-04-26 08:43:54 --> Total execution time: 3.5715
INFO - 2017-04-26 08:44:56 --> Config Class Initialized
INFO - 2017-04-26 08:44:56 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:44:56 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:44:56 --> Utf8 Class Initialized
INFO - 2017-04-26 08:44:56 --> URI Class Initialized
INFO - 2017-04-26 08:44:56 --> Router Class Initialized
INFO - 2017-04-26 08:44:56 --> Output Class Initialized
INFO - 2017-04-26 08:44:56 --> Security Class Initialized
DEBUG - 2017-04-26 08:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:44:56 --> Input Class Initialized
INFO - 2017-04-26 08:44:56 --> Language Class Initialized
INFO - 2017-04-26 08:44:56 --> Loader Class Initialized
INFO - 2017-04-26 08:44:56 --> Helper loaded: url_helper
INFO - 2017-04-26 08:44:56 --> Helper loaded: form_helper
INFO - 2017-04-26 08:44:56 --> Helper loaded: html_helper
INFO - 2017-04-26 08:44:56 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:44:56 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:44:56 --> Database Driver Class Initialized
INFO - 2017-04-26 08:44:56 --> Parser Class Initialized
DEBUG - 2017-04-26 08:44:56 --> Session Class Initialized
INFO - 2017-04-26 08:44:56 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:44:56 --> Session routines successfully run
INFO - 2017-04-26 08:44:56 --> Form Validation Class Initialized
INFO - 2017-04-26 08:44:56 --> Controller Class Initialized
DEBUG - 2017-04-26 08:44:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:44:56 --> Model Class Initialized
DEBUG - 2017-04-26 08:44:56 --> Pagination Class Initialized
INFO - 2017-04-26 08:44:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:44:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:44:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:44:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:44:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:44:59 --> Final output sent to browser
DEBUG - 2017-04-26 08:44:59 --> Total execution time: 3.0523
INFO - 2017-04-26 08:45:24 --> Config Class Initialized
INFO - 2017-04-26 08:45:24 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:45:24 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:45:24 --> Utf8 Class Initialized
INFO - 2017-04-26 08:45:24 --> URI Class Initialized
INFO - 2017-04-26 08:45:24 --> Router Class Initialized
INFO - 2017-04-26 08:45:24 --> Output Class Initialized
INFO - 2017-04-26 08:45:24 --> Security Class Initialized
DEBUG - 2017-04-26 08:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:45:24 --> Input Class Initialized
INFO - 2017-04-26 08:45:24 --> Language Class Initialized
INFO - 2017-04-26 08:45:24 --> Loader Class Initialized
INFO - 2017-04-26 08:45:24 --> Helper loaded: url_helper
INFO - 2017-04-26 08:45:24 --> Helper loaded: form_helper
INFO - 2017-04-26 08:45:24 --> Helper loaded: html_helper
INFO - 2017-04-26 08:45:24 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:45:24 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:45:24 --> Database Driver Class Initialized
INFO - 2017-04-26 08:45:24 --> Parser Class Initialized
DEBUG - 2017-04-26 08:45:24 --> Session Class Initialized
INFO - 2017-04-26 08:45:24 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:45:24 --> Session routines successfully run
INFO - 2017-04-26 08:45:24 --> Form Validation Class Initialized
INFO - 2017-04-26 08:45:24 --> Controller Class Initialized
DEBUG - 2017-04-26 08:45:24 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:45:24 --> Model Class Initialized
DEBUG - 2017-04-26 08:45:24 --> Pagination Class Initialized
INFO - 2017-04-26 08:45:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:45:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:45:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:45:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:45:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:45:27 --> Final output sent to browser
DEBUG - 2017-04-26 08:45:27 --> Total execution time: 3.1081
INFO - 2017-04-26 08:46:03 --> Config Class Initialized
INFO - 2017-04-26 08:46:03 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:46:03 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:46:03 --> Utf8 Class Initialized
INFO - 2017-04-26 08:46:03 --> URI Class Initialized
INFO - 2017-04-26 08:46:03 --> Router Class Initialized
INFO - 2017-04-26 08:46:03 --> Output Class Initialized
INFO - 2017-04-26 08:46:03 --> Security Class Initialized
DEBUG - 2017-04-26 08:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:46:03 --> Input Class Initialized
INFO - 2017-04-26 08:46:03 --> Language Class Initialized
INFO - 2017-04-26 08:46:03 --> Loader Class Initialized
INFO - 2017-04-26 08:46:03 --> Helper loaded: url_helper
INFO - 2017-04-26 08:46:03 --> Helper loaded: form_helper
INFO - 2017-04-26 08:46:03 --> Helper loaded: html_helper
INFO - 2017-04-26 08:46:03 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:46:03 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:46:03 --> Database Driver Class Initialized
INFO - 2017-04-26 08:46:03 --> Parser Class Initialized
DEBUG - 2017-04-26 08:46:03 --> Session Class Initialized
INFO - 2017-04-26 08:46:03 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:46:03 --> Session routines successfully run
INFO - 2017-04-26 08:46:03 --> Form Validation Class Initialized
INFO - 2017-04-26 08:46:03 --> Controller Class Initialized
DEBUG - 2017-04-26 08:46:03 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:46:03 --> Model Class Initialized
DEBUG - 2017-04-26 08:46:03 --> Pagination Class Initialized
INFO - 2017-04-26 08:46:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:46:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:46:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:46:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:46:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:46:12 --> Final output sent to browser
DEBUG - 2017-04-26 08:46:12 --> Total execution time: 9.3428
INFO - 2017-04-26 08:46:31 --> Config Class Initialized
INFO - 2017-04-26 08:46:31 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:46:31 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:46:31 --> Utf8 Class Initialized
INFO - 2017-04-26 08:46:31 --> URI Class Initialized
INFO - 2017-04-26 08:46:31 --> Router Class Initialized
INFO - 2017-04-26 08:46:31 --> Output Class Initialized
INFO - 2017-04-26 08:46:31 --> Security Class Initialized
DEBUG - 2017-04-26 08:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:46:31 --> Input Class Initialized
INFO - 2017-04-26 08:46:31 --> Language Class Initialized
INFO - 2017-04-26 08:46:31 --> Loader Class Initialized
INFO - 2017-04-26 08:46:31 --> Helper loaded: url_helper
INFO - 2017-04-26 08:46:31 --> Helper loaded: form_helper
INFO - 2017-04-26 08:46:31 --> Helper loaded: html_helper
INFO - 2017-04-26 08:46:31 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:46:31 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:46:31 --> Database Driver Class Initialized
INFO - 2017-04-26 08:46:31 --> Parser Class Initialized
DEBUG - 2017-04-26 08:46:31 --> Session Class Initialized
INFO - 2017-04-26 08:46:31 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:46:31 --> Session routines successfully run
INFO - 2017-04-26 08:46:31 --> Form Validation Class Initialized
INFO - 2017-04-26 08:46:31 --> Controller Class Initialized
DEBUG - 2017-04-26 08:46:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:46:31 --> Model Class Initialized
DEBUG - 2017-04-26 08:46:31 --> Pagination Class Initialized
INFO - 2017-04-26 08:46:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:46:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:46:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:46:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:46:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:46:34 --> Final output sent to browser
DEBUG - 2017-04-26 08:46:34 --> Total execution time: 3.1395
INFO - 2017-04-26 08:46:54 --> Config Class Initialized
INFO - 2017-04-26 08:46:54 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:46:54 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:46:54 --> Utf8 Class Initialized
INFO - 2017-04-26 08:46:54 --> URI Class Initialized
INFO - 2017-04-26 08:46:54 --> Router Class Initialized
INFO - 2017-04-26 08:46:54 --> Output Class Initialized
INFO - 2017-04-26 08:46:54 --> Security Class Initialized
DEBUG - 2017-04-26 08:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:46:54 --> Input Class Initialized
INFO - 2017-04-26 08:46:54 --> Language Class Initialized
INFO - 2017-04-26 08:46:54 --> Loader Class Initialized
INFO - 2017-04-26 08:46:54 --> Helper loaded: url_helper
INFO - 2017-04-26 08:46:54 --> Helper loaded: form_helper
INFO - 2017-04-26 08:46:54 --> Helper loaded: html_helper
INFO - 2017-04-26 08:46:54 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:46:54 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:46:54 --> Database Driver Class Initialized
INFO - 2017-04-26 08:46:54 --> Parser Class Initialized
DEBUG - 2017-04-26 08:46:54 --> Session Class Initialized
INFO - 2017-04-26 08:46:54 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:46:54 --> Session routines successfully run
INFO - 2017-04-26 08:46:54 --> Form Validation Class Initialized
INFO - 2017-04-26 08:46:54 --> Controller Class Initialized
DEBUG - 2017-04-26 08:46:54 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:46:54 --> Model Class Initialized
DEBUG - 2017-04-26 08:46:54 --> Pagination Class Initialized
INFO - 2017-04-26 08:46:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:46:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:46:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:46:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:46:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:46:57 --> Final output sent to browser
DEBUG - 2017-04-26 08:46:57 --> Total execution time: 3.3024
INFO - 2017-04-26 08:48:28 --> Config Class Initialized
INFO - 2017-04-26 08:48:28 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:48:28 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:48:28 --> Utf8 Class Initialized
INFO - 2017-04-26 08:48:28 --> URI Class Initialized
INFO - 2017-04-26 08:48:28 --> Router Class Initialized
INFO - 2017-04-26 08:48:28 --> Output Class Initialized
INFO - 2017-04-26 08:48:28 --> Security Class Initialized
DEBUG - 2017-04-26 08:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:48:28 --> Input Class Initialized
INFO - 2017-04-26 08:48:28 --> Language Class Initialized
INFO - 2017-04-26 08:48:28 --> Loader Class Initialized
INFO - 2017-04-26 08:48:28 --> Helper loaded: url_helper
INFO - 2017-04-26 08:48:28 --> Helper loaded: form_helper
INFO - 2017-04-26 08:48:28 --> Helper loaded: html_helper
INFO - 2017-04-26 08:48:28 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:48:28 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:48:28 --> Database Driver Class Initialized
INFO - 2017-04-26 08:48:28 --> Parser Class Initialized
DEBUG - 2017-04-26 08:48:28 --> Session Class Initialized
INFO - 2017-04-26 08:48:28 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:48:28 --> Session routines successfully run
INFO - 2017-04-26 08:48:28 --> Form Validation Class Initialized
INFO - 2017-04-26 08:48:28 --> Controller Class Initialized
INFO - 2017-04-26 08:48:28 --> Model Class Initialized
DEBUG - 2017-04-26 08:48:29 --> Pagination Class Initialized
INFO - 2017-04-26 08:48:29 --> Config Class Initialized
INFO - 2017-04-26 08:48:29 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:48:29 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:48:29 --> Utf8 Class Initialized
INFO - 2017-04-26 08:48:29 --> URI Class Initialized
INFO - 2017-04-26 08:48:29 --> Router Class Initialized
INFO - 2017-04-26 08:48:29 --> Output Class Initialized
INFO - 2017-04-26 08:48:29 --> Security Class Initialized
DEBUG - 2017-04-26 08:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:48:29 --> Input Class Initialized
INFO - 2017-04-26 08:48:29 --> Language Class Initialized
INFO - 2017-04-26 08:48:29 --> Loader Class Initialized
INFO - 2017-04-26 08:48:29 --> Helper loaded: url_helper
INFO - 2017-04-26 08:48:29 --> Helper loaded: form_helper
INFO - 2017-04-26 08:48:29 --> Helper loaded: html_helper
INFO - 2017-04-26 08:48:29 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:48:29 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:48:29 --> Database Driver Class Initialized
INFO - 2017-04-26 08:48:29 --> Parser Class Initialized
DEBUG - 2017-04-26 08:48:29 --> Session Class Initialized
INFO - 2017-04-26 08:48:29 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:48:29 --> Session routines successfully run
INFO - 2017-04-26 08:48:29 --> Form Validation Class Initialized
INFO - 2017-04-26 08:48:29 --> Controller Class Initialized
INFO - 2017-04-26 08:48:29 --> Model Class Initialized
DEBUG - 2017-04-26 08:48:29 --> Pagination Class Initialized
INFO - 2017-04-26 08:48:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:48:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-26 08:48:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 287
ERROR - 2017-04-26 08:48:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 288
ERROR - 2017-04-26 08:48:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 289
ERROR - 2017-04-26 08:48:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 290
INFO - 2017-04-26 08:48:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/Plan_subscription/list_plan_subscription.php
INFO - 2017-04-26 08:48:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:48:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:48:29 --> Final output sent to browser
DEBUG - 2017-04-26 08:48:29 --> Total execution time: 0.5610
INFO - 2017-04-26 08:48:34 --> Config Class Initialized
INFO - 2017-04-26 08:48:34 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:48:34 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:48:34 --> Utf8 Class Initialized
INFO - 2017-04-26 08:48:34 --> URI Class Initialized
INFO - 2017-04-26 08:48:34 --> Router Class Initialized
INFO - 2017-04-26 08:48:34 --> Output Class Initialized
INFO - 2017-04-26 08:48:34 --> Security Class Initialized
DEBUG - 2017-04-26 08:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:48:34 --> Input Class Initialized
INFO - 2017-04-26 08:48:34 --> Language Class Initialized
INFO - 2017-04-26 08:48:34 --> Loader Class Initialized
INFO - 2017-04-26 08:48:34 --> Helper loaded: url_helper
INFO - 2017-04-26 08:48:34 --> Helper loaded: form_helper
INFO - 2017-04-26 08:48:34 --> Helper loaded: html_helper
INFO - 2017-04-26 08:48:34 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:48:34 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:48:34 --> Database Driver Class Initialized
INFO - 2017-04-26 08:48:34 --> Parser Class Initialized
DEBUG - 2017-04-26 08:48:34 --> Session Class Initialized
INFO - 2017-04-26 08:48:34 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:48:34 --> Session routines successfully run
INFO - 2017-04-26 08:48:34 --> Form Validation Class Initialized
INFO - 2017-04-26 08:48:34 --> Controller Class Initialized
INFO - 2017-04-26 08:48:34 --> Model Class Initialized
DEBUG - 2017-04-26 08:48:34 --> Pagination Class Initialized
INFO - 2017-04-26 08:48:34 --> Config Class Initialized
INFO - 2017-04-26 08:48:34 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:48:34 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:48:34 --> Utf8 Class Initialized
INFO - 2017-04-26 08:48:34 --> URI Class Initialized
INFO - 2017-04-26 08:48:34 --> Router Class Initialized
INFO - 2017-04-26 08:48:34 --> Output Class Initialized
INFO - 2017-04-26 08:48:34 --> Security Class Initialized
DEBUG - 2017-04-26 08:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:48:34 --> Input Class Initialized
INFO - 2017-04-26 08:48:34 --> Language Class Initialized
INFO - 2017-04-26 08:48:34 --> Loader Class Initialized
INFO - 2017-04-26 08:48:34 --> Helper loaded: url_helper
INFO - 2017-04-26 08:48:34 --> Helper loaded: form_helper
INFO - 2017-04-26 08:48:34 --> Helper loaded: html_helper
INFO - 2017-04-26 08:48:34 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:48:34 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:48:34 --> Database Driver Class Initialized
INFO - 2017-04-26 08:48:34 --> Parser Class Initialized
DEBUG - 2017-04-26 08:48:34 --> Session Class Initialized
INFO - 2017-04-26 08:48:34 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:48:34 --> Session routines successfully run
INFO - 2017-04-26 08:48:35 --> Form Validation Class Initialized
INFO - 2017-04-26 08:48:35 --> Controller Class Initialized
INFO - 2017-04-26 08:48:35 --> Model Class Initialized
DEBUG - 2017-04-26 08:48:35 --> Pagination Class Initialized
INFO - 2017-04-26 08:48:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:48:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:48:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/list_color.php
INFO - 2017-04-26 08:48:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:48:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:48:36 --> Final output sent to browser
DEBUG - 2017-04-26 08:48:36 --> Total execution time: 1.7889
INFO - 2017-04-26 08:48:46 --> Config Class Initialized
INFO - 2017-04-26 08:48:46 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:48:46 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:48:46 --> Utf8 Class Initialized
INFO - 2017-04-26 08:48:46 --> URI Class Initialized
INFO - 2017-04-26 08:48:46 --> Router Class Initialized
INFO - 2017-04-26 08:48:46 --> Output Class Initialized
INFO - 2017-04-26 08:48:46 --> Security Class Initialized
DEBUG - 2017-04-26 08:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:48:47 --> Input Class Initialized
INFO - 2017-04-26 08:48:47 --> Language Class Initialized
INFO - 2017-04-26 08:48:47 --> Loader Class Initialized
INFO - 2017-04-26 08:48:47 --> Helper loaded: url_helper
INFO - 2017-04-26 08:48:47 --> Helper loaded: form_helper
INFO - 2017-04-26 08:48:47 --> Helper loaded: html_helper
INFO - 2017-04-26 08:48:47 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:48:47 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:48:47 --> Database Driver Class Initialized
INFO - 2017-04-26 08:48:47 --> Parser Class Initialized
DEBUG - 2017-04-26 08:48:47 --> Session Class Initialized
INFO - 2017-04-26 08:48:47 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:48:47 --> Session routines successfully run
INFO - 2017-04-26 08:48:47 --> Form Validation Class Initialized
INFO - 2017-04-26 08:48:47 --> Controller Class Initialized
INFO - 2017-04-26 08:48:47 --> Model Class Initialized
DEBUG - 2017-04-26 08:48:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-26 08:48:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
ERROR - 2017-04-26 08:48:47 --> Severity: Notice --> Undefined variable: site_version C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 79
ERROR - 2017-04-26 08:48:47 --> Severity: Notice --> Undefined variable: google_map_key C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 146
ERROR - 2017-04-26 08:48:47 --> Severity: Notice --> Undefined variable: default_longitude C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 153
ERROR - 2017-04-26 08:48:47 --> Severity: Notice --> Undefined variable: default_latitude C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 160
ERROR - 2017-04-26 08:48:47 --> Severity: Notice --> Undefined variable: order_cancellation_time C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 177
ERROR - 2017-04-26 08:48:47 --> Severity: Notice --> Undefined variable: order_close_time C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 182
ERROR - 2017-04-26 08:48:47 --> Severity: Notice --> Undefined variable: facebook_link C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 195
ERROR - 2017-04-26 08:48:47 --> Severity: Notice --> Undefined variable: twitter_link C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 202
ERROR - 2017-04-26 08:48:47 --> Severity: Notice --> Undefined variable: instagram_link C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 208
ERROR - 2017-04-26 08:48:47 --> Severity: Notice --> Undefined variable: skype_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 215
INFO - 2017-04-26 08:48:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/setting/add_site.php
INFO - 2017-04-26 08:48:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:48:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:48:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:48:47 --> Final output sent to browser
DEBUG - 2017-04-26 08:48:47 --> Total execution time: 0.6477
INFO - 2017-04-26 08:48:47 --> Config Class Initialized
INFO - 2017-04-26 08:48:47 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:48:47 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:48:47 --> Config Class Initialized
INFO - 2017-04-26 08:48:47 --> Utf8 Class Initialized
INFO - 2017-04-26 08:48:47 --> Hooks Class Initialized
INFO - 2017-04-26 08:48:47 --> URI Class Initialized
DEBUG - 2017-04-26 08:48:47 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:48:47 --> Router Class Initialized
INFO - 2017-04-26 08:48:47 --> Utf8 Class Initialized
INFO - 2017-04-26 08:48:47 --> URI Class Initialized
INFO - 2017-04-26 08:48:47 --> Output Class Initialized
INFO - 2017-04-26 08:48:47 --> Router Class Initialized
INFO - 2017-04-26 08:48:47 --> Security Class Initialized
INFO - 2017-04-26 08:48:47 --> Output Class Initialized
DEBUG - 2017-04-26 08:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:48:47 --> Security Class Initialized
INFO - 2017-04-26 08:48:47 --> Input Class Initialized
INFO - 2017-04-26 08:48:47 --> Language Class Initialized
DEBUG - 2017-04-26 08:48:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-04-26 08:48:47 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:48:47 --> Input Class Initialized
INFO - 2017-04-26 08:48:47 --> Language Class Initialized
ERROR - 2017-04-26 08:48:47 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 08:48:56 --> Config Class Initialized
INFO - 2017-04-26 08:48:56 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:48:56 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:48:56 --> Utf8 Class Initialized
INFO - 2017-04-26 08:48:56 --> URI Class Initialized
INFO - 2017-04-26 08:48:56 --> Router Class Initialized
INFO - 2017-04-26 08:48:56 --> Output Class Initialized
INFO - 2017-04-26 08:48:56 --> Security Class Initialized
DEBUG - 2017-04-26 08:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:48:56 --> Input Class Initialized
INFO - 2017-04-26 08:48:56 --> Language Class Initialized
INFO - 2017-04-26 08:48:56 --> Loader Class Initialized
INFO - 2017-04-26 08:48:56 --> Helper loaded: url_helper
INFO - 2017-04-26 08:48:56 --> Helper loaded: form_helper
INFO - 2017-04-26 08:48:56 --> Helper loaded: html_helper
INFO - 2017-04-26 08:48:56 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:48:56 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:48:56 --> Database Driver Class Initialized
INFO - 2017-04-26 08:48:56 --> Parser Class Initialized
DEBUG - 2017-04-26 08:48:56 --> Session Class Initialized
INFO - 2017-04-26 08:48:56 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:48:56 --> Session routines successfully run
INFO - 2017-04-26 08:48:56 --> Form Validation Class Initialized
INFO - 2017-04-26 08:48:56 --> Controller Class Initialized
DEBUG - 2017-04-26 08:48:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:48:56 --> Model Class Initialized
DEBUG - 2017-04-26 08:48:56 --> Pagination Class Initialized
INFO - 2017-04-26 08:48:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:48:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:48:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:48:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:48:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:48:59 --> Final output sent to browser
DEBUG - 2017-04-26 08:48:59 --> Total execution time: 3.2448
INFO - 2017-04-26 08:50:22 --> Config Class Initialized
INFO - 2017-04-26 08:50:22 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:50:22 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:50:22 --> Utf8 Class Initialized
INFO - 2017-04-26 08:50:22 --> URI Class Initialized
INFO - 2017-04-26 08:50:22 --> Router Class Initialized
INFO - 2017-04-26 08:50:22 --> Output Class Initialized
INFO - 2017-04-26 08:50:22 --> Security Class Initialized
DEBUG - 2017-04-26 08:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:50:22 --> Input Class Initialized
INFO - 2017-04-26 08:50:22 --> Language Class Initialized
INFO - 2017-04-26 08:50:22 --> Loader Class Initialized
INFO - 2017-04-26 08:50:22 --> Helper loaded: url_helper
INFO - 2017-04-26 08:50:22 --> Helper loaded: form_helper
INFO - 2017-04-26 08:50:22 --> Helper loaded: html_helper
INFO - 2017-04-26 08:50:22 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:50:22 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:50:22 --> Database Driver Class Initialized
INFO - 2017-04-26 08:50:22 --> Parser Class Initialized
DEBUG - 2017-04-26 08:50:22 --> Session Class Initialized
INFO - 2017-04-26 08:50:22 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:50:22 --> Session routines successfully run
INFO - 2017-04-26 08:50:22 --> Form Validation Class Initialized
INFO - 2017-04-26 08:50:22 --> Controller Class Initialized
DEBUG - 2017-04-26 08:50:22 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:50:22 --> Model Class Initialized
DEBUG - 2017-04-26 08:50:22 --> Pagination Class Initialized
INFO - 2017-04-26 08:50:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:50:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:50:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:50:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:50:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:50:25 --> Final output sent to browser
DEBUG - 2017-04-26 08:50:25 --> Total execution time: 3.1557
INFO - 2017-04-26 08:50:51 --> Config Class Initialized
INFO - 2017-04-26 08:50:51 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:50:51 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:50:51 --> Utf8 Class Initialized
INFO - 2017-04-26 08:50:51 --> URI Class Initialized
INFO - 2017-04-26 08:50:51 --> Router Class Initialized
INFO - 2017-04-26 08:50:51 --> Output Class Initialized
INFO - 2017-04-26 08:50:51 --> Security Class Initialized
DEBUG - 2017-04-26 08:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:50:51 --> Input Class Initialized
INFO - 2017-04-26 08:50:51 --> Language Class Initialized
INFO - 2017-04-26 08:50:51 --> Loader Class Initialized
INFO - 2017-04-26 08:50:51 --> Helper loaded: url_helper
INFO - 2017-04-26 08:50:51 --> Helper loaded: form_helper
INFO - 2017-04-26 08:50:51 --> Helper loaded: html_helper
INFO - 2017-04-26 08:50:51 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:50:51 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:50:51 --> Database Driver Class Initialized
INFO - 2017-04-26 08:50:51 --> Parser Class Initialized
DEBUG - 2017-04-26 08:50:51 --> Session Class Initialized
INFO - 2017-04-26 08:50:51 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:50:51 --> Session routines successfully run
INFO - 2017-04-26 08:50:51 --> Form Validation Class Initialized
INFO - 2017-04-26 08:50:51 --> Controller Class Initialized
DEBUG - 2017-04-26 08:50:51 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:50:51 --> Model Class Initialized
DEBUG - 2017-04-26 08:50:51 --> Pagination Class Initialized
INFO - 2017-04-26 08:50:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:50:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:50:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:50:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:50:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:50:54 --> Final output sent to browser
DEBUG - 2017-04-26 08:50:54 --> Total execution time: 3.1576
INFO - 2017-04-26 08:51:18 --> Config Class Initialized
INFO - 2017-04-26 08:51:18 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:51:18 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:51:18 --> Utf8 Class Initialized
INFO - 2017-04-26 08:51:18 --> URI Class Initialized
INFO - 2017-04-26 08:51:18 --> Router Class Initialized
INFO - 2017-04-26 08:51:18 --> Output Class Initialized
INFO - 2017-04-26 08:51:18 --> Security Class Initialized
DEBUG - 2017-04-26 08:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:51:18 --> Input Class Initialized
INFO - 2017-04-26 08:51:18 --> Language Class Initialized
INFO - 2017-04-26 08:51:18 --> Loader Class Initialized
INFO - 2017-04-26 08:51:18 --> Helper loaded: url_helper
INFO - 2017-04-26 08:51:18 --> Helper loaded: form_helper
INFO - 2017-04-26 08:51:18 --> Helper loaded: html_helper
INFO - 2017-04-26 08:51:18 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:51:18 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:51:18 --> Database Driver Class Initialized
INFO - 2017-04-26 08:51:18 --> Parser Class Initialized
DEBUG - 2017-04-26 08:51:18 --> Session Class Initialized
INFO - 2017-04-26 08:51:18 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:51:18 --> Session routines successfully run
INFO - 2017-04-26 08:51:18 --> Form Validation Class Initialized
INFO - 2017-04-26 08:51:18 --> Controller Class Initialized
DEBUG - 2017-04-26 08:51:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:51:18 --> Model Class Initialized
DEBUG - 2017-04-26 08:51:18 --> Pagination Class Initialized
INFO - 2017-04-26 08:51:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:51:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:51:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:51:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:51:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:51:21 --> Final output sent to browser
DEBUG - 2017-04-26 08:51:21 --> Total execution time: 3.2820
INFO - 2017-04-26 08:51:45 --> Config Class Initialized
INFO - 2017-04-26 08:51:45 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:51:45 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:51:45 --> Utf8 Class Initialized
INFO - 2017-04-26 08:51:45 --> URI Class Initialized
INFO - 2017-04-26 08:51:45 --> Router Class Initialized
INFO - 2017-04-26 08:51:45 --> Output Class Initialized
INFO - 2017-04-26 08:51:45 --> Security Class Initialized
DEBUG - 2017-04-26 08:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:51:45 --> Input Class Initialized
INFO - 2017-04-26 08:51:45 --> Language Class Initialized
INFO - 2017-04-26 08:51:45 --> Loader Class Initialized
INFO - 2017-04-26 08:51:45 --> Helper loaded: url_helper
INFO - 2017-04-26 08:51:45 --> Helper loaded: form_helper
INFO - 2017-04-26 08:51:45 --> Helper loaded: html_helper
INFO - 2017-04-26 08:51:45 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:51:45 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:51:45 --> Database Driver Class Initialized
INFO - 2017-04-26 08:51:45 --> Parser Class Initialized
DEBUG - 2017-04-26 08:51:45 --> Session Class Initialized
INFO - 2017-04-26 08:51:45 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:51:45 --> Session routines successfully run
INFO - 2017-04-26 08:51:45 --> Form Validation Class Initialized
INFO - 2017-04-26 08:51:45 --> Controller Class Initialized
DEBUG - 2017-04-26 08:51:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:51:45 --> Model Class Initialized
DEBUG - 2017-04-26 08:51:45 --> Pagination Class Initialized
INFO - 2017-04-26 08:51:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:51:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:51:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:51:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:51:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:51:48 --> Final output sent to browser
DEBUG - 2017-04-26 08:51:48 --> Total execution time: 3.2517
INFO - 2017-04-26 08:53:54 --> Config Class Initialized
INFO - 2017-04-26 08:53:54 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:53:54 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:53:54 --> Utf8 Class Initialized
INFO - 2017-04-26 08:53:54 --> URI Class Initialized
INFO - 2017-04-26 08:53:54 --> Router Class Initialized
INFO - 2017-04-26 08:53:54 --> Output Class Initialized
INFO - 2017-04-26 08:53:54 --> Security Class Initialized
DEBUG - 2017-04-26 08:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:53:54 --> Input Class Initialized
INFO - 2017-04-26 08:53:54 --> Language Class Initialized
INFO - 2017-04-26 08:53:54 --> Loader Class Initialized
INFO - 2017-04-26 08:53:54 --> Helper loaded: url_helper
INFO - 2017-04-26 08:53:55 --> Helper loaded: form_helper
INFO - 2017-04-26 08:53:55 --> Helper loaded: html_helper
INFO - 2017-04-26 08:53:55 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:53:55 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:53:55 --> Database Driver Class Initialized
INFO - 2017-04-26 08:53:55 --> Parser Class Initialized
DEBUG - 2017-04-26 08:53:55 --> Session Class Initialized
INFO - 2017-04-26 08:53:55 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:53:55 --> Session routines successfully run
INFO - 2017-04-26 08:53:55 --> Form Validation Class Initialized
INFO - 2017-04-26 08:53:55 --> Controller Class Initialized
DEBUG - 2017-04-26 08:53:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:53:55 --> Model Class Initialized
DEBUG - 2017-04-26 08:53:55 --> Pagination Class Initialized
INFO - 2017-04-26 08:53:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:53:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:53:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:53:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:53:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:53:58 --> Final output sent to browser
DEBUG - 2017-04-26 08:53:58 --> Total execution time: 3.5787
INFO - 2017-04-26 08:54:52 --> Config Class Initialized
INFO - 2017-04-26 08:54:52 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:54:52 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:54:52 --> Utf8 Class Initialized
INFO - 2017-04-26 08:54:52 --> URI Class Initialized
INFO - 2017-04-26 08:54:52 --> Router Class Initialized
INFO - 2017-04-26 08:54:52 --> Output Class Initialized
INFO - 2017-04-26 08:54:52 --> Security Class Initialized
DEBUG - 2017-04-26 08:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:54:52 --> Input Class Initialized
INFO - 2017-04-26 08:54:52 --> Language Class Initialized
INFO - 2017-04-26 08:54:52 --> Loader Class Initialized
INFO - 2017-04-26 08:54:52 --> Helper loaded: url_helper
INFO - 2017-04-26 08:54:52 --> Helper loaded: form_helper
INFO - 2017-04-26 08:54:52 --> Helper loaded: html_helper
INFO - 2017-04-26 08:54:52 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:54:52 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:54:52 --> Database Driver Class Initialized
INFO - 2017-04-26 08:54:52 --> Parser Class Initialized
DEBUG - 2017-04-26 08:54:52 --> Session Class Initialized
INFO - 2017-04-26 08:54:52 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:54:52 --> Session routines successfully run
INFO - 2017-04-26 08:54:52 --> Form Validation Class Initialized
INFO - 2017-04-26 08:54:52 --> Controller Class Initialized
DEBUG - 2017-04-26 08:54:52 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:54:52 --> Model Class Initialized
DEBUG - 2017-04-26 08:54:52 --> Pagination Class Initialized
INFO - 2017-04-26 08:54:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:54:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:54:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:54:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:54:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:54:55 --> Final output sent to browser
DEBUG - 2017-04-26 08:54:55 --> Total execution time: 3.1805
INFO - 2017-04-26 08:55:01 --> Config Class Initialized
INFO - 2017-04-26 08:55:02 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:55:02 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:55:02 --> Utf8 Class Initialized
INFO - 2017-04-26 08:55:02 --> URI Class Initialized
INFO - 2017-04-26 08:55:02 --> Router Class Initialized
INFO - 2017-04-26 08:55:02 --> Output Class Initialized
INFO - 2017-04-26 08:55:02 --> Security Class Initialized
DEBUG - 2017-04-26 08:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:55:02 --> Input Class Initialized
INFO - 2017-04-26 08:55:02 --> Language Class Initialized
INFO - 2017-04-26 08:55:02 --> Loader Class Initialized
INFO - 2017-04-26 08:55:02 --> Helper loaded: url_helper
INFO - 2017-04-26 08:55:02 --> Helper loaded: form_helper
INFO - 2017-04-26 08:55:02 --> Helper loaded: html_helper
INFO - 2017-04-26 08:55:02 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:55:02 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:55:02 --> Database Driver Class Initialized
INFO - 2017-04-26 08:55:02 --> Parser Class Initialized
DEBUG - 2017-04-26 08:55:02 --> Session Class Initialized
INFO - 2017-04-26 08:55:02 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:55:02 --> Session routines successfully run
INFO - 2017-04-26 08:55:02 --> Form Validation Class Initialized
INFO - 2017-04-26 08:55:02 --> Controller Class Initialized
DEBUG - 2017-04-26 08:55:02 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:55:02 --> Model Class Initialized
DEBUG - 2017-04-26 08:55:02 --> Pagination Class Initialized
INFO - 2017-04-26 08:55:02 --> Config Class Initialized
INFO - 2017-04-26 08:55:02 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:55:02 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:55:02 --> Utf8 Class Initialized
INFO - 2017-04-26 08:55:02 --> URI Class Initialized
INFO - 2017-04-26 08:55:02 --> Router Class Initialized
INFO - 2017-04-26 08:55:02 --> Output Class Initialized
INFO - 2017-04-26 08:55:02 --> Security Class Initialized
DEBUG - 2017-04-26 08:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:55:02 --> Input Class Initialized
INFO - 2017-04-26 08:55:02 --> Language Class Initialized
INFO - 2017-04-26 08:55:02 --> Loader Class Initialized
INFO - 2017-04-26 08:55:02 --> Helper loaded: url_helper
INFO - 2017-04-26 08:55:02 --> Helper loaded: form_helper
INFO - 2017-04-26 08:55:02 --> Helper loaded: html_helper
INFO - 2017-04-26 08:55:02 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:55:02 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:55:02 --> Database Driver Class Initialized
INFO - 2017-04-26 08:55:02 --> Parser Class Initialized
DEBUG - 2017-04-26 08:55:02 --> Session Class Initialized
INFO - 2017-04-26 08:55:02 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:55:02 --> Session routines successfully run
INFO - 2017-04-26 08:55:02 --> Form Validation Class Initialized
INFO - 2017-04-26 08:55:02 --> Controller Class Initialized
DEBUG - 2017-04-26 08:55:02 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:55:02 --> Model Class Initialized
DEBUG - 2017-04-26 08:55:02 --> Pagination Class Initialized
INFO - 2017-04-26 08:55:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:55:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:55:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 08:55:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:55:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:55:08 --> Final output sent to browser
DEBUG - 2017-04-26 08:55:08 --> Total execution time: 6.6067
INFO - 2017-04-26 08:58:50 --> Config Class Initialized
INFO - 2017-04-26 08:58:50 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:58:50 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:58:50 --> Utf8 Class Initialized
INFO - 2017-04-26 08:58:50 --> URI Class Initialized
INFO - 2017-04-26 08:58:50 --> Router Class Initialized
INFO - 2017-04-26 08:58:50 --> Output Class Initialized
INFO - 2017-04-26 08:58:50 --> Security Class Initialized
DEBUG - 2017-04-26 08:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:58:50 --> Input Class Initialized
INFO - 2017-04-26 08:58:50 --> Language Class Initialized
INFO - 2017-04-26 08:58:50 --> Loader Class Initialized
INFO - 2017-04-26 08:58:50 --> Helper loaded: url_helper
INFO - 2017-04-26 08:58:50 --> Helper loaded: form_helper
INFO - 2017-04-26 08:58:50 --> Helper loaded: html_helper
INFO - 2017-04-26 08:58:50 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:58:50 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:58:50 --> Database Driver Class Initialized
INFO - 2017-04-26 08:58:50 --> Parser Class Initialized
DEBUG - 2017-04-26 08:58:50 --> Session Class Initialized
INFO - 2017-04-26 08:58:50 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:58:50 --> Session routines successfully run
INFO - 2017-04-26 08:58:50 --> Form Validation Class Initialized
INFO - 2017-04-26 08:58:50 --> Controller Class Initialized
DEBUG - 2017-04-26 08:58:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:58:50 --> Model Class Initialized
DEBUG - 2017-04-26 08:58:50 --> Pagination Class Initialized
INFO - 2017-04-26 08:58:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:58:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:58:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:58:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:58:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:58:53 --> Final output sent to browser
INFO - 2017-04-26 08:58:53 --> Config Class Initialized
DEBUG - 2017-04-26 08:58:53 --> Total execution time: 3.3007
INFO - 2017-04-26 08:58:53 --> Hooks Class Initialized
DEBUG - 2017-04-26 08:58:53 --> UTF-8 Support Enabled
INFO - 2017-04-26 08:58:53 --> Utf8 Class Initialized
INFO - 2017-04-26 08:58:53 --> URI Class Initialized
INFO - 2017-04-26 08:58:53 --> Router Class Initialized
INFO - 2017-04-26 08:58:53 --> Output Class Initialized
INFO - 2017-04-26 08:58:53 --> Security Class Initialized
DEBUG - 2017-04-26 08:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 08:58:53 --> Input Class Initialized
INFO - 2017-04-26 08:58:53 --> Language Class Initialized
INFO - 2017-04-26 08:58:53 --> Loader Class Initialized
INFO - 2017-04-26 08:58:53 --> Helper loaded: url_helper
INFO - 2017-04-26 08:58:53 --> Helper loaded: form_helper
INFO - 2017-04-26 08:58:53 --> Helper loaded: html_helper
INFO - 2017-04-26 08:58:53 --> Helper loaded: custom_helper
INFO - 2017-04-26 08:58:53 --> Helper loaded: cache_helper
INFO - 2017-04-26 08:58:53 --> Database Driver Class Initialized
INFO - 2017-04-26 08:58:53 --> Parser Class Initialized
DEBUG - 2017-04-26 08:58:53 --> Session Class Initialized
INFO - 2017-04-26 08:58:53 --> Helper loaded: string_helper
DEBUG - 2017-04-26 08:58:53 --> Session routines successfully run
INFO - 2017-04-26 08:58:53 --> Form Validation Class Initialized
INFO - 2017-04-26 08:58:53 --> Controller Class Initialized
DEBUG - 2017-04-26 08:58:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 08:58:53 --> Model Class Initialized
DEBUG - 2017-04-26 08:58:53 --> Pagination Class Initialized
INFO - 2017-04-26 08:58:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 08:58:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 08:58:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 08:58:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 08:58:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 08:58:56 --> Final output sent to browser
DEBUG - 2017-04-26 08:58:56 --> Total execution time: 3.1843
INFO - 2017-04-26 09:03:08 --> Config Class Initialized
INFO - 2017-04-26 09:03:08 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:03:08 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:03:08 --> Utf8 Class Initialized
INFO - 2017-04-26 09:03:08 --> URI Class Initialized
INFO - 2017-04-26 09:03:08 --> Router Class Initialized
INFO - 2017-04-26 09:03:08 --> Output Class Initialized
INFO - 2017-04-26 09:03:08 --> Security Class Initialized
DEBUG - 2017-04-26 09:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:03:08 --> Input Class Initialized
INFO - 2017-04-26 09:03:08 --> Language Class Initialized
INFO - 2017-04-26 09:03:08 --> Loader Class Initialized
INFO - 2017-04-26 09:03:08 --> Helper loaded: url_helper
INFO - 2017-04-26 09:03:08 --> Helper loaded: form_helper
INFO - 2017-04-26 09:03:08 --> Helper loaded: html_helper
INFO - 2017-04-26 09:03:08 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:03:08 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:03:08 --> Database Driver Class Initialized
INFO - 2017-04-26 09:03:08 --> Parser Class Initialized
DEBUG - 2017-04-26 09:03:08 --> Session Class Initialized
INFO - 2017-04-26 09:03:08 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:03:08 --> Session routines successfully run
INFO - 2017-04-26 09:03:08 --> Form Validation Class Initialized
INFO - 2017-04-26 09:03:08 --> Controller Class Initialized
DEBUG - 2017-04-26 09:03:08 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:03:08 --> Model Class Initialized
DEBUG - 2017-04-26 09:03:08 --> Pagination Class Initialized
INFO - 2017-04-26 09:03:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:03:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:03:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:03:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:03:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:03:11 --> Final output sent to browser
DEBUG - 2017-04-26 09:03:11 --> Total execution time: 3.4753
INFO - 2017-04-26 09:09:30 --> Config Class Initialized
INFO - 2017-04-26 09:09:30 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:09:30 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:09:30 --> Utf8 Class Initialized
INFO - 2017-04-26 09:09:30 --> URI Class Initialized
INFO - 2017-04-26 09:09:30 --> Router Class Initialized
INFO - 2017-04-26 09:09:30 --> Output Class Initialized
INFO - 2017-04-26 09:09:30 --> Security Class Initialized
DEBUG - 2017-04-26 09:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:09:30 --> Input Class Initialized
INFO - 2017-04-26 09:09:30 --> Language Class Initialized
INFO - 2017-04-26 09:09:30 --> Loader Class Initialized
INFO - 2017-04-26 09:09:30 --> Helper loaded: url_helper
INFO - 2017-04-26 09:09:30 --> Helper loaded: form_helper
INFO - 2017-04-26 09:09:30 --> Helper loaded: html_helper
INFO - 2017-04-26 09:09:30 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:09:30 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:09:30 --> Database Driver Class Initialized
INFO - 2017-04-26 09:09:30 --> Parser Class Initialized
DEBUG - 2017-04-26 09:09:30 --> Session Class Initialized
INFO - 2017-04-26 09:09:30 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:09:30 --> Session routines successfully run
INFO - 2017-04-26 09:09:30 --> Form Validation Class Initialized
INFO - 2017-04-26 09:09:30 --> Controller Class Initialized
DEBUG - 2017-04-26 09:09:30 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:09:30 --> Model Class Initialized
DEBUG - 2017-04-26 09:09:30 --> Pagination Class Initialized
ERROR - 2017-04-26 09:09:30 --> Query error: Column 'company_id' in group statement is ambiguous - Invalid query: SELECT `company`.*, `users`.`chargify_subscriptions_ID`, `ar`.*
FROM `company`
LEFT JOIN `users` ON `users`.`company_id` = `company`.`company_id`
LEFT JOIN `app_registration` `ar` ON `ar`.`company_id` = `company`.`company_id`
WHERE `company`.`is_deleted` != '1'
GROUP BY `company_id`
ORDER BY `company`.`company_id` DESC
 LIMIT 20
INFO - 2017-04-26 09:09:30 --> Language file loaded: language/english/db_lang.php
INFO - 2017-04-26 09:10:13 --> Config Class Initialized
INFO - 2017-04-26 09:10:13 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:10:13 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:10:13 --> Utf8 Class Initialized
INFO - 2017-04-26 09:10:13 --> URI Class Initialized
INFO - 2017-04-26 09:10:13 --> Router Class Initialized
INFO - 2017-04-26 09:10:13 --> Output Class Initialized
INFO - 2017-04-26 09:10:13 --> Security Class Initialized
DEBUG - 2017-04-26 09:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:10:13 --> Input Class Initialized
INFO - 2017-04-26 09:10:13 --> Language Class Initialized
INFO - 2017-04-26 09:10:13 --> Loader Class Initialized
INFO - 2017-04-26 09:10:13 --> Helper loaded: url_helper
INFO - 2017-04-26 09:10:13 --> Helper loaded: form_helper
INFO - 2017-04-26 09:10:13 --> Helper loaded: html_helper
INFO - 2017-04-26 09:10:13 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:10:13 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:10:13 --> Database Driver Class Initialized
INFO - 2017-04-26 09:10:13 --> Parser Class Initialized
DEBUG - 2017-04-26 09:10:13 --> Session Class Initialized
INFO - 2017-04-26 09:10:13 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:10:13 --> Session routines successfully run
INFO - 2017-04-26 09:10:13 --> Form Validation Class Initialized
INFO - 2017-04-26 09:10:13 --> Controller Class Initialized
DEBUG - 2017-04-26 09:10:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:10:13 --> Model Class Initialized
DEBUG - 2017-04-26 09:10:13 --> Pagination Class Initialized
ERROR - 2017-04-26 09:10:14 --> Query error: Column 'company_id' in group statement is ambiguous - Invalid query: SELECT `company`.*, `users`.`chargify_subscriptions_ID`, `ar`.*
FROM `company`
LEFT JOIN `users` ON `users`.`company_id` = `company`.`company_id`
LEFT JOIN `app_registration` `ar` ON `ar`.`company_id` = `company`.`company_id`
WHERE `company`.`is_deleted` != '1'
GROUP BY `company_id`
ORDER BY `company`.`company_id` DESC
 LIMIT 20
INFO - 2017-04-26 09:10:14 --> Language file loaded: language/english/db_lang.php
INFO - 2017-04-26 09:10:22 --> Config Class Initialized
INFO - 2017-04-26 09:10:22 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:10:22 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:10:22 --> Utf8 Class Initialized
INFO - 2017-04-26 09:10:22 --> URI Class Initialized
INFO - 2017-04-26 09:10:22 --> Router Class Initialized
INFO - 2017-04-26 09:10:22 --> Output Class Initialized
INFO - 2017-04-26 09:10:22 --> Security Class Initialized
DEBUG - 2017-04-26 09:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:10:22 --> Input Class Initialized
INFO - 2017-04-26 09:10:22 --> Language Class Initialized
INFO - 2017-04-26 09:10:22 --> Loader Class Initialized
INFO - 2017-04-26 09:10:22 --> Helper loaded: url_helper
INFO - 2017-04-26 09:10:22 --> Helper loaded: form_helper
INFO - 2017-04-26 09:10:22 --> Helper loaded: html_helper
INFO - 2017-04-26 09:10:22 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:10:22 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:10:22 --> Database Driver Class Initialized
INFO - 2017-04-26 09:10:22 --> Parser Class Initialized
DEBUG - 2017-04-26 09:10:22 --> Session Class Initialized
INFO - 2017-04-26 09:10:22 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:10:22 --> Session routines successfully run
INFO - 2017-04-26 09:10:22 --> Form Validation Class Initialized
INFO - 2017-04-26 09:10:22 --> Controller Class Initialized
DEBUG - 2017-04-26 09:10:22 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:10:22 --> Model Class Initialized
DEBUG - 2017-04-26 09:10:22 --> Pagination Class Initialized
INFO - 2017-04-26 09:10:40 --> Config Class Initialized
INFO - 2017-04-26 09:10:40 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:10:40 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:10:40 --> Utf8 Class Initialized
INFO - 2017-04-26 09:10:40 --> URI Class Initialized
INFO - 2017-04-26 09:10:40 --> Router Class Initialized
INFO - 2017-04-26 09:10:40 --> Output Class Initialized
INFO - 2017-04-26 09:10:40 --> Security Class Initialized
DEBUG - 2017-04-26 09:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:10:41 --> Input Class Initialized
INFO - 2017-04-26 09:10:41 --> Language Class Initialized
INFO - 2017-04-26 09:10:41 --> Loader Class Initialized
INFO - 2017-04-26 09:10:41 --> Helper loaded: url_helper
INFO - 2017-04-26 09:10:41 --> Helper loaded: form_helper
INFO - 2017-04-26 09:10:41 --> Helper loaded: html_helper
INFO - 2017-04-26 09:10:41 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:10:41 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:10:41 --> Database Driver Class Initialized
INFO - 2017-04-26 09:10:41 --> Parser Class Initialized
DEBUG - 2017-04-26 09:10:41 --> Session Class Initialized
INFO - 2017-04-26 09:10:41 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:10:41 --> Session routines successfully run
INFO - 2017-04-26 09:10:41 --> Form Validation Class Initialized
INFO - 2017-04-26 09:10:41 --> Controller Class Initialized
DEBUG - 2017-04-26 09:10:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:10:41 --> Model Class Initialized
DEBUG - 2017-04-26 09:10:41 --> Pagination Class Initialized
INFO - 2017-04-26 09:10:41 --> Config Class Initialized
INFO - 2017-04-26 09:10:41 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:10:41 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:10:41 --> Utf8 Class Initialized
INFO - 2017-04-26 09:10:41 --> URI Class Initialized
INFO - 2017-04-26 09:10:41 --> Router Class Initialized
INFO - 2017-04-26 09:10:41 --> Output Class Initialized
INFO - 2017-04-26 09:10:41 --> Security Class Initialized
DEBUG - 2017-04-26 09:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:10:41 --> Input Class Initialized
INFO - 2017-04-26 09:10:41 --> Language Class Initialized
INFO - 2017-04-26 09:10:41 --> Loader Class Initialized
INFO - 2017-04-26 09:10:41 --> Helper loaded: url_helper
INFO - 2017-04-26 09:10:41 --> Helper loaded: form_helper
INFO - 2017-04-26 09:10:41 --> Helper loaded: html_helper
INFO - 2017-04-26 09:10:41 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:10:41 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:10:41 --> Database Driver Class Initialized
INFO - 2017-04-26 09:10:41 --> Parser Class Initialized
DEBUG - 2017-04-26 09:10:41 --> Session Class Initialized
INFO - 2017-04-26 09:10:41 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:10:41 --> Session routines successfully run
INFO - 2017-04-26 09:10:41 --> Form Validation Class Initialized
INFO - 2017-04-26 09:10:41 --> Controller Class Initialized
DEBUG - 2017-04-26 09:10:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:10:41 --> Model Class Initialized
DEBUG - 2017-04-26 09:10:41 --> Pagination Class Initialized
INFO - 2017-04-26 09:10:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:10:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:10:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 09:10:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:10:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:10:41 --> Final output sent to browser
DEBUG - 2017-04-26 09:10:41 --> Total execution time: 0.3714
INFO - 2017-04-26 09:10:46 --> Config Class Initialized
INFO - 2017-04-26 09:10:46 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:10:46 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:10:46 --> Utf8 Class Initialized
INFO - 2017-04-26 09:10:46 --> URI Class Initialized
INFO - 2017-04-26 09:10:46 --> Router Class Initialized
INFO - 2017-04-26 09:10:46 --> Output Class Initialized
INFO - 2017-04-26 09:10:46 --> Security Class Initialized
DEBUG - 2017-04-26 09:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:10:46 --> Input Class Initialized
INFO - 2017-04-26 09:10:46 --> Language Class Initialized
INFO - 2017-04-26 09:10:46 --> Loader Class Initialized
INFO - 2017-04-26 09:10:46 --> Helper loaded: url_helper
INFO - 2017-04-26 09:10:46 --> Helper loaded: form_helper
INFO - 2017-04-26 09:10:46 --> Helper loaded: html_helper
INFO - 2017-04-26 09:10:46 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:10:46 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:10:46 --> Database Driver Class Initialized
INFO - 2017-04-26 09:10:46 --> Parser Class Initialized
DEBUG - 2017-04-26 09:10:46 --> Session Class Initialized
INFO - 2017-04-26 09:10:46 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:10:46 --> Session routines successfully run
INFO - 2017-04-26 09:10:46 --> Form Validation Class Initialized
INFO - 2017-04-26 09:10:46 --> Controller Class Initialized
DEBUG - 2017-04-26 09:10:46 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:10:46 --> Model Class Initialized
DEBUG - 2017-04-26 09:10:46 --> Pagination Class Initialized
INFO - 2017-04-26 09:10:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:10:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:10:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-26 09:10:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:10:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:10:46 --> Final output sent to browser
DEBUG - 2017-04-26 09:10:46 --> Total execution time: 0.3587
INFO - 2017-04-26 09:10:46 --> Config Class Initialized
INFO - 2017-04-26 09:10:46 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:10:46 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:10:46 --> Utf8 Class Initialized
INFO - 2017-04-26 09:10:46 --> URI Class Initialized
INFO - 2017-04-26 09:10:46 --> Router Class Initialized
INFO - 2017-04-26 09:10:46 --> Output Class Initialized
INFO - 2017-04-26 09:10:46 --> Security Class Initialized
DEBUG - 2017-04-26 09:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:10:46 --> Input Class Initialized
INFO - 2017-04-26 09:10:46 --> Language Class Initialized
ERROR - 2017-04-26 09:10:46 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 09:10:46 --> Config Class Initialized
INFO - 2017-04-26 09:10:46 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:10:46 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:10:46 --> Utf8 Class Initialized
INFO - 2017-04-26 09:10:46 --> URI Class Initialized
INFO - 2017-04-26 09:10:46 --> Router Class Initialized
INFO - 2017-04-26 09:10:46 --> Output Class Initialized
INFO - 2017-04-26 09:10:46 --> Security Class Initialized
DEBUG - 2017-04-26 09:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:10:46 --> Input Class Initialized
INFO - 2017-04-26 09:10:46 --> Language Class Initialized
ERROR - 2017-04-26 09:10:46 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 09:10:48 --> Config Class Initialized
INFO - 2017-04-26 09:10:48 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:10:48 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:10:48 --> Utf8 Class Initialized
INFO - 2017-04-26 09:10:48 --> URI Class Initialized
INFO - 2017-04-26 09:10:48 --> Router Class Initialized
INFO - 2017-04-26 09:10:48 --> Output Class Initialized
INFO - 2017-04-26 09:10:49 --> Security Class Initialized
DEBUG - 2017-04-26 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:10:49 --> Input Class Initialized
INFO - 2017-04-26 09:10:49 --> Language Class Initialized
INFO - 2017-04-26 09:10:49 --> Loader Class Initialized
INFO - 2017-04-26 09:10:49 --> Helper loaded: url_helper
INFO - 2017-04-26 09:10:49 --> Helper loaded: form_helper
INFO - 2017-04-26 09:10:49 --> Helper loaded: html_helper
INFO - 2017-04-26 09:10:49 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:10:49 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:10:49 --> Database Driver Class Initialized
INFO - 2017-04-26 09:10:49 --> Parser Class Initialized
DEBUG - 2017-04-26 09:10:49 --> Session Class Initialized
INFO - 2017-04-26 09:10:49 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:10:49 --> Session routines successfully run
INFO - 2017-04-26 09:10:49 --> Form Validation Class Initialized
INFO - 2017-04-26 09:10:49 --> Controller Class Initialized
DEBUG - 2017-04-26 09:10:49 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:10:49 --> Model Class Initialized
DEBUG - 2017-04-26 09:10:49 --> Pagination Class Initialized
INFO - 2017-04-26 09:10:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:10:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:10:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 09:10:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:10:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:10:49 --> Final output sent to browser
DEBUG - 2017-04-26 09:10:49 --> Total execution time: 0.6072
INFO - 2017-04-26 09:10:54 --> Config Class Initialized
INFO - 2017-04-26 09:10:54 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:10:54 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:10:54 --> Utf8 Class Initialized
INFO - 2017-04-26 09:10:54 --> URI Class Initialized
INFO - 2017-04-26 09:10:54 --> Router Class Initialized
INFO - 2017-04-26 09:10:54 --> Output Class Initialized
INFO - 2017-04-26 09:10:54 --> Security Class Initialized
DEBUG - 2017-04-26 09:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:10:54 --> Input Class Initialized
INFO - 2017-04-26 09:10:54 --> Language Class Initialized
INFO - 2017-04-26 09:10:54 --> Loader Class Initialized
INFO - 2017-04-26 09:10:54 --> Helper loaded: url_helper
INFO - 2017-04-26 09:10:54 --> Helper loaded: form_helper
INFO - 2017-04-26 09:10:54 --> Helper loaded: html_helper
INFO - 2017-04-26 09:10:54 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:10:54 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:10:54 --> Database Driver Class Initialized
INFO - 2017-04-26 09:10:54 --> Parser Class Initialized
DEBUG - 2017-04-26 09:10:54 --> Session Class Initialized
INFO - 2017-04-26 09:10:54 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:10:54 --> Session routines successfully run
INFO - 2017-04-26 09:10:54 --> Form Validation Class Initialized
INFO - 2017-04-26 09:10:54 --> Controller Class Initialized
DEBUG - 2017-04-26 09:10:54 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:10:54 --> Model Class Initialized
DEBUG - 2017-04-26 09:10:54 --> Pagination Class Initialized
INFO - 2017-04-26 09:10:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:10:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:10:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 09:10:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:10:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:10:55 --> Final output sent to browser
DEBUG - 2017-04-26 09:10:55 --> Total execution time: 1.0347
INFO - 2017-04-26 09:10:58 --> Config Class Initialized
INFO - 2017-04-26 09:10:58 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:10:58 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:10:58 --> Utf8 Class Initialized
INFO - 2017-04-26 09:10:58 --> URI Class Initialized
INFO - 2017-04-26 09:10:58 --> Router Class Initialized
INFO - 2017-04-26 09:10:58 --> Output Class Initialized
INFO - 2017-04-26 09:10:58 --> Security Class Initialized
DEBUG - 2017-04-26 09:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:10:58 --> Input Class Initialized
INFO - 2017-04-26 09:10:58 --> Language Class Initialized
INFO - 2017-04-26 09:10:58 --> Loader Class Initialized
INFO - 2017-04-26 09:10:58 --> Helper loaded: url_helper
INFO - 2017-04-26 09:10:58 --> Helper loaded: form_helper
INFO - 2017-04-26 09:10:58 --> Helper loaded: html_helper
INFO - 2017-04-26 09:10:58 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:10:58 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:10:58 --> Database Driver Class Initialized
INFO - 2017-04-26 09:10:58 --> Parser Class Initialized
DEBUG - 2017-04-26 09:10:58 --> Session Class Initialized
INFO - 2017-04-26 09:10:58 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:10:58 --> Session routines successfully run
INFO - 2017-04-26 09:10:58 --> Form Validation Class Initialized
INFO - 2017-04-26 09:10:58 --> Controller Class Initialized
DEBUG - 2017-04-26 09:10:58 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:10:58 --> Model Class Initialized
DEBUG - 2017-04-26 09:10:58 --> Pagination Class Initialized
INFO - 2017-04-26 09:10:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:10:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:10:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 09:10:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:10:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:10:59 --> Final output sent to browser
DEBUG - 2017-04-26 09:10:59 --> Total execution time: 0.9447
INFO - 2017-04-26 09:11:52 --> Config Class Initialized
INFO - 2017-04-26 09:11:52 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:11:52 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:11:52 --> Utf8 Class Initialized
INFO - 2017-04-26 09:11:52 --> URI Class Initialized
INFO - 2017-04-26 09:11:52 --> Router Class Initialized
INFO - 2017-04-26 09:11:52 --> Output Class Initialized
INFO - 2017-04-26 09:11:52 --> Security Class Initialized
DEBUG - 2017-04-26 09:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:11:52 --> Input Class Initialized
INFO - 2017-04-26 09:11:52 --> Language Class Initialized
INFO - 2017-04-26 09:11:52 --> Loader Class Initialized
INFO - 2017-04-26 09:11:52 --> Helper loaded: url_helper
INFO - 2017-04-26 09:11:52 --> Helper loaded: form_helper
INFO - 2017-04-26 09:11:52 --> Helper loaded: html_helper
INFO - 2017-04-26 09:11:52 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:11:52 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:11:52 --> Database Driver Class Initialized
INFO - 2017-04-26 09:11:52 --> Parser Class Initialized
DEBUG - 2017-04-26 09:11:52 --> Session Class Initialized
INFO - 2017-04-26 09:11:52 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:11:52 --> Session routines successfully run
INFO - 2017-04-26 09:11:52 --> Form Validation Class Initialized
INFO - 2017-04-26 09:11:52 --> Controller Class Initialized
DEBUG - 2017-04-26 09:11:52 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:11:52 --> Model Class Initialized
DEBUG - 2017-04-26 09:11:52 --> Pagination Class Initialized
INFO - 2017-04-26 09:12:00 --> Config Class Initialized
INFO - 2017-04-26 09:12:00 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:12:00 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:12:00 --> Utf8 Class Initialized
INFO - 2017-04-26 09:12:00 --> URI Class Initialized
INFO - 2017-04-26 09:12:00 --> Router Class Initialized
INFO - 2017-04-26 09:12:00 --> Output Class Initialized
INFO - 2017-04-26 09:12:00 --> Security Class Initialized
DEBUG - 2017-04-26 09:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:12:00 --> Input Class Initialized
INFO - 2017-04-26 09:12:00 --> Language Class Initialized
INFO - 2017-04-26 09:12:00 --> Loader Class Initialized
INFO - 2017-04-26 09:12:00 --> Helper loaded: url_helper
INFO - 2017-04-26 09:12:00 --> Helper loaded: form_helper
INFO - 2017-04-26 09:12:00 --> Helper loaded: html_helper
INFO - 2017-04-26 09:12:00 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:12:00 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:12:00 --> Database Driver Class Initialized
INFO - 2017-04-26 09:12:00 --> Parser Class Initialized
DEBUG - 2017-04-26 09:12:00 --> Session Class Initialized
INFO - 2017-04-26 09:12:00 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:12:00 --> Session routines successfully run
INFO - 2017-04-26 09:12:00 --> Form Validation Class Initialized
INFO - 2017-04-26 09:12:00 --> Controller Class Initialized
DEBUG - 2017-04-26 09:12:00 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:12:00 --> Model Class Initialized
DEBUG - 2017-04-26 09:12:00 --> Pagination Class Initialized
INFO - 2017-04-26 09:13:56 --> Config Class Initialized
INFO - 2017-04-26 09:13:56 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:13:56 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:13:56 --> Utf8 Class Initialized
INFO - 2017-04-26 09:13:56 --> URI Class Initialized
INFO - 2017-04-26 09:13:56 --> Router Class Initialized
INFO - 2017-04-26 09:13:56 --> Output Class Initialized
INFO - 2017-04-26 09:13:56 --> Security Class Initialized
DEBUG - 2017-04-26 09:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:13:56 --> Input Class Initialized
INFO - 2017-04-26 09:13:56 --> Language Class Initialized
INFO - 2017-04-26 09:13:56 --> Loader Class Initialized
INFO - 2017-04-26 09:13:56 --> Helper loaded: url_helper
INFO - 2017-04-26 09:13:56 --> Helper loaded: form_helper
INFO - 2017-04-26 09:13:56 --> Helper loaded: html_helper
INFO - 2017-04-26 09:13:56 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:13:56 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:13:56 --> Database Driver Class Initialized
INFO - 2017-04-26 09:13:56 --> Parser Class Initialized
DEBUG - 2017-04-26 09:13:56 --> Session Class Initialized
INFO - 2017-04-26 09:13:56 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:13:56 --> Session routines successfully run
INFO - 2017-04-26 09:13:56 --> Form Validation Class Initialized
INFO - 2017-04-26 09:13:57 --> Controller Class Initialized
DEBUG - 2017-04-26 09:13:57 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:13:57 --> Model Class Initialized
DEBUG - 2017-04-26 09:13:57 --> Pagination Class Initialized
INFO - 2017-04-26 09:14:15 --> Config Class Initialized
INFO - 2017-04-26 09:14:15 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:14:15 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:14:15 --> Utf8 Class Initialized
INFO - 2017-04-26 09:14:15 --> URI Class Initialized
INFO - 2017-04-26 09:14:15 --> Router Class Initialized
INFO - 2017-04-26 09:14:15 --> Output Class Initialized
INFO - 2017-04-26 09:14:15 --> Security Class Initialized
DEBUG - 2017-04-26 09:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:14:15 --> Input Class Initialized
INFO - 2017-04-26 09:14:15 --> Language Class Initialized
INFO - 2017-04-26 09:14:15 --> Loader Class Initialized
INFO - 2017-04-26 09:14:15 --> Helper loaded: url_helper
INFO - 2017-04-26 09:14:15 --> Helper loaded: form_helper
INFO - 2017-04-26 09:14:15 --> Helper loaded: html_helper
INFO - 2017-04-26 09:14:15 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:14:15 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:14:15 --> Database Driver Class Initialized
INFO - 2017-04-26 09:14:15 --> Parser Class Initialized
DEBUG - 2017-04-26 09:14:15 --> Session Class Initialized
INFO - 2017-04-26 09:14:15 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:14:15 --> Session routines successfully run
INFO - 2017-04-26 09:14:15 --> Form Validation Class Initialized
INFO - 2017-04-26 09:14:15 --> Controller Class Initialized
DEBUG - 2017-04-26 09:14:15 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:14:15 --> Model Class Initialized
DEBUG - 2017-04-26 09:14:15 --> Pagination Class Initialized
INFO - 2017-04-26 09:14:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:14:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:14:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:14:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:14:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:14:15 --> Final output sent to browser
DEBUG - 2017-04-26 09:14:15 --> Total execution time: 0.3697
INFO - 2017-04-26 09:17:16 --> Config Class Initialized
INFO - 2017-04-26 09:17:16 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:17:16 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:17:16 --> Utf8 Class Initialized
INFO - 2017-04-26 09:17:16 --> URI Class Initialized
INFO - 2017-04-26 09:17:16 --> Router Class Initialized
INFO - 2017-04-26 09:17:17 --> Output Class Initialized
INFO - 2017-04-26 09:17:17 --> Security Class Initialized
DEBUG - 2017-04-26 09:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:17:17 --> Input Class Initialized
INFO - 2017-04-26 09:17:17 --> Language Class Initialized
INFO - 2017-04-26 09:17:17 --> Loader Class Initialized
INFO - 2017-04-26 09:17:17 --> Helper loaded: url_helper
INFO - 2017-04-26 09:17:17 --> Helper loaded: form_helper
INFO - 2017-04-26 09:17:17 --> Helper loaded: html_helper
INFO - 2017-04-26 09:17:17 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:17:17 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:17:17 --> Database Driver Class Initialized
INFO - 2017-04-26 09:17:17 --> Parser Class Initialized
DEBUG - 2017-04-26 09:17:17 --> Session Class Initialized
INFO - 2017-04-26 09:17:17 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:17:17 --> Session routines successfully run
INFO - 2017-04-26 09:17:17 --> Form Validation Class Initialized
INFO - 2017-04-26 09:17:17 --> Controller Class Initialized
DEBUG - 2017-04-26 09:17:17 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:17:17 --> Model Class Initialized
DEBUG - 2017-04-26 09:17:17 --> Pagination Class Initialized
INFO - 2017-04-26 09:17:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:17:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:17:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 09:17:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:17:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:17:20 --> Final output sent to browser
DEBUG - 2017-04-26 09:17:20 --> Total execution time: 3.3403
INFO - 2017-04-26 09:17:21 --> Config Class Initialized
INFO - 2017-04-26 09:17:21 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:17:21 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:17:21 --> Utf8 Class Initialized
INFO - 2017-04-26 09:17:21 --> URI Class Initialized
INFO - 2017-04-26 09:17:21 --> Router Class Initialized
INFO - 2017-04-26 09:17:22 --> Output Class Initialized
INFO - 2017-04-26 09:17:22 --> Security Class Initialized
DEBUG - 2017-04-26 09:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:17:22 --> Input Class Initialized
INFO - 2017-04-26 09:17:22 --> Language Class Initialized
INFO - 2017-04-26 09:17:22 --> Loader Class Initialized
INFO - 2017-04-26 09:17:22 --> Helper loaded: url_helper
INFO - 2017-04-26 09:17:22 --> Helper loaded: form_helper
INFO - 2017-04-26 09:17:22 --> Helper loaded: html_helper
INFO - 2017-04-26 09:17:22 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:17:22 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:17:22 --> Database Driver Class Initialized
INFO - 2017-04-26 09:17:22 --> Parser Class Initialized
DEBUG - 2017-04-26 09:17:22 --> Session Class Initialized
INFO - 2017-04-26 09:17:22 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:17:22 --> Session routines successfully run
INFO - 2017-04-26 09:17:22 --> Form Validation Class Initialized
INFO - 2017-04-26 09:17:22 --> Controller Class Initialized
DEBUG - 2017-04-26 09:17:22 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:17:22 --> Model Class Initialized
DEBUG - 2017-04-26 09:17:22 --> Pagination Class Initialized
INFO - 2017-04-26 09:17:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:17:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:17:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:17:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:17:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:17:22 --> Final output sent to browser
DEBUG - 2017-04-26 09:17:22 --> Total execution time: 0.5454
INFO - 2017-04-26 09:17:30 --> Config Class Initialized
INFO - 2017-04-26 09:17:30 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:17:30 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:17:30 --> Utf8 Class Initialized
INFO - 2017-04-26 09:17:30 --> URI Class Initialized
INFO - 2017-04-26 09:17:30 --> Router Class Initialized
INFO - 2017-04-26 09:17:30 --> Output Class Initialized
INFO - 2017-04-26 09:17:30 --> Security Class Initialized
DEBUG - 2017-04-26 09:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:17:30 --> Input Class Initialized
INFO - 2017-04-26 09:17:30 --> Language Class Initialized
INFO - 2017-04-26 09:17:30 --> Loader Class Initialized
INFO - 2017-04-26 09:17:30 --> Helper loaded: url_helper
INFO - 2017-04-26 09:17:30 --> Helper loaded: form_helper
INFO - 2017-04-26 09:17:30 --> Helper loaded: html_helper
INFO - 2017-04-26 09:17:30 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:17:31 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:17:31 --> Database Driver Class Initialized
INFO - 2017-04-26 09:17:31 --> Parser Class Initialized
DEBUG - 2017-04-26 09:17:31 --> Session Class Initialized
INFO - 2017-04-26 09:17:31 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:17:31 --> Session routines successfully run
INFO - 2017-04-26 09:17:31 --> Form Validation Class Initialized
INFO - 2017-04-26 09:17:31 --> Controller Class Initialized
DEBUG - 2017-04-26 09:17:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:17:31 --> Model Class Initialized
DEBUG - 2017-04-26 09:17:31 --> Pagination Class Initialized
INFO - 2017-04-26 09:17:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:17:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:17:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:17:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:17:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:17:31 --> Final output sent to browser
DEBUG - 2017-04-26 09:17:31 --> Total execution time: 0.3689
INFO - 2017-04-26 09:19:25 --> Config Class Initialized
INFO - 2017-04-26 09:19:25 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:19:25 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:19:25 --> Utf8 Class Initialized
INFO - 2017-04-26 09:19:25 --> URI Class Initialized
INFO - 2017-04-26 09:19:25 --> Router Class Initialized
INFO - 2017-04-26 09:19:25 --> Output Class Initialized
INFO - 2017-04-26 09:19:25 --> Security Class Initialized
DEBUG - 2017-04-26 09:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:19:25 --> Input Class Initialized
INFO - 2017-04-26 09:19:25 --> Language Class Initialized
INFO - 2017-04-26 09:19:25 --> Loader Class Initialized
INFO - 2017-04-26 09:19:25 --> Helper loaded: url_helper
INFO - 2017-04-26 09:19:25 --> Helper loaded: form_helper
INFO - 2017-04-26 09:19:25 --> Helper loaded: html_helper
INFO - 2017-04-26 09:19:25 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:19:25 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:19:25 --> Database Driver Class Initialized
INFO - 2017-04-26 09:19:25 --> Parser Class Initialized
DEBUG - 2017-04-26 09:19:25 --> Session Class Initialized
INFO - 2017-04-26 09:19:25 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:19:25 --> Session routines successfully run
INFO - 2017-04-26 09:19:25 --> Form Validation Class Initialized
INFO - 2017-04-26 09:19:25 --> Controller Class Initialized
DEBUG - 2017-04-26 09:19:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:19:25 --> Model Class Initialized
DEBUG - 2017-04-26 09:19:25 --> Pagination Class Initialized
INFO - 2017-04-26 09:19:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:19:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:19:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:19:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:19:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:19:25 --> Final output sent to browser
DEBUG - 2017-04-26 09:19:25 --> Total execution time: 0.3967
INFO - 2017-04-26 09:20:18 --> Config Class Initialized
INFO - 2017-04-26 09:20:18 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:20:18 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:20:18 --> Utf8 Class Initialized
INFO - 2017-04-26 09:20:18 --> URI Class Initialized
INFO - 2017-04-26 09:20:18 --> Router Class Initialized
INFO - 2017-04-26 09:20:18 --> Output Class Initialized
INFO - 2017-04-26 09:20:18 --> Security Class Initialized
DEBUG - 2017-04-26 09:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:20:18 --> Input Class Initialized
INFO - 2017-04-26 09:20:18 --> Language Class Initialized
INFO - 2017-04-26 09:20:18 --> Loader Class Initialized
INFO - 2017-04-26 09:20:18 --> Helper loaded: url_helper
INFO - 2017-04-26 09:20:18 --> Helper loaded: form_helper
INFO - 2017-04-26 09:20:18 --> Helper loaded: html_helper
INFO - 2017-04-26 09:20:18 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:20:18 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:20:18 --> Database Driver Class Initialized
INFO - 2017-04-26 09:20:18 --> Parser Class Initialized
DEBUG - 2017-04-26 09:20:18 --> Session Class Initialized
INFO - 2017-04-26 09:20:18 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:20:18 --> Session routines successfully run
INFO - 2017-04-26 09:20:18 --> Form Validation Class Initialized
INFO - 2017-04-26 09:20:18 --> Controller Class Initialized
DEBUG - 2017-04-26 09:20:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:20:18 --> Model Class Initialized
DEBUG - 2017-04-26 09:20:18 --> Pagination Class Initialized
INFO - 2017-04-26 09:20:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:20:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
ERROR - 2017-04-26 09:20:18 --> Severity: Notice --> Undefined property: stdClass::$companY_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 50
INFO - 2017-04-26 09:20:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:20:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:20:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:20:18 --> Final output sent to browser
DEBUG - 2017-04-26 09:20:18 --> Total execution time: 0.6297
INFO - 2017-04-26 09:20:34 --> Config Class Initialized
INFO - 2017-04-26 09:20:34 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:20:34 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:20:34 --> Utf8 Class Initialized
INFO - 2017-04-26 09:20:34 --> URI Class Initialized
INFO - 2017-04-26 09:20:34 --> Router Class Initialized
INFO - 2017-04-26 09:20:34 --> Output Class Initialized
INFO - 2017-04-26 09:20:34 --> Security Class Initialized
DEBUG - 2017-04-26 09:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:20:34 --> Input Class Initialized
INFO - 2017-04-26 09:20:34 --> Language Class Initialized
INFO - 2017-04-26 09:20:34 --> Loader Class Initialized
INFO - 2017-04-26 09:20:34 --> Helper loaded: url_helper
INFO - 2017-04-26 09:20:34 --> Helper loaded: form_helper
INFO - 2017-04-26 09:20:34 --> Helper loaded: html_helper
INFO - 2017-04-26 09:20:35 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:20:35 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:20:35 --> Database Driver Class Initialized
INFO - 2017-04-26 09:20:35 --> Parser Class Initialized
DEBUG - 2017-04-26 09:20:35 --> Session Class Initialized
INFO - 2017-04-26 09:20:35 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:20:35 --> Session routines successfully run
INFO - 2017-04-26 09:20:35 --> Form Validation Class Initialized
INFO - 2017-04-26 09:20:35 --> Controller Class Initialized
DEBUG - 2017-04-26 09:20:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:20:35 --> Model Class Initialized
DEBUG - 2017-04-26 09:20:35 --> Pagination Class Initialized
INFO - 2017-04-26 09:20:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:20:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:20:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:20:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:20:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:20:35 --> Final output sent to browser
DEBUG - 2017-04-26 09:20:35 --> Total execution time: 0.3704
INFO - 2017-04-26 09:21:10 --> Config Class Initialized
INFO - 2017-04-26 09:21:10 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:21:10 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:21:10 --> Utf8 Class Initialized
INFO - 2017-04-26 09:21:10 --> URI Class Initialized
INFO - 2017-04-26 09:21:10 --> Router Class Initialized
INFO - 2017-04-26 09:21:10 --> Output Class Initialized
INFO - 2017-04-26 09:21:10 --> Security Class Initialized
DEBUG - 2017-04-26 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:21:10 --> Input Class Initialized
INFO - 2017-04-26 09:21:10 --> Language Class Initialized
INFO - 2017-04-26 09:21:10 --> Loader Class Initialized
INFO - 2017-04-26 09:21:10 --> Helper loaded: url_helper
INFO - 2017-04-26 09:21:10 --> Helper loaded: form_helper
INFO - 2017-04-26 09:21:10 --> Helper loaded: html_helper
INFO - 2017-04-26 09:21:10 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:21:10 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:21:10 --> Database Driver Class Initialized
INFO - 2017-04-26 09:21:10 --> Parser Class Initialized
DEBUG - 2017-04-26 09:21:10 --> Session Class Initialized
INFO - 2017-04-26 09:21:10 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:21:10 --> Session routines successfully run
INFO - 2017-04-26 09:21:10 --> Form Validation Class Initialized
INFO - 2017-04-26 09:21:10 --> Controller Class Initialized
DEBUG - 2017-04-26 09:21:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:21:11 --> Model Class Initialized
DEBUG - 2017-04-26 09:21:11 --> Pagination Class Initialized
INFO - 2017-04-26 09:21:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:21:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:21:12 --> Config Class Initialized
INFO - 2017-04-26 09:21:12 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:21:12 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:21:12 --> Utf8 Class Initialized
INFO - 2017-04-26 09:21:12 --> URI Class Initialized
INFO - 2017-04-26 09:21:12 --> Router Class Initialized
INFO - 2017-04-26 09:21:13 --> Output Class Initialized
INFO - 2017-04-26 09:21:13 --> Security Class Initialized
DEBUG - 2017-04-26 09:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:21:13 --> Input Class Initialized
INFO - 2017-04-26 09:21:13 --> Language Class Initialized
INFO - 2017-04-26 09:21:13 --> Loader Class Initialized
INFO - 2017-04-26 09:21:13 --> Helper loaded: url_helper
INFO - 2017-04-26 09:21:13 --> Helper loaded: form_helper
INFO - 2017-04-26 09:21:13 --> Helper loaded: html_helper
INFO - 2017-04-26 09:21:13 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:21:13 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:21:13 --> Database Driver Class Initialized
INFO - 2017-04-26 09:21:13 --> Parser Class Initialized
DEBUG - 2017-04-26 09:21:13 --> Session Class Initialized
INFO - 2017-04-26 09:21:13 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:21:13 --> Session routines successfully run
INFO - 2017-04-26 09:21:13 --> Form Validation Class Initialized
INFO - 2017-04-26 09:21:13 --> Controller Class Initialized
DEBUG - 2017-04-26 09:21:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:21:13 --> Model Class Initialized
DEBUG - 2017-04-26 09:21:13 --> Pagination Class Initialized
INFO - 2017-04-26 09:21:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:21:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:21:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:21:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:21:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:21:13 --> Final output sent to browser
DEBUG - 2017-04-26 09:21:13 --> Total execution time: 0.6399
INFO - 2017-04-26 09:21:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 09:21:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:21:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:21:14 --> Final output sent to browser
DEBUG - 2017-04-26 09:21:14 --> Total execution time: 3.4259
INFO - 2017-04-26 09:22:15 --> Config Class Initialized
INFO - 2017-04-26 09:22:15 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:22:15 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:22:15 --> Utf8 Class Initialized
INFO - 2017-04-26 09:22:15 --> URI Class Initialized
INFO - 2017-04-26 09:22:15 --> Router Class Initialized
INFO - 2017-04-26 09:22:15 --> Output Class Initialized
INFO - 2017-04-26 09:22:15 --> Security Class Initialized
DEBUG - 2017-04-26 09:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:22:16 --> Input Class Initialized
INFO - 2017-04-26 09:22:16 --> Language Class Initialized
INFO - 2017-04-26 09:22:16 --> Loader Class Initialized
INFO - 2017-04-26 09:22:16 --> Helper loaded: url_helper
INFO - 2017-04-26 09:22:16 --> Helper loaded: form_helper
INFO - 2017-04-26 09:22:16 --> Helper loaded: html_helper
INFO - 2017-04-26 09:22:16 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:22:16 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:22:16 --> Database Driver Class Initialized
INFO - 2017-04-26 09:22:16 --> Parser Class Initialized
DEBUG - 2017-04-26 09:22:16 --> Session Class Initialized
INFO - 2017-04-26 09:22:16 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:22:16 --> Session routines successfully run
INFO - 2017-04-26 09:22:16 --> Form Validation Class Initialized
INFO - 2017-04-26 09:22:16 --> Controller Class Initialized
DEBUG - 2017-04-26 09:22:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:22:16 --> Model Class Initialized
DEBUG - 2017-04-26 09:22:16 --> Pagination Class Initialized
INFO - 2017-04-26 09:22:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:22:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:22:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:22:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:22:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:22:16 --> Final output sent to browser
DEBUG - 2017-04-26 09:22:16 --> Total execution time: 0.4329
INFO - 2017-04-26 09:22:21 --> Config Class Initialized
INFO - 2017-04-26 09:22:21 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:22:21 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:22:21 --> Utf8 Class Initialized
INFO - 2017-04-26 09:22:21 --> URI Class Initialized
INFO - 2017-04-26 09:22:21 --> Router Class Initialized
INFO - 2017-04-26 09:22:21 --> Output Class Initialized
INFO - 2017-04-26 09:22:21 --> Security Class Initialized
DEBUG - 2017-04-26 09:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:22:21 --> Input Class Initialized
INFO - 2017-04-26 09:22:21 --> Language Class Initialized
INFO - 2017-04-26 09:22:21 --> Loader Class Initialized
INFO - 2017-04-26 09:22:21 --> Helper loaded: url_helper
INFO - 2017-04-26 09:22:21 --> Helper loaded: form_helper
INFO - 2017-04-26 09:22:21 --> Helper loaded: html_helper
INFO - 2017-04-26 09:22:21 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:22:21 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:22:21 --> Database Driver Class Initialized
INFO - 2017-04-26 09:22:22 --> Parser Class Initialized
DEBUG - 2017-04-26 09:22:22 --> Session Class Initialized
INFO - 2017-04-26 09:22:22 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:22:22 --> Session routines successfully run
INFO - 2017-04-26 09:22:22 --> Form Validation Class Initialized
INFO - 2017-04-26 09:22:22 --> Controller Class Initialized
DEBUG - 2017-04-26 09:22:22 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:22:22 --> Model Class Initialized
DEBUG - 2017-04-26 09:22:22 --> Pagination Class Initialized
INFO - 2017-04-26 09:22:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:22:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:22:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:22:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:22:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:22:22 --> Final output sent to browser
DEBUG - 2017-04-26 09:22:22 --> Total execution time: 0.3949
INFO - 2017-04-26 09:22:36 --> Config Class Initialized
INFO - 2017-04-26 09:22:36 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:22:36 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:22:36 --> Utf8 Class Initialized
INFO - 2017-04-26 09:22:36 --> URI Class Initialized
INFO - 2017-04-26 09:22:36 --> Router Class Initialized
INFO - 2017-04-26 09:22:36 --> Output Class Initialized
INFO - 2017-04-26 09:22:36 --> Security Class Initialized
DEBUG - 2017-04-26 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:22:36 --> Input Class Initialized
INFO - 2017-04-26 09:22:36 --> Language Class Initialized
INFO - 2017-04-26 09:22:36 --> Loader Class Initialized
INFO - 2017-04-26 09:22:36 --> Helper loaded: url_helper
INFO - 2017-04-26 09:22:36 --> Helper loaded: form_helper
INFO - 2017-04-26 09:22:36 --> Helper loaded: html_helper
INFO - 2017-04-26 09:22:36 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:22:36 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:22:36 --> Database Driver Class Initialized
INFO - 2017-04-26 09:22:36 --> Parser Class Initialized
DEBUG - 2017-04-26 09:22:36 --> Session Class Initialized
INFO - 2017-04-26 09:22:36 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:22:36 --> Session routines successfully run
INFO - 2017-04-26 09:22:36 --> Form Validation Class Initialized
INFO - 2017-04-26 09:22:36 --> Controller Class Initialized
DEBUG - 2017-04-26 09:22:36 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:22:36 --> Model Class Initialized
INFO - 2017-04-26 09:22:36 --> Config Class Initialized
INFO - 2017-04-26 09:22:36 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:22:36 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:22:36 --> Utf8 Class Initialized
INFO - 2017-04-26 09:22:36 --> URI Class Initialized
INFO - 2017-04-26 09:22:36 --> Router Class Initialized
INFO - 2017-04-26 09:22:36 --> Output Class Initialized
INFO - 2017-04-26 09:22:36 --> Security Class Initialized
DEBUG - 2017-04-26 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:22:36 --> Input Class Initialized
INFO - 2017-04-26 09:22:36 --> Language Class Initialized
INFO - 2017-04-26 09:22:36 --> Loader Class Initialized
INFO - 2017-04-26 09:22:36 --> Helper loaded: url_helper
INFO - 2017-04-26 09:22:36 --> Helper loaded: form_helper
INFO - 2017-04-26 09:22:36 --> Helper loaded: html_helper
INFO - 2017-04-26 09:22:36 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:22:36 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:22:36 --> Database Driver Class Initialized
INFO - 2017-04-26 09:22:36 --> Parser Class Initialized
DEBUG - 2017-04-26 09:22:36 --> Session Class Initialized
INFO - 2017-04-26 09:22:36 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:22:36 --> Session routines successfully run
INFO - 2017-04-26 09:22:36 --> Form Validation Class Initialized
INFO - 2017-04-26 09:22:36 --> Controller Class Initialized
DEBUG - 2017-04-26 09:22:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:22:37 --> Model Class Initialized
DEBUG - 2017-04-26 09:22:37 --> Pagination Class Initialized
INFO - 2017-04-26 09:22:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:22:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:22:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-26 09:22:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:22:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:22:37 --> Final output sent to browser
DEBUG - 2017-04-26 09:22:37 --> Total execution time: 0.3625
INFO - 2017-04-26 09:22:37 --> Config Class Initialized
INFO - 2017-04-26 09:22:37 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:22:37 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:22:37 --> Utf8 Class Initialized
INFO - 2017-04-26 09:22:37 --> URI Class Initialized
INFO - 2017-04-26 09:22:37 --> Router Class Initialized
INFO - 2017-04-26 09:22:37 --> Output Class Initialized
INFO - 2017-04-26 09:22:37 --> Security Class Initialized
DEBUG - 2017-04-26 09:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:22:37 --> Input Class Initialized
INFO - 2017-04-26 09:22:37 --> Language Class Initialized
ERROR - 2017-04-26 09:22:37 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 09:24:07 --> Config Class Initialized
INFO - 2017-04-26 09:24:07 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:24:07 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:24:07 --> Utf8 Class Initialized
INFO - 2017-04-26 09:24:07 --> URI Class Initialized
INFO - 2017-04-26 09:24:07 --> Router Class Initialized
INFO - 2017-04-26 09:24:07 --> Output Class Initialized
INFO - 2017-04-26 09:24:07 --> Security Class Initialized
DEBUG - 2017-04-26 09:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:24:07 --> Input Class Initialized
INFO - 2017-04-26 09:24:07 --> Language Class Initialized
INFO - 2017-04-26 09:24:07 --> Loader Class Initialized
INFO - 2017-04-26 09:24:07 --> Helper loaded: url_helper
INFO - 2017-04-26 09:24:07 --> Helper loaded: form_helper
INFO - 2017-04-26 09:24:07 --> Helper loaded: html_helper
INFO - 2017-04-26 09:24:07 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:24:07 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:24:07 --> Database Driver Class Initialized
INFO - 2017-04-26 09:24:07 --> Parser Class Initialized
DEBUG - 2017-04-26 09:24:07 --> Session Class Initialized
INFO - 2017-04-26 09:24:07 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:24:07 --> Session routines successfully run
INFO - 2017-04-26 09:24:07 --> Form Validation Class Initialized
INFO - 2017-04-26 09:24:07 --> Controller Class Initialized
DEBUG - 2017-04-26 09:24:07 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:24:07 --> Model Class Initialized
DEBUG - 2017-04-26 09:24:07 --> Pagination Class Initialized
INFO - 2017-04-26 09:24:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:24:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:24:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-26 09:24:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:24:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:24:07 --> Final output sent to browser
DEBUG - 2017-04-26 09:24:07 --> Total execution time: 0.3545
INFO - 2017-04-26 09:24:08 --> Config Class Initialized
INFO - 2017-04-26 09:24:08 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:24:08 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:24:08 --> Utf8 Class Initialized
INFO - 2017-04-26 09:24:08 --> URI Class Initialized
INFO - 2017-04-26 09:24:08 --> Router Class Initialized
INFO - 2017-04-26 09:24:08 --> Output Class Initialized
INFO - 2017-04-26 09:24:08 --> Security Class Initialized
DEBUG - 2017-04-26 09:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:24:08 --> Input Class Initialized
INFO - 2017-04-26 09:24:08 --> Language Class Initialized
ERROR - 2017-04-26 09:24:08 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 09:24:12 --> Config Class Initialized
INFO - 2017-04-26 09:24:12 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:24:12 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:24:12 --> Utf8 Class Initialized
INFO - 2017-04-26 09:24:12 --> URI Class Initialized
INFO - 2017-04-26 09:24:12 --> Router Class Initialized
INFO - 2017-04-26 09:24:12 --> Output Class Initialized
INFO - 2017-04-26 09:24:12 --> Security Class Initialized
DEBUG - 2017-04-26 09:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:24:12 --> Input Class Initialized
INFO - 2017-04-26 09:24:12 --> Language Class Initialized
INFO - 2017-04-26 09:24:12 --> Loader Class Initialized
INFO - 2017-04-26 09:24:12 --> Helper loaded: url_helper
INFO - 2017-04-26 09:24:12 --> Helper loaded: form_helper
INFO - 2017-04-26 09:24:12 --> Helper loaded: html_helper
INFO - 2017-04-26 09:24:12 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:24:12 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:24:12 --> Database Driver Class Initialized
INFO - 2017-04-26 09:24:12 --> Parser Class Initialized
DEBUG - 2017-04-26 09:24:12 --> Session Class Initialized
INFO - 2017-04-26 09:24:12 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:24:12 --> Session routines successfully run
INFO - 2017-04-26 09:24:12 --> Form Validation Class Initialized
INFO - 2017-04-26 09:24:12 --> Controller Class Initialized
DEBUG - 2017-04-26 09:24:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:24:12 --> Model Class Initialized
DEBUG - 2017-04-26 09:24:12 --> Pagination Class Initialized
INFO - 2017-04-26 09:24:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:24:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:24:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:24:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:24:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:24:12 --> Final output sent to browser
DEBUG - 2017-04-26 09:24:12 --> Total execution time: 0.3936
INFO - 2017-04-26 09:24:13 --> Config Class Initialized
INFO - 2017-04-26 09:24:13 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:24:13 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:24:13 --> Utf8 Class Initialized
INFO - 2017-04-26 09:24:13 --> URI Class Initialized
INFO - 2017-04-26 09:24:13 --> Router Class Initialized
INFO - 2017-04-26 09:24:13 --> Output Class Initialized
INFO - 2017-04-26 09:24:13 --> Security Class Initialized
DEBUG - 2017-04-26 09:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:24:13 --> Input Class Initialized
INFO - 2017-04-26 09:24:13 --> Language Class Initialized
ERROR - 2017-04-26 09:24:13 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 09:24:22 --> Config Class Initialized
INFO - 2017-04-26 09:24:22 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:24:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:24:23 --> Utf8 Class Initialized
INFO - 2017-04-26 09:24:23 --> URI Class Initialized
INFO - 2017-04-26 09:24:23 --> Router Class Initialized
INFO - 2017-04-26 09:24:23 --> Output Class Initialized
INFO - 2017-04-26 09:24:23 --> Security Class Initialized
DEBUG - 2017-04-26 09:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:24:23 --> Input Class Initialized
INFO - 2017-04-26 09:24:23 --> Language Class Initialized
INFO - 2017-04-26 09:24:23 --> Loader Class Initialized
INFO - 2017-04-26 09:24:23 --> Helper loaded: url_helper
INFO - 2017-04-26 09:24:23 --> Helper loaded: form_helper
INFO - 2017-04-26 09:24:23 --> Helper loaded: html_helper
INFO - 2017-04-26 09:24:23 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:24:23 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:24:23 --> Database Driver Class Initialized
INFO - 2017-04-26 09:24:23 --> Parser Class Initialized
DEBUG - 2017-04-26 09:24:23 --> Session Class Initialized
INFO - 2017-04-26 09:24:23 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:24:23 --> Session routines successfully run
INFO - 2017-04-26 09:24:23 --> Form Validation Class Initialized
INFO - 2017-04-26 09:24:23 --> Controller Class Initialized
DEBUG - 2017-04-26 09:24:23 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:24:23 --> Model Class Initialized
DEBUG - 2017-04-26 09:24:23 --> Pagination Class Initialized
INFO - 2017-04-26 09:24:23 --> Config Class Initialized
INFO - 2017-04-26 09:24:23 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:24:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:24:23 --> Utf8 Class Initialized
INFO - 2017-04-26 09:24:23 --> URI Class Initialized
INFO - 2017-04-26 09:24:23 --> Router Class Initialized
INFO - 2017-04-26 09:24:23 --> Output Class Initialized
INFO - 2017-04-26 09:24:23 --> Security Class Initialized
DEBUG - 2017-04-26 09:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:24:23 --> Input Class Initialized
INFO - 2017-04-26 09:24:23 --> Language Class Initialized
INFO - 2017-04-26 09:24:23 --> Loader Class Initialized
INFO - 2017-04-26 09:24:23 --> Helper loaded: url_helper
INFO - 2017-04-26 09:24:23 --> Helper loaded: form_helper
INFO - 2017-04-26 09:24:23 --> Helper loaded: html_helper
INFO - 2017-04-26 09:24:23 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:24:23 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:24:23 --> Database Driver Class Initialized
INFO - 2017-04-26 09:24:23 --> Parser Class Initialized
DEBUG - 2017-04-26 09:24:23 --> Session Class Initialized
INFO - 2017-04-26 09:24:23 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:24:23 --> Session routines successfully run
INFO - 2017-04-26 09:24:23 --> Form Validation Class Initialized
INFO - 2017-04-26 09:24:23 --> Controller Class Initialized
DEBUG - 2017-04-26 09:24:23 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:24:23 --> Model Class Initialized
DEBUG - 2017-04-26 09:24:23 --> Pagination Class Initialized
INFO - 2017-04-26 09:24:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:24:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:24:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 09:24:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:24:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:24:26 --> Final output sent to browser
DEBUG - 2017-04-26 09:24:26 --> Total execution time: 3.4365
INFO - 2017-04-26 09:24:27 --> Config Class Initialized
INFO - 2017-04-26 09:24:27 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:24:27 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:24:27 --> Utf8 Class Initialized
INFO - 2017-04-26 09:24:27 --> URI Class Initialized
INFO - 2017-04-26 09:24:27 --> Router Class Initialized
INFO - 2017-04-26 09:24:27 --> Output Class Initialized
INFO - 2017-04-26 09:24:27 --> Security Class Initialized
DEBUG - 2017-04-26 09:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:24:27 --> Input Class Initialized
INFO - 2017-04-26 09:24:27 --> Language Class Initialized
ERROR - 2017-04-26 09:24:27 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 09:24:29 --> Config Class Initialized
INFO - 2017-04-26 09:24:29 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:24:30 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:24:30 --> Utf8 Class Initialized
INFO - 2017-04-26 09:24:30 --> URI Class Initialized
INFO - 2017-04-26 09:24:30 --> Router Class Initialized
INFO - 2017-04-26 09:24:30 --> Output Class Initialized
INFO - 2017-04-26 09:24:30 --> Security Class Initialized
DEBUG - 2017-04-26 09:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:24:30 --> Input Class Initialized
INFO - 2017-04-26 09:24:30 --> Language Class Initialized
INFO - 2017-04-26 09:24:30 --> Loader Class Initialized
INFO - 2017-04-26 09:24:30 --> Helper loaded: url_helper
INFO - 2017-04-26 09:24:30 --> Helper loaded: form_helper
INFO - 2017-04-26 09:24:30 --> Helper loaded: html_helper
INFO - 2017-04-26 09:24:30 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:24:30 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:24:30 --> Database Driver Class Initialized
INFO - 2017-04-26 09:24:30 --> Parser Class Initialized
DEBUG - 2017-04-26 09:24:30 --> Session Class Initialized
INFO - 2017-04-26 09:24:30 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:24:30 --> Session routines successfully run
INFO - 2017-04-26 09:24:30 --> Form Validation Class Initialized
INFO - 2017-04-26 09:24:30 --> Controller Class Initialized
DEBUG - 2017-04-26 09:24:30 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:24:30 --> Model Class Initialized
DEBUG - 2017-04-26 09:24:30 --> Pagination Class Initialized
INFO - 2017-04-26 09:24:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:24:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:24:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:24:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:24:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:24:30 --> Final output sent to browser
DEBUG - 2017-04-26 09:24:30 --> Total execution time: 0.4101
INFO - 2017-04-26 09:24:30 --> Config Class Initialized
INFO - 2017-04-26 09:24:30 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:24:30 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:24:30 --> Utf8 Class Initialized
INFO - 2017-04-26 09:24:30 --> URI Class Initialized
INFO - 2017-04-26 09:24:30 --> Router Class Initialized
INFO - 2017-04-26 09:24:30 --> Output Class Initialized
INFO - 2017-04-26 09:24:30 --> Security Class Initialized
DEBUG - 2017-04-26 09:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:24:30 --> Input Class Initialized
INFO - 2017-04-26 09:24:30 --> Language Class Initialized
ERROR - 2017-04-26 09:24:30 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 09:24:55 --> Config Class Initialized
INFO - 2017-04-26 09:24:55 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:24:55 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:24:55 --> Utf8 Class Initialized
INFO - 2017-04-26 09:24:55 --> URI Class Initialized
INFO - 2017-04-26 09:24:55 --> Router Class Initialized
INFO - 2017-04-26 09:24:55 --> Output Class Initialized
INFO - 2017-04-26 09:24:55 --> Security Class Initialized
DEBUG - 2017-04-26 09:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:24:55 --> Input Class Initialized
INFO - 2017-04-26 09:24:55 --> Language Class Initialized
INFO - 2017-04-26 09:24:55 --> Loader Class Initialized
INFO - 2017-04-26 09:24:55 --> Helper loaded: url_helper
INFO - 2017-04-26 09:24:55 --> Helper loaded: form_helper
INFO - 2017-04-26 09:24:55 --> Helper loaded: html_helper
INFO - 2017-04-26 09:24:55 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:24:55 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:24:55 --> Database Driver Class Initialized
INFO - 2017-04-26 09:24:55 --> Parser Class Initialized
DEBUG - 2017-04-26 09:24:55 --> Session Class Initialized
INFO - 2017-04-26 09:24:55 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:24:55 --> Session routines successfully run
INFO - 2017-04-26 09:24:55 --> Form Validation Class Initialized
INFO - 2017-04-26 09:24:55 --> Controller Class Initialized
DEBUG - 2017-04-26 09:24:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:24:55 --> Model Class Initialized
DEBUG - 2017-04-26 09:24:55 --> Pagination Class Initialized
INFO - 2017-04-26 09:27:10 --> Config Class Initialized
INFO - 2017-04-26 09:27:10 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:27:10 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:27:10 --> Utf8 Class Initialized
INFO - 2017-04-26 09:27:10 --> URI Class Initialized
INFO - 2017-04-26 09:27:10 --> Router Class Initialized
INFO - 2017-04-26 09:27:10 --> Output Class Initialized
INFO - 2017-04-26 09:27:10 --> Security Class Initialized
DEBUG - 2017-04-26 09:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:27:10 --> Input Class Initialized
INFO - 2017-04-26 09:27:10 --> Language Class Initialized
INFO - 2017-04-26 09:27:10 --> Loader Class Initialized
INFO - 2017-04-26 09:27:10 --> Helper loaded: url_helper
INFO - 2017-04-26 09:27:10 --> Helper loaded: form_helper
INFO - 2017-04-26 09:27:10 --> Helper loaded: html_helper
INFO - 2017-04-26 09:27:10 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:27:10 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:27:10 --> Database Driver Class Initialized
INFO - 2017-04-26 09:27:10 --> Parser Class Initialized
DEBUG - 2017-04-26 09:27:10 --> Session Class Initialized
INFO - 2017-04-26 09:27:10 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:27:10 --> Session routines successfully run
INFO - 2017-04-26 09:27:10 --> Form Validation Class Initialized
INFO - 2017-04-26 09:27:10 --> Controller Class Initialized
DEBUG - 2017-04-26 09:27:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:27:10 --> Model Class Initialized
DEBUG - 2017-04-26 09:27:10 --> Pagination Class Initialized
INFO - 2017-04-26 09:29:16 --> Config Class Initialized
INFO - 2017-04-26 09:29:16 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:29:16 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:29:16 --> Utf8 Class Initialized
INFO - 2017-04-26 09:29:16 --> URI Class Initialized
INFO - 2017-04-26 09:29:16 --> Router Class Initialized
INFO - 2017-04-26 09:29:16 --> Output Class Initialized
INFO - 2017-04-26 09:29:16 --> Security Class Initialized
DEBUG - 2017-04-26 09:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:29:16 --> Input Class Initialized
INFO - 2017-04-26 09:29:16 --> Language Class Initialized
INFO - 2017-04-26 09:29:16 --> Loader Class Initialized
INFO - 2017-04-26 09:29:16 --> Helper loaded: url_helper
INFO - 2017-04-26 09:29:16 --> Helper loaded: form_helper
INFO - 2017-04-26 09:29:16 --> Helper loaded: html_helper
INFO - 2017-04-26 09:29:16 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:29:16 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:29:16 --> Database Driver Class Initialized
INFO - 2017-04-26 09:29:16 --> Parser Class Initialized
DEBUG - 2017-04-26 09:29:16 --> Session Class Initialized
INFO - 2017-04-26 09:29:17 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:29:17 --> Session routines successfully run
INFO - 2017-04-26 09:29:17 --> Form Validation Class Initialized
INFO - 2017-04-26 09:29:17 --> Controller Class Initialized
DEBUG - 2017-04-26 09:29:17 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:29:17 --> Model Class Initialized
DEBUG - 2017-04-26 09:29:17 --> Pagination Class Initialized
INFO - 2017-04-26 09:29:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:29:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:29:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 09:29:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:29:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:29:20 --> Final output sent to browser
DEBUG - 2017-04-26 09:29:20 --> Total execution time: 3.4389
INFO - 2017-04-26 09:29:21 --> Config Class Initialized
INFO - 2017-04-26 09:29:22 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:29:22 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:29:22 --> Utf8 Class Initialized
INFO - 2017-04-26 09:29:22 --> URI Class Initialized
INFO - 2017-04-26 09:29:22 --> Router Class Initialized
INFO - 2017-04-26 09:29:22 --> Output Class Initialized
INFO - 2017-04-26 09:29:22 --> Security Class Initialized
DEBUG - 2017-04-26 09:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:29:22 --> Input Class Initialized
INFO - 2017-04-26 09:29:22 --> Language Class Initialized
INFO - 2017-04-26 09:29:22 --> Loader Class Initialized
INFO - 2017-04-26 09:29:22 --> Helper loaded: url_helper
INFO - 2017-04-26 09:29:22 --> Helper loaded: form_helper
INFO - 2017-04-26 09:29:22 --> Helper loaded: html_helper
INFO - 2017-04-26 09:29:22 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:29:22 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:29:22 --> Database Driver Class Initialized
INFO - 2017-04-26 09:29:22 --> Parser Class Initialized
DEBUG - 2017-04-26 09:29:22 --> Session Class Initialized
INFO - 2017-04-26 09:29:22 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:29:22 --> Session routines successfully run
INFO - 2017-04-26 09:29:22 --> Form Validation Class Initialized
INFO - 2017-04-26 09:29:22 --> Controller Class Initialized
DEBUG - 2017-04-26 09:29:22 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:29:22 --> Model Class Initialized
DEBUG - 2017-04-26 09:29:22 --> Pagination Class Initialized
INFO - 2017-04-26 09:29:34 --> Config Class Initialized
INFO - 2017-04-26 09:29:34 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:29:34 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:29:34 --> Utf8 Class Initialized
INFO - 2017-04-26 09:29:34 --> URI Class Initialized
INFO - 2017-04-26 09:29:34 --> Router Class Initialized
INFO - 2017-04-26 09:29:34 --> Output Class Initialized
INFO - 2017-04-26 09:29:34 --> Security Class Initialized
DEBUG - 2017-04-26 09:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:29:34 --> Input Class Initialized
INFO - 2017-04-26 09:29:34 --> Language Class Initialized
INFO - 2017-04-26 09:29:34 --> Loader Class Initialized
INFO - 2017-04-26 09:29:34 --> Helper loaded: url_helper
INFO - 2017-04-26 09:29:34 --> Helper loaded: form_helper
INFO - 2017-04-26 09:29:34 --> Helper loaded: html_helper
INFO - 2017-04-26 09:29:34 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:29:34 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:29:34 --> Database Driver Class Initialized
INFO - 2017-04-26 09:29:34 --> Parser Class Initialized
DEBUG - 2017-04-26 09:29:34 --> Session Class Initialized
INFO - 2017-04-26 09:29:34 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:29:34 --> Session routines successfully run
INFO - 2017-04-26 09:29:34 --> Form Validation Class Initialized
INFO - 2017-04-26 09:29:34 --> Controller Class Initialized
DEBUG - 2017-04-26 09:29:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:29:34 --> Model Class Initialized
DEBUG - 2017-04-26 09:29:34 --> Pagination Class Initialized
INFO - 2017-04-26 09:32:15 --> Config Class Initialized
INFO - 2017-04-26 09:32:15 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:32:15 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:32:15 --> Utf8 Class Initialized
INFO - 2017-04-26 09:32:15 --> URI Class Initialized
INFO - 2017-04-26 09:32:15 --> Router Class Initialized
INFO - 2017-04-26 09:32:15 --> Output Class Initialized
INFO - 2017-04-26 09:32:15 --> Security Class Initialized
DEBUG - 2017-04-26 09:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:32:15 --> Input Class Initialized
INFO - 2017-04-26 09:32:15 --> Language Class Initialized
INFO - 2017-04-26 09:32:15 --> Loader Class Initialized
INFO - 2017-04-26 09:32:15 --> Helper loaded: url_helper
INFO - 2017-04-26 09:32:15 --> Helper loaded: form_helper
INFO - 2017-04-26 09:32:15 --> Helper loaded: html_helper
INFO - 2017-04-26 09:32:15 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:32:15 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:32:15 --> Database Driver Class Initialized
INFO - 2017-04-26 09:32:15 --> Parser Class Initialized
DEBUG - 2017-04-26 09:32:15 --> Session Class Initialized
INFO - 2017-04-26 09:32:15 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:32:15 --> Session routines successfully run
INFO - 2017-04-26 09:32:15 --> Form Validation Class Initialized
INFO - 2017-04-26 09:32:15 --> Controller Class Initialized
DEBUG - 2017-04-26 09:32:15 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:32:15 --> Model Class Initialized
DEBUG - 2017-04-26 09:32:15 --> Pagination Class Initialized
INFO - 2017-04-26 09:33:32 --> Config Class Initialized
INFO - 2017-04-26 09:33:32 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:33:32 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:33:32 --> Utf8 Class Initialized
INFO - 2017-04-26 09:33:32 --> URI Class Initialized
INFO - 2017-04-26 09:33:32 --> Router Class Initialized
INFO - 2017-04-26 09:33:32 --> Output Class Initialized
INFO - 2017-04-26 09:33:32 --> Security Class Initialized
DEBUG - 2017-04-26 09:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:33:32 --> Input Class Initialized
INFO - 2017-04-26 09:33:32 --> Language Class Initialized
INFO - 2017-04-26 09:33:32 --> Loader Class Initialized
INFO - 2017-04-26 09:33:32 --> Helper loaded: url_helper
INFO - 2017-04-26 09:33:32 --> Helper loaded: form_helper
INFO - 2017-04-26 09:33:32 --> Helper loaded: html_helper
INFO - 2017-04-26 09:33:32 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:33:32 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:33:32 --> Database Driver Class Initialized
INFO - 2017-04-26 09:33:32 --> Parser Class Initialized
DEBUG - 2017-04-26 09:33:32 --> Session Class Initialized
INFO - 2017-04-26 09:33:32 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:33:32 --> Session routines successfully run
INFO - 2017-04-26 09:33:32 --> Form Validation Class Initialized
INFO - 2017-04-26 09:33:32 --> Controller Class Initialized
DEBUG - 2017-04-26 09:33:32 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:33:32 --> Model Class Initialized
DEBUG - 2017-04-26 09:33:32 --> Pagination Class Initialized
INFO - 2017-04-26 09:33:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:33:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:33:33 --> Config Class Initialized
INFO - 2017-04-26 09:33:33 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:33:33 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:33:33 --> Utf8 Class Initialized
INFO - 2017-04-26 09:33:33 --> URI Class Initialized
INFO - 2017-04-26 09:33:33 --> Router Class Initialized
INFO - 2017-04-26 09:33:33 --> Output Class Initialized
INFO - 2017-04-26 09:33:33 --> Security Class Initialized
DEBUG - 2017-04-26 09:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:33:33 --> Input Class Initialized
INFO - 2017-04-26 09:33:33 --> Language Class Initialized
INFO - 2017-04-26 09:33:33 --> Loader Class Initialized
INFO - 2017-04-26 09:33:33 --> Helper loaded: url_helper
INFO - 2017-04-26 09:33:33 --> Helper loaded: form_helper
INFO - 2017-04-26 09:33:33 --> Helper loaded: html_helper
INFO - 2017-04-26 09:33:33 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:33:33 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:33:33 --> Database Driver Class Initialized
INFO - 2017-04-26 09:33:33 --> Parser Class Initialized
DEBUG - 2017-04-26 09:33:33 --> Session Class Initialized
INFO - 2017-04-26 09:33:33 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:33:33 --> Session routines successfully run
INFO - 2017-04-26 09:33:33 --> Form Validation Class Initialized
INFO - 2017-04-26 09:33:33 --> Controller Class Initialized
DEBUG - 2017-04-26 09:33:33 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:33:33 --> Model Class Initialized
DEBUG - 2017-04-26 09:33:33 --> Pagination Class Initialized
INFO - 2017-04-26 09:33:35 --> Config Class Initialized
INFO - 2017-04-26 09:33:35 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:33:35 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:33:35 --> Utf8 Class Initialized
INFO - 2017-04-26 09:33:35 --> URI Class Initialized
INFO - 2017-04-26 09:33:35 --> Router Class Initialized
INFO - 2017-04-26 09:33:35 --> Output Class Initialized
INFO - 2017-04-26 09:33:35 --> Security Class Initialized
DEBUG - 2017-04-26 09:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:33:35 --> Input Class Initialized
INFO - 2017-04-26 09:33:35 --> Language Class Initialized
INFO - 2017-04-26 09:33:35 --> Loader Class Initialized
INFO - 2017-04-26 09:33:35 --> Helper loaded: url_helper
INFO - 2017-04-26 09:33:35 --> Helper loaded: form_helper
INFO - 2017-04-26 09:33:35 --> Helper loaded: html_helper
INFO - 2017-04-26 09:33:35 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:33:35 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:33:35 --> Database Driver Class Initialized
INFO - 2017-04-26 09:33:35 --> Parser Class Initialized
DEBUG - 2017-04-26 09:33:35 --> Session Class Initialized
INFO - 2017-04-26 09:33:35 --> Helper loaded: string_helper
INFO - 2017-04-26 09:33:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
DEBUG - 2017-04-26 09:33:35 --> Session routines successfully run
INFO - 2017-04-26 09:33:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:33:35 --> Form Validation Class Initialized
INFO - 2017-04-26 09:33:35 --> Controller Class Initialized
INFO - 2017-04-26 09:33:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
DEBUG - 2017-04-26 09:33:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:33:35 --> Final output sent to browser
INFO - 2017-04-26 09:33:35 --> Model Class Initialized
DEBUG - 2017-04-26 09:33:36 --> Total execution time: 3.6521
DEBUG - 2017-04-26 09:33:36 --> Pagination Class Initialized
INFO - 2017-04-26 09:33:50 --> Config Class Initialized
INFO - 2017-04-26 09:33:50 --> Hooks Class Initialized
DEBUG - 2017-04-26 09:33:50 --> UTF-8 Support Enabled
INFO - 2017-04-26 09:33:50 --> Utf8 Class Initialized
INFO - 2017-04-26 09:33:50 --> URI Class Initialized
INFO - 2017-04-26 09:33:50 --> Router Class Initialized
INFO - 2017-04-26 09:33:50 --> Output Class Initialized
INFO - 2017-04-26 09:33:50 --> Security Class Initialized
DEBUG - 2017-04-26 09:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 09:33:50 --> Input Class Initialized
INFO - 2017-04-26 09:33:50 --> Language Class Initialized
INFO - 2017-04-26 09:33:50 --> Loader Class Initialized
INFO - 2017-04-26 09:33:50 --> Helper loaded: url_helper
INFO - 2017-04-26 09:33:50 --> Helper loaded: form_helper
INFO - 2017-04-26 09:33:50 --> Helper loaded: html_helper
INFO - 2017-04-26 09:33:50 --> Helper loaded: custom_helper
INFO - 2017-04-26 09:33:50 --> Helper loaded: cache_helper
INFO - 2017-04-26 09:33:50 --> Database Driver Class Initialized
INFO - 2017-04-26 09:33:50 --> Parser Class Initialized
DEBUG - 2017-04-26 09:33:50 --> Session Class Initialized
INFO - 2017-04-26 09:33:50 --> Helper loaded: string_helper
DEBUG - 2017-04-26 09:33:50 --> Session routines successfully run
INFO - 2017-04-26 09:33:50 --> Form Validation Class Initialized
INFO - 2017-04-26 09:33:50 --> Controller Class Initialized
DEBUG - 2017-04-26 09:33:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 09:33:50 --> Model Class Initialized
DEBUG - 2017-04-26 09:33:50 --> Pagination Class Initialized
INFO - 2017-04-26 09:33:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 09:33:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 09:33:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 09:33:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 09:33:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 09:33:50 --> Final output sent to browser
DEBUG - 2017-04-26 09:33:50 --> Total execution time: 0.3987
INFO - 2017-04-26 10:37:54 --> Config Class Initialized
INFO - 2017-04-26 10:37:55 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:37:55 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:37:55 --> Utf8 Class Initialized
INFO - 2017-04-26 10:37:55 --> URI Class Initialized
INFO - 2017-04-26 10:37:55 --> Router Class Initialized
INFO - 2017-04-26 10:37:55 --> Output Class Initialized
INFO - 2017-04-26 10:37:55 --> Security Class Initialized
DEBUG - 2017-04-26 10:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:37:55 --> Input Class Initialized
INFO - 2017-04-26 10:37:55 --> Language Class Initialized
INFO - 2017-04-26 10:37:55 --> Loader Class Initialized
INFO - 2017-04-26 10:37:55 --> Helper loaded: url_helper
INFO - 2017-04-26 10:37:55 --> Helper loaded: form_helper
INFO - 2017-04-26 10:37:55 --> Helper loaded: html_helper
INFO - 2017-04-26 10:37:55 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:37:55 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:37:55 --> Database Driver Class Initialized
INFO - 2017-04-26 10:37:55 --> Parser Class Initialized
DEBUG - 2017-04-26 10:37:55 --> Session Class Initialized
INFO - 2017-04-26 10:37:55 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:37:55 --> Session routines successfully run
INFO - 2017-04-26 10:37:55 --> Form Validation Class Initialized
INFO - 2017-04-26 10:37:55 --> Controller Class Initialized
DEBUG - 2017-04-26 10:37:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:37:55 --> Model Class Initialized
DEBUG - 2017-04-26 10:37:55 --> Pagination Class Initialized
INFO - 2017-04-26 10:37:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:37:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:37:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:37:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:37:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:37:55 --> Final output sent to browser
DEBUG - 2017-04-26 10:37:55 --> Total execution time: 0.7515
INFO - 2017-04-26 10:42:27 --> Config Class Initialized
INFO - 2017-04-26 10:42:27 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:42:27 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:42:27 --> Utf8 Class Initialized
INFO - 2017-04-26 10:42:27 --> URI Class Initialized
INFO - 2017-04-26 10:42:27 --> Router Class Initialized
INFO - 2017-04-26 10:42:27 --> Output Class Initialized
INFO - 2017-04-26 10:42:27 --> Security Class Initialized
DEBUG - 2017-04-26 10:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:42:27 --> Input Class Initialized
INFO - 2017-04-26 10:42:27 --> Language Class Initialized
INFO - 2017-04-26 10:42:27 --> Loader Class Initialized
INFO - 2017-04-26 10:42:27 --> Helper loaded: url_helper
INFO - 2017-04-26 10:42:27 --> Helper loaded: form_helper
INFO - 2017-04-26 10:42:27 --> Helper loaded: html_helper
INFO - 2017-04-26 10:42:28 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:42:28 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:42:28 --> Database Driver Class Initialized
INFO - 2017-04-26 10:42:28 --> Parser Class Initialized
DEBUG - 2017-04-26 10:42:28 --> Session Class Initialized
INFO - 2017-04-26 10:42:28 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:42:28 --> Session routines successfully run
INFO - 2017-04-26 10:42:28 --> Form Validation Class Initialized
INFO - 2017-04-26 10:42:28 --> Controller Class Initialized
DEBUG - 2017-04-26 10:42:28 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:42:28 --> Model Class Initialized
DEBUG - 2017-04-26 10:42:28 --> Pagination Class Initialized
INFO - 2017-04-26 10:42:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:42:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:42:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:42:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:42:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:42:28 --> Final output sent to browser
DEBUG - 2017-04-26 10:42:28 --> Total execution time: 0.5537
INFO - 2017-04-26 10:42:56 --> Config Class Initialized
INFO - 2017-04-26 10:42:56 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:42:56 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:42:56 --> Utf8 Class Initialized
INFO - 2017-04-26 10:42:56 --> URI Class Initialized
INFO - 2017-04-26 10:42:56 --> Router Class Initialized
INFO - 2017-04-26 10:42:56 --> Output Class Initialized
INFO - 2017-04-26 10:42:56 --> Security Class Initialized
DEBUG - 2017-04-26 10:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:42:56 --> Input Class Initialized
INFO - 2017-04-26 10:42:56 --> Language Class Initialized
INFO - 2017-04-26 10:42:56 --> Loader Class Initialized
INFO - 2017-04-26 10:42:56 --> Helper loaded: url_helper
INFO - 2017-04-26 10:42:56 --> Helper loaded: form_helper
INFO - 2017-04-26 10:42:56 --> Helper loaded: html_helper
INFO - 2017-04-26 10:42:56 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:42:56 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:42:56 --> Database Driver Class Initialized
INFO - 2017-04-26 10:42:56 --> Parser Class Initialized
DEBUG - 2017-04-26 10:42:56 --> Session Class Initialized
INFO - 2017-04-26 10:42:56 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:42:56 --> Session routines successfully run
INFO - 2017-04-26 10:42:56 --> Form Validation Class Initialized
INFO - 2017-04-26 10:42:56 --> Controller Class Initialized
DEBUG - 2017-04-26 10:42:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:42:56 --> Model Class Initialized
DEBUG - 2017-04-26 10:42:56 --> Pagination Class Initialized
INFO - 2017-04-26 10:42:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:42:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:42:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:42:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:42:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:42:56 --> Final output sent to browser
DEBUG - 2017-04-26 10:42:56 --> Total execution time: 0.4082
INFO - 2017-04-26 10:43:05 --> Config Class Initialized
INFO - 2017-04-26 10:43:05 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:43:05 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:43:05 --> Utf8 Class Initialized
INFO - 2017-04-26 10:43:05 --> URI Class Initialized
INFO - 2017-04-26 10:43:05 --> Router Class Initialized
INFO - 2017-04-26 10:43:05 --> Output Class Initialized
INFO - 2017-04-26 10:43:05 --> Security Class Initialized
DEBUG - 2017-04-26 10:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:43:05 --> Input Class Initialized
INFO - 2017-04-26 10:43:05 --> Language Class Initialized
INFO - 2017-04-26 10:43:05 --> Loader Class Initialized
INFO - 2017-04-26 10:43:05 --> Helper loaded: url_helper
INFO - 2017-04-26 10:43:05 --> Helper loaded: form_helper
INFO - 2017-04-26 10:43:05 --> Helper loaded: html_helper
INFO - 2017-04-26 10:43:05 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:43:05 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:43:05 --> Database Driver Class Initialized
INFO - 2017-04-26 10:43:05 --> Parser Class Initialized
DEBUG - 2017-04-26 10:43:05 --> Session Class Initialized
INFO - 2017-04-26 10:43:05 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:43:05 --> Session routines successfully run
INFO - 2017-04-26 10:43:05 --> Form Validation Class Initialized
INFO - 2017-04-26 10:43:05 --> Controller Class Initialized
DEBUG - 2017-04-26 10:43:05 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:43:05 --> Model Class Initialized
DEBUG - 2017-04-26 10:43:05 --> Pagination Class Initialized
INFO - 2017-04-26 10:43:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:43:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:43:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:43:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:43:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:43:06 --> Final output sent to browser
DEBUG - 2017-04-26 10:43:06 --> Total execution time: 0.4203
INFO - 2017-04-26 10:43:39 --> Config Class Initialized
INFO - 2017-04-26 10:43:39 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:43:39 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:43:39 --> Utf8 Class Initialized
INFO - 2017-04-26 10:43:39 --> URI Class Initialized
INFO - 2017-04-26 10:43:39 --> Router Class Initialized
INFO - 2017-04-26 10:43:39 --> Output Class Initialized
INFO - 2017-04-26 10:43:39 --> Security Class Initialized
DEBUG - 2017-04-26 10:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:43:39 --> Input Class Initialized
INFO - 2017-04-26 10:43:39 --> Language Class Initialized
INFO - 2017-04-26 10:43:39 --> Loader Class Initialized
INFO - 2017-04-26 10:43:40 --> Helper loaded: url_helper
INFO - 2017-04-26 10:43:40 --> Helper loaded: form_helper
INFO - 2017-04-26 10:43:40 --> Helper loaded: html_helper
INFO - 2017-04-26 10:43:40 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:43:40 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:43:40 --> Database Driver Class Initialized
INFO - 2017-04-26 10:43:40 --> Parser Class Initialized
DEBUG - 2017-04-26 10:43:40 --> Session Class Initialized
INFO - 2017-04-26 10:43:40 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:43:40 --> Session routines successfully run
INFO - 2017-04-26 10:43:40 --> Form Validation Class Initialized
INFO - 2017-04-26 10:43:40 --> Controller Class Initialized
DEBUG - 2017-04-26 10:43:40 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:43:40 --> Model Class Initialized
DEBUG - 2017-04-26 10:43:40 --> Pagination Class Initialized
INFO - 2017-04-26 10:43:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:43:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:43:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:43:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:43:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:43:40 --> Final output sent to browser
DEBUG - 2017-04-26 10:43:40 --> Total execution time: 0.5158
INFO - 2017-04-26 10:45:22 --> Config Class Initialized
INFO - 2017-04-26 10:45:22 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:45:22 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:45:22 --> Utf8 Class Initialized
INFO - 2017-04-26 10:45:22 --> URI Class Initialized
INFO - 2017-04-26 10:45:22 --> Router Class Initialized
INFO - 2017-04-26 10:45:22 --> Output Class Initialized
INFO - 2017-04-26 10:45:22 --> Security Class Initialized
DEBUG - 2017-04-26 10:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:45:22 --> Input Class Initialized
INFO - 2017-04-26 10:45:22 --> Language Class Initialized
INFO - 2017-04-26 10:45:22 --> Loader Class Initialized
INFO - 2017-04-26 10:45:22 --> Helper loaded: url_helper
INFO - 2017-04-26 10:45:22 --> Helper loaded: form_helper
INFO - 2017-04-26 10:45:22 --> Helper loaded: html_helper
INFO - 2017-04-26 10:45:22 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:45:22 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:45:23 --> Database Driver Class Initialized
INFO - 2017-04-26 10:45:23 --> Parser Class Initialized
DEBUG - 2017-04-26 10:45:23 --> Session Class Initialized
INFO - 2017-04-26 10:45:23 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:45:23 --> Session routines successfully run
INFO - 2017-04-26 10:45:23 --> Form Validation Class Initialized
INFO - 2017-04-26 10:45:23 --> Controller Class Initialized
DEBUG - 2017-04-26 10:45:23 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:45:23 --> Model Class Initialized
DEBUG - 2017-04-26 10:45:23 --> Pagination Class Initialized
INFO - 2017-04-26 10:45:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:45:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:45:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:45:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:45:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:45:23 --> Final output sent to browser
DEBUG - 2017-04-26 10:45:23 --> Total execution time: 0.9235
INFO - 2017-04-26 10:46:41 --> Config Class Initialized
INFO - 2017-04-26 10:46:41 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:46:41 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:46:41 --> Utf8 Class Initialized
INFO - 2017-04-26 10:46:41 --> URI Class Initialized
INFO - 2017-04-26 10:46:41 --> Router Class Initialized
INFO - 2017-04-26 10:46:41 --> Output Class Initialized
INFO - 2017-04-26 10:46:41 --> Security Class Initialized
DEBUG - 2017-04-26 10:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:46:41 --> Input Class Initialized
INFO - 2017-04-26 10:46:41 --> Language Class Initialized
INFO - 2017-04-26 10:46:41 --> Loader Class Initialized
INFO - 2017-04-26 10:46:41 --> Helper loaded: url_helper
INFO - 2017-04-26 10:46:41 --> Helper loaded: form_helper
INFO - 2017-04-26 10:46:41 --> Helper loaded: html_helper
INFO - 2017-04-26 10:46:41 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:46:41 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:46:41 --> Database Driver Class Initialized
INFO - 2017-04-26 10:46:41 --> Parser Class Initialized
DEBUG - 2017-04-26 10:46:41 --> Session Class Initialized
INFO - 2017-04-26 10:46:41 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:46:41 --> Session routines successfully run
INFO - 2017-04-26 10:46:41 --> Form Validation Class Initialized
INFO - 2017-04-26 10:46:41 --> Controller Class Initialized
DEBUG - 2017-04-26 10:46:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:46:41 --> Model Class Initialized
DEBUG - 2017-04-26 10:46:41 --> Pagination Class Initialized
INFO - 2017-04-26 10:46:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:46:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:46:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:46:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:46:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:46:41 --> Final output sent to browser
DEBUG - 2017-04-26 10:46:41 --> Total execution time: 0.4610
INFO - 2017-04-26 10:48:10 --> Config Class Initialized
INFO - 2017-04-26 10:48:10 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:48:10 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:48:10 --> Utf8 Class Initialized
INFO - 2017-04-26 10:48:10 --> URI Class Initialized
INFO - 2017-04-26 10:48:10 --> Router Class Initialized
INFO - 2017-04-26 10:48:10 --> Output Class Initialized
INFO - 2017-04-26 10:48:10 --> Security Class Initialized
DEBUG - 2017-04-26 10:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:48:10 --> Input Class Initialized
INFO - 2017-04-26 10:48:10 --> Language Class Initialized
INFO - 2017-04-26 10:48:10 --> Loader Class Initialized
INFO - 2017-04-26 10:48:10 --> Helper loaded: url_helper
INFO - 2017-04-26 10:48:10 --> Helper loaded: form_helper
INFO - 2017-04-26 10:48:10 --> Helper loaded: html_helper
INFO - 2017-04-26 10:48:10 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:48:10 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:48:10 --> Database Driver Class Initialized
INFO - 2017-04-26 10:48:10 --> Parser Class Initialized
DEBUG - 2017-04-26 10:48:10 --> Session Class Initialized
INFO - 2017-04-26 10:48:10 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:48:10 --> Session routines successfully run
INFO - 2017-04-26 10:48:10 --> Form Validation Class Initialized
INFO - 2017-04-26 10:48:10 --> Controller Class Initialized
DEBUG - 2017-04-26 10:48:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:48:10 --> Model Class Initialized
DEBUG - 2017-04-26 10:48:10 --> Pagination Class Initialized
INFO - 2017-04-26 10:48:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:48:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:48:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:48:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:48:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:48:10 --> Final output sent to browser
DEBUG - 2017-04-26 10:48:10 --> Total execution time: 0.4801
INFO - 2017-04-26 10:48:14 --> Config Class Initialized
INFO - 2017-04-26 10:48:14 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:48:14 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:48:14 --> Utf8 Class Initialized
INFO - 2017-04-26 10:48:14 --> URI Class Initialized
INFO - 2017-04-26 10:48:14 --> Router Class Initialized
INFO - 2017-04-26 10:48:14 --> Output Class Initialized
INFO - 2017-04-26 10:48:14 --> Security Class Initialized
DEBUG - 2017-04-26 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:48:14 --> Input Class Initialized
INFO - 2017-04-26 10:48:14 --> Language Class Initialized
INFO - 2017-04-26 10:48:14 --> Loader Class Initialized
INFO - 2017-04-26 10:48:14 --> Helper loaded: url_helper
INFO - 2017-04-26 10:48:14 --> Helper loaded: form_helper
INFO - 2017-04-26 10:48:14 --> Helper loaded: html_helper
INFO - 2017-04-26 10:48:14 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:48:14 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:48:14 --> Database Driver Class Initialized
INFO - 2017-04-26 10:48:14 --> Parser Class Initialized
DEBUG - 2017-04-26 10:48:14 --> Session Class Initialized
INFO - 2017-04-26 10:48:14 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:48:14 --> Session routines successfully run
INFO - 2017-04-26 10:48:14 --> Form Validation Class Initialized
INFO - 2017-04-26 10:48:14 --> Controller Class Initialized
DEBUG - 2017-04-26 10:48:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:48:14 --> Model Class Initialized
DEBUG - 2017-04-26 10:48:14 --> Pagination Class Initialized
INFO - 2017-04-26 10:48:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:48:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:48:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:48:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:48:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:48:15 --> Final output sent to browser
DEBUG - 2017-04-26 10:48:15 --> Total execution time: 0.3991
INFO - 2017-04-26 10:48:42 --> Config Class Initialized
INFO - 2017-04-26 10:48:42 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:48:43 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:48:43 --> Utf8 Class Initialized
INFO - 2017-04-26 10:48:43 --> URI Class Initialized
INFO - 2017-04-26 10:48:43 --> Router Class Initialized
INFO - 2017-04-26 10:48:43 --> Output Class Initialized
INFO - 2017-04-26 10:48:43 --> Security Class Initialized
DEBUG - 2017-04-26 10:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:48:43 --> Input Class Initialized
INFO - 2017-04-26 10:48:43 --> Language Class Initialized
INFO - 2017-04-26 10:48:43 --> Loader Class Initialized
INFO - 2017-04-26 10:48:43 --> Helper loaded: url_helper
INFO - 2017-04-26 10:48:43 --> Helper loaded: form_helper
INFO - 2017-04-26 10:48:43 --> Helper loaded: html_helper
INFO - 2017-04-26 10:48:43 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:48:43 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:48:43 --> Database Driver Class Initialized
INFO - 2017-04-26 10:48:43 --> Parser Class Initialized
DEBUG - 2017-04-26 10:48:43 --> Session Class Initialized
INFO - 2017-04-26 10:48:43 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:48:43 --> Session routines successfully run
INFO - 2017-04-26 10:48:43 --> Form Validation Class Initialized
INFO - 2017-04-26 10:48:43 --> Controller Class Initialized
DEBUG - 2017-04-26 10:48:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:48:43 --> Model Class Initialized
DEBUG - 2017-04-26 10:48:43 --> Pagination Class Initialized
INFO - 2017-04-26 10:48:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:48:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:48:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:48:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:48:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:48:43 --> Final output sent to browser
DEBUG - 2017-04-26 10:48:43 --> Total execution time: 0.3985
INFO - 2017-04-26 10:48:47 --> Config Class Initialized
INFO - 2017-04-26 10:48:47 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:48:47 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:48:47 --> Utf8 Class Initialized
INFO - 2017-04-26 10:48:47 --> URI Class Initialized
INFO - 2017-04-26 10:48:47 --> Router Class Initialized
INFO - 2017-04-26 10:48:47 --> Output Class Initialized
INFO - 2017-04-26 10:48:47 --> Security Class Initialized
DEBUG - 2017-04-26 10:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:48:47 --> Input Class Initialized
INFO - 2017-04-26 10:48:47 --> Language Class Initialized
INFO - 2017-04-26 10:48:47 --> Loader Class Initialized
INFO - 2017-04-26 10:48:47 --> Helper loaded: url_helper
INFO - 2017-04-26 10:48:47 --> Helper loaded: form_helper
INFO - 2017-04-26 10:48:47 --> Helper loaded: html_helper
INFO - 2017-04-26 10:48:47 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:48:47 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:48:47 --> Database Driver Class Initialized
INFO - 2017-04-26 10:48:47 --> Parser Class Initialized
DEBUG - 2017-04-26 10:48:47 --> Session Class Initialized
INFO - 2017-04-26 10:48:47 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:48:47 --> Session routines successfully run
INFO - 2017-04-26 10:48:47 --> Form Validation Class Initialized
INFO - 2017-04-26 10:48:47 --> Controller Class Initialized
DEBUG - 2017-04-26 10:48:47 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:48:47 --> Model Class Initialized
DEBUG - 2017-04-26 10:48:47 --> Pagination Class Initialized
INFO - 2017-04-26 10:48:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:48:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:48:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:48:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:48:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:48:47 --> Final output sent to browser
DEBUG - 2017-04-26 10:48:47 --> Total execution time: 0.4125
INFO - 2017-04-26 10:48:51 --> Config Class Initialized
INFO - 2017-04-26 10:48:51 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:48:51 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:48:51 --> Utf8 Class Initialized
INFO - 2017-04-26 10:48:51 --> URI Class Initialized
INFO - 2017-04-26 10:48:51 --> Router Class Initialized
INFO - 2017-04-26 10:48:51 --> Output Class Initialized
INFO - 2017-04-26 10:48:51 --> Security Class Initialized
DEBUG - 2017-04-26 10:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:48:51 --> Input Class Initialized
INFO - 2017-04-26 10:48:51 --> Language Class Initialized
INFO - 2017-04-26 10:48:51 --> Loader Class Initialized
INFO - 2017-04-26 10:48:51 --> Helper loaded: url_helper
INFO - 2017-04-26 10:48:51 --> Helper loaded: form_helper
INFO - 2017-04-26 10:48:51 --> Helper loaded: html_helper
INFO - 2017-04-26 10:48:51 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:48:51 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:48:51 --> Database Driver Class Initialized
INFO - 2017-04-26 10:48:51 --> Parser Class Initialized
DEBUG - 2017-04-26 10:48:51 --> Session Class Initialized
INFO - 2017-04-26 10:48:51 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:48:51 --> Session routines successfully run
INFO - 2017-04-26 10:48:51 --> Form Validation Class Initialized
INFO - 2017-04-26 10:48:51 --> Controller Class Initialized
DEBUG - 2017-04-26 10:48:52 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:48:52 --> Model Class Initialized
DEBUG - 2017-04-26 10:48:52 --> Pagination Class Initialized
INFO - 2017-04-26 10:48:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:48:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:48:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:48:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:48:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:48:52 --> Final output sent to browser
DEBUG - 2017-04-26 10:48:52 --> Total execution time: 0.4063
INFO - 2017-04-26 10:50:04 --> Config Class Initialized
INFO - 2017-04-26 10:50:04 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:50:04 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:50:04 --> Utf8 Class Initialized
INFO - 2017-04-26 10:50:04 --> URI Class Initialized
INFO - 2017-04-26 10:50:04 --> Router Class Initialized
INFO - 2017-04-26 10:50:04 --> Output Class Initialized
INFO - 2017-04-26 10:50:04 --> Security Class Initialized
DEBUG - 2017-04-26 10:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:50:04 --> Input Class Initialized
INFO - 2017-04-26 10:50:04 --> Language Class Initialized
INFO - 2017-04-26 10:50:04 --> Loader Class Initialized
INFO - 2017-04-26 10:50:04 --> Helper loaded: url_helper
INFO - 2017-04-26 10:50:04 --> Helper loaded: form_helper
INFO - 2017-04-26 10:50:04 --> Helper loaded: html_helper
INFO - 2017-04-26 10:50:04 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:50:04 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:50:04 --> Database Driver Class Initialized
INFO - 2017-04-26 10:50:04 --> Parser Class Initialized
DEBUG - 2017-04-26 10:50:04 --> Session Class Initialized
INFO - 2017-04-26 10:50:04 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:50:04 --> Session routines successfully run
INFO - 2017-04-26 10:50:04 --> Form Validation Class Initialized
INFO - 2017-04-26 10:50:04 --> Controller Class Initialized
DEBUG - 2017-04-26 10:50:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:50:04 --> Model Class Initialized
DEBUG - 2017-04-26 10:50:04 --> Pagination Class Initialized
INFO - 2017-04-26 10:50:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:50:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:50:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:50:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:50:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:50:04 --> Final output sent to browser
DEBUG - 2017-04-26 10:50:04 --> Total execution time: 0.4279
INFO - 2017-04-26 10:50:06 --> Config Class Initialized
INFO - 2017-04-26 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:50:07 --> Utf8 Class Initialized
INFO - 2017-04-26 10:50:07 --> URI Class Initialized
INFO - 2017-04-26 10:50:07 --> Router Class Initialized
INFO - 2017-04-26 10:50:07 --> Output Class Initialized
INFO - 2017-04-26 10:50:07 --> Security Class Initialized
DEBUG - 2017-04-26 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:50:07 --> Input Class Initialized
INFO - 2017-04-26 10:50:07 --> Language Class Initialized
INFO - 2017-04-26 10:50:07 --> Loader Class Initialized
INFO - 2017-04-26 10:50:07 --> Helper loaded: url_helper
INFO - 2017-04-26 10:50:07 --> Helper loaded: form_helper
INFO - 2017-04-26 10:50:07 --> Helper loaded: html_helper
INFO - 2017-04-26 10:50:07 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:50:07 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:50:07 --> Database Driver Class Initialized
INFO - 2017-04-26 10:50:07 --> Parser Class Initialized
DEBUG - 2017-04-26 10:50:07 --> Session Class Initialized
INFO - 2017-04-26 10:50:07 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:50:07 --> Session routines successfully run
INFO - 2017-04-26 10:50:07 --> Form Validation Class Initialized
INFO - 2017-04-26 10:50:07 --> Controller Class Initialized
DEBUG - 2017-04-26 10:50:07 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:50:07 --> Model Class Initialized
DEBUG - 2017-04-26 10:50:07 --> Pagination Class Initialized
INFO - 2017-04-26 10:50:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:50:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:50:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:50:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:50:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:50:07 --> Final output sent to browser
DEBUG - 2017-04-26 10:50:07 --> Total execution time: 0.5460
INFO - 2017-04-26 10:50:08 --> Config Class Initialized
INFO - 2017-04-26 10:50:08 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:50:08 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:50:08 --> Utf8 Class Initialized
INFO - 2017-04-26 10:50:08 --> URI Class Initialized
INFO - 2017-04-26 10:50:08 --> Router Class Initialized
INFO - 2017-04-26 10:50:08 --> Output Class Initialized
INFO - 2017-04-26 10:50:08 --> Security Class Initialized
DEBUG - 2017-04-26 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:50:08 --> Input Class Initialized
INFO - 2017-04-26 10:50:08 --> Language Class Initialized
INFO - 2017-04-26 10:50:08 --> Loader Class Initialized
INFO - 2017-04-26 10:50:09 --> Helper loaded: url_helper
INFO - 2017-04-26 10:50:09 --> Helper loaded: form_helper
INFO - 2017-04-26 10:50:09 --> Helper loaded: html_helper
INFO - 2017-04-26 10:50:09 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:50:09 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:50:09 --> Database Driver Class Initialized
INFO - 2017-04-26 10:50:09 --> Parser Class Initialized
DEBUG - 2017-04-26 10:50:09 --> Session Class Initialized
INFO - 2017-04-26 10:50:09 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:50:09 --> Session routines successfully run
INFO - 2017-04-26 10:50:09 --> Form Validation Class Initialized
INFO - 2017-04-26 10:50:09 --> Controller Class Initialized
DEBUG - 2017-04-26 10:50:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:50:09 --> Model Class Initialized
DEBUG - 2017-04-26 10:50:09 --> Pagination Class Initialized
INFO - 2017-04-26 10:50:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:50:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:50:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:50:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:50:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:50:09 --> Final output sent to browser
DEBUG - 2017-04-26 10:50:09 --> Total execution time: 0.4695
INFO - 2017-04-26 10:50:11 --> Config Class Initialized
INFO - 2017-04-26 10:50:11 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:50:11 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:50:11 --> Utf8 Class Initialized
INFO - 2017-04-26 10:50:11 --> URI Class Initialized
INFO - 2017-04-26 10:50:11 --> Router Class Initialized
INFO - 2017-04-26 10:50:11 --> Output Class Initialized
INFO - 2017-04-26 10:50:11 --> Security Class Initialized
DEBUG - 2017-04-26 10:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:50:12 --> Input Class Initialized
INFO - 2017-04-26 10:50:12 --> Language Class Initialized
INFO - 2017-04-26 10:50:12 --> Loader Class Initialized
INFO - 2017-04-26 10:50:12 --> Helper loaded: url_helper
INFO - 2017-04-26 10:50:12 --> Helper loaded: form_helper
INFO - 2017-04-26 10:50:12 --> Helper loaded: html_helper
INFO - 2017-04-26 10:50:12 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:50:12 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:50:12 --> Database Driver Class Initialized
INFO - 2017-04-26 10:50:12 --> Parser Class Initialized
DEBUG - 2017-04-26 10:50:12 --> Session Class Initialized
INFO - 2017-04-26 10:50:12 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:50:12 --> Session routines successfully run
INFO - 2017-04-26 10:50:12 --> Form Validation Class Initialized
INFO - 2017-04-26 10:50:12 --> Controller Class Initialized
DEBUG - 2017-04-26 10:50:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:50:12 --> Model Class Initialized
DEBUG - 2017-04-26 10:50:12 --> Pagination Class Initialized
INFO - 2017-04-26 10:50:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:50:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:50:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:50:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:50:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:50:12 --> Final output sent to browser
DEBUG - 2017-04-26 10:50:12 --> Total execution time: 0.5649
INFO - 2017-04-26 10:51:34 --> Config Class Initialized
INFO - 2017-04-26 10:51:34 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:51:34 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:51:34 --> Utf8 Class Initialized
INFO - 2017-04-26 10:51:34 --> URI Class Initialized
INFO - 2017-04-26 10:51:34 --> Router Class Initialized
INFO - 2017-04-26 10:51:34 --> Output Class Initialized
INFO - 2017-04-26 10:51:34 --> Security Class Initialized
DEBUG - 2017-04-26 10:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:51:34 --> Input Class Initialized
INFO - 2017-04-26 10:51:34 --> Language Class Initialized
INFO - 2017-04-26 10:51:34 --> Loader Class Initialized
INFO - 2017-04-26 10:51:34 --> Helper loaded: url_helper
INFO - 2017-04-26 10:51:34 --> Helper loaded: form_helper
INFO - 2017-04-26 10:51:34 --> Helper loaded: html_helper
INFO - 2017-04-26 10:51:34 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:51:34 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:51:34 --> Database Driver Class Initialized
INFO - 2017-04-26 10:51:34 --> Parser Class Initialized
DEBUG - 2017-04-26 10:51:34 --> Session Class Initialized
INFO - 2017-04-26 10:51:34 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:51:34 --> Session routines successfully run
INFO - 2017-04-26 10:51:34 --> Form Validation Class Initialized
INFO - 2017-04-26 10:51:34 --> Controller Class Initialized
DEBUG - 2017-04-26 10:51:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:51:34 --> Model Class Initialized
DEBUG - 2017-04-26 10:51:34 --> Pagination Class Initialized
INFO - 2017-04-26 10:51:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:51:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:51:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:51:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:51:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:51:35 --> Final output sent to browser
DEBUG - 2017-04-26 10:51:35 --> Total execution time: 0.7253
INFO - 2017-04-26 10:52:03 --> Config Class Initialized
INFO - 2017-04-26 10:52:03 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:52:03 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:52:03 --> Utf8 Class Initialized
INFO - 2017-04-26 10:52:03 --> URI Class Initialized
INFO - 2017-04-26 10:52:03 --> Router Class Initialized
INFO - 2017-04-26 10:52:03 --> Output Class Initialized
INFO - 2017-04-26 10:52:03 --> Security Class Initialized
DEBUG - 2017-04-26 10:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:52:03 --> Input Class Initialized
INFO - 2017-04-26 10:52:03 --> Language Class Initialized
INFO - 2017-04-26 10:52:03 --> Loader Class Initialized
INFO - 2017-04-26 10:52:03 --> Helper loaded: url_helper
INFO - 2017-04-26 10:52:03 --> Helper loaded: form_helper
INFO - 2017-04-26 10:52:03 --> Helper loaded: html_helper
INFO - 2017-04-26 10:52:03 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:52:03 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:52:03 --> Database Driver Class Initialized
INFO - 2017-04-26 10:52:03 --> Parser Class Initialized
DEBUG - 2017-04-26 10:52:03 --> Session Class Initialized
INFO - 2017-04-26 10:52:03 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:52:03 --> Session routines successfully run
INFO - 2017-04-26 10:52:03 --> Form Validation Class Initialized
INFO - 2017-04-26 10:52:03 --> Controller Class Initialized
DEBUG - 2017-04-26 10:52:03 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:52:03 --> Model Class Initialized
DEBUG - 2017-04-26 10:52:03 --> Pagination Class Initialized
INFO - 2017-04-26 10:52:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:52:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:52:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:52:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:52:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:52:03 --> Final output sent to browser
DEBUG - 2017-04-26 10:52:03 --> Total execution time: 0.4644
INFO - 2017-04-26 10:52:07 --> Config Class Initialized
INFO - 2017-04-26 10:52:07 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:52:07 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:52:07 --> Utf8 Class Initialized
INFO - 2017-04-26 10:52:07 --> URI Class Initialized
INFO - 2017-04-26 10:52:07 --> Router Class Initialized
INFO - 2017-04-26 10:52:07 --> Output Class Initialized
INFO - 2017-04-26 10:52:07 --> Security Class Initialized
DEBUG - 2017-04-26 10:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:52:07 --> Input Class Initialized
INFO - 2017-04-26 10:52:07 --> Language Class Initialized
INFO - 2017-04-26 10:52:07 --> Loader Class Initialized
INFO - 2017-04-26 10:52:07 --> Helper loaded: url_helper
INFO - 2017-04-26 10:52:07 --> Helper loaded: form_helper
INFO - 2017-04-26 10:52:07 --> Helper loaded: html_helper
INFO - 2017-04-26 10:52:07 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:52:07 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:52:07 --> Database Driver Class Initialized
INFO - 2017-04-26 10:52:07 --> Parser Class Initialized
DEBUG - 2017-04-26 10:52:07 --> Session Class Initialized
INFO - 2017-04-26 10:52:07 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:52:07 --> Session routines successfully run
INFO - 2017-04-26 10:52:07 --> Form Validation Class Initialized
INFO - 2017-04-26 10:52:07 --> Controller Class Initialized
DEBUG - 2017-04-26 10:52:07 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:52:07 --> Model Class Initialized
DEBUG - 2017-04-26 10:52:07 --> Pagination Class Initialized
INFO - 2017-04-26 10:52:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:52:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:52:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:52:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:52:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:52:07 --> Final output sent to browser
DEBUG - 2017-04-26 10:52:07 --> Total execution time: 0.4720
INFO - 2017-04-26 10:52:09 --> Config Class Initialized
INFO - 2017-04-26 10:52:09 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:52:09 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:52:09 --> Utf8 Class Initialized
INFO - 2017-04-26 10:52:10 --> URI Class Initialized
INFO - 2017-04-26 10:52:10 --> Router Class Initialized
INFO - 2017-04-26 10:52:10 --> Output Class Initialized
INFO - 2017-04-26 10:52:10 --> Security Class Initialized
DEBUG - 2017-04-26 10:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:52:10 --> Input Class Initialized
INFO - 2017-04-26 10:52:10 --> Language Class Initialized
INFO - 2017-04-26 10:52:10 --> Loader Class Initialized
INFO - 2017-04-26 10:52:10 --> Helper loaded: url_helper
INFO - 2017-04-26 10:52:10 --> Helper loaded: form_helper
INFO - 2017-04-26 10:52:10 --> Helper loaded: html_helper
INFO - 2017-04-26 10:52:10 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:52:10 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:52:10 --> Database Driver Class Initialized
INFO - 2017-04-26 10:52:10 --> Parser Class Initialized
DEBUG - 2017-04-26 10:52:10 --> Session Class Initialized
INFO - 2017-04-26 10:52:10 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:52:10 --> Session routines successfully run
INFO - 2017-04-26 10:52:10 --> Form Validation Class Initialized
INFO - 2017-04-26 10:52:10 --> Controller Class Initialized
DEBUG - 2017-04-26 10:52:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:52:10 --> Model Class Initialized
DEBUG - 2017-04-26 10:52:10 --> Pagination Class Initialized
INFO - 2017-04-26 10:52:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:52:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:52:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:52:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:52:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:52:10 --> Final output sent to browser
DEBUG - 2017-04-26 10:52:10 --> Total execution time: 0.5930
INFO - 2017-04-26 10:54:14 --> Config Class Initialized
INFO - 2017-04-26 10:54:14 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:54:14 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:54:14 --> Utf8 Class Initialized
INFO - 2017-04-26 10:54:14 --> URI Class Initialized
INFO - 2017-04-26 10:54:14 --> Router Class Initialized
INFO - 2017-04-26 10:54:14 --> Output Class Initialized
INFO - 2017-04-26 10:54:14 --> Security Class Initialized
DEBUG - 2017-04-26 10:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:54:14 --> Input Class Initialized
INFO - 2017-04-26 10:54:14 --> Language Class Initialized
INFO - 2017-04-26 10:54:14 --> Loader Class Initialized
INFO - 2017-04-26 10:54:14 --> Helper loaded: url_helper
INFO - 2017-04-26 10:54:14 --> Helper loaded: form_helper
INFO - 2017-04-26 10:54:14 --> Helper loaded: html_helper
INFO - 2017-04-26 10:54:14 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:54:14 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:54:14 --> Database Driver Class Initialized
INFO - 2017-04-26 10:54:14 --> Parser Class Initialized
DEBUG - 2017-04-26 10:54:14 --> Session Class Initialized
INFO - 2017-04-26 10:54:14 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:54:14 --> Session routines successfully run
INFO - 2017-04-26 10:54:14 --> Form Validation Class Initialized
INFO - 2017-04-26 10:54:14 --> Controller Class Initialized
DEBUG - 2017-04-26 10:54:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:54:14 --> Model Class Initialized
DEBUG - 2017-04-26 10:54:14 --> Pagination Class Initialized
ERROR - 2017-04-26 10:54:14 --> Query error: Unknown column 'company_id' in 'where clause' - Invalid query: SELECT *
FROM `app_registration`
WHERE `company_id` = '126'
INFO - 2017-04-26 10:54:14 --> Language file loaded: language/english/db_lang.php
INFO - 2017-04-26 10:54:24 --> Config Class Initialized
INFO - 2017-04-26 10:54:24 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:54:24 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:54:24 --> Utf8 Class Initialized
INFO - 2017-04-26 10:54:24 --> URI Class Initialized
INFO - 2017-04-26 10:54:24 --> Router Class Initialized
INFO - 2017-04-26 10:54:24 --> Output Class Initialized
INFO - 2017-04-26 10:54:24 --> Security Class Initialized
DEBUG - 2017-04-26 10:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:54:24 --> Input Class Initialized
INFO - 2017-04-26 10:54:24 --> Language Class Initialized
INFO - 2017-04-26 10:54:24 --> Loader Class Initialized
INFO - 2017-04-26 10:54:24 --> Helper loaded: url_helper
INFO - 2017-04-26 10:54:24 --> Helper loaded: form_helper
INFO - 2017-04-26 10:54:24 --> Helper loaded: html_helper
INFO - 2017-04-26 10:54:24 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:54:24 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:54:24 --> Database Driver Class Initialized
INFO - 2017-04-26 10:54:24 --> Parser Class Initialized
DEBUG - 2017-04-26 10:54:24 --> Session Class Initialized
INFO - 2017-04-26 10:54:24 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:54:24 --> Session routines successfully run
INFO - 2017-04-26 10:54:24 --> Form Validation Class Initialized
INFO - 2017-04-26 10:54:24 --> Controller Class Initialized
DEBUG - 2017-04-26 10:54:24 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:54:24 --> Model Class Initialized
DEBUG - 2017-04-26 10:54:24 --> Pagination Class Initialized
INFO - 2017-04-26 10:54:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:54:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:54:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 10:54:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:54:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:54:28 --> Final output sent to browser
DEBUG - 2017-04-26 10:54:28 --> Total execution time: 3.3733
INFO - 2017-04-26 10:57:47 --> Config Class Initialized
INFO - 2017-04-26 10:57:47 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:57:47 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:57:47 --> Utf8 Class Initialized
INFO - 2017-04-26 10:57:47 --> URI Class Initialized
INFO - 2017-04-26 10:57:47 --> Router Class Initialized
INFO - 2017-04-26 10:57:47 --> Output Class Initialized
INFO - 2017-04-26 10:57:47 --> Security Class Initialized
DEBUG - 2017-04-26 10:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:57:47 --> Input Class Initialized
INFO - 2017-04-26 10:57:47 --> Language Class Initialized
INFO - 2017-04-26 10:57:47 --> Loader Class Initialized
INFO - 2017-04-26 10:57:47 --> Helper loaded: url_helper
INFO - 2017-04-26 10:57:47 --> Helper loaded: form_helper
INFO - 2017-04-26 10:57:47 --> Helper loaded: html_helper
INFO - 2017-04-26 10:57:47 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:57:47 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:57:47 --> Database Driver Class Initialized
INFO - 2017-04-26 10:57:47 --> Parser Class Initialized
DEBUG - 2017-04-26 10:57:47 --> Session Class Initialized
INFO - 2017-04-26 10:57:47 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:57:47 --> Session routines successfully run
INFO - 2017-04-26 10:57:47 --> Form Validation Class Initialized
INFO - 2017-04-26 10:57:47 --> Controller Class Initialized
DEBUG - 2017-04-26 10:57:47 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:57:47 --> Model Class Initialized
DEBUG - 2017-04-26 10:57:47 --> Pagination Class Initialized
INFO - 2017-04-26 10:57:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:57:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:57:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 10:57:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:57:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:57:50 --> Final output sent to browser
DEBUG - 2017-04-26 10:57:50 --> Total execution time: 3.4379
INFO - 2017-04-26 10:57:53 --> Config Class Initialized
INFO - 2017-04-26 10:57:53 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:57:53 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:57:53 --> Utf8 Class Initialized
INFO - 2017-04-26 10:57:53 --> URI Class Initialized
INFO - 2017-04-26 10:57:53 --> Router Class Initialized
INFO - 2017-04-26 10:57:53 --> Output Class Initialized
INFO - 2017-04-26 10:57:53 --> Security Class Initialized
DEBUG - 2017-04-26 10:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:57:53 --> Input Class Initialized
INFO - 2017-04-26 10:57:53 --> Language Class Initialized
ERROR - 2017-04-26 10:57:53 --> 404 Page Not Found: Company/api_view
INFO - 2017-04-26 10:58:45 --> Config Class Initialized
INFO - 2017-04-26 10:58:45 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:58:45 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:58:45 --> Utf8 Class Initialized
INFO - 2017-04-26 10:58:45 --> URI Class Initialized
INFO - 2017-04-26 10:58:45 --> Router Class Initialized
INFO - 2017-04-26 10:58:45 --> Output Class Initialized
INFO - 2017-04-26 10:58:45 --> Security Class Initialized
DEBUG - 2017-04-26 10:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:58:45 --> Input Class Initialized
INFO - 2017-04-26 10:58:45 --> Language Class Initialized
ERROR - 2017-04-26 10:58:45 --> 404 Page Not Found: Company/api_view
INFO - 2017-04-26 10:58:49 --> Config Class Initialized
INFO - 2017-04-26 10:58:49 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:58:49 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:58:49 --> Utf8 Class Initialized
INFO - 2017-04-26 10:58:49 --> URI Class Initialized
INFO - 2017-04-26 10:58:49 --> Router Class Initialized
INFO - 2017-04-26 10:58:49 --> Output Class Initialized
INFO - 2017-04-26 10:58:49 --> Security Class Initialized
DEBUG - 2017-04-26 10:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:58:49 --> Input Class Initialized
INFO - 2017-04-26 10:58:49 --> Language Class Initialized
INFO - 2017-04-26 10:58:49 --> Loader Class Initialized
INFO - 2017-04-26 10:58:49 --> Helper loaded: url_helper
INFO - 2017-04-26 10:58:49 --> Helper loaded: form_helper
INFO - 2017-04-26 10:58:49 --> Helper loaded: html_helper
INFO - 2017-04-26 10:58:49 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:58:49 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:58:49 --> Database Driver Class Initialized
INFO - 2017-04-26 10:58:49 --> Parser Class Initialized
DEBUG - 2017-04-26 10:58:49 --> Session Class Initialized
INFO - 2017-04-26 10:58:49 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:58:49 --> Session routines successfully run
INFO - 2017-04-26 10:58:49 --> Form Validation Class Initialized
INFO - 2017-04-26 10:58:49 --> Controller Class Initialized
DEBUG - 2017-04-26 10:58:49 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:58:49 --> Model Class Initialized
DEBUG - 2017-04-26 10:58:49 --> Pagination Class Initialized
INFO - 2017-04-26 10:58:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:58:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:58:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:58:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:58:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:58:50 --> Final output sent to browser
DEBUG - 2017-04-26 10:58:50 --> Total execution time: 0.4440
INFO - 2017-04-26 10:58:52 --> Config Class Initialized
INFO - 2017-04-26 10:58:52 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:58:52 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:58:52 --> Utf8 Class Initialized
INFO - 2017-04-26 10:58:52 --> URI Class Initialized
INFO - 2017-04-26 10:58:53 --> Router Class Initialized
INFO - 2017-04-26 10:58:53 --> Output Class Initialized
INFO - 2017-04-26 10:58:53 --> Security Class Initialized
DEBUG - 2017-04-26 10:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:58:53 --> Input Class Initialized
INFO - 2017-04-26 10:58:53 --> Language Class Initialized
INFO - 2017-04-26 10:58:53 --> Loader Class Initialized
INFO - 2017-04-26 10:58:53 --> Helper loaded: url_helper
INFO - 2017-04-26 10:58:53 --> Helper loaded: form_helper
INFO - 2017-04-26 10:58:53 --> Helper loaded: html_helper
INFO - 2017-04-26 10:58:53 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:58:53 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:58:53 --> Database Driver Class Initialized
INFO - 2017-04-26 10:58:53 --> Parser Class Initialized
DEBUG - 2017-04-26 10:58:53 --> Session Class Initialized
INFO - 2017-04-26 10:58:53 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:58:53 --> Session routines successfully run
INFO - 2017-04-26 10:58:53 --> Form Validation Class Initialized
INFO - 2017-04-26 10:58:53 --> Controller Class Initialized
DEBUG - 2017-04-26 10:58:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:58:53 --> Model Class Initialized
DEBUG - 2017-04-26 10:58:53 --> Pagination Class Initialized
INFO - 2017-04-26 10:58:53 --> Config Class Initialized
INFO - 2017-04-26 10:58:53 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:58:53 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:58:53 --> Utf8 Class Initialized
INFO - 2017-04-26 10:58:53 --> URI Class Initialized
INFO - 2017-04-26 10:58:53 --> Router Class Initialized
INFO - 2017-04-26 10:58:53 --> Output Class Initialized
INFO - 2017-04-26 10:58:53 --> Security Class Initialized
DEBUG - 2017-04-26 10:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:58:53 --> Input Class Initialized
INFO - 2017-04-26 10:58:53 --> Language Class Initialized
INFO - 2017-04-26 10:58:53 --> Loader Class Initialized
INFO - 2017-04-26 10:58:53 --> Helper loaded: url_helper
INFO - 2017-04-26 10:58:53 --> Helper loaded: form_helper
INFO - 2017-04-26 10:58:53 --> Helper loaded: html_helper
INFO - 2017-04-26 10:58:53 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:58:53 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:58:53 --> Database Driver Class Initialized
INFO - 2017-04-26 10:58:53 --> Parser Class Initialized
DEBUG - 2017-04-26 10:58:53 --> Session Class Initialized
INFO - 2017-04-26 10:58:53 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:58:53 --> Session routines successfully run
INFO - 2017-04-26 10:58:53 --> Form Validation Class Initialized
INFO - 2017-04-26 10:58:53 --> Controller Class Initialized
DEBUG - 2017-04-26 10:58:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:58:53 --> Model Class Initialized
DEBUG - 2017-04-26 10:58:53 --> Pagination Class Initialized
INFO - 2017-04-26 10:58:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:58:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:58:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:58:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:58:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:58:53 --> Final output sent to browser
DEBUG - 2017-04-26 10:58:53 --> Total execution time: 0.4091
INFO - 2017-04-26 10:59:31 --> Config Class Initialized
INFO - 2017-04-26 10:59:31 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:59:31 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:59:31 --> Utf8 Class Initialized
INFO - 2017-04-26 10:59:31 --> URI Class Initialized
INFO - 2017-04-26 10:59:31 --> Router Class Initialized
INFO - 2017-04-26 10:59:31 --> Output Class Initialized
INFO - 2017-04-26 10:59:31 --> Security Class Initialized
DEBUG - 2017-04-26 10:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:59:31 --> Input Class Initialized
INFO - 2017-04-26 10:59:31 --> Language Class Initialized
INFO - 2017-04-26 10:59:31 --> Loader Class Initialized
INFO - 2017-04-26 10:59:31 --> Helper loaded: url_helper
INFO - 2017-04-26 10:59:31 --> Helper loaded: form_helper
INFO - 2017-04-26 10:59:31 --> Helper loaded: html_helper
INFO - 2017-04-26 10:59:31 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:59:31 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:59:31 --> Database Driver Class Initialized
INFO - 2017-04-26 10:59:31 --> Parser Class Initialized
DEBUG - 2017-04-26 10:59:31 --> Session Class Initialized
INFO - 2017-04-26 10:59:31 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:59:31 --> Session routines successfully run
INFO - 2017-04-26 10:59:31 --> Form Validation Class Initialized
INFO - 2017-04-26 10:59:31 --> Controller Class Initialized
DEBUG - 2017-04-26 10:59:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:59:31 --> Model Class Initialized
DEBUG - 2017-04-26 10:59:31 --> Pagination Class Initialized
INFO - 2017-04-26 10:59:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:59:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:59:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 10:59:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:59:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:59:34 --> Final output sent to browser
DEBUG - 2017-04-26 10:59:34 --> Total execution time: 3.2116
INFO - 2017-04-26 10:59:35 --> Config Class Initialized
INFO - 2017-04-26 10:59:35 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:59:35 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:59:35 --> Utf8 Class Initialized
INFO - 2017-04-26 10:59:35 --> URI Class Initialized
INFO - 2017-04-26 10:59:35 --> Router Class Initialized
INFO - 2017-04-26 10:59:35 --> Output Class Initialized
INFO - 2017-04-26 10:59:35 --> Security Class Initialized
DEBUG - 2017-04-26 10:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:59:35 --> Input Class Initialized
INFO - 2017-04-26 10:59:35 --> Language Class Initialized
ERROR - 2017-04-26 10:59:35 --> 404 Page Not Found: Company/api_view
INFO - 2017-04-26 10:59:39 --> Config Class Initialized
INFO - 2017-04-26 10:59:39 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:59:39 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:59:39 --> Utf8 Class Initialized
INFO - 2017-04-26 10:59:39 --> URI Class Initialized
DEBUG - 2017-04-26 10:59:39 --> No URI present. Default controller set.
INFO - 2017-04-26 10:59:39 --> Router Class Initialized
INFO - 2017-04-26 10:59:39 --> Output Class Initialized
INFO - 2017-04-26 10:59:39 --> Security Class Initialized
DEBUG - 2017-04-26 10:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:59:39 --> Input Class Initialized
INFO - 2017-04-26 10:59:39 --> Language Class Initialized
INFO - 2017-04-26 10:59:39 --> Loader Class Initialized
INFO - 2017-04-26 10:59:39 --> Helper loaded: url_helper
INFO - 2017-04-26 10:59:39 --> Helper loaded: form_helper
INFO - 2017-04-26 10:59:39 --> Helper loaded: html_helper
INFO - 2017-04-26 10:59:39 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:59:39 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:59:39 --> Database Driver Class Initialized
INFO - 2017-04-26 10:59:39 --> Parser Class Initialized
DEBUG - 2017-04-26 10:59:39 --> Session Class Initialized
INFO - 2017-04-26 10:59:39 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:59:39 --> Session routines successfully run
INFO - 2017-04-26 10:59:39 --> Form Validation Class Initialized
INFO - 2017-04-26 10:59:39 --> Controller Class Initialized
INFO - 2017-04-26 10:59:39 --> Model Class Initialized
INFO - 2017-04-26 10:59:39 --> Config Class Initialized
INFO - 2017-04-26 10:59:39 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:59:39 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:59:39 --> Utf8 Class Initialized
INFO - 2017-04-26 10:59:39 --> URI Class Initialized
INFO - 2017-04-26 10:59:39 --> Router Class Initialized
INFO - 2017-04-26 10:59:39 --> Output Class Initialized
INFO - 2017-04-26 10:59:39 --> Security Class Initialized
DEBUG - 2017-04-26 10:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:59:39 --> Input Class Initialized
INFO - 2017-04-26 10:59:39 --> Language Class Initialized
INFO - 2017-04-26 10:59:39 --> Loader Class Initialized
INFO - 2017-04-26 10:59:39 --> Helper loaded: url_helper
INFO - 2017-04-26 10:59:39 --> Helper loaded: form_helper
INFO - 2017-04-26 10:59:39 --> Helper loaded: html_helper
INFO - 2017-04-26 10:59:40 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:59:40 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:59:40 --> Database Driver Class Initialized
INFO - 2017-04-26 10:59:40 --> Parser Class Initialized
DEBUG - 2017-04-26 10:59:40 --> Session Class Initialized
INFO - 2017-04-26 10:59:40 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:59:40 --> Session routines successfully run
INFO - 2017-04-26 10:59:40 --> Form Validation Class Initialized
INFO - 2017-04-26 10:59:40 --> Controller Class Initialized
DEBUG - 2017-04-26 10:59:40 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:59:40 --> Model Class Initialized
DEBUG - 2017-04-26 10:59:40 --> Pagination Class Initialized
INFO - 2017-04-26 10:59:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:59:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:59:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-26 10:59:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:59:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:59:40 --> Final output sent to browser
DEBUG - 2017-04-26 10:59:40 --> Total execution time: 0.3920
INFO - 2017-04-26 10:59:41 --> Config Class Initialized
INFO - 2017-04-26 10:59:41 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:59:41 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:59:41 --> Utf8 Class Initialized
INFO - 2017-04-26 10:59:42 --> URI Class Initialized
INFO - 2017-04-26 10:59:42 --> Router Class Initialized
INFO - 2017-04-26 10:59:42 --> Output Class Initialized
INFO - 2017-04-26 10:59:42 --> Security Class Initialized
DEBUG - 2017-04-26 10:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:59:42 --> Input Class Initialized
INFO - 2017-04-26 10:59:42 --> Language Class Initialized
INFO - 2017-04-26 10:59:42 --> Loader Class Initialized
INFO - 2017-04-26 10:59:42 --> Helper loaded: url_helper
INFO - 2017-04-26 10:59:42 --> Helper loaded: form_helper
INFO - 2017-04-26 10:59:42 --> Helper loaded: html_helper
INFO - 2017-04-26 10:59:42 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:59:42 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:59:42 --> Database Driver Class Initialized
INFO - 2017-04-26 10:59:42 --> Parser Class Initialized
DEBUG - 2017-04-26 10:59:42 --> Session Class Initialized
INFO - 2017-04-26 10:59:42 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:59:42 --> Session routines successfully run
INFO - 2017-04-26 10:59:42 --> Form Validation Class Initialized
INFO - 2017-04-26 10:59:42 --> Controller Class Initialized
DEBUG - 2017-04-26 10:59:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:59:42 --> Model Class Initialized
DEBUG - 2017-04-26 10:59:42 --> Pagination Class Initialized
INFO - 2017-04-26 10:59:42 --> Config Class Initialized
INFO - 2017-04-26 10:59:42 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:59:42 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:59:42 --> Utf8 Class Initialized
INFO - 2017-04-26 10:59:42 --> URI Class Initialized
INFO - 2017-04-26 10:59:42 --> Router Class Initialized
INFO - 2017-04-26 10:59:42 --> Output Class Initialized
INFO - 2017-04-26 10:59:42 --> Security Class Initialized
DEBUG - 2017-04-26 10:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:59:42 --> Input Class Initialized
INFO - 2017-04-26 10:59:42 --> Language Class Initialized
INFO - 2017-04-26 10:59:42 --> Loader Class Initialized
INFO - 2017-04-26 10:59:42 --> Helper loaded: url_helper
INFO - 2017-04-26 10:59:42 --> Helper loaded: form_helper
INFO - 2017-04-26 10:59:42 --> Helper loaded: html_helper
INFO - 2017-04-26 10:59:42 --> Helper loaded: custom_helper
INFO - 2017-04-26 10:59:42 --> Helper loaded: cache_helper
INFO - 2017-04-26 10:59:42 --> Database Driver Class Initialized
INFO - 2017-04-26 10:59:42 --> Parser Class Initialized
DEBUG - 2017-04-26 10:59:42 --> Session Class Initialized
INFO - 2017-04-26 10:59:42 --> Helper loaded: string_helper
DEBUG - 2017-04-26 10:59:42 --> Session routines successfully run
INFO - 2017-04-26 10:59:42 --> Form Validation Class Initialized
INFO - 2017-04-26 10:59:42 --> Controller Class Initialized
DEBUG - 2017-04-26 10:59:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 10:59:42 --> Model Class Initialized
DEBUG - 2017-04-26 10:59:42 --> Pagination Class Initialized
INFO - 2017-04-26 10:59:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 10:59:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 10:59:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 10:59:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 10:59:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 10:59:43 --> Final output sent to browser
DEBUG - 2017-04-26 10:59:43 --> Total execution time: 0.4372
INFO - 2017-04-26 10:59:44 --> Config Class Initialized
INFO - 2017-04-26 10:59:44 --> Hooks Class Initialized
DEBUG - 2017-04-26 10:59:45 --> UTF-8 Support Enabled
INFO - 2017-04-26 10:59:45 --> Utf8 Class Initialized
INFO - 2017-04-26 10:59:45 --> URI Class Initialized
INFO - 2017-04-26 10:59:45 --> Router Class Initialized
INFO - 2017-04-26 10:59:45 --> Output Class Initialized
INFO - 2017-04-26 10:59:45 --> Security Class Initialized
DEBUG - 2017-04-26 10:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 10:59:45 --> Input Class Initialized
INFO - 2017-04-26 10:59:45 --> Language Class Initialized
ERROR - 2017-04-26 10:59:45 --> 404 Page Not Found: Company/api_view
INFO - 2017-04-26 11:00:01 --> Config Class Initialized
INFO - 2017-04-26 11:00:01 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:00:01 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:00:01 --> Utf8 Class Initialized
INFO - 2017-04-26 11:00:01 --> URI Class Initialized
INFO - 2017-04-26 11:00:01 --> Router Class Initialized
INFO - 2017-04-26 11:00:01 --> Output Class Initialized
INFO - 2017-04-26 11:00:01 --> Security Class Initialized
DEBUG - 2017-04-26 11:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:00:01 --> Input Class Initialized
INFO - 2017-04-26 11:00:01 --> Language Class Initialized
INFO - 2017-04-26 11:00:01 --> Loader Class Initialized
INFO - 2017-04-26 11:00:01 --> Helper loaded: url_helper
INFO - 2017-04-26 11:00:01 --> Helper loaded: form_helper
INFO - 2017-04-26 11:00:01 --> Helper loaded: html_helper
INFO - 2017-04-26 11:00:01 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:00:01 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:00:01 --> Database Driver Class Initialized
INFO - 2017-04-26 11:00:01 --> Parser Class Initialized
DEBUG - 2017-04-26 11:00:01 --> Session Class Initialized
INFO - 2017-04-26 11:00:01 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:00:01 --> Session routines successfully run
INFO - 2017-04-26 11:00:01 --> Form Validation Class Initialized
INFO - 2017-04-26 11:00:01 --> Controller Class Initialized
DEBUG - 2017-04-26 11:00:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:00:01 --> Model Class Initialized
DEBUG - 2017-04-26 11:00:01 --> Pagination Class Initialized
INFO - 2017-04-26 11:00:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:00:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:00:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:00:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:00:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:00:02 --> Final output sent to browser
DEBUG - 2017-04-26 11:00:02 --> Total execution time: 1.1083
INFO - 2017-04-26 11:00:04 --> Config Class Initialized
INFO - 2017-04-26 11:00:04 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:00:04 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:00:04 --> Utf8 Class Initialized
INFO - 2017-04-26 11:00:04 --> URI Class Initialized
INFO - 2017-04-26 11:00:04 --> Router Class Initialized
INFO - 2017-04-26 11:00:04 --> Output Class Initialized
INFO - 2017-04-26 11:00:04 --> Security Class Initialized
DEBUG - 2017-04-26 11:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:00:04 --> Input Class Initialized
INFO - 2017-04-26 11:00:04 --> Language Class Initialized
INFO - 2017-04-26 11:00:04 --> Loader Class Initialized
INFO - 2017-04-26 11:00:04 --> Helper loaded: url_helper
INFO - 2017-04-26 11:00:04 --> Helper loaded: form_helper
INFO - 2017-04-26 11:00:04 --> Helper loaded: html_helper
INFO - 2017-04-26 11:00:04 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:00:05 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:00:05 --> Database Driver Class Initialized
INFO - 2017-04-26 11:00:05 --> Parser Class Initialized
DEBUG - 2017-04-26 11:00:05 --> Session Class Initialized
INFO - 2017-04-26 11:00:05 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:00:05 --> Session routines successfully run
INFO - 2017-04-26 11:00:05 --> Form Validation Class Initialized
INFO - 2017-04-26 11:00:05 --> Controller Class Initialized
DEBUG - 2017-04-26 11:00:05 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:00:05 --> Model Class Initialized
DEBUG - 2017-04-26 11:00:05 --> Pagination Class Initialized
INFO - 2017-04-26 11:00:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:00:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:00:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:00:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:00:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:00:05 --> Final output sent to browser
DEBUG - 2017-04-26 11:00:05 --> Total execution time: 0.9706
INFO - 2017-04-26 11:00:07 --> Config Class Initialized
INFO - 2017-04-26 11:00:07 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:00:08 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:00:08 --> Utf8 Class Initialized
INFO - 2017-04-26 11:00:08 --> URI Class Initialized
INFO - 2017-04-26 11:00:08 --> Router Class Initialized
INFO - 2017-04-26 11:00:08 --> Output Class Initialized
INFO - 2017-04-26 11:00:08 --> Security Class Initialized
DEBUG - 2017-04-26 11:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:00:08 --> Input Class Initialized
INFO - 2017-04-26 11:00:08 --> Language Class Initialized
INFO - 2017-04-26 11:00:08 --> Loader Class Initialized
INFO - 2017-04-26 11:00:08 --> Helper loaded: url_helper
INFO - 2017-04-26 11:00:08 --> Helper loaded: form_helper
INFO - 2017-04-26 11:00:08 --> Helper loaded: html_helper
INFO - 2017-04-26 11:00:08 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:00:08 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:00:08 --> Database Driver Class Initialized
INFO - 2017-04-26 11:00:08 --> Parser Class Initialized
DEBUG - 2017-04-26 11:00:08 --> Session Class Initialized
INFO - 2017-04-26 11:00:08 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:00:08 --> Session routines successfully run
INFO - 2017-04-26 11:00:08 --> Form Validation Class Initialized
INFO - 2017-04-26 11:00:08 --> Controller Class Initialized
DEBUG - 2017-04-26 11:00:08 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:00:08 --> Model Class Initialized
DEBUG - 2017-04-26 11:00:08 --> Pagination Class Initialized
INFO - 2017-04-26 11:00:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:00:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:00:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:00:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:00:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:00:08 --> Final output sent to browser
DEBUG - 2017-04-26 11:00:08 --> Total execution time: 0.7826
INFO - 2017-04-26 11:05:02 --> Config Class Initialized
INFO - 2017-04-26 11:05:02 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:05:03 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:05:03 --> Utf8 Class Initialized
INFO - 2017-04-26 11:05:03 --> URI Class Initialized
INFO - 2017-04-26 11:05:03 --> Router Class Initialized
INFO - 2017-04-26 11:05:03 --> Output Class Initialized
INFO - 2017-04-26 11:05:03 --> Security Class Initialized
DEBUG - 2017-04-26 11:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:05:03 --> Input Class Initialized
INFO - 2017-04-26 11:05:03 --> Language Class Initialized
INFO - 2017-04-26 11:05:03 --> Loader Class Initialized
INFO - 2017-04-26 11:05:03 --> Helper loaded: url_helper
INFO - 2017-04-26 11:05:03 --> Helper loaded: form_helper
INFO - 2017-04-26 11:05:03 --> Helper loaded: html_helper
INFO - 2017-04-26 11:05:03 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:05:03 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:05:03 --> Database Driver Class Initialized
INFO - 2017-04-26 11:05:03 --> Parser Class Initialized
DEBUG - 2017-04-26 11:05:03 --> Session Class Initialized
INFO - 2017-04-26 11:05:03 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:05:03 --> Session routines successfully run
INFO - 2017-04-26 11:05:03 --> Form Validation Class Initialized
INFO - 2017-04-26 11:05:03 --> Controller Class Initialized
DEBUG - 2017-04-26 11:05:03 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:05:03 --> Model Class Initialized
DEBUG - 2017-04-26 11:05:03 --> Pagination Class Initialized
INFO - 2017-04-26 11:05:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:05:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:05:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 11:05:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:05:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:05:06 --> Final output sent to browser
DEBUG - 2017-04-26 11:05:06 --> Total execution time: 3.1795
INFO - 2017-04-26 11:05:10 --> Config Class Initialized
INFO - 2017-04-26 11:05:10 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:05:10 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:05:10 --> Utf8 Class Initialized
INFO - 2017-04-26 11:05:10 --> URI Class Initialized
INFO - 2017-04-26 11:05:10 --> Router Class Initialized
INFO - 2017-04-26 11:05:10 --> Output Class Initialized
INFO - 2017-04-26 11:05:10 --> Security Class Initialized
DEBUG - 2017-04-26 11:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:05:10 --> Input Class Initialized
INFO - 2017-04-26 11:05:10 --> Language Class Initialized
INFO - 2017-04-26 11:05:10 --> Loader Class Initialized
INFO - 2017-04-26 11:05:10 --> Helper loaded: url_helper
INFO - 2017-04-26 11:05:10 --> Helper loaded: form_helper
INFO - 2017-04-26 11:05:10 --> Helper loaded: html_helper
INFO - 2017-04-26 11:05:10 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:05:10 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:05:11 --> Database Driver Class Initialized
INFO - 2017-04-26 11:05:11 --> Parser Class Initialized
DEBUG - 2017-04-26 11:05:11 --> Session Class Initialized
INFO - 2017-04-26 11:05:11 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:05:11 --> Session routines successfully run
INFO - 2017-04-26 11:05:11 --> Form Validation Class Initialized
INFO - 2017-04-26 11:05:11 --> Controller Class Initialized
DEBUG - 2017-04-26 11:05:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:05:11 --> Model Class Initialized
DEBUG - 2017-04-26 11:05:11 --> Pagination Class Initialized
INFO - 2017-04-26 11:05:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:05:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:05:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-26 11:05:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:05:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:05:11 --> Final output sent to browser
DEBUG - 2017-04-26 11:05:11 --> Total execution time: 0.4844
INFO - 2017-04-26 11:05:11 --> Config Class Initialized
INFO - 2017-04-26 11:05:11 --> Config Class Initialized
INFO - 2017-04-26 11:05:11 --> Hooks Class Initialized
INFO - 2017-04-26 11:05:11 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:05:11 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:05:11 --> Utf8 Class Initialized
DEBUG - 2017-04-26 11:05:11 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:05:11 --> Utf8 Class Initialized
INFO - 2017-04-26 11:05:11 --> URI Class Initialized
INFO - 2017-04-26 11:05:11 --> URI Class Initialized
INFO - 2017-04-26 11:05:11 --> Router Class Initialized
INFO - 2017-04-26 11:05:11 --> Router Class Initialized
INFO - 2017-04-26 11:05:11 --> Output Class Initialized
INFO - 2017-04-26 11:05:11 --> Output Class Initialized
INFO - 2017-04-26 11:05:11 --> Security Class Initialized
INFO - 2017-04-26 11:05:11 --> Security Class Initialized
DEBUG - 2017-04-26 11:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-26 11:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:05:11 --> Input Class Initialized
INFO - 2017-04-26 11:05:11 --> Input Class Initialized
INFO - 2017-04-26 11:05:11 --> Language Class Initialized
INFO - 2017-04-26 11:05:11 --> Language Class Initialized
ERROR - 2017-04-26 11:05:11 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-26 11:05:11 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:05:13 --> Config Class Initialized
INFO - 2017-04-26 11:05:13 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:05:14 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:05:14 --> Utf8 Class Initialized
INFO - 2017-04-26 11:05:14 --> URI Class Initialized
INFO - 2017-04-26 11:05:14 --> Router Class Initialized
INFO - 2017-04-26 11:05:14 --> Output Class Initialized
INFO - 2017-04-26 11:05:14 --> Security Class Initialized
DEBUG - 2017-04-26 11:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:05:14 --> Input Class Initialized
INFO - 2017-04-26 11:05:14 --> Language Class Initialized
INFO - 2017-04-26 11:05:14 --> Loader Class Initialized
INFO - 2017-04-26 11:05:14 --> Helper loaded: url_helper
INFO - 2017-04-26 11:05:14 --> Helper loaded: form_helper
INFO - 2017-04-26 11:05:14 --> Helper loaded: html_helper
INFO - 2017-04-26 11:05:14 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:05:14 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:05:14 --> Database Driver Class Initialized
INFO - 2017-04-26 11:05:14 --> Parser Class Initialized
DEBUG - 2017-04-26 11:05:14 --> Session Class Initialized
INFO - 2017-04-26 11:05:14 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:05:14 --> Session routines successfully run
INFO - 2017-04-26 11:05:14 --> Form Validation Class Initialized
INFO - 2017-04-26 11:05:14 --> Controller Class Initialized
DEBUG - 2017-04-26 11:05:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:05:14 --> Model Class Initialized
DEBUG - 2017-04-26 11:05:14 --> Pagination Class Initialized
DEBUG - 2017-04-26 11:05:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-26 11:05:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-04-26 11:05:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:05:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:05:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-26 11:05:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:05:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:05:15 --> Final output sent to browser
DEBUG - 2017-04-26 11:05:15 --> Total execution time: 1.1741
INFO - 2017-04-26 11:05:15 --> Config Class Initialized
INFO - 2017-04-26 11:05:15 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:05:15 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:05:15 --> Utf8 Class Initialized
INFO - 2017-04-26 11:05:15 --> Config Class Initialized
INFO - 2017-04-26 11:05:15 --> URI Class Initialized
INFO - 2017-04-26 11:05:15 --> Hooks Class Initialized
INFO - 2017-04-26 11:05:15 --> Router Class Initialized
DEBUG - 2017-04-26 11:05:15 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:05:15 --> Output Class Initialized
INFO - 2017-04-26 11:05:15 --> Utf8 Class Initialized
INFO - 2017-04-26 11:05:15 --> URI Class Initialized
INFO - 2017-04-26 11:05:15 --> Security Class Initialized
DEBUG - 2017-04-26 11:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:05:15 --> Router Class Initialized
INFO - 2017-04-26 11:05:15 --> Input Class Initialized
INFO - 2017-04-26 11:05:15 --> Output Class Initialized
INFO - 2017-04-26 11:05:15 --> Language Class Initialized
INFO - 2017-04-26 11:05:15 --> Security Class Initialized
ERROR - 2017-04-26 11:05:15 --> 404 Page Not Found: Default/assets
DEBUG - 2017-04-26 11:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:05:15 --> Input Class Initialized
INFO - 2017-04-26 11:05:15 --> Language Class Initialized
ERROR - 2017-04-26 11:05:15 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:05:15 --> Config Class Initialized
INFO - 2017-04-26 11:05:15 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:05:15 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:05:15 --> Utf8 Class Initialized
INFO - 2017-04-26 11:05:15 --> URI Class Initialized
INFO - 2017-04-26 11:05:15 --> Router Class Initialized
INFO - 2017-04-26 11:05:15 --> Output Class Initialized
INFO - 2017-04-26 11:05:15 --> Security Class Initialized
DEBUG - 2017-04-26 11:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:05:15 --> Input Class Initialized
INFO - 2017-04-26 11:05:15 --> Language Class Initialized
ERROR - 2017-04-26 11:05:15 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:05:18 --> Config Class Initialized
INFO - 2017-04-26 11:05:18 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:05:18 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:05:18 --> Utf8 Class Initialized
INFO - 2017-04-26 11:05:18 --> URI Class Initialized
INFO - 2017-04-26 11:05:18 --> Router Class Initialized
INFO - 2017-04-26 11:05:18 --> Output Class Initialized
INFO - 2017-04-26 11:05:18 --> Security Class Initialized
DEBUG - 2017-04-26 11:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:05:18 --> Input Class Initialized
INFO - 2017-04-26 11:05:18 --> Language Class Initialized
INFO - 2017-04-26 11:05:18 --> Loader Class Initialized
INFO - 2017-04-26 11:05:18 --> Helper loaded: url_helper
INFO - 2017-04-26 11:05:18 --> Helper loaded: form_helper
INFO - 2017-04-26 11:05:18 --> Helper loaded: html_helper
INFO - 2017-04-26 11:05:18 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:05:18 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:05:18 --> Database Driver Class Initialized
INFO - 2017-04-26 11:05:18 --> Parser Class Initialized
DEBUG - 2017-04-26 11:05:18 --> Session Class Initialized
INFO - 2017-04-26 11:05:18 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:05:18 --> Session routines successfully run
INFO - 2017-04-26 11:05:18 --> Form Validation Class Initialized
INFO - 2017-04-26 11:05:18 --> Controller Class Initialized
DEBUG - 2017-04-26 11:05:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:05:18 --> Model Class Initialized
DEBUG - 2017-04-26 11:05:18 --> Pagination Class Initialized
INFO - 2017-04-26 11:05:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:05:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:05:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 11:05:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:05:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:05:21 --> Final output sent to browser
DEBUG - 2017-04-26 11:05:21 --> Total execution time: 3.2174
INFO - 2017-04-26 11:05:23 --> Config Class Initialized
INFO - 2017-04-26 11:05:23 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:05:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:05:23 --> Utf8 Class Initialized
INFO - 2017-04-26 11:05:23 --> URI Class Initialized
INFO - 2017-04-26 11:05:23 --> Router Class Initialized
INFO - 2017-04-26 11:05:23 --> Output Class Initialized
INFO - 2017-04-26 11:05:23 --> Security Class Initialized
DEBUG - 2017-04-26 11:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:05:23 --> Input Class Initialized
INFO - 2017-04-26 11:05:23 --> Language Class Initialized
INFO - 2017-04-26 11:05:23 --> Loader Class Initialized
INFO - 2017-04-26 11:05:23 --> Helper loaded: url_helper
INFO - 2017-04-26 11:05:23 --> Helper loaded: form_helper
INFO - 2017-04-26 11:05:23 --> Helper loaded: html_helper
INFO - 2017-04-26 11:05:23 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:05:23 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:05:23 --> Database Driver Class Initialized
INFO - 2017-04-26 11:05:23 --> Parser Class Initialized
DEBUG - 2017-04-26 11:05:23 --> Session Class Initialized
INFO - 2017-04-26 11:05:23 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:05:23 --> Session routines successfully run
INFO - 2017-04-26 11:05:23 --> Form Validation Class Initialized
INFO - 2017-04-26 11:05:23 --> Controller Class Initialized
DEBUG - 2017-04-26 11:05:23 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:05:23 --> Model Class Initialized
DEBUG - 2017-04-26 11:05:23 --> Pagination Class Initialized
INFO - 2017-04-26 11:05:23 --> Config Class Initialized
INFO - 2017-04-26 11:05:23 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:05:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:05:23 --> Utf8 Class Initialized
INFO - 2017-04-26 11:05:23 --> URI Class Initialized
INFO - 2017-04-26 11:05:24 --> Router Class Initialized
INFO - 2017-04-26 11:05:24 --> Output Class Initialized
INFO - 2017-04-26 11:05:24 --> Security Class Initialized
DEBUG - 2017-04-26 11:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:05:24 --> Input Class Initialized
INFO - 2017-04-26 11:05:24 --> Language Class Initialized
INFO - 2017-04-26 11:05:24 --> Loader Class Initialized
INFO - 2017-04-26 11:05:24 --> Helper loaded: url_helper
INFO - 2017-04-26 11:05:24 --> Helper loaded: form_helper
INFO - 2017-04-26 11:05:24 --> Helper loaded: html_helper
INFO - 2017-04-26 11:05:24 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:05:24 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:05:24 --> Database Driver Class Initialized
INFO - 2017-04-26 11:05:24 --> Parser Class Initialized
DEBUG - 2017-04-26 11:05:24 --> Session Class Initialized
INFO - 2017-04-26 11:05:24 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:05:24 --> Session routines successfully run
INFO - 2017-04-26 11:05:24 --> Form Validation Class Initialized
INFO - 2017-04-26 11:05:24 --> Controller Class Initialized
DEBUG - 2017-04-26 11:05:24 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:05:24 --> Model Class Initialized
DEBUG - 2017-04-26 11:05:24 --> Pagination Class Initialized
INFO - 2017-04-26 11:05:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:05:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:05:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:05:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:05:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:05:24 --> Final output sent to browser
DEBUG - 2017-04-26 11:05:24 --> Total execution time: 0.4523
INFO - 2017-04-26 11:07:08 --> Config Class Initialized
INFO - 2017-04-26 11:07:08 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:07:08 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:07:08 --> Utf8 Class Initialized
INFO - 2017-04-26 11:07:08 --> URI Class Initialized
INFO - 2017-04-26 11:07:08 --> Router Class Initialized
INFO - 2017-04-26 11:07:08 --> Output Class Initialized
INFO - 2017-04-26 11:07:08 --> Security Class Initialized
DEBUG - 2017-04-26 11:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:07:08 --> Input Class Initialized
INFO - 2017-04-26 11:07:08 --> Language Class Initialized
INFO - 2017-04-26 11:07:08 --> Loader Class Initialized
INFO - 2017-04-26 11:07:08 --> Helper loaded: url_helper
INFO - 2017-04-26 11:07:08 --> Helper loaded: form_helper
INFO - 2017-04-26 11:07:08 --> Helper loaded: html_helper
INFO - 2017-04-26 11:07:08 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:07:08 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:07:08 --> Database Driver Class Initialized
INFO - 2017-04-26 11:07:08 --> Parser Class Initialized
DEBUG - 2017-04-26 11:07:08 --> Session Class Initialized
INFO - 2017-04-26 11:07:08 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:07:08 --> Session routines successfully run
INFO - 2017-04-26 11:07:08 --> Form Validation Class Initialized
INFO - 2017-04-26 11:07:08 --> Controller Class Initialized
DEBUG - 2017-04-26 11:07:08 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:07:08 --> Model Class Initialized
DEBUG - 2017-04-26 11:07:08 --> Pagination Class Initialized
INFO - 2017-04-26 11:07:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:07:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:07:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:07:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:07:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:07:08 --> Final output sent to browser
DEBUG - 2017-04-26 11:07:08 --> Total execution time: 0.4538
INFO - 2017-04-26 11:08:31 --> Config Class Initialized
INFO - 2017-04-26 11:08:31 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:08:31 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:08:31 --> Utf8 Class Initialized
INFO - 2017-04-26 11:08:31 --> URI Class Initialized
INFO - 2017-04-26 11:08:31 --> Router Class Initialized
INFO - 2017-04-26 11:08:31 --> Output Class Initialized
INFO - 2017-04-26 11:08:31 --> Security Class Initialized
DEBUG - 2017-04-26 11:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:08:31 --> Input Class Initialized
INFO - 2017-04-26 11:08:32 --> Language Class Initialized
INFO - 2017-04-26 11:08:32 --> Loader Class Initialized
INFO - 2017-04-26 11:08:32 --> Helper loaded: url_helper
INFO - 2017-04-26 11:08:32 --> Helper loaded: form_helper
INFO - 2017-04-26 11:08:32 --> Helper loaded: html_helper
INFO - 2017-04-26 11:08:32 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:08:32 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:08:32 --> Database Driver Class Initialized
INFO - 2017-04-26 11:08:32 --> Parser Class Initialized
DEBUG - 2017-04-26 11:08:32 --> Session Class Initialized
INFO - 2017-04-26 11:08:32 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:08:32 --> Session routines successfully run
INFO - 2017-04-26 11:08:32 --> Form Validation Class Initialized
INFO - 2017-04-26 11:08:32 --> Controller Class Initialized
DEBUG - 2017-04-26 11:08:32 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:08:32 --> Model Class Initialized
DEBUG - 2017-04-26 11:08:32 --> Pagination Class Initialized
INFO - 2017-04-26 11:08:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:08:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:08:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:08:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:08:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:08:32 --> Final output sent to browser
DEBUG - 2017-04-26 11:08:32 --> Total execution time: 1.0300
INFO - 2017-04-26 11:08:37 --> Config Class Initialized
INFO - 2017-04-26 11:08:37 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:08:37 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:08:37 --> Utf8 Class Initialized
INFO - 2017-04-26 11:08:37 --> URI Class Initialized
INFO - 2017-04-26 11:08:37 --> Router Class Initialized
INFO - 2017-04-26 11:08:37 --> Output Class Initialized
INFO - 2017-04-26 11:08:37 --> Security Class Initialized
DEBUG - 2017-04-26 11:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:08:37 --> Input Class Initialized
INFO - 2017-04-26 11:08:37 --> Language Class Initialized
INFO - 2017-04-26 11:08:37 --> Loader Class Initialized
INFO - 2017-04-26 11:08:37 --> Helper loaded: url_helper
INFO - 2017-04-26 11:08:37 --> Helper loaded: form_helper
INFO - 2017-04-26 11:08:37 --> Helper loaded: html_helper
INFO - 2017-04-26 11:08:37 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:08:37 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:08:37 --> Database Driver Class Initialized
INFO - 2017-04-26 11:08:37 --> Parser Class Initialized
DEBUG - 2017-04-26 11:08:37 --> Session Class Initialized
INFO - 2017-04-26 11:08:37 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:08:37 --> Session routines successfully run
INFO - 2017-04-26 11:08:37 --> Form Validation Class Initialized
INFO - 2017-04-26 11:08:37 --> Controller Class Initialized
DEBUG - 2017-04-26 11:08:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:08:37 --> Model Class Initialized
DEBUG - 2017-04-26 11:08:37 --> Pagination Class Initialized
INFO - 2017-04-26 11:08:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:08:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:08:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:08:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:08:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:08:37 --> Final output sent to browser
DEBUG - 2017-04-26 11:08:37 --> Total execution time: 0.4484
INFO - 2017-04-26 11:09:33 --> Config Class Initialized
INFO - 2017-04-26 11:09:33 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:09:33 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:09:33 --> Utf8 Class Initialized
INFO - 2017-04-26 11:09:33 --> URI Class Initialized
INFO - 2017-04-26 11:09:33 --> Router Class Initialized
INFO - 2017-04-26 11:09:33 --> Output Class Initialized
INFO - 2017-04-26 11:09:33 --> Security Class Initialized
DEBUG - 2017-04-26 11:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:09:33 --> Input Class Initialized
INFO - 2017-04-26 11:09:33 --> Language Class Initialized
INFO - 2017-04-26 11:09:33 --> Loader Class Initialized
INFO - 2017-04-26 11:09:33 --> Helper loaded: url_helper
INFO - 2017-04-26 11:09:33 --> Helper loaded: form_helper
INFO - 2017-04-26 11:09:33 --> Helper loaded: html_helper
INFO - 2017-04-26 11:09:33 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:09:33 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:09:33 --> Database Driver Class Initialized
INFO - 2017-04-26 11:09:33 --> Parser Class Initialized
DEBUG - 2017-04-26 11:09:33 --> Session Class Initialized
INFO - 2017-04-26 11:09:33 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:09:33 --> Session routines successfully run
INFO - 2017-04-26 11:09:33 --> Form Validation Class Initialized
INFO - 2017-04-26 11:09:33 --> Controller Class Initialized
DEBUG - 2017-04-26 11:09:33 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:09:33 --> Model Class Initialized
DEBUG - 2017-04-26 11:09:33 --> Pagination Class Initialized
INFO - 2017-04-26 11:09:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:09:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:09:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:09:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:09:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:09:33 --> Final output sent to browser
DEBUG - 2017-04-26 11:09:33 --> Total execution time: 0.4339
INFO - 2017-04-26 11:10:05 --> Config Class Initialized
INFO - 2017-04-26 11:10:05 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:05 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:05 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:05 --> URI Class Initialized
INFO - 2017-04-26 11:10:05 --> Router Class Initialized
INFO - 2017-04-26 11:10:05 --> Output Class Initialized
INFO - 2017-04-26 11:10:05 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:05 --> Input Class Initialized
INFO - 2017-04-26 11:10:05 --> Language Class Initialized
INFO - 2017-04-26 11:10:05 --> Loader Class Initialized
INFO - 2017-04-26 11:10:05 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:05 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:05 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:05 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:05 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:05 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:05 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:05 --> Session Class Initialized
INFO - 2017-04-26 11:10:05 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:05 --> Session routines successfully run
INFO - 2017-04-26 11:10:05 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:05 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:05 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:06 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:06 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:10:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:06 --> Final output sent to browser
DEBUG - 2017-04-26 11:10:06 --> Total execution time: 0.4594
INFO - 2017-04-26 11:10:08 --> Config Class Initialized
INFO - 2017-04-26 11:10:08 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:08 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:08 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:08 --> URI Class Initialized
INFO - 2017-04-26 11:10:08 --> Router Class Initialized
INFO - 2017-04-26 11:10:08 --> Output Class Initialized
INFO - 2017-04-26 11:10:08 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:08 --> Input Class Initialized
INFO - 2017-04-26 11:10:08 --> Language Class Initialized
INFO - 2017-04-26 11:10:08 --> Loader Class Initialized
INFO - 2017-04-26 11:10:08 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:08 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:08 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:08 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:08 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:08 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:08 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:08 --> Session Class Initialized
INFO - 2017-04-26 11:10:08 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:08 --> Session routines successfully run
INFO - 2017-04-26 11:10:08 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:08 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:08 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:08 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:08 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:10:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:08 --> Final output sent to browser
DEBUG - 2017-04-26 11:10:08 --> Total execution time: 0.4431
INFO - 2017-04-26 11:10:09 --> Config Class Initialized
INFO - 2017-04-26 11:10:09 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:09 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:09 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:09 --> URI Class Initialized
INFO - 2017-04-26 11:10:09 --> Router Class Initialized
INFO - 2017-04-26 11:10:09 --> Output Class Initialized
INFO - 2017-04-26 11:10:09 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:09 --> Input Class Initialized
INFO - 2017-04-26 11:10:09 --> Language Class Initialized
INFO - 2017-04-26 11:10:09 --> Loader Class Initialized
INFO - 2017-04-26 11:10:09 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:09 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:09 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:09 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:09 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:09 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:09 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:09 --> Session Class Initialized
INFO - 2017-04-26 11:10:09 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:09 --> Session routines successfully run
INFO - 2017-04-26 11:10:09 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:09 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:09 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:09 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:10:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:09 --> Final output sent to browser
DEBUG - 2017-04-26 11:10:09 --> Total execution time: 0.4496
INFO - 2017-04-26 11:10:10 --> Config Class Initialized
INFO - 2017-04-26 11:10:10 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:10 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:10 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:10 --> URI Class Initialized
INFO - 2017-04-26 11:10:10 --> Router Class Initialized
INFO - 2017-04-26 11:10:10 --> Output Class Initialized
INFO - 2017-04-26 11:10:10 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:10 --> Input Class Initialized
INFO - 2017-04-26 11:10:10 --> Language Class Initialized
INFO - 2017-04-26 11:10:10 --> Loader Class Initialized
INFO - 2017-04-26 11:10:10 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:10 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:10 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:10 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:10 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:10 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:10 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:10 --> Session Class Initialized
INFO - 2017-04-26 11:10:10 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:10 --> Session routines successfully run
INFO - 2017-04-26 11:10:10 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:10 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:10 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:10 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:10 --> Config Class Initialized
INFO - 2017-04-26 11:10:10 --> Hooks Class Initialized
INFO - 2017-04-26 11:10:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
DEBUG - 2017-04-26 11:10:11 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:11 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:11 --> URI Class Initialized
INFO - 2017-04-26 11:10:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:11 --> Router Class Initialized
INFO - 2017-04-26 11:10:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:11 --> Output Class Initialized
INFO - 2017-04-26 11:10:11 --> Final output sent to browser
INFO - 2017-04-26 11:10:11 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:11 --> Total execution time: 0.4859
DEBUG - 2017-04-26 11:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:11 --> Input Class Initialized
INFO - 2017-04-26 11:10:11 --> Language Class Initialized
INFO - 2017-04-26 11:10:11 --> Loader Class Initialized
INFO - 2017-04-26 11:10:11 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:11 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:11 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:11 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:11 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:11 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:11 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:11 --> Session Class Initialized
INFO - 2017-04-26 11:10:11 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:11 --> Session routines successfully run
INFO - 2017-04-26 11:10:11 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:11 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:11 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:11 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:10:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:11 --> Final output sent to browser
DEBUG - 2017-04-26 11:10:11 --> Total execution time: 0.5209
INFO - 2017-04-26 11:10:11 --> Config Class Initialized
INFO - 2017-04-26 11:10:11 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:11 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:11 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:11 --> URI Class Initialized
INFO - 2017-04-26 11:10:11 --> Router Class Initialized
INFO - 2017-04-26 11:10:11 --> Output Class Initialized
INFO - 2017-04-26 11:10:11 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:11 --> Input Class Initialized
INFO - 2017-04-26 11:10:11 --> Language Class Initialized
INFO - 2017-04-26 11:10:11 --> Loader Class Initialized
INFO - 2017-04-26 11:10:11 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:11 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:11 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:11 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:11 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:12 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:12 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:12 --> Session Class Initialized
INFO - 2017-04-26 11:10:12 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:12 --> Session routines successfully run
INFO - 2017-04-26 11:10:12 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:12 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:12 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:12 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:10:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:12 --> Final output sent to browser
DEBUG - 2017-04-26 11:10:12 --> Total execution time: 0.4505
INFO - 2017-04-26 11:10:39 --> Config Class Initialized
INFO - 2017-04-26 11:10:39 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:39 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:39 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:39 --> URI Class Initialized
INFO - 2017-04-26 11:10:39 --> Router Class Initialized
INFO - 2017-04-26 11:10:39 --> Output Class Initialized
INFO - 2017-04-26 11:10:39 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:39 --> Input Class Initialized
INFO - 2017-04-26 11:10:39 --> Language Class Initialized
INFO - 2017-04-26 11:10:39 --> Loader Class Initialized
INFO - 2017-04-26 11:10:39 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:39 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:39 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:39 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:39 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:39 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:39 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:39 --> Session Class Initialized
INFO - 2017-04-26 11:10:39 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:39 --> Session routines successfully run
INFO - 2017-04-26 11:10:39 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:39 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:39 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:39 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:39 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:10:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:39 --> Final output sent to browser
DEBUG - 2017-04-26 11:10:40 --> Total execution time: 0.4378
INFO - 2017-04-26 11:10:44 --> Config Class Initialized
INFO - 2017-04-26 11:10:44 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:44 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:44 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:44 --> URI Class Initialized
INFO - 2017-04-26 11:10:44 --> Router Class Initialized
INFO - 2017-04-26 11:10:44 --> Output Class Initialized
INFO - 2017-04-26 11:10:44 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:44 --> Input Class Initialized
INFO - 2017-04-26 11:10:44 --> Language Class Initialized
INFO - 2017-04-26 11:10:44 --> Loader Class Initialized
INFO - 2017-04-26 11:10:44 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:44 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:44 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:44 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:44 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:44 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:44 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:44 --> Session Class Initialized
INFO - 2017-04-26 11:10:44 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:44 --> Session routines successfully run
INFO - 2017-04-26 11:10:44 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:44 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:44 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:44 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:44 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:10:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:44 --> Final output sent to browser
DEBUG - 2017-04-26 11:10:44 --> Total execution time: 0.4982
INFO - 2017-04-26 11:10:47 --> Config Class Initialized
INFO - 2017-04-26 11:10:47 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:47 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:47 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:47 --> URI Class Initialized
INFO - 2017-04-26 11:10:47 --> Router Class Initialized
INFO - 2017-04-26 11:10:47 --> Output Class Initialized
INFO - 2017-04-26 11:10:47 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:47 --> Input Class Initialized
INFO - 2017-04-26 11:10:47 --> Language Class Initialized
INFO - 2017-04-26 11:10:47 --> Loader Class Initialized
INFO - 2017-04-26 11:10:47 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:47 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:47 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:47 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:47 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:47 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:47 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:47 --> Session Class Initialized
INFO - 2017-04-26 11:10:47 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:47 --> Session routines successfully run
INFO - 2017-04-26 11:10:47 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:47 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:47 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:47 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:47 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:10:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:48 --> Final output sent to browser
DEBUG - 2017-04-26 11:10:48 --> Total execution time: 0.4422
INFO - 2017-04-26 11:10:49 --> Config Class Initialized
INFO - 2017-04-26 11:10:49 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:49 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:49 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:49 --> URI Class Initialized
INFO - 2017-04-26 11:10:49 --> Router Class Initialized
INFO - 2017-04-26 11:10:49 --> Output Class Initialized
INFO - 2017-04-26 11:10:49 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:49 --> Input Class Initialized
INFO - 2017-04-26 11:10:49 --> Language Class Initialized
INFO - 2017-04-26 11:10:49 --> Loader Class Initialized
INFO - 2017-04-26 11:10:49 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:49 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:49 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:49 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:49 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:49 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:49 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:49 --> Session Class Initialized
INFO - 2017-04-26 11:10:49 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:49 --> Session routines successfully run
INFO - 2017-04-26 11:10:49 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:49 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:49 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:49 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:49 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:10:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:49 --> Final output sent to browser
DEBUG - 2017-04-26 11:10:49 --> Total execution time: 0.4531
INFO - 2017-04-26 11:10:51 --> Config Class Initialized
INFO - 2017-04-26 11:10:51 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:51 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:51 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:51 --> URI Class Initialized
INFO - 2017-04-26 11:10:51 --> Router Class Initialized
INFO - 2017-04-26 11:10:51 --> Output Class Initialized
INFO - 2017-04-26 11:10:51 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:51 --> Input Class Initialized
INFO - 2017-04-26 11:10:51 --> Language Class Initialized
INFO - 2017-04-26 11:10:51 --> Loader Class Initialized
INFO - 2017-04-26 11:10:51 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:51 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:51 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:51 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:51 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:51 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:51 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:51 --> Session Class Initialized
INFO - 2017-04-26 11:10:51 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:51 --> Session routines successfully run
INFO - 2017-04-26 11:10:51 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:51 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:51 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:51 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:51 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:10:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:52 --> Final output sent to browser
DEBUG - 2017-04-26 11:10:52 --> Total execution time: 0.4626
INFO - 2017-04-26 11:10:53 --> Config Class Initialized
INFO - 2017-04-26 11:10:53 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:53 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:53 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:53 --> URI Class Initialized
INFO - 2017-04-26 11:10:53 --> Router Class Initialized
INFO - 2017-04-26 11:10:53 --> Output Class Initialized
INFO - 2017-04-26 11:10:53 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:53 --> Input Class Initialized
INFO - 2017-04-26 11:10:53 --> Language Class Initialized
INFO - 2017-04-26 11:10:53 --> Loader Class Initialized
INFO - 2017-04-26 11:10:53 --> Helper loaded: url_helper
INFO - 2017-04-26 11:10:53 --> Helper loaded: form_helper
INFO - 2017-04-26 11:10:53 --> Helper loaded: html_helper
INFO - 2017-04-26 11:10:53 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:10:53 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:10:53 --> Database Driver Class Initialized
INFO - 2017-04-26 11:10:53 --> Parser Class Initialized
DEBUG - 2017-04-26 11:10:53 --> Session Class Initialized
INFO - 2017-04-26 11:10:53 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:10:53 --> Session routines successfully run
INFO - 2017-04-26 11:10:53 --> Form Validation Class Initialized
INFO - 2017-04-26 11:10:53 --> Controller Class Initialized
DEBUG - 2017-04-26 11:10:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:10:53 --> Model Class Initialized
DEBUG - 2017-04-26 11:10:53 --> Pagination Class Initialized
INFO - 2017-04-26 11:10:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:10:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:10:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:10:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:10:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:10:53 --> Final output sent to browser
DEBUG - 2017-04-26 11:10:53 --> Total execution time: 0.4485
INFO - 2017-04-26 11:10:56 --> Config Class Initialized
INFO - 2017-04-26 11:10:56 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:56 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:56 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:56 --> URI Class Initialized
INFO - 2017-04-26 11:10:56 --> Router Class Initialized
INFO - 2017-04-26 11:10:56 --> Output Class Initialized
INFO - 2017-04-26 11:10:56 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:56 --> Input Class Initialized
INFO - 2017-04-26 11:10:56 --> Language Class Initialized
ERROR - 2017-04-26 11:10:56 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:10:57 --> Config Class Initialized
INFO - 2017-04-26 11:10:57 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:57 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:57 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:57 --> URI Class Initialized
INFO - 2017-04-26 11:10:57 --> Router Class Initialized
INFO - 2017-04-26 11:10:57 --> Output Class Initialized
INFO - 2017-04-26 11:10:57 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:57 --> Input Class Initialized
INFO - 2017-04-26 11:10:57 --> Language Class Initialized
ERROR - 2017-04-26 11:10:57 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:10:58 --> Config Class Initialized
INFO - 2017-04-26 11:10:58 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:58 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:58 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:58 --> URI Class Initialized
INFO - 2017-04-26 11:10:58 --> Router Class Initialized
INFO - 2017-04-26 11:10:58 --> Output Class Initialized
INFO - 2017-04-26 11:10:58 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:58 --> Input Class Initialized
INFO - 2017-04-26 11:10:58 --> Language Class Initialized
ERROR - 2017-04-26 11:10:58 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:10:58 --> Config Class Initialized
INFO - 2017-04-26 11:10:58 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:58 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:58 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:58 --> URI Class Initialized
INFO - 2017-04-26 11:10:58 --> Router Class Initialized
INFO - 2017-04-26 11:10:58 --> Output Class Initialized
INFO - 2017-04-26 11:10:58 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:59 --> Input Class Initialized
INFO - 2017-04-26 11:10:59 --> Language Class Initialized
ERROR - 2017-04-26 11:10:59 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:10:59 --> Config Class Initialized
INFO - 2017-04-26 11:10:59 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:10:59 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:10:59 --> Utf8 Class Initialized
INFO - 2017-04-26 11:10:59 --> URI Class Initialized
INFO - 2017-04-26 11:10:59 --> Router Class Initialized
INFO - 2017-04-26 11:10:59 --> Output Class Initialized
INFO - 2017-04-26 11:10:59 --> Security Class Initialized
DEBUG - 2017-04-26 11:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:10:59 --> Input Class Initialized
INFO - 2017-04-26 11:10:59 --> Language Class Initialized
ERROR - 2017-04-26 11:10:59 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:11:01 --> Config Class Initialized
INFO - 2017-04-26 11:11:01 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:11:01 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:11:01 --> Utf8 Class Initialized
INFO - 2017-04-26 11:11:01 --> URI Class Initialized
INFO - 2017-04-26 11:11:01 --> Router Class Initialized
INFO - 2017-04-26 11:11:01 --> Output Class Initialized
INFO - 2017-04-26 11:11:01 --> Security Class Initialized
DEBUG - 2017-04-26 11:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:11:01 --> Input Class Initialized
INFO - 2017-04-26 11:11:01 --> Language Class Initialized
ERROR - 2017-04-26 11:11:01 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:11:02 --> Config Class Initialized
INFO - 2017-04-26 11:11:02 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:11:02 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:11:02 --> Utf8 Class Initialized
INFO - 2017-04-26 11:11:02 --> URI Class Initialized
INFO - 2017-04-26 11:11:02 --> Router Class Initialized
INFO - 2017-04-26 11:11:02 --> Output Class Initialized
INFO - 2017-04-26 11:11:02 --> Security Class Initialized
DEBUG - 2017-04-26 11:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:11:02 --> Input Class Initialized
INFO - 2017-04-26 11:11:02 --> Language Class Initialized
ERROR - 2017-04-26 11:11:02 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:11:03 --> Config Class Initialized
INFO - 2017-04-26 11:11:03 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:11:03 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:11:03 --> Utf8 Class Initialized
INFO - 2017-04-26 11:11:03 --> URI Class Initialized
INFO - 2017-04-26 11:11:03 --> Router Class Initialized
INFO - 2017-04-26 11:11:03 --> Output Class Initialized
INFO - 2017-04-26 11:11:03 --> Security Class Initialized
DEBUG - 2017-04-26 11:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:11:03 --> Input Class Initialized
INFO - 2017-04-26 11:11:03 --> Language Class Initialized
ERROR - 2017-04-26 11:11:03 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:11:29 --> Config Class Initialized
INFO - 2017-04-26 11:11:29 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:11:30 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:11:30 --> Utf8 Class Initialized
INFO - 2017-04-26 11:11:30 --> URI Class Initialized
INFO - 2017-04-26 11:11:30 --> Router Class Initialized
INFO - 2017-04-26 11:11:30 --> Output Class Initialized
INFO - 2017-04-26 11:11:30 --> Security Class Initialized
DEBUG - 2017-04-26 11:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:11:30 --> Input Class Initialized
INFO - 2017-04-26 11:11:30 --> Language Class Initialized
INFO - 2017-04-26 11:11:30 --> Loader Class Initialized
INFO - 2017-04-26 11:11:30 --> Helper loaded: url_helper
INFO - 2017-04-26 11:11:30 --> Helper loaded: form_helper
INFO - 2017-04-26 11:11:30 --> Helper loaded: html_helper
INFO - 2017-04-26 11:11:30 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:11:30 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:11:30 --> Database Driver Class Initialized
INFO - 2017-04-26 11:11:30 --> Parser Class Initialized
DEBUG - 2017-04-26 11:11:30 --> Session Class Initialized
INFO - 2017-04-26 11:11:30 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:11:30 --> Session routines successfully run
INFO - 2017-04-26 11:11:30 --> Form Validation Class Initialized
INFO - 2017-04-26 11:11:30 --> Controller Class Initialized
DEBUG - 2017-04-26 11:11:30 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:11:30 --> Model Class Initialized
DEBUG - 2017-04-26 11:11:30 --> Pagination Class Initialized
INFO - 2017-04-26 11:11:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:11:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:11:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:11:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:11:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:11:30 --> Final output sent to browser
DEBUG - 2017-04-26 11:11:31 --> Total execution time: 1.0377
INFO - 2017-04-26 11:11:35 --> Config Class Initialized
INFO - 2017-04-26 11:11:35 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:11:35 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:11:36 --> Utf8 Class Initialized
INFO - 2017-04-26 11:11:36 --> URI Class Initialized
INFO - 2017-04-26 11:11:36 --> Router Class Initialized
INFO - 2017-04-26 11:11:36 --> Output Class Initialized
INFO - 2017-04-26 11:11:36 --> Security Class Initialized
DEBUG - 2017-04-26 11:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:11:36 --> Input Class Initialized
INFO - 2017-04-26 11:11:36 --> Language Class Initialized
ERROR - 2017-04-26 11:11:36 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:11:36 --> Config Class Initialized
INFO - 2017-04-26 11:11:36 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:11:36 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:11:36 --> Utf8 Class Initialized
INFO - 2017-04-26 11:11:36 --> URI Class Initialized
INFO - 2017-04-26 11:11:36 --> Router Class Initialized
INFO - 2017-04-26 11:11:36 --> Output Class Initialized
INFO - 2017-04-26 11:11:36 --> Security Class Initialized
DEBUG - 2017-04-26 11:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:11:36 --> Input Class Initialized
INFO - 2017-04-26 11:11:36 --> Language Class Initialized
ERROR - 2017-04-26 11:11:36 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:11:36 --> Config Class Initialized
INFO - 2017-04-26 11:11:36 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:11:36 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:11:36 --> Utf8 Class Initialized
INFO - 2017-04-26 11:11:36 --> URI Class Initialized
INFO - 2017-04-26 11:11:36 --> Router Class Initialized
INFO - 2017-04-26 11:11:36 --> Output Class Initialized
INFO - 2017-04-26 11:11:36 --> Security Class Initialized
DEBUG - 2017-04-26 11:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:11:36 --> Input Class Initialized
INFO - 2017-04-26 11:11:36 --> Language Class Initialized
ERROR - 2017-04-26 11:11:36 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:11:36 --> Config Class Initialized
INFO - 2017-04-26 11:11:36 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:11:36 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:11:36 --> Utf8 Class Initialized
INFO - 2017-04-26 11:11:36 --> URI Class Initialized
INFO - 2017-04-26 11:11:36 --> Router Class Initialized
INFO - 2017-04-26 11:11:36 --> Output Class Initialized
INFO - 2017-04-26 11:11:36 --> Security Class Initialized
DEBUG - 2017-04-26 11:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:11:36 --> Input Class Initialized
INFO - 2017-04-26 11:11:36 --> Language Class Initialized
ERROR - 2017-04-26 11:11:37 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:11:37 --> Config Class Initialized
INFO - 2017-04-26 11:11:37 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:11:37 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:11:37 --> Utf8 Class Initialized
INFO - 2017-04-26 11:11:37 --> URI Class Initialized
INFO - 2017-04-26 11:11:37 --> Router Class Initialized
INFO - 2017-04-26 11:11:37 --> Output Class Initialized
INFO - 2017-04-26 11:11:37 --> Security Class Initialized
DEBUG - 2017-04-26 11:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:11:37 --> Input Class Initialized
INFO - 2017-04-26 11:11:37 --> Language Class Initialized
ERROR - 2017-04-26 11:11:37 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:11:37 --> Config Class Initialized
INFO - 2017-04-26 11:11:37 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:11:37 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:11:37 --> Utf8 Class Initialized
INFO - 2017-04-26 11:11:37 --> URI Class Initialized
INFO - 2017-04-26 11:11:37 --> Router Class Initialized
INFO - 2017-04-26 11:11:37 --> Output Class Initialized
INFO - 2017-04-26 11:11:37 --> Security Class Initialized
DEBUG - 2017-04-26 11:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:11:37 --> Input Class Initialized
INFO - 2017-04-26 11:11:37 --> Language Class Initialized
ERROR - 2017-04-26 11:11:37 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:14:11 --> Config Class Initialized
INFO - 2017-04-26 11:14:11 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:14:11 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:14:11 --> Utf8 Class Initialized
INFO - 2017-04-26 11:14:11 --> URI Class Initialized
INFO - 2017-04-26 11:14:11 --> Router Class Initialized
INFO - 2017-04-26 11:14:11 --> Output Class Initialized
INFO - 2017-04-26 11:14:11 --> Security Class Initialized
DEBUG - 2017-04-26 11:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:14:11 --> Input Class Initialized
INFO - 2017-04-26 11:14:11 --> Language Class Initialized
INFO - 2017-04-26 11:14:11 --> Loader Class Initialized
INFO - 2017-04-26 11:14:11 --> Helper loaded: url_helper
INFO - 2017-04-26 11:14:11 --> Helper loaded: form_helper
INFO - 2017-04-26 11:14:11 --> Helper loaded: html_helper
INFO - 2017-04-26 11:14:11 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:14:11 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:14:11 --> Database Driver Class Initialized
INFO - 2017-04-26 11:14:11 --> Parser Class Initialized
DEBUG - 2017-04-26 11:14:11 --> Session Class Initialized
INFO - 2017-04-26 11:14:11 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:14:11 --> Session routines successfully run
INFO - 2017-04-26 11:14:11 --> Form Validation Class Initialized
INFO - 2017-04-26 11:14:11 --> Controller Class Initialized
DEBUG - 2017-04-26 11:14:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:14:11 --> Model Class Initialized
DEBUG - 2017-04-26 11:14:11 --> Pagination Class Initialized
INFO - 2017-04-26 11:14:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:14:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:14:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:14:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:14:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:14:12 --> Final output sent to browser
DEBUG - 2017-04-26 11:14:12 --> Total execution time: 0.4707
INFO - 2017-04-26 11:16:27 --> Config Class Initialized
INFO - 2017-04-26 11:16:27 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:27 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:27 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:28 --> URI Class Initialized
INFO - 2017-04-26 11:16:28 --> Router Class Initialized
INFO - 2017-04-26 11:16:28 --> Output Class Initialized
INFO - 2017-04-26 11:16:28 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:28 --> Input Class Initialized
INFO - 2017-04-26 11:16:28 --> Language Class Initialized
INFO - 2017-04-26 11:16:28 --> Loader Class Initialized
INFO - 2017-04-26 11:16:28 --> Helper loaded: url_helper
INFO - 2017-04-26 11:16:28 --> Helper loaded: form_helper
INFO - 2017-04-26 11:16:28 --> Helper loaded: html_helper
INFO - 2017-04-26 11:16:28 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:16:28 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:16:28 --> Database Driver Class Initialized
INFO - 2017-04-26 11:16:28 --> Parser Class Initialized
DEBUG - 2017-04-26 11:16:28 --> Session Class Initialized
INFO - 2017-04-26 11:16:28 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:16:28 --> Session routines successfully run
INFO - 2017-04-26 11:16:28 --> Form Validation Class Initialized
INFO - 2017-04-26 11:16:28 --> Controller Class Initialized
DEBUG - 2017-04-26 11:16:28 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:16:28 --> Model Class Initialized
DEBUG - 2017-04-26 11:16:28 --> Pagination Class Initialized
INFO - 2017-04-26 11:16:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:16:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:16:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:16:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:16:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:16:28 --> Final output sent to browser
DEBUG - 2017-04-26 11:16:28 --> Total execution time: 0.5060
INFO - 2017-04-26 11:16:37 --> Config Class Initialized
INFO - 2017-04-26 11:16:37 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:37 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:37 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:37 --> URI Class Initialized
INFO - 2017-04-26 11:16:37 --> Router Class Initialized
INFO - 2017-04-26 11:16:37 --> Output Class Initialized
INFO - 2017-04-26 11:16:37 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:37 --> Input Class Initialized
INFO - 2017-04-26 11:16:37 --> Language Class Initialized
INFO - 2017-04-26 11:16:37 --> Loader Class Initialized
INFO - 2017-04-26 11:16:37 --> Helper loaded: url_helper
INFO - 2017-04-26 11:16:37 --> Helper loaded: form_helper
INFO - 2017-04-26 11:16:37 --> Helper loaded: html_helper
INFO - 2017-04-26 11:16:37 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:16:37 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:16:37 --> Database Driver Class Initialized
INFO - 2017-04-26 11:16:37 --> Parser Class Initialized
DEBUG - 2017-04-26 11:16:37 --> Session Class Initialized
INFO - 2017-04-26 11:16:37 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:16:37 --> Session routines successfully run
INFO - 2017-04-26 11:16:37 --> Form Validation Class Initialized
INFO - 2017-04-26 11:16:37 --> Controller Class Initialized
DEBUG - 2017-04-26 11:16:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:16:37 --> Model Class Initialized
DEBUG - 2017-04-26 11:16:37 --> Pagination Class Initialized
INFO - 2017-04-26 11:16:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:16:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:16:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:16:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:16:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:16:37 --> Final output sent to browser
DEBUG - 2017-04-26 11:16:37 --> Total execution time: 0.4502
INFO - 2017-04-26 11:16:38 --> Config Class Initialized
INFO - 2017-04-26 11:16:38 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:38 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:38 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:38 --> URI Class Initialized
INFO - 2017-04-26 11:16:38 --> Router Class Initialized
INFO - 2017-04-26 11:16:38 --> Output Class Initialized
INFO - 2017-04-26 11:16:38 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:38 --> Input Class Initialized
INFO - 2017-04-26 11:16:38 --> Language Class Initialized
ERROR - 2017-04-26 11:16:38 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:16:49 --> Config Class Initialized
INFO - 2017-04-26 11:16:49 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:49 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:49 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:49 --> URI Class Initialized
INFO - 2017-04-26 11:16:49 --> Router Class Initialized
INFO - 2017-04-26 11:16:49 --> Output Class Initialized
INFO - 2017-04-26 11:16:49 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:49 --> Input Class Initialized
INFO - 2017-04-26 11:16:49 --> Language Class Initialized
INFO - 2017-04-26 11:16:49 --> Loader Class Initialized
INFO - 2017-04-26 11:16:49 --> Helper loaded: url_helper
INFO - 2017-04-26 11:16:49 --> Helper loaded: form_helper
INFO - 2017-04-26 11:16:49 --> Helper loaded: html_helper
INFO - 2017-04-26 11:16:49 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:16:49 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:16:49 --> Database Driver Class Initialized
INFO - 2017-04-26 11:16:49 --> Parser Class Initialized
DEBUG - 2017-04-26 11:16:49 --> Session Class Initialized
INFO - 2017-04-26 11:16:49 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:16:50 --> Session routines successfully run
INFO - 2017-04-26 11:16:50 --> Form Validation Class Initialized
INFO - 2017-04-26 11:16:50 --> Controller Class Initialized
DEBUG - 2017-04-26 11:16:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:16:50 --> Model Class Initialized
DEBUG - 2017-04-26 11:16:50 --> Pagination Class Initialized
INFO - 2017-04-26 11:16:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:16:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:16:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:16:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:16:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:16:50 --> Final output sent to browser
DEBUG - 2017-04-26 11:16:50 --> Total execution time: 0.4794
INFO - 2017-04-26 11:16:53 --> Config Class Initialized
INFO - 2017-04-26 11:16:53 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:53 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:53 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:53 --> URI Class Initialized
INFO - 2017-04-26 11:16:53 --> Router Class Initialized
INFO - 2017-04-26 11:16:53 --> Output Class Initialized
INFO - 2017-04-26 11:16:53 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:53 --> Input Class Initialized
INFO - 2017-04-26 11:16:53 --> Language Class Initialized
ERROR - 2017-04-26 11:16:53 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:16:53 --> Config Class Initialized
INFO - 2017-04-26 11:16:53 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:53 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:53 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:53 --> URI Class Initialized
INFO - 2017-04-26 11:16:54 --> Router Class Initialized
INFO - 2017-04-26 11:16:54 --> Output Class Initialized
INFO - 2017-04-26 11:16:54 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:54 --> Input Class Initialized
INFO - 2017-04-26 11:16:54 --> Language Class Initialized
ERROR - 2017-04-26 11:16:54 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:16:54 --> Config Class Initialized
INFO - 2017-04-26 11:16:54 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:54 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:54 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:54 --> URI Class Initialized
INFO - 2017-04-26 11:16:54 --> Router Class Initialized
INFO - 2017-04-26 11:16:54 --> Output Class Initialized
INFO - 2017-04-26 11:16:54 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:54 --> Input Class Initialized
INFO - 2017-04-26 11:16:54 --> Language Class Initialized
ERROR - 2017-04-26 11:16:54 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:16:55 --> Config Class Initialized
INFO - 2017-04-26 11:16:55 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:55 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:55 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:55 --> URI Class Initialized
INFO - 2017-04-26 11:16:55 --> Router Class Initialized
INFO - 2017-04-26 11:16:55 --> Output Class Initialized
INFO - 2017-04-26 11:16:55 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:55 --> Input Class Initialized
INFO - 2017-04-26 11:16:55 --> Language Class Initialized
ERROR - 2017-04-26 11:16:55 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:16:55 --> Config Class Initialized
INFO - 2017-04-26 11:16:55 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:55 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:55 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:55 --> URI Class Initialized
INFO - 2017-04-26 11:16:55 --> Router Class Initialized
INFO - 2017-04-26 11:16:55 --> Output Class Initialized
INFO - 2017-04-26 11:16:55 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:55 --> Input Class Initialized
INFO - 2017-04-26 11:16:55 --> Language Class Initialized
ERROR - 2017-04-26 11:16:55 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:16:56 --> Config Class Initialized
INFO - 2017-04-26 11:16:56 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:56 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:56 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:56 --> URI Class Initialized
INFO - 2017-04-26 11:16:56 --> Router Class Initialized
INFO - 2017-04-26 11:16:56 --> Output Class Initialized
INFO - 2017-04-26 11:16:56 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:56 --> Input Class Initialized
INFO - 2017-04-26 11:16:56 --> Language Class Initialized
ERROR - 2017-04-26 11:16:56 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:16:56 --> Config Class Initialized
INFO - 2017-04-26 11:16:56 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:56 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:56 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:56 --> URI Class Initialized
INFO - 2017-04-26 11:16:56 --> Router Class Initialized
INFO - 2017-04-26 11:16:56 --> Output Class Initialized
INFO - 2017-04-26 11:16:56 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:56 --> Input Class Initialized
INFO - 2017-04-26 11:16:56 --> Language Class Initialized
ERROR - 2017-04-26 11:16:56 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:16:57 --> Config Class Initialized
INFO - 2017-04-26 11:16:57 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:57 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:57 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:57 --> URI Class Initialized
INFO - 2017-04-26 11:16:57 --> Router Class Initialized
INFO - 2017-04-26 11:16:57 --> Output Class Initialized
INFO - 2017-04-26 11:16:57 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:57 --> Input Class Initialized
INFO - 2017-04-26 11:16:57 --> Language Class Initialized
ERROR - 2017-04-26 11:16:57 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:16:57 --> Config Class Initialized
INFO - 2017-04-26 11:16:57 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:57 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:57 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:57 --> URI Class Initialized
INFO - 2017-04-26 11:16:57 --> Router Class Initialized
INFO - 2017-04-26 11:16:57 --> Output Class Initialized
INFO - 2017-04-26 11:16:57 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:57 --> Input Class Initialized
INFO - 2017-04-26 11:16:57 --> Language Class Initialized
ERROR - 2017-04-26 11:16:57 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:16:58 --> Config Class Initialized
INFO - 2017-04-26 11:16:58 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:16:58 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:16:58 --> Utf8 Class Initialized
INFO - 2017-04-26 11:16:58 --> URI Class Initialized
INFO - 2017-04-26 11:16:58 --> Router Class Initialized
INFO - 2017-04-26 11:16:58 --> Output Class Initialized
INFO - 2017-04-26 11:16:58 --> Security Class Initialized
DEBUG - 2017-04-26 11:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:16:58 --> Input Class Initialized
INFO - 2017-04-26 11:16:58 --> Language Class Initialized
ERROR - 2017-04-26 11:16:58 --> 404 Page Not Found: Company/change_api_status
INFO - 2017-04-26 11:18:54 --> Config Class Initialized
INFO - 2017-04-26 11:18:54 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:18:54 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:18:54 --> Utf8 Class Initialized
INFO - 2017-04-26 11:18:54 --> URI Class Initialized
INFO - 2017-04-26 11:18:54 --> Router Class Initialized
INFO - 2017-04-26 11:18:54 --> Output Class Initialized
INFO - 2017-04-26 11:18:54 --> Security Class Initialized
DEBUG - 2017-04-26 11:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:18:54 --> Input Class Initialized
INFO - 2017-04-26 11:18:54 --> Language Class Initialized
INFO - 2017-04-26 11:18:54 --> Loader Class Initialized
INFO - 2017-04-26 11:18:54 --> Helper loaded: url_helper
INFO - 2017-04-26 11:18:54 --> Helper loaded: form_helper
INFO - 2017-04-26 11:18:54 --> Helper loaded: html_helper
INFO - 2017-04-26 11:18:54 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:18:54 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:18:54 --> Database Driver Class Initialized
INFO - 2017-04-26 11:18:54 --> Parser Class Initialized
DEBUG - 2017-04-26 11:18:54 --> Session Class Initialized
INFO - 2017-04-26 11:18:54 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:18:54 --> Session routines successfully run
INFO - 2017-04-26 11:18:54 --> Form Validation Class Initialized
INFO - 2017-04-26 11:18:54 --> Controller Class Initialized
DEBUG - 2017-04-26 11:18:54 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:18:54 --> Model Class Initialized
DEBUG - 2017-04-26 11:18:54 --> Pagination Class Initialized
INFO - 2017-04-26 11:18:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:18:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:18:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:18:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:18:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:18:55 --> Final output sent to browser
DEBUG - 2017-04-26 11:18:55 --> Total execution time: 0.7980
INFO - 2017-04-26 11:18:58 --> Config Class Initialized
INFO - 2017-04-26 11:18:58 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:18:58 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:18:58 --> Utf8 Class Initialized
INFO - 2017-04-26 11:18:58 --> URI Class Initialized
INFO - 2017-04-26 11:18:58 --> Router Class Initialized
INFO - 2017-04-26 11:18:58 --> Output Class Initialized
INFO - 2017-04-26 11:18:58 --> Security Class Initialized
DEBUG - 2017-04-26 11:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:18:58 --> Input Class Initialized
INFO - 2017-04-26 11:18:58 --> Language Class Initialized
INFO - 2017-04-26 11:18:58 --> Loader Class Initialized
INFO - 2017-04-26 11:18:58 --> Helper loaded: url_helper
INFO - 2017-04-26 11:18:58 --> Helper loaded: form_helper
INFO - 2017-04-26 11:18:58 --> Helper loaded: html_helper
INFO - 2017-04-26 11:18:58 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:18:58 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:18:58 --> Database Driver Class Initialized
INFO - 2017-04-26 11:18:58 --> Parser Class Initialized
DEBUG - 2017-04-26 11:18:58 --> Session Class Initialized
INFO - 2017-04-26 11:18:58 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:18:58 --> Session routines successfully run
INFO - 2017-04-26 11:18:58 --> Form Validation Class Initialized
INFO - 2017-04-26 11:18:58 --> Controller Class Initialized
DEBUG - 2017-04-26 11:18:58 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:18:58 --> Model Class Initialized
DEBUG - 2017-04-26 11:18:58 --> Pagination Class Initialized
INFO - 2017-04-26 11:18:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:18:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:18:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:18:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:18:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:18:58 --> Final output sent to browser
DEBUG - 2017-04-26 11:18:58 --> Total execution time: 0.5743
INFO - 2017-04-26 11:19:21 --> Config Class Initialized
INFO - 2017-04-26 11:19:21 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:19:21 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:19:22 --> Utf8 Class Initialized
INFO - 2017-04-26 11:19:22 --> URI Class Initialized
INFO - 2017-04-26 11:19:22 --> Router Class Initialized
INFO - 2017-04-26 11:19:22 --> Output Class Initialized
INFO - 2017-04-26 11:19:22 --> Security Class Initialized
DEBUG - 2017-04-26 11:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:19:22 --> Input Class Initialized
INFO - 2017-04-26 11:19:22 --> Language Class Initialized
INFO - 2017-04-26 11:19:22 --> Loader Class Initialized
INFO - 2017-04-26 11:19:22 --> Helper loaded: url_helper
INFO - 2017-04-26 11:19:22 --> Helper loaded: form_helper
INFO - 2017-04-26 11:19:22 --> Helper loaded: html_helper
INFO - 2017-04-26 11:19:22 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:19:22 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:19:22 --> Database Driver Class Initialized
INFO - 2017-04-26 11:19:22 --> Parser Class Initialized
DEBUG - 2017-04-26 11:19:22 --> Session Class Initialized
INFO - 2017-04-26 11:19:22 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:19:22 --> Session routines successfully run
INFO - 2017-04-26 11:19:22 --> Form Validation Class Initialized
INFO - 2017-04-26 11:19:22 --> Controller Class Initialized
DEBUG - 2017-04-26 11:19:22 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:19:22 --> Model Class Initialized
DEBUG - 2017-04-26 11:19:22 --> Pagination Class Initialized
INFO - 2017-04-26 11:19:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:19:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:19:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:19:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:19:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:19:22 --> Final output sent to browser
DEBUG - 2017-04-26 11:19:22 --> Total execution time: 0.5057
INFO - 2017-04-26 11:20:10 --> Config Class Initialized
INFO - 2017-04-26 11:20:10 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:20:10 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:20:10 --> Utf8 Class Initialized
INFO - 2017-04-26 11:20:10 --> URI Class Initialized
INFO - 2017-04-26 11:20:10 --> Router Class Initialized
INFO - 2017-04-26 11:20:10 --> Output Class Initialized
INFO - 2017-04-26 11:20:10 --> Security Class Initialized
DEBUG - 2017-04-26 11:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:20:10 --> Input Class Initialized
INFO - 2017-04-26 11:20:10 --> Language Class Initialized
INFO - 2017-04-26 11:20:10 --> Loader Class Initialized
INFO - 2017-04-26 11:20:10 --> Helper loaded: url_helper
INFO - 2017-04-26 11:20:10 --> Helper loaded: form_helper
INFO - 2017-04-26 11:20:10 --> Helper loaded: html_helper
INFO - 2017-04-26 11:20:10 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:20:10 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:20:10 --> Database Driver Class Initialized
INFO - 2017-04-26 11:20:10 --> Parser Class Initialized
DEBUG - 2017-04-26 11:20:10 --> Session Class Initialized
INFO - 2017-04-26 11:20:10 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:20:10 --> Session routines successfully run
INFO - 2017-04-26 11:20:11 --> Form Validation Class Initialized
INFO - 2017-04-26 11:20:11 --> Controller Class Initialized
DEBUG - 2017-04-26 11:20:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:20:11 --> Model Class Initialized
DEBUG - 2017-04-26 11:20:11 --> Pagination Class Initialized
INFO - 2017-04-26 11:20:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:20:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:20:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:20:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:20:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:20:11 --> Final output sent to browser
DEBUG - 2017-04-26 11:20:11 --> Total execution time: 0.7643
INFO - 2017-04-26 11:20:12 --> Config Class Initialized
INFO - 2017-04-26 11:20:12 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:20:12 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:20:12 --> Utf8 Class Initialized
INFO - 2017-04-26 11:20:12 --> URI Class Initialized
INFO - 2017-04-26 11:20:12 --> Router Class Initialized
INFO - 2017-04-26 11:20:12 --> Output Class Initialized
INFO - 2017-04-26 11:20:12 --> Security Class Initialized
DEBUG - 2017-04-26 11:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:20:12 --> Input Class Initialized
INFO - 2017-04-26 11:20:12 --> Language Class Initialized
ERROR - 2017-04-26 11:20:12 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:21:36 --> Config Class Initialized
INFO - 2017-04-26 11:21:36 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:21:36 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:21:36 --> Utf8 Class Initialized
INFO - 2017-04-26 11:21:36 --> URI Class Initialized
INFO - 2017-04-26 11:21:36 --> Router Class Initialized
INFO - 2017-04-26 11:21:36 --> Output Class Initialized
INFO - 2017-04-26 11:21:36 --> Security Class Initialized
DEBUG - 2017-04-26 11:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:21:36 --> Input Class Initialized
INFO - 2017-04-26 11:21:36 --> Language Class Initialized
INFO - 2017-04-26 11:21:36 --> Loader Class Initialized
INFO - 2017-04-26 11:21:36 --> Helper loaded: url_helper
INFO - 2017-04-26 11:21:36 --> Helper loaded: form_helper
INFO - 2017-04-26 11:21:36 --> Helper loaded: html_helper
INFO - 2017-04-26 11:21:36 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:21:36 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:21:36 --> Database Driver Class Initialized
INFO - 2017-04-26 11:21:36 --> Parser Class Initialized
DEBUG - 2017-04-26 11:21:36 --> Session Class Initialized
INFO - 2017-04-26 11:21:36 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:21:36 --> Session routines successfully run
INFO - 2017-04-26 11:21:36 --> Form Validation Class Initialized
INFO - 2017-04-26 11:21:36 --> Controller Class Initialized
DEBUG - 2017-04-26 11:21:36 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:21:36 --> Model Class Initialized
DEBUG - 2017-04-26 11:21:36 --> Pagination Class Initialized
INFO - 2017-04-26 11:21:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:21:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:21:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:21:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:21:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:21:37 --> Final output sent to browser
DEBUG - 2017-04-26 11:21:37 --> Total execution time: 0.6985
INFO - 2017-04-26 11:21:37 --> Config Class Initialized
INFO - 2017-04-26 11:21:37 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:21:37 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:21:37 --> Utf8 Class Initialized
INFO - 2017-04-26 11:21:37 --> URI Class Initialized
INFO - 2017-04-26 11:21:37 --> Router Class Initialized
INFO - 2017-04-26 11:21:37 --> Output Class Initialized
INFO - 2017-04-26 11:21:37 --> Security Class Initialized
DEBUG - 2017-04-26 11:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:21:37 --> Input Class Initialized
INFO - 2017-04-26 11:21:37 --> Language Class Initialized
ERROR - 2017-04-26 11:21:37 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:21:46 --> Config Class Initialized
INFO - 2017-04-26 11:21:46 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:21:46 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:21:46 --> Utf8 Class Initialized
INFO - 2017-04-26 11:21:46 --> URI Class Initialized
INFO - 2017-04-26 11:21:46 --> Router Class Initialized
INFO - 2017-04-26 11:21:46 --> Output Class Initialized
INFO - 2017-04-26 11:21:46 --> Security Class Initialized
DEBUG - 2017-04-26 11:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:21:46 --> Input Class Initialized
INFO - 2017-04-26 11:21:46 --> Language Class Initialized
INFO - 2017-04-26 11:21:46 --> Loader Class Initialized
INFO - 2017-04-26 11:21:46 --> Helper loaded: url_helper
INFO - 2017-04-26 11:21:46 --> Helper loaded: form_helper
INFO - 2017-04-26 11:21:46 --> Helper loaded: html_helper
INFO - 2017-04-26 11:21:46 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:21:46 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:21:46 --> Database Driver Class Initialized
INFO - 2017-04-26 11:21:46 --> Parser Class Initialized
DEBUG - 2017-04-26 11:21:46 --> Session Class Initialized
INFO - 2017-04-26 11:21:46 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:21:46 --> Session routines successfully run
INFO - 2017-04-26 11:21:46 --> Form Validation Class Initialized
INFO - 2017-04-26 11:21:46 --> Controller Class Initialized
DEBUG - 2017-04-26 11:21:46 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:21:46 --> Model Class Initialized
DEBUG - 2017-04-26 11:21:46 --> Pagination Class Initialized
INFO - 2017-04-26 11:21:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:21:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:21:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:21:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:21:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:21:46 --> Final output sent to browser
DEBUG - 2017-04-26 11:21:46 --> Total execution time: 0.5101
INFO - 2017-04-26 11:21:47 --> Config Class Initialized
INFO - 2017-04-26 11:21:47 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:21:47 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:21:48 --> Utf8 Class Initialized
INFO - 2017-04-26 11:21:48 --> URI Class Initialized
INFO - 2017-04-26 11:21:48 --> Router Class Initialized
INFO - 2017-04-26 11:21:48 --> Output Class Initialized
INFO - 2017-04-26 11:21:48 --> Security Class Initialized
DEBUG - 2017-04-26 11:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:21:48 --> Input Class Initialized
INFO - 2017-04-26 11:21:48 --> Language Class Initialized
ERROR - 2017-04-26 11:21:48 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:22:35 --> Config Class Initialized
INFO - 2017-04-26 11:22:35 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:22:35 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:22:35 --> Utf8 Class Initialized
INFO - 2017-04-26 11:22:35 --> URI Class Initialized
INFO - 2017-04-26 11:22:35 --> Router Class Initialized
INFO - 2017-04-26 11:22:35 --> Output Class Initialized
INFO - 2017-04-26 11:22:35 --> Security Class Initialized
DEBUG - 2017-04-26 11:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:22:35 --> Input Class Initialized
INFO - 2017-04-26 11:22:35 --> Language Class Initialized
INFO - 2017-04-26 11:22:35 --> Loader Class Initialized
INFO - 2017-04-26 11:22:35 --> Helper loaded: url_helper
INFO - 2017-04-26 11:22:35 --> Helper loaded: form_helper
INFO - 2017-04-26 11:22:35 --> Helper loaded: html_helper
INFO - 2017-04-26 11:22:35 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:22:35 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:22:35 --> Database Driver Class Initialized
INFO - 2017-04-26 11:22:35 --> Parser Class Initialized
DEBUG - 2017-04-26 11:22:35 --> Session Class Initialized
INFO - 2017-04-26 11:22:35 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:22:35 --> Session routines successfully run
INFO - 2017-04-26 11:22:35 --> Form Validation Class Initialized
INFO - 2017-04-26 11:22:35 --> Controller Class Initialized
DEBUG - 2017-04-26 11:22:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:22:35 --> Model Class Initialized
DEBUG - 2017-04-26 11:22:35 --> Pagination Class Initialized
INFO - 2017-04-26 11:22:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:22:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:22:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:22:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:22:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:22:35 --> Final output sent to browser
DEBUG - 2017-04-26 11:22:35 --> Total execution time: 0.4954
INFO - 2017-04-26 11:22:36 --> Config Class Initialized
INFO - 2017-04-26 11:22:36 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:22:36 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:22:36 --> Utf8 Class Initialized
INFO - 2017-04-26 11:22:36 --> URI Class Initialized
INFO - 2017-04-26 11:22:36 --> Router Class Initialized
INFO - 2017-04-26 11:22:36 --> Output Class Initialized
INFO - 2017-04-26 11:22:36 --> Security Class Initialized
DEBUG - 2017-04-26 11:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:22:36 --> Input Class Initialized
INFO - 2017-04-26 11:22:36 --> Language Class Initialized
ERROR - 2017-04-26 11:22:36 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:22:41 --> Config Class Initialized
INFO - 2017-04-26 11:22:41 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:22:41 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:22:41 --> Utf8 Class Initialized
INFO - 2017-04-26 11:22:41 --> URI Class Initialized
INFO - 2017-04-26 11:22:41 --> Router Class Initialized
INFO - 2017-04-26 11:22:41 --> Output Class Initialized
INFO - 2017-04-26 11:22:41 --> Security Class Initialized
DEBUG - 2017-04-26 11:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:22:42 --> Input Class Initialized
INFO - 2017-04-26 11:22:42 --> Language Class Initialized
INFO - 2017-04-26 11:22:42 --> Loader Class Initialized
INFO - 2017-04-26 11:22:42 --> Helper loaded: url_helper
INFO - 2017-04-26 11:22:42 --> Helper loaded: form_helper
INFO - 2017-04-26 11:22:42 --> Helper loaded: html_helper
INFO - 2017-04-26 11:22:42 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:22:42 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:22:42 --> Database Driver Class Initialized
INFO - 2017-04-26 11:22:42 --> Parser Class Initialized
DEBUG - 2017-04-26 11:22:42 --> Session Class Initialized
INFO - 2017-04-26 11:22:42 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:22:42 --> Session routines successfully run
INFO - 2017-04-26 11:22:42 --> Form Validation Class Initialized
INFO - 2017-04-26 11:22:42 --> Controller Class Initialized
DEBUG - 2017-04-26 11:22:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:22:42 --> Model Class Initialized
DEBUG - 2017-04-26 11:22:42 --> Pagination Class Initialized
INFO - 2017-04-26 11:22:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:22:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:22:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:22:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:22:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:22:42 --> Final output sent to browser
DEBUG - 2017-04-26 11:22:42 --> Total execution time: 0.4732
INFO - 2017-04-26 11:22:42 --> Config Class Initialized
INFO - 2017-04-26 11:22:42 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:22:42 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:22:42 --> Utf8 Class Initialized
INFO - 2017-04-26 11:22:42 --> URI Class Initialized
INFO - 2017-04-26 11:22:42 --> Router Class Initialized
INFO - 2017-04-26 11:22:42 --> Output Class Initialized
INFO - 2017-04-26 11:22:42 --> Security Class Initialized
DEBUG - 2017-04-26 11:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:22:42 --> Input Class Initialized
INFO - 2017-04-26 11:22:42 --> Language Class Initialized
ERROR - 2017-04-26 11:22:42 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:25:55 --> Config Class Initialized
INFO - 2017-04-26 11:25:55 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:25:55 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:25:55 --> Utf8 Class Initialized
INFO - 2017-04-26 11:25:55 --> URI Class Initialized
INFO - 2017-04-26 11:25:55 --> Router Class Initialized
INFO - 2017-04-26 11:25:55 --> Output Class Initialized
INFO - 2017-04-26 11:25:55 --> Security Class Initialized
DEBUG - 2017-04-26 11:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:25:55 --> Input Class Initialized
INFO - 2017-04-26 11:25:55 --> Language Class Initialized
INFO - 2017-04-26 11:25:55 --> Loader Class Initialized
INFO - 2017-04-26 11:25:55 --> Helper loaded: url_helper
INFO - 2017-04-26 11:25:55 --> Helper loaded: form_helper
INFO - 2017-04-26 11:25:55 --> Helper loaded: html_helper
INFO - 2017-04-26 11:25:55 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:25:55 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:25:55 --> Database Driver Class Initialized
INFO - 2017-04-26 11:25:55 --> Parser Class Initialized
INFO - 2017-04-26 11:25:55 --> Config Class Initialized
DEBUG - 2017-04-26 11:25:55 --> Session Class Initialized
INFO - 2017-04-26 11:25:55 --> Hooks Class Initialized
INFO - 2017-04-26 11:25:55 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:25:55 --> UTF-8 Support Enabled
DEBUG - 2017-04-26 11:25:55 --> Session routines successfully run
INFO - 2017-04-26 11:25:55 --> Utf8 Class Initialized
INFO - 2017-04-26 11:25:55 --> Form Validation Class Initialized
INFO - 2017-04-26 11:25:55 --> URI Class Initialized
INFO - 2017-04-26 11:25:55 --> Controller Class Initialized
INFO - 2017-04-26 11:25:55 --> Router Class Initialized
DEBUG - 2017-04-26 11:25:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:25:55 --> Output Class Initialized
INFO - 2017-04-26 11:25:55 --> Model Class Initialized
INFO - 2017-04-26 11:25:55 --> Security Class Initialized
DEBUG - 2017-04-26 11:25:55 --> Pagination Class Initialized
DEBUG - 2017-04-26 11:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:25:55 --> Input Class Initialized
INFO - 2017-04-26 11:25:55 --> Language Class Initialized
INFO - 2017-04-26 11:25:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:25:55 --> Loader Class Initialized
INFO - 2017-04-26 11:25:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:25:55 --> Helper loaded: url_helper
INFO - 2017-04-26 11:25:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:25:55 --> Helper loaded: form_helper
INFO - 2017-04-26 11:25:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:25:55 --> Helper loaded: html_helper
INFO - 2017-04-26 11:25:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:25:55 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:25:55 --> Final output sent to browser
DEBUG - 2017-04-26 11:25:55 --> Total execution time: 0.5959
INFO - 2017-04-26 11:25:55 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:25:55 --> Database Driver Class Initialized
INFO - 2017-04-26 11:25:55 --> Parser Class Initialized
DEBUG - 2017-04-26 11:25:55 --> Session Class Initialized
INFO - 2017-04-26 11:25:55 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:25:55 --> Session routines successfully run
INFO - 2017-04-26 11:25:56 --> Form Validation Class Initialized
INFO - 2017-04-26 11:25:56 --> Controller Class Initialized
DEBUG - 2017-04-26 11:25:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:25:56 --> Model Class Initialized
DEBUG - 2017-04-26 11:25:56 --> Pagination Class Initialized
INFO - 2017-04-26 11:25:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:25:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:25:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:25:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:25:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:25:56 --> Final output sent to browser
DEBUG - 2017-04-26 11:25:56 --> Total execution time: 0.6075
INFO - 2017-04-26 11:25:56 --> Config Class Initialized
INFO - 2017-04-26 11:25:57 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:25:57 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:25:57 --> Utf8 Class Initialized
INFO - 2017-04-26 11:25:57 --> URI Class Initialized
INFO - 2017-04-26 11:25:57 --> Router Class Initialized
INFO - 2017-04-26 11:25:57 --> Output Class Initialized
INFO - 2017-04-26 11:25:57 --> Security Class Initialized
DEBUG - 2017-04-26 11:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:25:57 --> Input Class Initialized
INFO - 2017-04-26 11:25:57 --> Language Class Initialized
ERROR - 2017-04-26 11:25:57 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:28:44 --> Config Class Initialized
INFO - 2017-04-26 11:28:44 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:28:44 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:28:44 --> Utf8 Class Initialized
INFO - 2017-04-26 11:28:44 --> URI Class Initialized
INFO - 2017-04-26 11:28:44 --> Router Class Initialized
INFO - 2017-04-26 11:28:44 --> Output Class Initialized
INFO - 2017-04-26 11:28:44 --> Security Class Initialized
DEBUG - 2017-04-26 11:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:28:44 --> Input Class Initialized
INFO - 2017-04-26 11:28:44 --> Language Class Initialized
INFO - 2017-04-26 11:28:44 --> Loader Class Initialized
INFO - 2017-04-26 11:28:44 --> Helper loaded: url_helper
INFO - 2017-04-26 11:28:44 --> Helper loaded: form_helper
INFO - 2017-04-26 11:28:44 --> Helper loaded: html_helper
INFO - 2017-04-26 11:28:44 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:28:44 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:28:44 --> Database Driver Class Initialized
INFO - 2017-04-26 11:28:44 --> Parser Class Initialized
DEBUG - 2017-04-26 11:28:44 --> Session Class Initialized
INFO - 2017-04-26 11:28:44 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:28:44 --> Session routines successfully run
INFO - 2017-04-26 11:28:44 --> Form Validation Class Initialized
INFO - 2017-04-26 11:28:44 --> Controller Class Initialized
DEBUG - 2017-04-26 11:28:44 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:28:44 --> Model Class Initialized
DEBUG - 2017-04-26 11:28:44 --> Pagination Class Initialized
INFO - 2017-04-26 11:28:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:28:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:28:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:28:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:28:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:28:44 --> Final output sent to browser
DEBUG - 2017-04-26 11:28:44 --> Total execution time: 0.5110
INFO - 2017-04-26 11:30:14 --> Config Class Initialized
INFO - 2017-04-26 11:30:14 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:14 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:14 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:14 --> URI Class Initialized
INFO - 2017-04-26 11:30:14 --> Router Class Initialized
INFO - 2017-04-26 11:30:14 --> Output Class Initialized
INFO - 2017-04-26 11:30:14 --> Security Class Initialized
DEBUG - 2017-04-26 11:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:14 --> Input Class Initialized
INFO - 2017-04-26 11:30:14 --> Language Class Initialized
INFO - 2017-04-26 11:30:14 --> Loader Class Initialized
INFO - 2017-04-26 11:30:14 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:14 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:14 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:14 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:14 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:14 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:14 --> Parser Class Initialized
DEBUG - 2017-04-26 11:30:14 --> Session Class Initialized
INFO - 2017-04-26 11:30:14 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:30:14 --> Session routines successfully run
INFO - 2017-04-26 11:30:14 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:14 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:14 --> Model Class Initialized
DEBUG - 2017-04-26 11:30:15 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:15 --> Final output sent to browser
DEBUG - 2017-04-26 11:30:15 --> Total execution time: 0.5108
INFO - 2017-04-26 11:30:17 --> Config Class Initialized
INFO - 2017-04-26 11:30:17 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:17 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:17 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:17 --> URI Class Initialized
INFO - 2017-04-26 11:30:17 --> Router Class Initialized
INFO - 2017-04-26 11:30:17 --> Output Class Initialized
INFO - 2017-04-26 11:30:17 --> Security Class Initialized
DEBUG - 2017-04-26 11:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:17 --> Input Class Initialized
INFO - 2017-04-26 11:30:17 --> Language Class Initialized
INFO - 2017-04-26 11:30:17 --> Loader Class Initialized
INFO - 2017-04-26 11:30:17 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:17 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:18 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:18 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:18 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:18 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:18 --> Parser Class Initialized
DEBUG - 2017-04-26 11:30:18 --> Session Class Initialized
INFO - 2017-04-26 11:30:18 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:30:18 --> Session routines successfully run
INFO - 2017-04-26 11:30:18 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:18 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:18 --> Model Class Initialized
DEBUG - 2017-04-26 11:30:18 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:18 --> Final output sent to browser
DEBUG - 2017-04-26 11:30:18 --> Total execution time: 0.4762
INFO - 2017-04-26 11:30:20 --> Config Class Initialized
INFO - 2017-04-26 11:30:20 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:20 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:20 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:20 --> URI Class Initialized
INFO - 2017-04-26 11:30:20 --> Router Class Initialized
INFO - 2017-04-26 11:30:20 --> Output Class Initialized
INFO - 2017-04-26 11:30:20 --> Security Class Initialized
INFO - 2017-04-26 11:30:20 --> Config Class Initialized
INFO - 2017-04-26 11:30:20 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:20 --> Input Class Initialized
INFO - 2017-04-26 11:30:20 --> Language Class Initialized
INFO - 2017-04-26 11:30:20 --> Loader Class Initialized
INFO - 2017-04-26 11:30:20 --> Helper loaded: url_helper
DEBUG - 2017-04-26 11:30:20 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:20 --> Config Class Initialized
INFO - 2017-04-26 11:30:20 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:20 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:20 --> URI Class Initialized
INFO - 2017-04-26 11:30:20 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:20 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:20 --> Router Class Initialized
DEBUG - 2017-04-26 11:30:20 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:20 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:20 --> URI Class Initialized
INFO - 2017-04-26 11:30:20 --> Router Class Initialized
INFO - 2017-04-26 11:30:20 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:20 --> Output Class Initialized
INFO - 2017-04-26 11:30:20 --> Output Class Initialized
INFO - 2017-04-26 11:30:20 --> Security Class Initialized
INFO - 2017-04-26 11:30:20 --> Security Class Initialized
INFO - 2017-04-26 11:30:20 --> Helper loaded: cache_helper
DEBUG - 2017-04-26 11:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-26 11:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:20 --> Input Class Initialized
INFO - 2017-04-26 11:30:20 --> Input Class Initialized
INFO - 2017-04-26 11:30:20 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:21 --> Language Class Initialized
INFO - 2017-04-26 11:30:21 --> Language Class Initialized
INFO - 2017-04-26 11:30:21 --> Parser Class Initialized
INFO - 2017-04-26 11:30:21 --> Loader Class Initialized
INFO - 2017-04-26 11:30:21 --> Loader Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Session Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:21 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:21 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:21 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:21 --> Helper loaded: form_helper
DEBUG - 2017-04-26 11:30:21 --> Session routines successfully run
INFO - 2017-04-26 11:30:21 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:21 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:21 --> Controller Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:21 --> Config Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:21 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:21 --> Model Class Initialized
INFO - 2017-04-26 11:30:21 --> Config Class Initialized
INFO - 2017-04-26 11:30:21 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:21 --> Config Class Initialized
INFO - 2017-04-26 11:30:21 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:21 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:21 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:21 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:21 --> URI Class Initialized
DEBUG - 2017-04-26 11:30:21 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:21 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:21 --> Utf8 Class Initialized
DEBUG - 2017-04-26 11:30:21 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:21 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:21 --> Router Class Initialized
INFO - 2017-04-26 11:30:21 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:21 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:21 --> Parser Class Initialized
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:21 --> URI Class Initialized
INFO - 2017-04-26 11:30:21 --> Parser Class Initialized
INFO - 2017-04-26 11:30:21 --> URI Class Initialized
INFO - 2017-04-26 11:30:21 --> Output Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Session Class Initialized
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:21 --> Router Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Session Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:21 --> Router Class Initialized
INFO - 2017-04-26 11:30:21 --> Security Class Initialized
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
DEBUG - 2017-04-26 11:30:21 --> Session routines successfully run
INFO - 2017-04-26 11:30:21 --> Output Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:21 --> Output Class Initialized
INFO - 2017-04-26 11:30:21 --> Final output sent to browser
INFO - 2017-04-26 11:30:21 --> Security Class Initialized
INFO - 2017-04-26 11:30:21 --> Input Class Initialized
INFO - 2017-04-26 11:30:21 --> Form Validation Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Session routines successfully run
DEBUG - 2017-04-26 11:30:21 --> Total execution time: 1.3371
INFO - 2017-04-26 11:30:21 --> Controller Class Initialized
INFO - 2017-04-26 11:30:21 --> Security Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:21 --> Language Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:21 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:21 --> Input Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:21 --> Controller Class Initialized
INFO - 2017-04-26 11:30:21 --> Loader Class Initialized
INFO - 2017-04-26 11:30:21 --> Model Class Initialized
INFO - 2017-04-26 11:30:21 --> Input Class Initialized
INFO - 2017-04-26 11:30:21 --> Language Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2017-04-26 11:30:21 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:21 --> Model Class Initialized
INFO - 2017-04-26 11:30:21 --> Language Class Initialized
INFO - 2017-04-26 11:30:21 --> Loader Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:21 --> Config Class Initialized
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
DEBUG - 2017-04-26 11:30:21 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:21 --> Loader Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:21 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:21 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:21 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
DEBUG - 2017-04-26 11:30:21 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:21 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:21 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:21 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:21 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:21 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:21 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:21 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:21 --> URI Class Initialized
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:21 --> Final output sent to browser
INFO - 2017-04-26 11:30:21 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:21 --> Helper loaded: custom_helper
DEBUG - 2017-04-26 11:30:21 --> Total execution time: 1.2536
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:21 --> Router Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:21 --> Parser Class Initialized
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:21 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:21 --> Final output sent to browser
INFO - 2017-04-26 11:30:21 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:21 --> Output Class Initialized
INFO - 2017-04-26 11:30:21 --> Parser Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Total execution time: 1.0893
DEBUG - 2017-04-26 11:30:21 --> Session Class Initialized
INFO - 2017-04-26 11:30:21 --> Parser Class Initialized
INFO - 2017-04-26 11:30:21 --> Security Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Session Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-26 11:30:21 --> Session routines successfully run
DEBUG - 2017-04-26 11:30:21 --> Session Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:21 --> Input Class Initialized
INFO - 2017-04-26 11:30:21 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:21 --> Language Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Session routines successfully run
INFO - 2017-04-26 11:30:21 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Session routines successfully run
INFO - 2017-04-26 11:30:21 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:21 --> Loader Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:21 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:21 --> Controller Class Initialized
INFO - 2017-04-26 11:30:21 --> Model Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: url_helper
DEBUG - 2017-04-26 11:30:21 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:21 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:21 --> Model Class Initialized
DEBUG - 2017-04-26 11:30:21 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:21 --> Helper loaded: html_helper
DEBUG - 2017-04-26 11:30:21 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:21 --> Model Class Initialized
INFO - 2017-04-26 11:30:21 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
DEBUG - 2017-04-26 11:30:22 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:22 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:22 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:22 --> Parser Class Initialized
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
DEBUG - 2017-04-26 11:30:22 --> Session Class Initialized
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:22 --> Final output sent to browser
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:22 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:30:22 --> Total execution time: 0.9273
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
DEBUG - 2017-04-26 11:30:22 --> Session routines successfully run
INFO - 2017-04-26 11:30:22 --> Final output sent to browser
INFO - 2017-04-26 11:30:22 --> Final output sent to browser
INFO - 2017-04-26 11:30:22 --> Form Validation Class Initialized
DEBUG - 2017-04-26 11:30:22 --> Total execution time: 0.9566
DEBUG - 2017-04-26 11:30:22 --> Total execution time: 1.0338
INFO - 2017-04-26 11:30:22 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:22 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:22 --> Model Class Initialized
DEBUG - 2017-04-26 11:30:22 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:22 --> Final output sent to browser
DEBUG - 2017-04-26 11:30:22 --> Total execution time: 0.7981
INFO - 2017-04-26 11:30:22 --> Config Class Initialized
INFO - 2017-04-26 11:30:22 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:22 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:22 --> Config Class Initialized
INFO - 2017-04-26 11:30:22 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:22 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:22 --> URI Class Initialized
INFO - 2017-04-26 11:30:22 --> Router Class Initialized
INFO - 2017-04-26 11:30:23 --> Output Class Initialized
INFO - 2017-04-26 11:30:23 --> Security Class Initialized
INFO - 2017-04-26 11:30:23 --> Config Class Initialized
DEBUG - 2017-04-26 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:23 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:23 --> Input Class Initialized
INFO - 2017-04-26 11:30:23 --> Language Class Initialized
DEBUG - 2017-04-26 11:30:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:23 --> Loader Class Initialized
INFO - 2017-04-26 11:30:23 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:23 --> Config Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:23 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:23 --> URI Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:23 --> Router Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: custom_helper
DEBUG - 2017-04-26 11:30:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:23 --> Output Class Initialized
INFO - 2017-04-26 11:30:23 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:23 --> Security Class Initialized
INFO - 2017-04-26 11:30:23 --> URI Class Initialized
DEBUG - 2017-04-26 11:30:23 --> UTF-8 Support Enabled
DEBUG - 2017-04-26 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:23 --> Input Class Initialized
INFO - 2017-04-26 11:30:23 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:23 --> Language Class Initialized
INFO - 2017-04-26 11:30:23 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:23 --> Router Class Initialized
INFO - 2017-04-26 11:30:23 --> Config Class Initialized
INFO - 2017-04-26 11:30:23 --> URI Class Initialized
INFO - 2017-04-26 11:30:23 --> Config Class Initialized
INFO - 2017-04-26 11:30:23 --> Loader Class Initialized
INFO - 2017-04-26 11:30:23 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:23 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:23 --> Router Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:23 --> Config Class Initialized
INFO - 2017-04-26 11:30:23 --> Output Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:23 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:23 --> Output Class Initialized
DEBUG - 2017-04-26 11:30:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:23 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:23 --> URI Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:23 --> Security Class Initialized
DEBUG - 2017-04-26 11:30:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:23 --> Router Class Initialized
INFO - 2017-04-26 11:30:23 --> Security Class Initialized
INFO - 2017-04-26 11:30:23 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: cache_helper
DEBUG - 2017-04-26 11:30:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:23 --> Output Class Initialized
INFO - 2017-04-26 11:30:23 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:23 --> URI Class Initialized
INFO - 2017-04-26 11:30:23 --> Config Class Initialized
INFO - 2017-04-26 11:30:23 --> Security Class Initialized
DEBUG - 2017-04-26 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:23 --> Input Class Initialized
INFO - 2017-04-26 11:30:23 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:23 --> URI Class Initialized
INFO - 2017-04-26 11:30:23 --> Router Class Initialized
INFO - 2017-04-26 11:30:23 --> Language Class Initialized
INFO - 2017-04-26 11:30:23 --> Input Class Initialized
INFO - 2017-04-26 11:30:23 --> Router Class Initialized
INFO - 2017-04-26 11:30:23 --> Loader Class Initialized
INFO - 2017-04-26 11:30:23 --> Language Class Initialized
INFO - 2017-04-26 11:30:23 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:23 --> Output Class Initialized
DEBUG - 2017-04-26 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:23 --> Parser Class Initialized
INFO - 2017-04-26 11:30:23 --> Input Class Initialized
INFO - 2017-04-26 11:30:23 --> Security Class Initialized
DEBUG - 2017-04-26 11:30:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:23 --> Helper loaded: url_helper
DEBUG - 2017-04-26 11:30:23 --> Session Class Initialized
INFO - 2017-04-26 11:30:23 --> Loader Class Initialized
INFO - 2017-04-26 11:30:23 --> Output Class Initialized
INFO - 2017-04-26 11:30:23 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:23 --> Language Class Initialized
DEBUG - 2017-04-26 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:23 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:23 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:23 --> Security Class Initialized
INFO - 2017-04-26 11:30:23 --> Loader Class Initialized
INFO - 2017-04-26 11:30:23 --> URI Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: form_helper
DEBUG - 2017-04-26 11:30:23 --> Session routines successfully run
INFO - 2017-04-26 11:30:23 --> Input Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:23 --> Router Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:23 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:23 --> Form Validation Class Initialized
DEBUG - 2017-04-26 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:23 --> Language Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:23 --> Parser Class Initialized
INFO - 2017-04-26 11:30:23 --> Controller Class Initialized
INFO - 2017-04-26 11:30:23 --> Output Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:23 --> Helper loaded: custom_helper
DEBUG - 2017-04-26 11:30:23 --> Session Class Initialized
INFO - 2017-04-26 11:30:23 --> Security Class Initialized
INFO - 2017-04-26 11:30:23 --> Loader Class Initialized
INFO - 2017-04-26 11:30:23 --> Input Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:23 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:23 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:23 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:23 --> Language Class Initialized
INFO - 2017-04-26 11:30:23 --> Helper loaded: url_helper
DEBUG - 2017-04-26 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:23 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:23 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:23 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:23 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:23 --> Input Class Initialized
DEBUG - 2017-04-26 11:30:23 --> Session routines successfully run
INFO - 2017-04-26 11:30:23 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:24 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:24 --> Language Class Initialized
INFO - 2017-04-26 11:30:24 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:24 --> Parser Class Initialized
INFO - 2017-04-26 11:30:24 --> Loader Class Initialized
INFO - 2017-04-26 11:30:24 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:24 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:24 --> Controller Class Initialized
INFO - 2017-04-26 11:30:24 --> Loader Class Initialized
DEBUG - 2017-04-26 11:30:24 --> Session Class Initialized
INFO - 2017-04-26 11:30:24 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:24 --> Helper loaded: cache_helper
DEBUG - 2017-04-26 11:30:24 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:24 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:24 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:24 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:24 --> Model Class Initialized
DEBUG - 2017-04-26 11:30:24 --> Session routines successfully run
INFO - 2017-04-26 11:30:24 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:24 --> Helper loaded: html_helper
DEBUG - 2017-04-26 11:30:24 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:24 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:24 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:24 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:24 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:24 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:24 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:24 --> Model Class Initialized
INFO - 2017-04-26 11:30:24 --> Helper loaded: html_helper
DEBUG - 2017-04-26 11:30:24 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:24 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:24 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:24 --> Model Class Initialized
INFO - 2017-04-26 11:30:24 --> Database Driver Class Initialized
DEBUG - 2017-04-26 11:30:24 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:24 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:24 --> Config Class Initialized
INFO - 2017-04-26 11:30:24 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:24 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:24 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:24 --> URI Class Initialized
INFO - 2017-04-26 11:30:24 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:24 --> Router Class Initialized
INFO - 2017-04-26 11:30:24 --> Output Class Initialized
INFO - 2017-04-26 11:30:24 --> Security Class Initialized
DEBUG - 2017-04-26 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:24 --> Input Class Initialized
INFO - 2017-04-26 11:30:24 --> Language Class Initialized
INFO - 2017-04-26 11:30:24 --> Loader Class Initialized
INFO - 2017-04-26 11:30:24 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:24 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:24 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:24 --> Parser Class Initialized
INFO - 2017-04-26 11:30:24 --> Helper loaded: custom_helper
DEBUG - 2017-04-26 11:30:24 --> Session Class Initialized
INFO - 2017-04-26 11:30:24 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:24 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:24 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:24 --> Parser Class Initialized
DEBUG - 2017-04-26 11:30:24 --> Session Class Initialized
DEBUG - 2017-04-26 11:30:24 --> Session routines successfully run
INFO - 2017-04-26 11:30:24 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:24 --> Controller Class Initialized
INFO - 2017-04-26 11:30:24 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:30:24 --> Session routines successfully run
INFO - 2017-04-26 11:30:24 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:24 --> Controller Class Initialized
INFO - 2017-04-26 11:30:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:24 --> Model Class Initialized
INFO - 2017-04-26 11:30:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
DEBUG - 2017-04-26 11:30:24 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
DEBUG - 2017-04-26 11:30:24 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:24 --> Model Class Initialized
DEBUG - 2017-04-26 11:30:24 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:25 --> Final output sent to browser
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
DEBUG - 2017-04-26 11:30:25 --> Total execution time: 2.2863
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:25 --> Parser Class Initialized
INFO - 2017-04-26 11:30:25 --> Final output sent to browser
DEBUG - 2017-04-26 11:30:25 --> Session Class Initialized
DEBUG - 2017-04-26 11:30:25 --> Total execution time: 2.4419
INFO - 2017-04-26 11:30:25 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:30:25 --> Session routines successfully run
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:25 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:25 --> Controller Class Initialized
ERROR - 2017-04-26 11:30:25 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 287
ERROR - 2017-04-26 11:30:25 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 288
ERROR - 2017-04-26 11:30:25 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 289
ERROR - 2017-04-26 11:30:25 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 290
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/Plan_subscription/list_plan_subscription.php
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
DEBUG - 2017-04-26 11:30:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:25 --> Model Class Initialized
INFO - 2017-04-26 11:30:25 --> Final output sent to browser
DEBUG - 2017-04-26 11:30:25 --> Pagination Class Initialized
DEBUG - 2017-04-26 11:30:25 --> Total execution time: 1.0461
INFO - 2017-04-26 11:30:25 --> Parser Class Initialized
DEBUG - 2017-04-26 11:30:25 --> Session Class Initialized
INFO - 2017-04-26 11:30:25 --> Parser Class Initialized
INFO - 2017-04-26 11:30:25 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:30:25 --> Session Class Initialized
DEBUG - 2017-04-26 11:30:25 --> Session routines successfully run
INFO - 2017-04-26 11:30:25 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:25 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:25 --> Controller Class Initialized
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
DEBUG - 2017-04-26 11:30:25 --> Session routines successfully run
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:25 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:25 --> Controller Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:26 --> Final output sent to browser
DEBUG - 2017-04-26 11:30:26 --> Total execution time: 2.9134
DEBUG - 2017-04-26 11:30:26 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2017-04-26 11:30:26 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:26 --> Model Class Initialized
INFO - 2017-04-26 11:30:26 --> Model Class Initialized
DEBUG - 2017-04-26 11:30:26 --> Pagination Class Initialized
DEBUG - 2017-04-26 11:30:26 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:26 --> Parser Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
DEBUG - 2017-04-26 11:30:26 --> Session Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:26 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:26 --> Config Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:26 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
DEBUG - 2017-04-26 11:30:26 --> Session routines successfully run
INFO - 2017-04-26 11:30:26 --> Config Class Initialized
INFO - 2017-04-26 11:30:26 --> Final output sent to browser
DEBUG - 2017-04-26 11:30:26 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:26 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
DEBUG - 2017-04-26 11:30:26 --> Total execution time: 2.9339
INFO - 2017-04-26 11:30:26 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:26 --> Controller Class Initialized
INFO - 2017-04-26 11:30:26 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
DEBUG - 2017-04-26 11:30:26 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:26 --> Config Class Initialized
INFO - 2017-04-26 11:30:26 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:26 --> URI Class Initialized
INFO - 2017-04-26 11:30:26 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:26 --> Config Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:26 --> Router Class Initialized
DEBUG - 2017-04-26 11:30:26 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:26 --> URI Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
DEBUG - 2017-04-26 11:30:26 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:26 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:26 --> Final output sent to browser
INFO - 2017-04-26 11:30:26 --> Router Class Initialized
INFO - 2017-04-26 11:30:26 --> Output Class Initialized
INFO - 2017-04-26 11:30:26 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:26 --> Model Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
DEBUG - 2017-04-26 11:30:26 --> Total execution time: 2.8974
DEBUG - 2017-04-26 11:30:26 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:26 --> Output Class Initialized
INFO - 2017-04-26 11:30:26 --> Security Class Initialized
INFO - 2017-04-26 11:30:26 --> URI Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
DEBUG - 2017-04-26 11:30:26 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:26 --> Utf8 Class Initialized
DEBUG - 2017-04-26 11:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:26 --> Security Class Initialized
INFO - 2017-04-26 11:30:26 --> Router Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:26 --> Input Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:26 --> URI Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:26 --> Output Class Initialized
INFO - 2017-04-26 11:30:26 --> Language Class Initialized
DEBUG - 2017-04-26 11:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:26 --> Input Class Initialized
INFO - 2017-04-26 11:30:26 --> Router Class Initialized
INFO - 2017-04-26 11:30:26 --> Final output sent to browser
INFO - 2017-04-26 11:30:26 --> Security Class Initialized
INFO - 2017-04-26 11:30:26 --> Loader Class Initialized
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
DEBUG - 2017-04-26 11:30:26 --> Total execution time: 3.6531
INFO - 2017-04-26 11:30:26 --> Language Class Initialized
INFO - 2017-04-26 11:30:26 --> Output Class Initialized
DEBUG - 2017-04-26 11:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:26 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:26 --> Security Class Initialized
INFO - 2017-04-26 11:30:26 --> Input Class Initialized
INFO - 2017-04-26 11:30:26 --> Loader Class Initialized
INFO - 2017-04-26 11:30:26 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:26 --> Language Class Initialized
INFO - 2017-04-26 11:30:26 --> Helper loaded: url_helper
DEBUG - 2017-04-26 11:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:26 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:26 --> Input Class Initialized
INFO - 2017-04-26 11:30:26 --> Loader Class Initialized
INFO - 2017-04-26 11:30:26 --> Final output sent to browser
INFO - 2017-04-26 11:30:26 --> Helper loaded: form_helper
DEBUG - 2017-04-26 11:30:26 --> Total execution time: 3.2895
INFO - 2017-04-26 11:30:26 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:26 --> Language Class Initialized
INFO - 2017-04-26 11:30:26 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:26 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:26 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:26 --> Loader Class Initialized
INFO - 2017-04-26 11:30:26 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:26 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:26 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:26 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:26 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:26 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:26 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:26 --> Parser Class Initialized
INFO - 2017-04-26 11:30:26 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:26 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:26 --> Helper loaded: html_helper
DEBUG - 2017-04-26 11:30:26 --> Session Class Initialized
INFO - 2017-04-26 11:30:26 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:26 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:26 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:26 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:26 --> Parser Class Initialized
DEBUG - 2017-04-26 11:30:26 --> Session routines successfully run
INFO - 2017-04-26 11:30:26 --> Helper loaded: cache_helper
DEBUG - 2017-04-26 11:30:26 --> Session Class Initialized
INFO - 2017-04-26 11:30:26 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:26 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:26 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:26 --> Parser Class Initialized
INFO - 2017-04-26 11:30:26 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:26 --> Session routines successfully run
DEBUG - 2017-04-26 11:30:26 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2017-04-26 11:30:26 --> Session Class Initialized
INFO - 2017-04-26 11:30:26 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:26 --> Model Class Initialized
INFO - 2017-04-26 11:30:26 --> Parser Class Initialized
INFO - 2017-04-26 11:30:26 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:26 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:26 --> Session routines successfully run
DEBUG - 2017-04-26 11:30:26 --> Session Class Initialized
DEBUG - 2017-04-26 11:30:26 --> Pagination Class Initialized
DEBUG - 2017-04-26 11:30:26 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:26 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:27 --> Helper loaded: string_helper
INFO - 2017-04-26 11:30:27 --> Model Class Initialized
INFO - 2017-04-26 11:30:27 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Session routines successfully run
DEBUG - 2017-04-26 11:30:27 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:27 --> Config Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:27 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:27 --> Hooks Class Initialized
INFO - 2017-04-26 11:30:27 --> Model Class Initialized
INFO - 2017-04-26 11:30:27 --> Controller Class Initialized
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
DEBUG - 2017-04-26 11:30:27 --> UTF-8 Support Enabled
DEBUG - 2017-04-26 11:30:27 --> Pagination Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:27 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:27 --> URI Class Initialized
INFO - 2017-04-26 11:30:27 --> Model Class Initialized
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:27 --> Router Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:27 --> Final output sent to browser
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:27 --> Output Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Total execution time: 0.8881
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:27 --> Final output sent to browser
INFO - 2017-04-26 11:30:27 --> Security Class Initialized
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
DEBUG - 2017-04-26 11:30:27 --> Total execution time: 0.8865
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
DEBUG - 2017-04-26 11:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:27 --> Input Class Initialized
INFO - 2017-04-26 11:30:27 --> Final output sent to browser
INFO - 2017-04-26 11:30:27 --> Language Class Initialized
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
DEBUG - 2017-04-26 11:30:27 --> Total execution time: 0.8986
INFO - 2017-04-26 11:30:27 --> Loader Class Initialized
INFO - 2017-04-26 11:30:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:27 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:27 --> Final output sent to browser
INFO - 2017-04-26 11:30:27 --> Helper loaded: form_helper
DEBUG - 2017-04-26 11:30:27 --> Total execution time: 0.9466
INFO - 2017-04-26 11:30:27 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:27 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:27 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:27 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:27 --> Parser Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Session Class Initialized
INFO - 2017-04-26 11:30:27 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:30:27 --> Session routines successfully run
INFO - 2017-04-26 11:30:27 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:27 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:27 --> Model Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:27 --> Config Class Initialized
INFO - 2017-04-26 11:30:27 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:27 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:27 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:27 --> URI Class Initialized
INFO - 2017-04-26 11:30:27 --> Router Class Initialized
INFO - 2017-04-26 11:30:27 --> Output Class Initialized
INFO - 2017-04-26 11:30:27 --> Security Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:27 --> Input Class Initialized
INFO - 2017-04-26 11:30:27 --> Language Class Initialized
INFO - 2017-04-26 11:30:27 --> Loader Class Initialized
INFO - 2017-04-26 11:30:27 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:27 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:27 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:27 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:27 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:27 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:27 --> Parser Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Session Class Initialized
INFO - 2017-04-26 11:30:27 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:30:27 --> Session routines successfully run
INFO - 2017-04-26 11:30:27 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:27 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:27 --> Model Class Initialized
DEBUG - 2017-04-26 11:30:27 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:30:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:30:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:30:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:30:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:28 --> Final output sent to browser
DEBUG - 2017-04-26 11:30:28 --> Total execution time: 0.5205
INFO - 2017-04-26 11:30:56 --> Config Class Initialized
INFO - 2017-04-26 11:30:56 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:56 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:56 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:56 --> URI Class Initialized
INFO - 2017-04-26 11:30:56 --> Router Class Initialized
INFO - 2017-04-26 11:30:56 --> Output Class Initialized
INFO - 2017-04-26 11:30:56 --> Security Class Initialized
DEBUG - 2017-04-26 11:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:56 --> Input Class Initialized
INFO - 2017-04-26 11:30:56 --> Language Class Initialized
INFO - 2017-04-26 11:30:56 --> Loader Class Initialized
INFO - 2017-04-26 11:30:56 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:56 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:56 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:56 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:56 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:56 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:56 --> Parser Class Initialized
DEBUG - 2017-04-26 11:30:56 --> Session Class Initialized
INFO - 2017-04-26 11:30:56 --> Helper loaded: string_helper
ERROR - 2017-04-26 11:30:57 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-26 11:30:57 --> Session routines successfully run
INFO - 2017-04-26 11:30:57 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:57 --> Controller Class Initialized
DEBUG - 2017-04-26 11:30:57 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:30:57 --> Model Class Initialized
DEBUG - 2017-04-26 11:30:57 --> Pagination Class Initialized
INFO - 2017-04-26 11:30:57 --> Config Class Initialized
INFO - 2017-04-26 11:30:57 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:30:57 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:30:57 --> Utf8 Class Initialized
INFO - 2017-04-26 11:30:57 --> URI Class Initialized
INFO - 2017-04-26 11:30:57 --> Router Class Initialized
INFO - 2017-04-26 11:30:57 --> Output Class Initialized
INFO - 2017-04-26 11:30:57 --> Security Class Initialized
DEBUG - 2017-04-26 11:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:30:57 --> Input Class Initialized
INFO - 2017-04-26 11:30:57 --> Language Class Initialized
INFO - 2017-04-26 11:30:57 --> Loader Class Initialized
INFO - 2017-04-26 11:30:57 --> Helper loaded: url_helper
INFO - 2017-04-26 11:30:57 --> Helper loaded: form_helper
INFO - 2017-04-26 11:30:57 --> Helper loaded: html_helper
INFO - 2017-04-26 11:30:57 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:30:57 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:30:57 --> Database Driver Class Initialized
INFO - 2017-04-26 11:30:57 --> Parser Class Initialized
DEBUG - 2017-04-26 11:30:57 --> Session Class Initialized
INFO - 2017-04-26 11:30:57 --> Helper loaded: string_helper
ERROR - 2017-04-26 11:30:57 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-26 11:30:57 --> Session routines successfully run
INFO - 2017-04-26 11:30:57 --> Form Validation Class Initialized
INFO - 2017-04-26 11:30:57 --> Controller Class Initialized
INFO - 2017-04-26 11:30:57 --> Model Class Initialized
INFO - 2017-04-26 11:30:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-26 11:30:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:30:57 --> Final output sent to browser
DEBUG - 2017-04-26 11:30:57 --> Total execution time: 0.4995
INFO - 2017-04-26 11:31:54 --> Config Class Initialized
INFO - 2017-04-26 11:31:54 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:31:54 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:31:54 --> Utf8 Class Initialized
INFO - 2017-04-26 11:31:54 --> URI Class Initialized
INFO - 2017-04-26 11:31:54 --> Router Class Initialized
INFO - 2017-04-26 11:31:54 --> Output Class Initialized
INFO - 2017-04-26 11:31:54 --> Security Class Initialized
DEBUG - 2017-04-26 11:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:31:54 --> Input Class Initialized
INFO - 2017-04-26 11:31:54 --> Language Class Initialized
INFO - 2017-04-26 11:31:54 --> Loader Class Initialized
INFO - 2017-04-26 11:31:54 --> Helper loaded: url_helper
INFO - 2017-04-26 11:31:54 --> Helper loaded: form_helper
INFO - 2017-04-26 11:31:54 --> Helper loaded: html_helper
INFO - 2017-04-26 11:31:54 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:31:54 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:31:54 --> Database Driver Class Initialized
INFO - 2017-04-26 11:31:55 --> Parser Class Initialized
DEBUG - 2017-04-26 11:31:55 --> Session Class Initialized
INFO - 2017-04-26 11:31:55 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:31:55 --> Session routines successfully run
INFO - 2017-04-26 11:31:55 --> Form Validation Class Initialized
INFO - 2017-04-26 11:31:55 --> Controller Class Initialized
DEBUG - 2017-04-26 11:31:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:31:55 --> Model Class Initialized
DEBUG - 2017-04-26 11:31:55 --> Pagination Class Initialized
INFO - 2017-04-26 11:31:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:31:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:31:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:31:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:31:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:31:55 --> Final output sent to browser
DEBUG - 2017-04-26 11:31:55 --> Total execution time: 0.6185
INFO - 2017-04-26 11:32:08 --> Config Class Initialized
INFO - 2017-04-26 11:32:08 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:32:08 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:32:08 --> Utf8 Class Initialized
INFO - 2017-04-26 11:32:08 --> URI Class Initialized
INFO - 2017-04-26 11:32:08 --> Router Class Initialized
INFO - 2017-04-26 11:32:08 --> Output Class Initialized
INFO - 2017-04-26 11:32:08 --> Security Class Initialized
DEBUG - 2017-04-26 11:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:32:08 --> Input Class Initialized
INFO - 2017-04-26 11:32:08 --> Language Class Initialized
INFO - 2017-04-26 11:32:08 --> Loader Class Initialized
INFO - 2017-04-26 11:32:08 --> Helper loaded: url_helper
INFO - 2017-04-26 11:32:08 --> Helper loaded: form_helper
INFO - 2017-04-26 11:32:08 --> Helper loaded: html_helper
INFO - 2017-04-26 11:32:08 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:32:08 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:32:08 --> Database Driver Class Initialized
INFO - 2017-04-26 11:32:08 --> Parser Class Initialized
DEBUG - 2017-04-26 11:32:08 --> Session Class Initialized
INFO - 2017-04-26 11:32:08 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:32:08 --> Session routines successfully run
INFO - 2017-04-26 11:32:08 --> Form Validation Class Initialized
INFO - 2017-04-26 11:32:08 --> Controller Class Initialized
DEBUG - 2017-04-26 11:32:08 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:32:08 --> Model Class Initialized
DEBUG - 2017-04-26 11:32:08 --> Pagination Class Initialized
INFO - 2017-04-26 11:32:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:32:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:32:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:32:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:32:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:32:08 --> Final output sent to browser
DEBUG - 2017-04-26 11:32:08 --> Total execution time: 0.5891
INFO - 2017-04-26 11:33:05 --> Config Class Initialized
INFO - 2017-04-26 11:33:05 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:33:05 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:33:05 --> Utf8 Class Initialized
INFO - 2017-04-26 11:33:05 --> URI Class Initialized
INFO - 2017-04-26 11:33:05 --> Router Class Initialized
INFO - 2017-04-26 11:33:05 --> Output Class Initialized
INFO - 2017-04-26 11:33:05 --> Security Class Initialized
DEBUG - 2017-04-26 11:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:33:05 --> Input Class Initialized
INFO - 2017-04-26 11:33:05 --> Language Class Initialized
INFO - 2017-04-26 11:33:05 --> Loader Class Initialized
INFO - 2017-04-26 11:33:05 --> Helper loaded: url_helper
INFO - 2017-04-26 11:33:05 --> Helper loaded: form_helper
INFO - 2017-04-26 11:33:05 --> Helper loaded: html_helper
INFO - 2017-04-26 11:33:05 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:33:05 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:33:05 --> Database Driver Class Initialized
INFO - 2017-04-26 11:33:05 --> Parser Class Initialized
DEBUG - 2017-04-26 11:33:05 --> Session Class Initialized
INFO - 2017-04-26 11:33:05 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:33:05 --> Session routines successfully run
INFO - 2017-04-26 11:33:05 --> Form Validation Class Initialized
INFO - 2017-04-26 11:33:05 --> Controller Class Initialized
DEBUG - 2017-04-26 11:33:05 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:33:05 --> Model Class Initialized
DEBUG - 2017-04-26 11:33:05 --> Pagination Class Initialized
INFO - 2017-04-26 11:33:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:33:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:33:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:33:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:33:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:33:06 --> Final output sent to browser
DEBUG - 2017-04-26 11:33:06 --> Total execution time: 0.9465
INFO - 2017-04-26 11:33:06 --> Config Class Initialized
INFO - 2017-04-26 11:33:06 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:33:06 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:33:06 --> Utf8 Class Initialized
INFO - 2017-04-26 11:33:06 --> URI Class Initialized
INFO - 2017-04-26 11:33:06 --> Router Class Initialized
INFO - 2017-04-26 11:33:06 --> Output Class Initialized
INFO - 2017-04-26 11:33:06 --> Security Class Initialized
DEBUG - 2017-04-26 11:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:33:06 --> Input Class Initialized
INFO - 2017-04-26 11:33:06 --> Language Class Initialized
ERROR - 2017-04-26 11:33:06 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:33:13 --> Config Class Initialized
INFO - 2017-04-26 11:33:13 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:33:13 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:33:13 --> Utf8 Class Initialized
INFO - 2017-04-26 11:33:13 --> URI Class Initialized
INFO - 2017-04-26 11:33:13 --> Router Class Initialized
INFO - 2017-04-26 11:33:13 --> Output Class Initialized
INFO - 2017-04-26 11:33:13 --> Security Class Initialized
DEBUG - 2017-04-26 11:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:33:13 --> Input Class Initialized
INFO - 2017-04-26 11:33:13 --> Language Class Initialized
INFO - 2017-04-26 11:33:13 --> Loader Class Initialized
INFO - 2017-04-26 11:33:13 --> Helper loaded: url_helper
INFO - 2017-04-26 11:33:13 --> Helper loaded: form_helper
INFO - 2017-04-26 11:33:13 --> Helper loaded: html_helper
INFO - 2017-04-26 11:33:13 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:33:13 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:33:13 --> Database Driver Class Initialized
INFO - 2017-04-26 11:33:13 --> Parser Class Initialized
DEBUG - 2017-04-26 11:33:13 --> Session Class Initialized
INFO - 2017-04-26 11:33:13 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:33:13 --> Session routines successfully run
INFO - 2017-04-26 11:33:13 --> Form Validation Class Initialized
INFO - 2017-04-26 11:33:13 --> Controller Class Initialized
DEBUG - 2017-04-26 11:33:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:33:13 --> Model Class Initialized
DEBUG - 2017-04-26 11:33:13 --> Pagination Class Initialized
INFO - 2017-04-26 11:33:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:33:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:33:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:33:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:33:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:33:13 --> Final output sent to browser
DEBUG - 2017-04-26 11:33:13 --> Total execution time: 0.5526
INFO - 2017-04-26 11:33:15 --> Config Class Initialized
INFO - 2017-04-26 11:33:15 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:33:15 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:33:15 --> Utf8 Class Initialized
INFO - 2017-04-26 11:33:15 --> URI Class Initialized
INFO - 2017-04-26 11:33:15 --> Router Class Initialized
INFO - 2017-04-26 11:33:15 --> Output Class Initialized
INFO - 2017-04-26 11:33:15 --> Security Class Initialized
DEBUG - 2017-04-26 11:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:33:16 --> Input Class Initialized
INFO - 2017-04-26 11:33:16 --> Language Class Initialized
INFO - 2017-04-26 11:33:16 --> Loader Class Initialized
INFO - 2017-04-26 11:33:16 --> Helper loaded: url_helper
INFO - 2017-04-26 11:33:16 --> Helper loaded: form_helper
INFO - 2017-04-26 11:33:16 --> Helper loaded: html_helper
INFO - 2017-04-26 11:33:16 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:33:16 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:33:16 --> Database Driver Class Initialized
INFO - 2017-04-26 11:33:16 --> Parser Class Initialized
DEBUG - 2017-04-26 11:33:16 --> Session Class Initialized
INFO - 2017-04-26 11:33:16 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:33:16 --> Session routines successfully run
INFO - 2017-04-26 11:33:16 --> Form Validation Class Initialized
INFO - 2017-04-26 11:33:16 --> Controller Class Initialized
DEBUG - 2017-04-26 11:33:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:33:16 --> Model Class Initialized
DEBUG - 2017-04-26 11:33:16 --> Pagination Class Initialized
INFO - 2017-04-26 11:33:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:33:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:33:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:33:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:33:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:33:16 --> Final output sent to browser
DEBUG - 2017-04-26 11:33:16 --> Total execution time: 0.8331
INFO - 2017-04-26 11:33:24 --> Config Class Initialized
INFO - 2017-04-26 11:33:24 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:33:24 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:33:25 --> Utf8 Class Initialized
INFO - 2017-04-26 11:33:25 --> URI Class Initialized
INFO - 2017-04-26 11:33:25 --> Router Class Initialized
INFO - 2017-04-26 11:33:25 --> Output Class Initialized
INFO - 2017-04-26 11:33:25 --> Security Class Initialized
DEBUG - 2017-04-26 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:33:25 --> Input Class Initialized
INFO - 2017-04-26 11:33:25 --> Language Class Initialized
INFO - 2017-04-26 11:33:25 --> Loader Class Initialized
INFO - 2017-04-26 11:33:25 --> Helper loaded: url_helper
INFO - 2017-04-26 11:33:25 --> Helper loaded: form_helper
INFO - 2017-04-26 11:33:25 --> Helper loaded: html_helper
INFO - 2017-04-26 11:33:25 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:33:25 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:33:25 --> Database Driver Class Initialized
INFO - 2017-04-26 11:33:25 --> Parser Class Initialized
DEBUG - 2017-04-26 11:33:25 --> Session Class Initialized
INFO - 2017-04-26 11:33:25 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:33:25 --> Session routines successfully run
INFO - 2017-04-26 11:33:25 --> Form Validation Class Initialized
INFO - 2017-04-26 11:33:25 --> Controller Class Initialized
DEBUG - 2017-04-26 11:33:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:33:25 --> Model Class Initialized
DEBUG - 2017-04-26 11:33:25 --> Pagination Class Initialized
INFO - 2017-04-26 11:33:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:33:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:33:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:33:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:33:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:33:25 --> Final output sent to browser
DEBUG - 2017-04-26 11:33:25 --> Total execution time: 0.4984
INFO - 2017-04-26 11:33:37 --> Config Class Initialized
INFO - 2017-04-26 11:33:37 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:33:37 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:33:37 --> Utf8 Class Initialized
INFO - 2017-04-26 11:33:37 --> URI Class Initialized
INFO - 2017-04-26 11:33:37 --> Router Class Initialized
INFO - 2017-04-26 11:33:37 --> Output Class Initialized
INFO - 2017-04-26 11:33:37 --> Security Class Initialized
DEBUG - 2017-04-26 11:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:33:37 --> Input Class Initialized
INFO - 2017-04-26 11:33:37 --> Language Class Initialized
INFO - 2017-04-26 11:33:37 --> Loader Class Initialized
INFO - 2017-04-26 11:33:37 --> Helper loaded: url_helper
INFO - 2017-04-26 11:33:37 --> Helper loaded: form_helper
INFO - 2017-04-26 11:33:37 --> Helper loaded: html_helper
INFO - 2017-04-26 11:33:37 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:33:37 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:33:37 --> Database Driver Class Initialized
INFO - 2017-04-26 11:33:37 --> Parser Class Initialized
DEBUG - 2017-04-26 11:33:37 --> Session Class Initialized
INFO - 2017-04-26 11:33:37 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:33:37 --> Session routines successfully run
INFO - 2017-04-26 11:33:37 --> Form Validation Class Initialized
INFO - 2017-04-26 11:33:37 --> Controller Class Initialized
DEBUG - 2017-04-26 11:33:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:33:37 --> Model Class Initialized
DEBUG - 2017-04-26 11:33:37 --> Pagination Class Initialized
INFO - 2017-04-26 11:33:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:33:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:33:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:33:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:33:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:33:37 --> Final output sent to browser
DEBUG - 2017-04-26 11:33:37 --> Total execution time: 0.5222
INFO - 2017-04-26 11:35:26 --> Config Class Initialized
INFO - 2017-04-26 11:35:26 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:35:26 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:35:26 --> Utf8 Class Initialized
INFO - 2017-04-26 11:35:26 --> URI Class Initialized
INFO - 2017-04-26 11:35:26 --> Router Class Initialized
INFO - 2017-04-26 11:35:26 --> Output Class Initialized
INFO - 2017-04-26 11:35:26 --> Security Class Initialized
DEBUG - 2017-04-26 11:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:35:26 --> Input Class Initialized
INFO - 2017-04-26 11:35:26 --> Language Class Initialized
INFO - 2017-04-26 11:35:26 --> Loader Class Initialized
INFO - 2017-04-26 11:35:26 --> Helper loaded: url_helper
INFO - 2017-04-26 11:35:26 --> Helper loaded: form_helper
INFO - 2017-04-26 11:35:26 --> Helper loaded: html_helper
INFO - 2017-04-26 11:35:26 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:35:26 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:35:26 --> Database Driver Class Initialized
INFO - 2017-04-26 11:35:26 --> Parser Class Initialized
DEBUG - 2017-04-26 11:35:26 --> Session Class Initialized
INFO - 2017-04-26 11:35:26 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:35:26 --> Session routines successfully run
INFO - 2017-04-26 11:35:26 --> Form Validation Class Initialized
INFO - 2017-04-26 11:35:26 --> Controller Class Initialized
DEBUG - 2017-04-26 11:35:26 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:35:26 --> Model Class Initialized
DEBUG - 2017-04-26 11:35:26 --> Pagination Class Initialized
INFO - 2017-04-26 11:35:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:35:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:35:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:35:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:35:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:35:27 --> Final output sent to browser
DEBUG - 2017-04-26 11:35:27 --> Total execution time: 0.5257
INFO - 2017-04-26 11:35:34 --> Config Class Initialized
INFO - 2017-04-26 11:35:34 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:35:34 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:35:34 --> Utf8 Class Initialized
INFO - 2017-04-26 11:35:34 --> URI Class Initialized
INFO - 2017-04-26 11:35:34 --> Router Class Initialized
INFO - 2017-04-26 11:35:34 --> Output Class Initialized
INFO - 2017-04-26 11:35:34 --> Security Class Initialized
DEBUG - 2017-04-26 11:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:35:34 --> Input Class Initialized
INFO - 2017-04-26 11:35:34 --> Language Class Initialized
INFO - 2017-04-26 11:35:34 --> Loader Class Initialized
INFO - 2017-04-26 11:35:34 --> Helper loaded: url_helper
INFO - 2017-04-26 11:35:34 --> Helper loaded: form_helper
INFO - 2017-04-26 11:35:34 --> Helper loaded: html_helper
INFO - 2017-04-26 11:35:34 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:35:34 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:35:34 --> Database Driver Class Initialized
INFO - 2017-04-26 11:35:34 --> Parser Class Initialized
DEBUG - 2017-04-26 11:35:34 --> Session Class Initialized
INFO - 2017-04-26 11:35:34 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:35:34 --> Session routines successfully run
INFO - 2017-04-26 11:35:34 --> Form Validation Class Initialized
INFO - 2017-04-26 11:35:34 --> Controller Class Initialized
DEBUG - 2017-04-26 11:35:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:35:35 --> Model Class Initialized
DEBUG - 2017-04-26 11:35:35 --> Pagination Class Initialized
INFO - 2017-04-26 11:35:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:35:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:35:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:35:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:35:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:35:35 --> Final output sent to browser
DEBUG - 2017-04-26 11:35:35 --> Total execution time: 0.5116
INFO - 2017-04-26 11:35:37 --> Config Class Initialized
INFO - 2017-04-26 11:35:37 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:35:37 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:35:37 --> Utf8 Class Initialized
INFO - 2017-04-26 11:35:37 --> URI Class Initialized
INFO - 2017-04-26 11:35:37 --> Router Class Initialized
INFO - 2017-04-26 11:35:37 --> Output Class Initialized
INFO - 2017-04-26 11:35:37 --> Security Class Initialized
DEBUG - 2017-04-26 11:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:35:37 --> Input Class Initialized
INFO - 2017-04-26 11:35:37 --> Language Class Initialized
INFO - 2017-04-26 11:35:37 --> Loader Class Initialized
INFO - 2017-04-26 11:35:37 --> Helper loaded: url_helper
INFO - 2017-04-26 11:35:38 --> Helper loaded: form_helper
INFO - 2017-04-26 11:35:38 --> Helper loaded: html_helper
INFO - 2017-04-26 11:35:38 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:35:38 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:35:38 --> Database Driver Class Initialized
INFO - 2017-04-26 11:35:38 --> Parser Class Initialized
DEBUG - 2017-04-26 11:35:38 --> Session Class Initialized
INFO - 2017-04-26 11:35:38 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:35:38 --> Session routines successfully run
INFO - 2017-04-26 11:35:38 --> Form Validation Class Initialized
INFO - 2017-04-26 11:35:38 --> Controller Class Initialized
DEBUG - 2017-04-26 11:35:38 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:35:38 --> Model Class Initialized
DEBUG - 2017-04-26 11:35:38 --> Pagination Class Initialized
INFO - 2017-04-26 11:35:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:35:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:35:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:35:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:35:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:35:38 --> Final output sent to browser
DEBUG - 2017-04-26 11:35:38 --> Total execution time: 0.6157
INFO - 2017-04-26 11:37:52 --> Config Class Initialized
INFO - 2017-04-26 11:37:52 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:37:52 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:37:52 --> Utf8 Class Initialized
INFO - 2017-04-26 11:37:52 --> URI Class Initialized
INFO - 2017-04-26 11:37:52 --> Router Class Initialized
INFO - 2017-04-26 11:37:52 --> Output Class Initialized
INFO - 2017-04-26 11:37:52 --> Security Class Initialized
DEBUG - 2017-04-26 11:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:37:52 --> Input Class Initialized
INFO - 2017-04-26 11:37:52 --> Language Class Initialized
INFO - 2017-04-26 11:37:52 --> Loader Class Initialized
INFO - 2017-04-26 11:37:52 --> Helper loaded: url_helper
INFO - 2017-04-26 11:37:52 --> Helper loaded: form_helper
INFO - 2017-04-26 11:37:52 --> Helper loaded: html_helper
INFO - 2017-04-26 11:37:52 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:37:52 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:37:52 --> Database Driver Class Initialized
INFO - 2017-04-26 11:37:52 --> Parser Class Initialized
DEBUG - 2017-04-26 11:37:52 --> Session Class Initialized
INFO - 2017-04-26 11:37:53 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:37:53 --> Session routines successfully run
INFO - 2017-04-26 11:37:53 --> Form Validation Class Initialized
INFO - 2017-04-26 11:37:53 --> Controller Class Initialized
DEBUG - 2017-04-26 11:37:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:37:53 --> Model Class Initialized
DEBUG - 2017-04-26 11:37:53 --> Pagination Class Initialized
INFO - 2017-04-26 11:37:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:37:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:37:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:37:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:37:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:37:53 --> Final output sent to browser
DEBUG - 2017-04-26 11:37:53 --> Total execution time: 0.9137
INFO - 2017-04-26 11:39:23 --> Config Class Initialized
INFO - 2017-04-26 11:39:23 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:39:23 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:39:23 --> Utf8 Class Initialized
INFO - 2017-04-26 11:39:23 --> URI Class Initialized
INFO - 2017-04-26 11:39:23 --> Router Class Initialized
INFO - 2017-04-26 11:39:23 --> Output Class Initialized
INFO - 2017-04-26 11:39:23 --> Security Class Initialized
DEBUG - 2017-04-26 11:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:39:23 --> Input Class Initialized
INFO - 2017-04-26 11:39:23 --> Language Class Initialized
INFO - 2017-04-26 11:39:23 --> Loader Class Initialized
INFO - 2017-04-26 11:39:23 --> Helper loaded: url_helper
INFO - 2017-04-26 11:39:23 --> Helper loaded: form_helper
INFO - 2017-04-26 11:39:23 --> Helper loaded: html_helper
INFO - 2017-04-26 11:39:23 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:39:23 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:39:23 --> Database Driver Class Initialized
INFO - 2017-04-26 11:39:23 --> Parser Class Initialized
DEBUG - 2017-04-26 11:39:23 --> Session Class Initialized
INFO - 2017-04-26 11:39:23 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:39:23 --> Session routines successfully run
INFO - 2017-04-26 11:39:23 --> Form Validation Class Initialized
INFO - 2017-04-26 11:39:23 --> Controller Class Initialized
DEBUG - 2017-04-26 11:39:23 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:39:23 --> Model Class Initialized
DEBUG - 2017-04-26 11:39:23 --> Pagination Class Initialized
INFO - 2017-04-26 11:39:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:39:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:39:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:39:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:39:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:39:24 --> Final output sent to browser
DEBUG - 2017-04-26 11:39:24 --> Total execution time: 0.7509
INFO - 2017-04-26 11:42:07 --> Config Class Initialized
INFO - 2017-04-26 11:42:07 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:42:07 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:42:07 --> Utf8 Class Initialized
INFO - 2017-04-26 11:42:07 --> URI Class Initialized
INFO - 2017-04-26 11:42:07 --> Router Class Initialized
INFO - 2017-04-26 11:42:07 --> Output Class Initialized
INFO - 2017-04-26 11:42:07 --> Security Class Initialized
DEBUG - 2017-04-26 11:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:42:07 --> Input Class Initialized
INFO - 2017-04-26 11:42:07 --> Language Class Initialized
INFO - 2017-04-26 11:42:07 --> Loader Class Initialized
INFO - 2017-04-26 11:42:07 --> Helper loaded: url_helper
INFO - 2017-04-26 11:42:07 --> Helper loaded: form_helper
INFO - 2017-04-26 11:42:07 --> Helper loaded: html_helper
INFO - 2017-04-26 11:42:07 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:42:07 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:42:07 --> Database Driver Class Initialized
INFO - 2017-04-26 11:42:07 --> Parser Class Initialized
DEBUG - 2017-04-26 11:42:07 --> Session Class Initialized
INFO - 2017-04-26 11:42:07 --> Helper loaded: string_helper
ERROR - 2017-04-26 11:42:07 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-26 11:42:07 --> Session routines successfully run
INFO - 2017-04-26 11:42:08 --> Form Validation Class Initialized
INFO - 2017-04-26 11:42:08 --> Controller Class Initialized
DEBUG - 2017-04-26 11:42:08 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:42:08 --> Model Class Initialized
DEBUG - 2017-04-26 11:42:08 --> Pagination Class Initialized
INFO - 2017-04-26 11:42:08 --> Config Class Initialized
INFO - 2017-04-26 11:42:08 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:42:08 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:42:08 --> Utf8 Class Initialized
INFO - 2017-04-26 11:42:08 --> URI Class Initialized
INFO - 2017-04-26 11:42:08 --> Router Class Initialized
INFO - 2017-04-26 11:42:08 --> Output Class Initialized
INFO - 2017-04-26 11:42:08 --> Security Class Initialized
DEBUG - 2017-04-26 11:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:42:08 --> Input Class Initialized
INFO - 2017-04-26 11:42:08 --> Language Class Initialized
INFO - 2017-04-26 11:42:08 --> Loader Class Initialized
INFO - 2017-04-26 11:42:08 --> Helper loaded: url_helper
INFO - 2017-04-26 11:42:08 --> Helper loaded: form_helper
INFO - 2017-04-26 11:42:08 --> Helper loaded: html_helper
INFO - 2017-04-26 11:42:08 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:42:08 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:42:08 --> Database Driver Class Initialized
INFO - 2017-04-26 11:42:08 --> Parser Class Initialized
DEBUG - 2017-04-26 11:42:08 --> Session Class Initialized
INFO - 2017-04-26 11:42:08 --> Helper loaded: string_helper
ERROR - 2017-04-26 11:42:08 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-26 11:42:08 --> Session routines successfully run
INFO - 2017-04-26 11:42:08 --> Form Validation Class Initialized
INFO - 2017-04-26 11:42:08 --> Controller Class Initialized
INFO - 2017-04-26 11:42:08 --> Model Class Initialized
INFO - 2017-04-26 11:42:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-26 11:42:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:42:08 --> Final output sent to browser
DEBUG - 2017-04-26 11:42:08 --> Total execution time: 0.4680
INFO - 2017-04-26 11:55:42 --> Config Class Initialized
INFO - 2017-04-26 11:55:42 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:55:42 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:55:42 --> Utf8 Class Initialized
INFO - 2017-04-26 11:55:42 --> URI Class Initialized
INFO - 2017-04-26 11:55:42 --> Router Class Initialized
INFO - 2017-04-26 11:55:42 --> Output Class Initialized
INFO - 2017-04-26 11:55:42 --> Security Class Initialized
DEBUG - 2017-04-26 11:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:55:42 --> Input Class Initialized
INFO - 2017-04-26 11:55:42 --> Language Class Initialized
INFO - 2017-04-26 11:55:42 --> Loader Class Initialized
INFO - 2017-04-26 11:55:42 --> Helper loaded: url_helper
INFO - 2017-04-26 11:55:42 --> Helper loaded: form_helper
INFO - 2017-04-26 11:55:42 --> Helper loaded: html_helper
INFO - 2017-04-26 11:55:42 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:55:42 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:55:42 --> Database Driver Class Initialized
INFO - 2017-04-26 11:55:42 --> Parser Class Initialized
DEBUG - 2017-04-26 11:55:42 --> Session Class Initialized
INFO - 2017-04-26 11:55:42 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:55:43 --> Session routines successfully run
INFO - 2017-04-26 11:55:43 --> Form Validation Class Initialized
INFO - 2017-04-26 11:55:43 --> Controller Class Initialized
DEBUG - 2017-04-26 11:55:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:55:43 --> Model Class Initialized
DEBUG - 2017-04-26 11:55:43 --> Pagination Class Initialized
INFO - 2017-04-26 11:55:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:55:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:55:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:55:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:55:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:55:43 --> Final output sent to browser
DEBUG - 2017-04-26 11:55:43 --> Total execution time: 0.5463
INFO - 2017-04-26 11:55:46 --> Config Class Initialized
INFO - 2017-04-26 11:55:46 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:55:46 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:55:46 --> Utf8 Class Initialized
INFO - 2017-04-26 11:55:46 --> URI Class Initialized
INFO - 2017-04-26 11:55:46 --> Router Class Initialized
INFO - 2017-04-26 11:55:46 --> Output Class Initialized
INFO - 2017-04-26 11:55:46 --> Security Class Initialized
DEBUG - 2017-04-26 11:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:55:46 --> Input Class Initialized
INFO - 2017-04-26 11:55:46 --> Language Class Initialized
INFO - 2017-04-26 11:55:46 --> Loader Class Initialized
INFO - 2017-04-26 11:55:46 --> Helper loaded: url_helper
INFO - 2017-04-26 11:55:46 --> Helper loaded: form_helper
INFO - 2017-04-26 11:55:46 --> Helper loaded: html_helper
INFO - 2017-04-26 11:55:46 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:55:46 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:55:46 --> Database Driver Class Initialized
INFO - 2017-04-26 11:55:46 --> Parser Class Initialized
DEBUG - 2017-04-26 11:55:46 --> Session Class Initialized
INFO - 2017-04-26 11:55:46 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:55:46 --> Session routines successfully run
INFO - 2017-04-26 11:55:46 --> Form Validation Class Initialized
INFO - 2017-04-26 11:55:46 --> Controller Class Initialized
DEBUG - 2017-04-26 11:55:46 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:55:46 --> Model Class Initialized
DEBUG - 2017-04-26 11:55:46 --> Pagination Class Initialized
INFO - 2017-04-26 11:55:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:55:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:55:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:55:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:55:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:55:46 --> Final output sent to browser
DEBUG - 2017-04-26 11:55:46 --> Total execution time: 0.5254
INFO - 2017-04-26 11:56:40 --> Config Class Initialized
INFO - 2017-04-26 11:56:40 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:56:40 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:56:40 --> Utf8 Class Initialized
INFO - 2017-04-26 11:56:40 --> URI Class Initialized
INFO - 2017-04-26 11:56:40 --> Router Class Initialized
INFO - 2017-04-26 11:56:40 --> Output Class Initialized
INFO - 2017-04-26 11:56:40 --> Security Class Initialized
DEBUG - 2017-04-26 11:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:56:40 --> Input Class Initialized
INFO - 2017-04-26 11:56:40 --> Language Class Initialized
ERROR - 2017-04-26 11:56:40 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:57:05 --> Config Class Initialized
INFO - 2017-04-26 11:57:05 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:57:05 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:57:05 --> Utf8 Class Initialized
INFO - 2017-04-26 11:57:05 --> URI Class Initialized
INFO - 2017-04-26 11:57:06 --> Router Class Initialized
INFO - 2017-04-26 11:57:06 --> Output Class Initialized
INFO - 2017-04-26 11:57:06 --> Security Class Initialized
DEBUG - 2017-04-26 11:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:57:06 --> Input Class Initialized
INFO - 2017-04-26 11:57:06 --> Language Class Initialized
INFO - 2017-04-26 11:57:06 --> Loader Class Initialized
INFO - 2017-04-26 11:57:06 --> Helper loaded: url_helper
INFO - 2017-04-26 11:57:06 --> Helper loaded: form_helper
INFO - 2017-04-26 11:57:06 --> Helper loaded: html_helper
INFO - 2017-04-26 11:57:06 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:57:06 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:57:06 --> Database Driver Class Initialized
INFO - 2017-04-26 11:57:06 --> Parser Class Initialized
DEBUG - 2017-04-26 11:57:06 --> Session Class Initialized
INFO - 2017-04-26 11:57:06 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:57:06 --> Session routines successfully run
INFO - 2017-04-26 11:57:06 --> Form Validation Class Initialized
INFO - 2017-04-26 11:57:06 --> Controller Class Initialized
DEBUG - 2017-04-26 11:57:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:57:06 --> Model Class Initialized
DEBUG - 2017-04-26 11:57:06 --> Pagination Class Initialized
INFO - 2017-04-26 11:57:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:57:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:57:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:57:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:57:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:57:06 --> Final output sent to browser
DEBUG - 2017-04-26 11:57:06 --> Total execution time: 0.5366
INFO - 2017-04-26 11:57:07 --> Config Class Initialized
INFO - 2017-04-26 11:57:07 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:57:07 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:57:07 --> Utf8 Class Initialized
INFO - 2017-04-26 11:57:07 --> URI Class Initialized
INFO - 2017-04-26 11:57:07 --> Router Class Initialized
INFO - 2017-04-26 11:57:07 --> Output Class Initialized
INFO - 2017-04-26 11:57:07 --> Security Class Initialized
DEBUG - 2017-04-26 11:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:57:07 --> Input Class Initialized
INFO - 2017-04-26 11:57:07 --> Language Class Initialized
ERROR - 2017-04-26 11:57:07 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 11:58:06 --> Config Class Initialized
INFO - 2017-04-26 11:58:06 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:58:06 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:58:06 --> Utf8 Class Initialized
INFO - 2017-04-26 11:58:06 --> URI Class Initialized
INFO - 2017-04-26 11:58:06 --> Router Class Initialized
INFO - 2017-04-26 11:58:06 --> Output Class Initialized
INFO - 2017-04-26 11:58:06 --> Security Class Initialized
DEBUG - 2017-04-26 11:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:58:07 --> Input Class Initialized
INFO - 2017-04-26 11:58:07 --> Language Class Initialized
INFO - 2017-04-26 11:58:07 --> Loader Class Initialized
INFO - 2017-04-26 11:58:07 --> Helper loaded: url_helper
INFO - 2017-04-26 11:58:07 --> Helper loaded: form_helper
INFO - 2017-04-26 11:58:07 --> Helper loaded: html_helper
INFO - 2017-04-26 11:58:07 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:58:07 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:58:07 --> Database Driver Class Initialized
INFO - 2017-04-26 11:58:07 --> Parser Class Initialized
DEBUG - 2017-04-26 11:58:07 --> Session Class Initialized
INFO - 2017-04-26 11:58:07 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:58:07 --> Session routines successfully run
INFO - 2017-04-26 11:58:07 --> Form Validation Class Initialized
INFO - 2017-04-26 11:58:07 --> Controller Class Initialized
DEBUG - 2017-04-26 11:58:07 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:58:07 --> Model Class Initialized
DEBUG - 2017-04-26 11:58:07 --> Pagination Class Initialized
INFO - 2017-04-26 11:58:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:58:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:58:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:58:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:58:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:58:07 --> Final output sent to browser
DEBUG - 2017-04-26 11:58:07 --> Total execution time: 0.5338
INFO - 2017-04-26 11:58:11 --> Config Class Initialized
INFO - 2017-04-26 11:58:11 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:58:11 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:58:11 --> Utf8 Class Initialized
INFO - 2017-04-26 11:58:11 --> URI Class Initialized
INFO - 2017-04-26 11:58:11 --> Router Class Initialized
INFO - 2017-04-26 11:58:12 --> Output Class Initialized
INFO - 2017-04-26 11:58:12 --> Security Class Initialized
DEBUG - 2017-04-26 11:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:58:12 --> Input Class Initialized
INFO - 2017-04-26 11:58:12 --> Language Class Initialized
INFO - 2017-04-26 11:58:12 --> Loader Class Initialized
INFO - 2017-04-26 11:58:12 --> Helper loaded: url_helper
INFO - 2017-04-26 11:58:12 --> Helper loaded: form_helper
INFO - 2017-04-26 11:58:12 --> Helper loaded: html_helper
INFO - 2017-04-26 11:58:12 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:58:12 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:58:12 --> Database Driver Class Initialized
INFO - 2017-04-26 11:58:12 --> Parser Class Initialized
DEBUG - 2017-04-26 11:58:12 --> Session Class Initialized
INFO - 2017-04-26 11:58:12 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:58:12 --> Session routines successfully run
INFO - 2017-04-26 11:58:12 --> Form Validation Class Initialized
INFO - 2017-04-26 11:58:12 --> Controller Class Initialized
DEBUG - 2017-04-26 11:58:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:58:12 --> Model Class Initialized
DEBUG - 2017-04-26 11:58:12 --> Pagination Class Initialized
INFO - 2017-04-26 11:58:48 --> Config Class Initialized
INFO - 2017-04-26 11:58:48 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:58:48 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:58:48 --> Utf8 Class Initialized
INFO - 2017-04-26 11:58:48 --> URI Class Initialized
INFO - 2017-04-26 11:58:48 --> Router Class Initialized
INFO - 2017-04-26 11:58:48 --> Output Class Initialized
INFO - 2017-04-26 11:58:49 --> Security Class Initialized
DEBUG - 2017-04-26 11:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:58:49 --> Input Class Initialized
INFO - 2017-04-26 11:58:49 --> Language Class Initialized
INFO - 2017-04-26 11:58:49 --> Loader Class Initialized
INFO - 2017-04-26 11:58:49 --> Helper loaded: url_helper
INFO - 2017-04-26 11:58:49 --> Helper loaded: form_helper
INFO - 2017-04-26 11:58:49 --> Helper loaded: html_helper
INFO - 2017-04-26 11:58:49 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:58:49 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:58:49 --> Database Driver Class Initialized
INFO - 2017-04-26 11:58:49 --> Parser Class Initialized
DEBUG - 2017-04-26 11:58:49 --> Session Class Initialized
INFO - 2017-04-26 11:58:49 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:58:49 --> Session routines successfully run
INFO - 2017-04-26 11:58:49 --> Form Validation Class Initialized
INFO - 2017-04-26 11:58:49 --> Controller Class Initialized
DEBUG - 2017-04-26 11:58:49 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:58:49 --> Model Class Initialized
DEBUG - 2017-04-26 11:58:49 --> Pagination Class Initialized
INFO - 2017-04-26 11:59:18 --> Config Class Initialized
INFO - 2017-04-26 11:59:18 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:59:18 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:59:18 --> Utf8 Class Initialized
INFO - 2017-04-26 11:59:18 --> URI Class Initialized
INFO - 2017-04-26 11:59:18 --> Router Class Initialized
INFO - 2017-04-26 11:59:18 --> Output Class Initialized
INFO - 2017-04-26 11:59:18 --> Security Class Initialized
DEBUG - 2017-04-26 11:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:59:18 --> Input Class Initialized
INFO - 2017-04-26 11:59:18 --> Language Class Initialized
INFO - 2017-04-26 11:59:18 --> Loader Class Initialized
INFO - 2017-04-26 11:59:18 --> Helper loaded: url_helper
INFO - 2017-04-26 11:59:18 --> Helper loaded: form_helper
INFO - 2017-04-26 11:59:18 --> Helper loaded: html_helper
INFO - 2017-04-26 11:59:18 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:59:18 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:59:18 --> Database Driver Class Initialized
INFO - 2017-04-26 11:59:18 --> Parser Class Initialized
DEBUG - 2017-04-26 11:59:18 --> Session Class Initialized
INFO - 2017-04-26 11:59:18 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:59:18 --> Session routines successfully run
INFO - 2017-04-26 11:59:18 --> Form Validation Class Initialized
INFO - 2017-04-26 11:59:18 --> Controller Class Initialized
DEBUG - 2017-04-26 11:59:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:59:18 --> Model Class Initialized
DEBUG - 2017-04-26 11:59:18 --> Pagination Class Initialized
INFO - 2017-04-26 11:59:34 --> Config Class Initialized
INFO - 2017-04-26 11:59:34 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:59:34 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:59:34 --> Utf8 Class Initialized
INFO - 2017-04-26 11:59:34 --> URI Class Initialized
INFO - 2017-04-26 11:59:34 --> Router Class Initialized
INFO - 2017-04-26 11:59:34 --> Output Class Initialized
INFO - 2017-04-26 11:59:34 --> Security Class Initialized
DEBUG - 2017-04-26 11:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:59:34 --> Input Class Initialized
INFO - 2017-04-26 11:59:34 --> Language Class Initialized
INFO - 2017-04-26 11:59:34 --> Loader Class Initialized
INFO - 2017-04-26 11:59:34 --> Helper loaded: url_helper
INFO - 2017-04-26 11:59:34 --> Helper loaded: form_helper
INFO - 2017-04-26 11:59:34 --> Helper loaded: html_helper
INFO - 2017-04-26 11:59:34 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:59:34 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:59:34 --> Database Driver Class Initialized
INFO - 2017-04-26 11:59:34 --> Parser Class Initialized
DEBUG - 2017-04-26 11:59:34 --> Session Class Initialized
INFO - 2017-04-26 11:59:34 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:59:34 --> Session routines successfully run
INFO - 2017-04-26 11:59:34 --> Form Validation Class Initialized
INFO - 2017-04-26 11:59:34 --> Controller Class Initialized
DEBUG - 2017-04-26 11:59:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:59:34 --> Model Class Initialized
DEBUG - 2017-04-26 11:59:34 --> Pagination Class Initialized
INFO - 2017-04-26 11:59:44 --> Config Class Initialized
INFO - 2017-04-26 11:59:44 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:59:44 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:59:44 --> Utf8 Class Initialized
INFO - 2017-04-26 11:59:44 --> URI Class Initialized
INFO - 2017-04-26 11:59:44 --> Router Class Initialized
INFO - 2017-04-26 11:59:44 --> Output Class Initialized
INFO - 2017-04-26 11:59:44 --> Security Class Initialized
DEBUG - 2017-04-26 11:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:59:44 --> Input Class Initialized
INFO - 2017-04-26 11:59:44 --> Language Class Initialized
INFO - 2017-04-26 11:59:44 --> Loader Class Initialized
INFO - 2017-04-26 11:59:44 --> Helper loaded: url_helper
INFO - 2017-04-26 11:59:44 --> Helper loaded: form_helper
INFO - 2017-04-26 11:59:44 --> Helper loaded: html_helper
INFO - 2017-04-26 11:59:44 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:59:44 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:59:44 --> Database Driver Class Initialized
INFO - 2017-04-26 11:59:44 --> Parser Class Initialized
DEBUG - 2017-04-26 11:59:44 --> Session Class Initialized
INFO - 2017-04-26 11:59:44 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:59:44 --> Session routines successfully run
INFO - 2017-04-26 11:59:44 --> Form Validation Class Initialized
INFO - 2017-04-26 11:59:44 --> Controller Class Initialized
DEBUG - 2017-04-26 11:59:44 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:59:44 --> Model Class Initialized
DEBUG - 2017-04-26 11:59:44 --> Pagination Class Initialized
INFO - 2017-04-26 11:59:50 --> Config Class Initialized
INFO - 2017-04-26 11:59:50 --> Hooks Class Initialized
DEBUG - 2017-04-26 11:59:50 --> UTF-8 Support Enabled
INFO - 2017-04-26 11:59:50 --> Utf8 Class Initialized
INFO - 2017-04-26 11:59:50 --> URI Class Initialized
INFO - 2017-04-26 11:59:50 --> Router Class Initialized
INFO - 2017-04-26 11:59:50 --> Output Class Initialized
INFO - 2017-04-26 11:59:50 --> Security Class Initialized
DEBUG - 2017-04-26 11:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 11:59:50 --> Input Class Initialized
INFO - 2017-04-26 11:59:50 --> Language Class Initialized
INFO - 2017-04-26 11:59:50 --> Loader Class Initialized
INFO - 2017-04-26 11:59:50 --> Helper loaded: url_helper
INFO - 2017-04-26 11:59:50 --> Helper loaded: form_helper
INFO - 2017-04-26 11:59:50 --> Helper loaded: html_helper
INFO - 2017-04-26 11:59:50 --> Helper loaded: custom_helper
INFO - 2017-04-26 11:59:50 --> Helper loaded: cache_helper
INFO - 2017-04-26 11:59:50 --> Database Driver Class Initialized
INFO - 2017-04-26 11:59:50 --> Parser Class Initialized
DEBUG - 2017-04-26 11:59:50 --> Session Class Initialized
INFO - 2017-04-26 11:59:50 --> Helper loaded: string_helper
DEBUG - 2017-04-26 11:59:50 --> Session routines successfully run
INFO - 2017-04-26 11:59:50 --> Form Validation Class Initialized
INFO - 2017-04-26 11:59:50 --> Controller Class Initialized
DEBUG - 2017-04-26 11:59:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 11:59:50 --> Model Class Initialized
DEBUG - 2017-04-26 11:59:50 --> Pagination Class Initialized
INFO - 2017-04-26 11:59:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 11:59:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 11:59:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 11:59:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 11:59:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 11:59:50 --> Final output sent to browser
DEBUG - 2017-04-26 11:59:50 --> Total execution time: 0.6095
INFO - 2017-04-26 12:02:25 --> Config Class Initialized
INFO - 2017-04-26 12:02:25 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:02:25 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:02:25 --> Utf8 Class Initialized
INFO - 2017-04-26 12:02:25 --> URI Class Initialized
INFO - 2017-04-26 12:02:25 --> Router Class Initialized
INFO - 2017-04-26 12:02:25 --> Output Class Initialized
INFO - 2017-04-26 12:02:25 --> Security Class Initialized
DEBUG - 2017-04-26 12:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:02:25 --> Input Class Initialized
INFO - 2017-04-26 12:02:25 --> Language Class Initialized
INFO - 2017-04-26 12:02:25 --> Loader Class Initialized
INFO - 2017-04-26 12:02:25 --> Helper loaded: url_helper
INFO - 2017-04-26 12:02:25 --> Helper loaded: form_helper
INFO - 2017-04-26 12:02:25 --> Helper loaded: html_helper
INFO - 2017-04-26 12:02:25 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:02:25 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:02:25 --> Database Driver Class Initialized
INFO - 2017-04-26 12:02:25 --> Parser Class Initialized
DEBUG - 2017-04-26 12:02:25 --> Session Class Initialized
INFO - 2017-04-26 12:02:25 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:02:25 --> Session routines successfully run
INFO - 2017-04-26 12:02:25 --> Form Validation Class Initialized
INFO - 2017-04-26 12:02:25 --> Controller Class Initialized
DEBUG - 2017-04-26 12:02:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:02:25 --> Model Class Initialized
DEBUG - 2017-04-26 12:02:25 --> Pagination Class Initialized
INFO - 2017-04-26 12:02:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:02:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:02:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:02:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:02:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:02:25 --> Final output sent to browser
DEBUG - 2017-04-26 12:02:25 --> Total execution time: 0.5725
INFO - 2017-04-26 12:04:30 --> Config Class Initialized
INFO - 2017-04-26 12:04:30 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:04:30 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:04:30 --> Utf8 Class Initialized
INFO - 2017-04-26 12:04:30 --> URI Class Initialized
INFO - 2017-04-26 12:04:30 --> Router Class Initialized
INFO - 2017-04-26 12:04:30 --> Output Class Initialized
INFO - 2017-04-26 12:04:30 --> Security Class Initialized
DEBUG - 2017-04-26 12:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:04:30 --> Input Class Initialized
INFO - 2017-04-26 12:04:30 --> Language Class Initialized
INFO - 2017-04-26 12:04:30 --> Loader Class Initialized
INFO - 2017-04-26 12:04:30 --> Helper loaded: url_helper
INFO - 2017-04-26 12:04:30 --> Helper loaded: form_helper
INFO - 2017-04-26 12:04:30 --> Helper loaded: html_helper
INFO - 2017-04-26 12:04:30 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:04:30 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:04:31 --> Database Driver Class Initialized
INFO - 2017-04-26 12:04:31 --> Parser Class Initialized
DEBUG - 2017-04-26 12:04:31 --> Session Class Initialized
INFO - 2017-04-26 12:04:31 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:04:31 --> Session routines successfully run
INFO - 2017-04-26 12:04:31 --> Form Validation Class Initialized
INFO - 2017-04-26 12:04:31 --> Controller Class Initialized
DEBUG - 2017-04-26 12:04:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:04:31 --> Model Class Initialized
DEBUG - 2017-04-26 12:04:31 --> Pagination Class Initialized
INFO - 2017-04-26 12:04:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:04:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:04:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:04:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:04:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:04:31 --> Final output sent to browser
DEBUG - 2017-04-26 12:04:31 --> Total execution time: 0.5418
INFO - 2017-04-26 12:04:42 --> Config Class Initialized
INFO - 2017-04-26 12:04:42 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:04:42 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:04:42 --> Utf8 Class Initialized
INFO - 2017-04-26 12:04:42 --> URI Class Initialized
INFO - 2017-04-26 12:04:42 --> Router Class Initialized
INFO - 2017-04-26 12:04:42 --> Output Class Initialized
INFO - 2017-04-26 12:04:42 --> Security Class Initialized
DEBUG - 2017-04-26 12:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:04:42 --> Input Class Initialized
INFO - 2017-04-26 12:04:42 --> Language Class Initialized
INFO - 2017-04-26 12:04:42 --> Loader Class Initialized
INFO - 2017-04-26 12:04:42 --> Helper loaded: url_helper
INFO - 2017-04-26 12:04:42 --> Helper loaded: form_helper
INFO - 2017-04-26 12:04:42 --> Helper loaded: html_helper
INFO - 2017-04-26 12:04:42 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:04:42 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:04:42 --> Database Driver Class Initialized
INFO - 2017-04-26 12:04:42 --> Parser Class Initialized
DEBUG - 2017-04-26 12:04:42 --> Session Class Initialized
INFO - 2017-04-26 12:04:42 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:04:42 --> Session routines successfully run
INFO - 2017-04-26 12:04:42 --> Form Validation Class Initialized
INFO - 2017-04-26 12:04:42 --> Controller Class Initialized
DEBUG - 2017-04-26 12:04:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:04:42 --> Model Class Initialized
DEBUG - 2017-04-26 12:04:42 --> Pagination Class Initialized
INFO - 2017-04-26 12:04:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:04:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:04:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:04:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:04:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:04:42 --> Final output sent to browser
DEBUG - 2017-04-26 12:04:42 --> Total execution time: 0.5318
INFO - 2017-04-26 12:14:35 --> Config Class Initialized
INFO - 2017-04-26 12:14:35 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:14:35 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:14:35 --> Utf8 Class Initialized
INFO - 2017-04-26 12:14:35 --> URI Class Initialized
INFO - 2017-04-26 12:14:35 --> Router Class Initialized
INFO - 2017-04-26 12:14:35 --> Output Class Initialized
INFO - 2017-04-26 12:14:35 --> Security Class Initialized
DEBUG - 2017-04-26 12:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:14:35 --> Input Class Initialized
INFO - 2017-04-26 12:14:35 --> Language Class Initialized
INFO - 2017-04-26 12:14:35 --> Loader Class Initialized
INFO - 2017-04-26 12:14:35 --> Helper loaded: url_helper
INFO - 2017-04-26 12:14:35 --> Helper loaded: form_helper
INFO - 2017-04-26 12:14:35 --> Helper loaded: html_helper
INFO - 2017-04-26 12:14:35 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:14:35 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:14:35 --> Database Driver Class Initialized
INFO - 2017-04-26 12:14:35 --> Parser Class Initialized
DEBUG - 2017-04-26 12:14:35 --> Session Class Initialized
INFO - 2017-04-26 12:14:35 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:14:35 --> Session routines successfully run
INFO - 2017-04-26 12:14:35 --> Form Validation Class Initialized
INFO - 2017-04-26 12:14:35 --> Controller Class Initialized
DEBUG - 2017-04-26 12:14:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:14:35 --> Model Class Initialized
DEBUG - 2017-04-26 12:14:35 --> Pagination Class Initialized
INFO - 2017-04-26 12:14:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:14:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:14:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:14:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:14:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:14:35 --> Final output sent to browser
DEBUG - 2017-04-26 12:14:35 --> Total execution time: 0.5415
INFO - 2017-04-26 12:15:03 --> Config Class Initialized
INFO - 2017-04-26 12:15:03 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:15:03 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:15:03 --> Utf8 Class Initialized
INFO - 2017-04-26 12:15:03 --> URI Class Initialized
INFO - 2017-04-26 12:15:03 --> Router Class Initialized
INFO - 2017-04-26 12:15:03 --> Output Class Initialized
INFO - 2017-04-26 12:15:03 --> Security Class Initialized
DEBUG - 2017-04-26 12:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:15:03 --> Input Class Initialized
INFO - 2017-04-26 12:15:03 --> Language Class Initialized
INFO - 2017-04-26 12:15:03 --> Loader Class Initialized
INFO - 2017-04-26 12:15:03 --> Helper loaded: url_helper
INFO - 2017-04-26 12:15:03 --> Helper loaded: form_helper
INFO - 2017-04-26 12:15:03 --> Helper loaded: html_helper
INFO - 2017-04-26 12:15:03 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:15:03 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:15:03 --> Database Driver Class Initialized
INFO - 2017-04-26 12:15:03 --> Parser Class Initialized
DEBUG - 2017-04-26 12:15:03 --> Session Class Initialized
INFO - 2017-04-26 12:15:03 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:15:03 --> Session routines successfully run
INFO - 2017-04-26 12:15:03 --> Form Validation Class Initialized
INFO - 2017-04-26 12:15:03 --> Controller Class Initialized
DEBUG - 2017-04-26 12:15:03 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:15:03 --> Model Class Initialized
DEBUG - 2017-04-26 12:15:03 --> Pagination Class Initialized
INFO - 2017-04-26 12:15:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:15:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:15:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:15:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:15:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:15:03 --> Final output sent to browser
DEBUG - 2017-04-26 12:15:03 --> Total execution time: 0.5667
INFO - 2017-04-26 12:15:04 --> Config Class Initialized
INFO - 2017-04-26 12:15:04 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:15:04 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:15:04 --> Utf8 Class Initialized
INFO - 2017-04-26 12:15:04 --> URI Class Initialized
INFO - 2017-04-26 12:15:04 --> Router Class Initialized
INFO - 2017-04-26 12:15:04 --> Output Class Initialized
INFO - 2017-04-26 12:15:04 --> Security Class Initialized
DEBUG - 2017-04-26 12:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:15:04 --> Input Class Initialized
INFO - 2017-04-26 12:15:04 --> Language Class Initialized
ERROR - 2017-04-26 12:15:04 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 12:15:11 --> Config Class Initialized
INFO - 2017-04-26 12:15:11 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:15:11 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:15:11 --> Utf8 Class Initialized
INFO - 2017-04-26 12:15:11 --> URI Class Initialized
INFO - 2017-04-26 12:15:11 --> Router Class Initialized
INFO - 2017-04-26 12:15:11 --> Output Class Initialized
INFO - 2017-04-26 12:15:11 --> Security Class Initialized
DEBUG - 2017-04-26 12:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:15:11 --> Input Class Initialized
INFO - 2017-04-26 12:15:11 --> Language Class Initialized
INFO - 2017-04-26 12:15:11 --> Loader Class Initialized
INFO - 2017-04-26 12:15:11 --> Helper loaded: url_helper
INFO - 2017-04-26 12:15:11 --> Helper loaded: form_helper
INFO - 2017-04-26 12:15:11 --> Helper loaded: html_helper
INFO - 2017-04-26 12:15:11 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:15:11 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:15:11 --> Database Driver Class Initialized
INFO - 2017-04-26 12:15:11 --> Parser Class Initialized
DEBUG - 2017-04-26 12:15:11 --> Session Class Initialized
INFO - 2017-04-26 12:15:11 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:15:11 --> Session routines successfully run
INFO - 2017-04-26 12:15:11 --> Form Validation Class Initialized
INFO - 2017-04-26 12:15:11 --> Controller Class Initialized
DEBUG - 2017-04-26 12:15:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:15:11 --> Model Class Initialized
DEBUG - 2017-04-26 12:15:11 --> Pagination Class Initialized
INFO - 2017-04-26 12:15:13 --> Config Class Initialized
INFO - 2017-04-26 12:15:13 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:15:13 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:15:13 --> Utf8 Class Initialized
INFO - 2017-04-26 12:15:13 --> URI Class Initialized
INFO - 2017-04-26 12:15:13 --> Router Class Initialized
INFO - 2017-04-26 12:15:13 --> Output Class Initialized
INFO - 2017-04-26 12:15:13 --> Security Class Initialized
DEBUG - 2017-04-26 12:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:15:13 --> Input Class Initialized
INFO - 2017-04-26 12:15:13 --> Language Class Initialized
INFO - 2017-04-26 12:15:13 --> Loader Class Initialized
INFO - 2017-04-26 12:15:13 --> Helper loaded: url_helper
INFO - 2017-04-26 12:15:13 --> Helper loaded: form_helper
INFO - 2017-04-26 12:15:13 --> Helper loaded: html_helper
INFO - 2017-04-26 12:15:13 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:15:13 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:15:13 --> Database Driver Class Initialized
INFO - 2017-04-26 12:15:13 --> Parser Class Initialized
DEBUG - 2017-04-26 12:15:13 --> Session Class Initialized
INFO - 2017-04-26 12:15:13 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:15:13 --> Session routines successfully run
INFO - 2017-04-26 12:15:13 --> Form Validation Class Initialized
INFO - 2017-04-26 12:15:13 --> Controller Class Initialized
DEBUG - 2017-04-26 12:15:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:15:14 --> Model Class Initialized
DEBUG - 2017-04-26 12:15:14 --> Pagination Class Initialized
INFO - 2017-04-26 12:15:15 --> Config Class Initialized
INFO - 2017-04-26 12:15:15 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:15:15 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:15:15 --> Utf8 Class Initialized
INFO - 2017-04-26 12:15:15 --> URI Class Initialized
INFO - 2017-04-26 12:15:15 --> Router Class Initialized
INFO - 2017-04-26 12:15:15 --> Output Class Initialized
INFO - 2017-04-26 12:15:15 --> Security Class Initialized
DEBUG - 2017-04-26 12:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:15:15 --> Input Class Initialized
INFO - 2017-04-26 12:15:15 --> Language Class Initialized
INFO - 2017-04-26 12:15:15 --> Loader Class Initialized
INFO - 2017-04-26 12:15:15 --> Helper loaded: url_helper
INFO - 2017-04-26 12:15:15 --> Helper loaded: form_helper
INFO - 2017-04-26 12:15:15 --> Helper loaded: html_helper
INFO - 2017-04-26 12:15:15 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:15:15 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:15:15 --> Database Driver Class Initialized
INFO - 2017-04-26 12:15:15 --> Parser Class Initialized
DEBUG - 2017-04-26 12:15:15 --> Session Class Initialized
INFO - 2017-04-26 12:15:15 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:15:15 --> Session routines successfully run
INFO - 2017-04-26 12:15:15 --> Form Validation Class Initialized
INFO - 2017-04-26 12:15:15 --> Controller Class Initialized
DEBUG - 2017-04-26 12:15:15 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:15:16 --> Model Class Initialized
DEBUG - 2017-04-26 12:15:16 --> Pagination Class Initialized
INFO - 2017-04-26 12:15:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:15:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:15:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:15:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:15:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:15:16 --> Final output sent to browser
DEBUG - 2017-04-26 12:15:16 --> Total execution time: 0.5376
INFO - 2017-04-26 12:16:53 --> Config Class Initialized
INFO - 2017-04-26 12:16:53 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:16:53 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:16:53 --> Utf8 Class Initialized
INFO - 2017-04-26 12:16:53 --> URI Class Initialized
INFO - 2017-04-26 12:16:53 --> Router Class Initialized
INFO - 2017-04-26 12:16:53 --> Output Class Initialized
INFO - 2017-04-26 12:16:54 --> Security Class Initialized
DEBUG - 2017-04-26 12:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:16:54 --> Input Class Initialized
INFO - 2017-04-26 12:16:54 --> Language Class Initialized
INFO - 2017-04-26 12:16:54 --> Loader Class Initialized
INFO - 2017-04-26 12:16:54 --> Helper loaded: url_helper
INFO - 2017-04-26 12:16:54 --> Helper loaded: form_helper
INFO - 2017-04-26 12:16:54 --> Helper loaded: html_helper
INFO - 2017-04-26 12:16:54 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:16:54 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:16:54 --> Database Driver Class Initialized
INFO - 2017-04-26 12:16:54 --> Parser Class Initialized
DEBUG - 2017-04-26 12:16:54 --> Session Class Initialized
INFO - 2017-04-26 12:16:54 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:16:54 --> Session routines successfully run
INFO - 2017-04-26 12:16:54 --> Form Validation Class Initialized
INFO - 2017-04-26 12:16:54 --> Controller Class Initialized
DEBUG - 2017-04-26 12:16:54 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:16:54 --> Model Class Initialized
DEBUG - 2017-04-26 12:16:54 --> Pagination Class Initialized
INFO - 2017-04-26 12:16:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:16:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:16:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:16:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:16:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:16:54 --> Final output sent to browser
DEBUG - 2017-04-26 12:16:54 --> Total execution time: 0.5176
INFO - 2017-04-26 12:17:01 --> Config Class Initialized
INFO - 2017-04-26 12:17:01 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:01 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:01 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:01 --> URI Class Initialized
INFO - 2017-04-26 12:17:01 --> Router Class Initialized
INFO - 2017-04-26 12:17:01 --> Output Class Initialized
INFO - 2017-04-26 12:17:01 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:01 --> Input Class Initialized
INFO - 2017-04-26 12:17:01 --> Language Class Initialized
INFO - 2017-04-26 12:17:01 --> Loader Class Initialized
INFO - 2017-04-26 12:17:01 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:01 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:01 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:01 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:01 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:01 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:01 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:01 --> Session Class Initialized
INFO - 2017-04-26 12:17:01 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:01 --> Session routines successfully run
INFO - 2017-04-26 12:17:01 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:01 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:01 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:01 --> Pagination Class Initialized
INFO - 2017-04-26 12:17:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:17:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:17:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:17:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:17:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:17:01 --> Final output sent to browser
DEBUG - 2017-04-26 12:17:01 --> Total execution time: 0.5561
INFO - 2017-04-26 12:17:04 --> Config Class Initialized
INFO - 2017-04-26 12:17:04 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:04 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:04 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:04 --> URI Class Initialized
INFO - 2017-04-26 12:17:04 --> Router Class Initialized
INFO - 2017-04-26 12:17:04 --> Output Class Initialized
INFO - 2017-04-26 12:17:04 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:04 --> Input Class Initialized
INFO - 2017-04-26 12:17:04 --> Language Class Initialized
INFO - 2017-04-26 12:17:04 --> Loader Class Initialized
INFO - 2017-04-26 12:17:04 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:04 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:04 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:04 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:04 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:04 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:04 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:04 --> Session Class Initialized
INFO - 2017-04-26 12:17:04 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:04 --> Session routines successfully run
INFO - 2017-04-26 12:17:05 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:05 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:05 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:05 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:05 --> Pagination Class Initialized
INFO - 2017-04-26 12:17:05 --> Config Class Initialized
INFO - 2017-04-26 12:17:05 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:05 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:05 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:05 --> URI Class Initialized
INFO - 2017-04-26 12:17:05 --> Router Class Initialized
INFO - 2017-04-26 12:17:05 --> Output Class Initialized
INFO - 2017-04-26 12:17:05 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:05 --> Input Class Initialized
INFO - 2017-04-26 12:17:05 --> Language Class Initialized
INFO - 2017-04-26 12:17:05 --> Loader Class Initialized
INFO - 2017-04-26 12:17:05 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:05 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:05 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:05 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:05 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:05 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:05 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:05 --> Session Class Initialized
INFO - 2017-04-26 12:17:05 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:05 --> Session routines successfully run
INFO - 2017-04-26 12:17:05 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:05 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:05 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:05 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:05 --> Pagination Class Initialized
INFO - 2017-04-26 12:17:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:17:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:17:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:17:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:17:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:17:05 --> Final output sent to browser
DEBUG - 2017-04-26 12:17:05 --> Total execution time: 0.5425
INFO - 2017-04-26 12:17:08 --> Config Class Initialized
INFO - 2017-04-26 12:17:08 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:08 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:09 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:09 --> URI Class Initialized
INFO - 2017-04-26 12:17:09 --> Router Class Initialized
INFO - 2017-04-26 12:17:09 --> Output Class Initialized
INFO - 2017-04-26 12:17:09 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:09 --> Input Class Initialized
INFO - 2017-04-26 12:17:09 --> Language Class Initialized
INFO - 2017-04-26 12:17:09 --> Loader Class Initialized
INFO - 2017-04-26 12:17:09 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:09 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:09 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:09 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:09 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:09 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:09 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:09 --> Session Class Initialized
INFO - 2017-04-26 12:17:09 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:09 --> Session routines successfully run
INFO - 2017-04-26 12:17:09 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:09 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:09 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:09 --> Pagination Class Initialized
INFO - 2017-04-26 12:17:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:17:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:17:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:17:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:17:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:17:09 --> Final output sent to browser
DEBUG - 2017-04-26 12:17:09 --> Total execution time: 0.5341
INFO - 2017-04-26 12:17:12 --> Config Class Initialized
INFO - 2017-04-26 12:17:12 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:12 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:12 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:12 --> URI Class Initialized
INFO - 2017-04-26 12:17:12 --> Router Class Initialized
INFO - 2017-04-26 12:17:12 --> Output Class Initialized
INFO - 2017-04-26 12:17:12 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:12 --> Input Class Initialized
INFO - 2017-04-26 12:17:12 --> Language Class Initialized
INFO - 2017-04-26 12:17:12 --> Loader Class Initialized
INFO - 2017-04-26 12:17:12 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:12 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:12 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:12 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:12 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:12 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:12 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:12 --> Session Class Initialized
INFO - 2017-04-26 12:17:12 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:12 --> Session routines successfully run
INFO - 2017-04-26 12:17:12 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:12 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:12 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:12 --> Pagination Class Initialized
INFO - 2017-04-26 12:17:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:17:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:17:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:17:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:17:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:17:12 --> Final output sent to browser
DEBUG - 2017-04-26 12:17:12 --> Total execution time: 0.5411
INFO - 2017-04-26 12:17:15 --> Config Class Initialized
INFO - 2017-04-26 12:17:15 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:15 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:15 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:15 --> URI Class Initialized
INFO - 2017-04-26 12:17:15 --> Router Class Initialized
INFO - 2017-04-26 12:17:15 --> Output Class Initialized
INFO - 2017-04-26 12:17:15 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:15 --> Input Class Initialized
INFO - 2017-04-26 12:17:15 --> Language Class Initialized
INFO - 2017-04-26 12:17:15 --> Loader Class Initialized
INFO - 2017-04-26 12:17:15 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:15 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:15 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:15 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:15 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:15 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:15 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:15 --> Session Class Initialized
INFO - 2017-04-26 12:17:15 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:15 --> Session routines successfully run
INFO - 2017-04-26 12:17:15 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:15 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:15 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:15 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:15 --> Pagination Class Initialized
INFO - 2017-04-26 12:17:15 --> Config Class Initialized
INFO - 2017-04-26 12:17:15 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:15 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:15 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:15 --> URI Class Initialized
INFO - 2017-04-26 12:17:15 --> Router Class Initialized
INFO - 2017-04-26 12:17:16 --> Output Class Initialized
INFO - 2017-04-26 12:17:16 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:16 --> Input Class Initialized
INFO - 2017-04-26 12:17:16 --> Language Class Initialized
INFO - 2017-04-26 12:17:16 --> Loader Class Initialized
INFO - 2017-04-26 12:17:16 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:16 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:16 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:16 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:16 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:16 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:16 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:16 --> Session Class Initialized
INFO - 2017-04-26 12:17:16 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:16 --> Session routines successfully run
INFO - 2017-04-26 12:17:16 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:16 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:16 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:16 --> Pagination Class Initialized
INFO - 2017-04-26 12:17:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:17:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:17:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 12:17:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:17:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:17:22 --> Final output sent to browser
DEBUG - 2017-04-26 12:17:22 --> Total execution time: 6.5419
INFO - 2017-04-26 12:17:25 --> Config Class Initialized
INFO - 2017-04-26 12:17:25 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:25 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:25 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:25 --> URI Class Initialized
INFO - 2017-04-26 12:17:25 --> Router Class Initialized
INFO - 2017-04-26 12:17:25 --> Output Class Initialized
INFO - 2017-04-26 12:17:25 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:25 --> Input Class Initialized
INFO - 2017-04-26 12:17:25 --> Language Class Initialized
INFO - 2017-04-26 12:17:25 --> Loader Class Initialized
INFO - 2017-04-26 12:17:25 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:25 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:25 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:25 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:25 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:25 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:26 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:26 --> Session Class Initialized
INFO - 2017-04-26 12:17:26 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:26 --> Session routines successfully run
INFO - 2017-04-26 12:17:26 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:26 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:26 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:26 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:26 --> Pagination Class Initialized
INFO - 2017-04-26 12:17:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:17:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:17:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 12:17:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:17:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:17:29 --> Final output sent to browser
DEBUG - 2017-04-26 12:17:29 --> Total execution time: 3.5667
INFO - 2017-04-26 12:17:33 --> Config Class Initialized
INFO - 2017-04-26 12:17:33 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:33 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:33 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:33 --> URI Class Initialized
INFO - 2017-04-26 12:17:33 --> Router Class Initialized
INFO - 2017-04-26 12:17:33 --> Output Class Initialized
INFO - 2017-04-26 12:17:33 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:33 --> Input Class Initialized
INFO - 2017-04-26 12:17:33 --> Language Class Initialized
INFO - 2017-04-26 12:17:33 --> Loader Class Initialized
INFO - 2017-04-26 12:17:33 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:33 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:33 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:33 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:33 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:33 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:33 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:33 --> Session Class Initialized
INFO - 2017-04-26 12:17:33 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:33 --> Session routines successfully run
INFO - 2017-04-26 12:17:33 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:33 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:33 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:33 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:33 --> Pagination Class Initialized
INFO - 2017-04-26 12:17:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:17:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:17:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 12:17:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:17:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:17:36 --> Final output sent to browser
DEBUG - 2017-04-26 12:17:36 --> Total execution time: 3.3418
INFO - 2017-04-26 12:17:43 --> Config Class Initialized
INFO - 2017-04-26 12:17:43 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:43 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:43 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:43 --> URI Class Initialized
INFO - 2017-04-26 12:17:43 --> Router Class Initialized
INFO - 2017-04-26 12:17:43 --> Output Class Initialized
INFO - 2017-04-26 12:17:44 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:44 --> Input Class Initialized
INFO - 2017-04-26 12:17:44 --> Language Class Initialized
INFO - 2017-04-26 12:17:44 --> Loader Class Initialized
INFO - 2017-04-26 12:17:44 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:44 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:44 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:44 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:44 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:44 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:44 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:44 --> Session Class Initialized
INFO - 2017-04-26 12:17:44 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:44 --> Session routines successfully run
INFO - 2017-04-26 12:17:44 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:44 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:44 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:44 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:44 --> Pagination Class Initialized
INFO - 2017-04-26 12:17:44 --> Config Class Initialized
INFO - 2017-04-26 12:17:44 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:44 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:44 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:44 --> URI Class Initialized
INFO - 2017-04-26 12:17:44 --> Router Class Initialized
INFO - 2017-04-26 12:17:44 --> Output Class Initialized
INFO - 2017-04-26 12:17:44 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:44 --> Input Class Initialized
INFO - 2017-04-26 12:17:44 --> Language Class Initialized
INFO - 2017-04-26 12:17:44 --> Loader Class Initialized
INFO - 2017-04-26 12:17:44 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:44 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:44 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:44 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:44 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:45 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:45 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:45 --> Session Class Initialized
INFO - 2017-04-26 12:17:45 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:45 --> Session routines successfully run
INFO - 2017-04-26 12:17:45 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:45 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:45 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:45 --> Pagination Class Initialized
INFO - 2017-04-26 12:17:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:17:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:17:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:17:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:17:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:17:45 --> Final output sent to browser
DEBUG - 2017-04-26 12:17:45 --> Total execution time: 0.5751
INFO - 2017-04-26 12:17:54 --> Config Class Initialized
INFO - 2017-04-26 12:17:54 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:17:54 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:17:54 --> Utf8 Class Initialized
INFO - 2017-04-26 12:17:54 --> URI Class Initialized
INFO - 2017-04-26 12:17:54 --> Router Class Initialized
INFO - 2017-04-26 12:17:54 --> Output Class Initialized
INFO - 2017-04-26 12:17:54 --> Security Class Initialized
DEBUG - 2017-04-26 12:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:17:54 --> Input Class Initialized
INFO - 2017-04-26 12:17:54 --> Language Class Initialized
INFO - 2017-04-26 12:17:54 --> Loader Class Initialized
INFO - 2017-04-26 12:17:54 --> Helper loaded: url_helper
INFO - 2017-04-26 12:17:54 --> Helper loaded: form_helper
INFO - 2017-04-26 12:17:54 --> Helper loaded: html_helper
INFO - 2017-04-26 12:17:54 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:17:54 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:17:54 --> Database Driver Class Initialized
INFO - 2017-04-26 12:17:54 --> Parser Class Initialized
DEBUG - 2017-04-26 12:17:54 --> Session Class Initialized
INFO - 2017-04-26 12:17:54 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:17:54 --> Session routines successfully run
INFO - 2017-04-26 12:17:54 --> Form Validation Class Initialized
INFO - 2017-04-26 12:17:54 --> Controller Class Initialized
DEBUG - 2017-04-26 12:17:54 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:17:55 --> Model Class Initialized
DEBUG - 2017-04-26 12:17:55 --> Pagination Class Initialized
INFO - 2017-04-26 12:18:24 --> Config Class Initialized
INFO - 2017-04-26 12:18:24 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:18:24 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:18:24 --> Utf8 Class Initialized
INFO - 2017-04-26 12:18:24 --> URI Class Initialized
INFO - 2017-04-26 12:18:24 --> Router Class Initialized
INFO - 2017-04-26 12:18:24 --> Output Class Initialized
INFO - 2017-04-26 12:18:24 --> Security Class Initialized
DEBUG - 2017-04-26 12:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:18:24 --> Input Class Initialized
INFO - 2017-04-26 12:18:24 --> Language Class Initialized
INFO - 2017-04-26 12:18:24 --> Loader Class Initialized
INFO - 2017-04-26 12:18:24 --> Helper loaded: url_helper
INFO - 2017-04-26 12:18:24 --> Helper loaded: form_helper
INFO - 2017-04-26 12:18:24 --> Helper loaded: html_helper
INFO - 2017-04-26 12:18:24 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:18:24 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:18:24 --> Database Driver Class Initialized
INFO - 2017-04-26 12:18:24 --> Parser Class Initialized
DEBUG - 2017-04-26 12:18:24 --> Session Class Initialized
INFO - 2017-04-26 12:18:24 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:18:24 --> Session routines successfully run
INFO - 2017-04-26 12:18:24 --> Form Validation Class Initialized
INFO - 2017-04-26 12:18:24 --> Controller Class Initialized
DEBUG - 2017-04-26 12:18:24 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:18:24 --> Model Class Initialized
DEBUG - 2017-04-26 12:18:24 --> Pagination Class Initialized
INFO - 2017-04-26 12:18:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:18:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:18:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:18:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:18:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:18:24 --> Final output sent to browser
DEBUG - 2017-04-26 12:18:24 --> Total execution time: 0.5982
INFO - 2017-04-26 12:18:52 --> Config Class Initialized
INFO - 2017-04-26 12:18:52 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:18:52 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:18:52 --> Utf8 Class Initialized
INFO - 2017-04-26 12:18:52 --> URI Class Initialized
INFO - 2017-04-26 12:18:52 --> Router Class Initialized
INFO - 2017-04-26 12:18:52 --> Output Class Initialized
INFO - 2017-04-26 12:18:52 --> Security Class Initialized
DEBUG - 2017-04-26 12:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:18:52 --> Input Class Initialized
INFO - 2017-04-26 12:18:52 --> Language Class Initialized
INFO - 2017-04-26 12:18:52 --> Loader Class Initialized
INFO - 2017-04-26 12:18:52 --> Helper loaded: url_helper
INFO - 2017-04-26 12:18:52 --> Helper loaded: form_helper
INFO - 2017-04-26 12:18:52 --> Helper loaded: html_helper
INFO - 2017-04-26 12:18:52 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:18:52 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:18:52 --> Database Driver Class Initialized
INFO - 2017-04-26 12:18:52 --> Parser Class Initialized
DEBUG - 2017-04-26 12:18:52 --> Session Class Initialized
INFO - 2017-04-26 12:18:52 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:18:52 --> Session routines successfully run
INFO - 2017-04-26 12:18:52 --> Form Validation Class Initialized
INFO - 2017-04-26 12:18:52 --> Controller Class Initialized
DEBUG - 2017-04-26 12:18:52 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:18:52 --> Model Class Initialized
DEBUG - 2017-04-26 12:18:52 --> Pagination Class Initialized
INFO - 2017-04-26 12:18:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:18:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:18:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:18:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:18:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:18:52 --> Final output sent to browser
DEBUG - 2017-04-26 12:18:52 --> Total execution time: 0.5473
INFO - 2017-04-26 12:18:55 --> Config Class Initialized
INFO - 2017-04-26 12:18:55 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:18:55 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:18:55 --> Utf8 Class Initialized
INFO - 2017-04-26 12:18:55 --> URI Class Initialized
INFO - 2017-04-26 12:18:55 --> Router Class Initialized
INFO - 2017-04-26 12:18:55 --> Output Class Initialized
INFO - 2017-04-26 12:18:55 --> Security Class Initialized
DEBUG - 2017-04-26 12:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:18:55 --> Input Class Initialized
INFO - 2017-04-26 12:18:55 --> Language Class Initialized
INFO - 2017-04-26 12:18:55 --> Loader Class Initialized
INFO - 2017-04-26 12:18:55 --> Helper loaded: url_helper
INFO - 2017-04-26 12:18:55 --> Helper loaded: form_helper
INFO - 2017-04-26 12:18:55 --> Helper loaded: html_helper
INFO - 2017-04-26 12:18:55 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:18:55 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:18:55 --> Database Driver Class Initialized
INFO - 2017-04-26 12:18:55 --> Parser Class Initialized
DEBUG - 2017-04-26 12:18:55 --> Session Class Initialized
INFO - 2017-04-26 12:18:55 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:18:55 --> Session routines successfully run
INFO - 2017-04-26 12:18:55 --> Form Validation Class Initialized
INFO - 2017-04-26 12:18:55 --> Controller Class Initialized
DEBUG - 2017-04-26 12:18:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:18:55 --> Model Class Initialized
DEBUG - 2017-04-26 12:18:55 --> Pagination Class Initialized
INFO - 2017-04-26 12:18:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:18:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:18:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:18:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:18:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:18:55 --> Final output sent to browser
DEBUG - 2017-04-26 12:18:55 --> Total execution time: 0.5580
INFO - 2017-04-26 12:19:53 --> Config Class Initialized
INFO - 2017-04-26 12:19:53 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:19:53 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:19:53 --> Utf8 Class Initialized
INFO - 2017-04-26 12:19:53 --> URI Class Initialized
INFO - 2017-04-26 12:19:53 --> Router Class Initialized
INFO - 2017-04-26 12:19:53 --> Output Class Initialized
INFO - 2017-04-26 12:19:53 --> Security Class Initialized
DEBUG - 2017-04-26 12:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:19:53 --> Input Class Initialized
INFO - 2017-04-26 12:19:53 --> Language Class Initialized
INFO - 2017-04-26 12:19:53 --> Loader Class Initialized
INFO - 2017-04-26 12:19:53 --> Helper loaded: url_helper
INFO - 2017-04-26 12:19:53 --> Helper loaded: form_helper
INFO - 2017-04-26 12:19:53 --> Helper loaded: html_helper
INFO - 2017-04-26 12:19:53 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:19:53 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:19:53 --> Database Driver Class Initialized
INFO - 2017-04-26 12:19:53 --> Parser Class Initialized
DEBUG - 2017-04-26 12:19:53 --> Session Class Initialized
INFO - 2017-04-26 12:19:53 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:19:53 --> Session routines successfully run
INFO - 2017-04-26 12:19:53 --> Form Validation Class Initialized
INFO - 2017-04-26 12:19:53 --> Controller Class Initialized
DEBUG - 2017-04-26 12:19:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:19:53 --> Model Class Initialized
DEBUG - 2017-04-26 12:19:53 --> Pagination Class Initialized
INFO - 2017-04-26 12:19:53 --> Config Class Initialized
INFO - 2017-04-26 12:19:53 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:19:53 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:19:53 --> Utf8 Class Initialized
INFO - 2017-04-26 12:19:53 --> URI Class Initialized
INFO - 2017-04-26 12:19:53 --> Router Class Initialized
INFO - 2017-04-26 12:19:53 --> Output Class Initialized
INFO - 2017-04-26 12:19:53 --> Security Class Initialized
DEBUG - 2017-04-26 12:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:19:53 --> Input Class Initialized
INFO - 2017-04-26 12:19:53 --> Language Class Initialized
INFO - 2017-04-26 12:19:53 --> Loader Class Initialized
INFO - 2017-04-26 12:19:53 --> Helper loaded: url_helper
INFO - 2017-04-26 12:19:53 --> Helper loaded: form_helper
INFO - 2017-04-26 12:19:53 --> Helper loaded: html_helper
INFO - 2017-04-26 12:19:53 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:19:53 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:19:53 --> Database Driver Class Initialized
INFO - 2017-04-26 12:19:54 --> Parser Class Initialized
DEBUG - 2017-04-26 12:19:54 --> Session Class Initialized
INFO - 2017-04-26 12:19:54 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:19:54 --> Session routines successfully run
INFO - 2017-04-26 12:19:54 --> Form Validation Class Initialized
INFO - 2017-04-26 12:19:54 --> Controller Class Initialized
DEBUG - 2017-04-26 12:19:54 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:19:54 --> Model Class Initialized
DEBUG - 2017-04-26 12:19:54 --> Pagination Class Initialized
INFO - 2017-04-26 12:19:54 --> Config Class Initialized
INFO - 2017-04-26 12:19:54 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:19:54 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:19:54 --> Utf8 Class Initialized
INFO - 2017-04-26 12:19:54 --> URI Class Initialized
INFO - 2017-04-26 12:19:54 --> Router Class Initialized
INFO - 2017-04-26 12:19:54 --> Output Class Initialized
INFO - 2017-04-26 12:19:54 --> Security Class Initialized
DEBUG - 2017-04-26 12:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:19:54 --> Input Class Initialized
INFO - 2017-04-26 12:19:54 --> Language Class Initialized
INFO - 2017-04-26 12:19:55 --> Loader Class Initialized
INFO - 2017-04-26 12:19:55 --> Helper loaded: url_helper
INFO - 2017-04-26 12:19:55 --> Helper loaded: form_helper
INFO - 2017-04-26 12:19:55 --> Helper loaded: html_helper
INFO - 2017-04-26 12:19:55 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:19:55 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:19:55 --> Database Driver Class Initialized
INFO - 2017-04-26 12:19:55 --> Parser Class Initialized
DEBUG - 2017-04-26 12:19:55 --> Session Class Initialized
INFO - 2017-04-26 12:19:55 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:19:55 --> Session routines successfully run
INFO - 2017-04-26 12:19:55 --> Form Validation Class Initialized
INFO - 2017-04-26 12:19:55 --> Controller Class Initialized
DEBUG - 2017-04-26 12:19:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:19:55 --> Model Class Initialized
DEBUG - 2017-04-26 12:19:55 --> Pagination Class Initialized
INFO - 2017-04-26 12:19:57 --> Config Class Initialized
INFO - 2017-04-26 12:19:57 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:19:57 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:19:57 --> Utf8 Class Initialized
INFO - 2017-04-26 12:19:57 --> URI Class Initialized
INFO - 2017-04-26 12:19:57 --> Router Class Initialized
INFO - 2017-04-26 12:19:57 --> Output Class Initialized
INFO - 2017-04-26 12:19:57 --> Security Class Initialized
DEBUG - 2017-04-26 12:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:19:57 --> Input Class Initialized
INFO - 2017-04-26 12:19:57 --> Language Class Initialized
INFO - 2017-04-26 12:19:57 --> Loader Class Initialized
INFO - 2017-04-26 12:19:57 --> Helper loaded: url_helper
INFO - 2017-04-26 12:19:57 --> Helper loaded: form_helper
INFO - 2017-04-26 12:19:57 --> Helper loaded: html_helper
INFO - 2017-04-26 12:19:57 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:19:57 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:19:57 --> Database Driver Class Initialized
INFO - 2017-04-26 12:19:57 --> Parser Class Initialized
DEBUG - 2017-04-26 12:19:57 --> Session Class Initialized
INFO - 2017-04-26 12:19:57 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:19:57 --> Session routines successfully run
INFO - 2017-04-26 12:19:57 --> Form Validation Class Initialized
INFO - 2017-04-26 12:19:57 --> Controller Class Initialized
DEBUG - 2017-04-26 12:19:57 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:19:57 --> Model Class Initialized
DEBUG - 2017-04-26 12:19:57 --> Pagination Class Initialized
INFO - 2017-04-26 12:19:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:19:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:19:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:19:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:19:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:19:57 --> Final output sent to browser
DEBUG - 2017-04-26 12:19:57 --> Total execution time: 0.5485
INFO - 2017-04-26 12:19:59 --> Config Class Initialized
INFO - 2017-04-26 12:19:59 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:19:59 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:19:59 --> Utf8 Class Initialized
INFO - 2017-04-26 12:19:59 --> URI Class Initialized
INFO - 2017-04-26 12:19:59 --> Router Class Initialized
INFO - 2017-04-26 12:19:59 --> Output Class Initialized
INFO - 2017-04-26 12:19:59 --> Security Class Initialized
DEBUG - 2017-04-26 12:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:19:59 --> Input Class Initialized
INFO - 2017-04-26 12:19:59 --> Language Class Initialized
INFO - 2017-04-26 12:19:59 --> Loader Class Initialized
INFO - 2017-04-26 12:19:59 --> Helper loaded: url_helper
INFO - 2017-04-26 12:19:59 --> Helper loaded: form_helper
INFO - 2017-04-26 12:19:59 --> Helper loaded: html_helper
INFO - 2017-04-26 12:19:59 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:19:59 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:20:00 --> Database Driver Class Initialized
INFO - 2017-04-26 12:20:00 --> Parser Class Initialized
DEBUG - 2017-04-26 12:20:00 --> Session Class Initialized
INFO - 2017-04-26 12:20:00 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:20:00 --> Session routines successfully run
INFO - 2017-04-26 12:20:00 --> Form Validation Class Initialized
INFO - 2017-04-26 12:20:00 --> Controller Class Initialized
DEBUG - 2017-04-26 12:20:00 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:20:00 --> Model Class Initialized
DEBUG - 2017-04-26 12:20:00 --> Pagination Class Initialized
INFO - 2017-04-26 12:20:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:20:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:20:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:20:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:20:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:20:00 --> Final output sent to browser
DEBUG - 2017-04-26 12:20:00 --> Total execution time: 0.5495
INFO - 2017-04-26 12:22:49 --> Config Class Initialized
INFO - 2017-04-26 12:22:49 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:22:49 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:22:49 --> Utf8 Class Initialized
INFO - 2017-04-26 12:22:49 --> URI Class Initialized
INFO - 2017-04-26 12:22:49 --> Router Class Initialized
INFO - 2017-04-26 12:22:49 --> Output Class Initialized
INFO - 2017-04-26 12:22:49 --> Security Class Initialized
DEBUG - 2017-04-26 12:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:22:49 --> Input Class Initialized
INFO - 2017-04-26 12:22:49 --> Language Class Initialized
INFO - 2017-04-26 12:22:49 --> Loader Class Initialized
INFO - 2017-04-26 12:22:49 --> Helper loaded: url_helper
INFO - 2017-04-26 12:22:49 --> Helper loaded: form_helper
INFO - 2017-04-26 12:22:49 --> Helper loaded: html_helper
INFO - 2017-04-26 12:22:49 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:22:49 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:22:49 --> Database Driver Class Initialized
INFO - 2017-04-26 12:22:50 --> Parser Class Initialized
DEBUG - 2017-04-26 12:22:50 --> Session Class Initialized
INFO - 2017-04-26 12:22:50 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:22:50 --> Session routines successfully run
INFO - 2017-04-26 12:22:50 --> Form Validation Class Initialized
INFO - 2017-04-26 12:22:50 --> Controller Class Initialized
DEBUG - 2017-04-26 12:22:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:22:50 --> Model Class Initialized
DEBUG - 2017-04-26 12:22:50 --> Pagination Class Initialized
INFO - 2017-04-26 12:22:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:22:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:22:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:22:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:22:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:22:50 --> Final output sent to browser
DEBUG - 2017-04-26 12:22:50 --> Total execution time: 0.5566
INFO - 2017-04-26 12:22:52 --> Config Class Initialized
INFO - 2017-04-26 12:22:52 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:22:52 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:22:52 --> Utf8 Class Initialized
INFO - 2017-04-26 12:22:52 --> URI Class Initialized
INFO - 2017-04-26 12:22:52 --> Router Class Initialized
INFO - 2017-04-26 12:22:52 --> Output Class Initialized
INFO - 2017-04-26 12:22:52 --> Security Class Initialized
DEBUG - 2017-04-26 12:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:22:52 --> Input Class Initialized
INFO - 2017-04-26 12:22:52 --> Language Class Initialized
INFO - 2017-04-26 12:22:52 --> Loader Class Initialized
INFO - 2017-04-26 12:22:52 --> Helper loaded: url_helper
INFO - 2017-04-26 12:22:52 --> Helper loaded: form_helper
INFO - 2017-04-26 12:22:52 --> Helper loaded: html_helper
INFO - 2017-04-26 12:22:52 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:22:52 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:22:52 --> Database Driver Class Initialized
INFO - 2017-04-26 12:22:52 --> Parser Class Initialized
DEBUG - 2017-04-26 12:22:52 --> Session Class Initialized
INFO - 2017-04-26 12:22:52 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:22:52 --> Session routines successfully run
INFO - 2017-04-26 12:22:52 --> Form Validation Class Initialized
INFO - 2017-04-26 12:22:52 --> Controller Class Initialized
DEBUG - 2017-04-26 12:22:52 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:22:52 --> Model Class Initialized
DEBUG - 2017-04-26 12:22:52 --> Pagination Class Initialized
INFO - 2017-04-26 12:22:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:22:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:22:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:22:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:22:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:22:53 --> Final output sent to browser
DEBUG - 2017-04-26 12:22:53 --> Total execution time: 0.5505
INFO - 2017-04-26 12:23:49 --> Config Class Initialized
INFO - 2017-04-26 12:23:49 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:23:49 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:23:49 --> Utf8 Class Initialized
INFO - 2017-04-26 12:23:49 --> URI Class Initialized
INFO - 2017-04-26 12:23:49 --> Router Class Initialized
INFO - 2017-04-26 12:23:49 --> Output Class Initialized
INFO - 2017-04-26 12:23:49 --> Security Class Initialized
DEBUG - 2017-04-26 12:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:23:49 --> Input Class Initialized
INFO - 2017-04-26 12:23:49 --> Language Class Initialized
INFO - 2017-04-26 12:23:50 --> Loader Class Initialized
INFO - 2017-04-26 12:23:50 --> Helper loaded: url_helper
INFO - 2017-04-26 12:23:50 --> Helper loaded: form_helper
INFO - 2017-04-26 12:23:50 --> Helper loaded: html_helper
INFO - 2017-04-26 12:23:50 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:23:50 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:23:50 --> Database Driver Class Initialized
INFO - 2017-04-26 12:23:50 --> Parser Class Initialized
DEBUG - 2017-04-26 12:23:50 --> Session Class Initialized
INFO - 2017-04-26 12:23:50 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:23:50 --> Session routines successfully run
INFO - 2017-04-26 12:23:50 --> Form Validation Class Initialized
INFO - 2017-04-26 12:23:50 --> Controller Class Initialized
DEBUG - 2017-04-26 12:23:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:23:50 --> Model Class Initialized
DEBUG - 2017-04-26 12:23:50 --> Pagination Class Initialized
INFO - 2017-04-26 12:23:50 --> Config Class Initialized
INFO - 2017-04-26 12:23:50 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:23:50 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:23:50 --> Utf8 Class Initialized
INFO - 2017-04-26 12:23:50 --> URI Class Initialized
INFO - 2017-04-26 12:23:50 --> Router Class Initialized
INFO - 2017-04-26 12:23:50 --> Output Class Initialized
INFO - 2017-04-26 12:23:50 --> Security Class Initialized
DEBUG - 2017-04-26 12:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:23:50 --> Input Class Initialized
INFO - 2017-04-26 12:23:50 --> Language Class Initialized
INFO - 2017-04-26 12:23:50 --> Loader Class Initialized
INFO - 2017-04-26 12:23:50 --> Helper loaded: url_helper
INFO - 2017-04-26 12:23:50 --> Helper loaded: form_helper
INFO - 2017-04-26 12:23:50 --> Helper loaded: html_helper
INFO - 2017-04-26 12:23:50 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:23:50 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:23:50 --> Database Driver Class Initialized
INFO - 2017-04-26 12:23:50 --> Parser Class Initialized
DEBUG - 2017-04-26 12:23:50 --> Session Class Initialized
INFO - 2017-04-26 12:23:50 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:23:50 --> Session routines successfully run
INFO - 2017-04-26 12:23:50 --> Form Validation Class Initialized
INFO - 2017-04-26 12:23:50 --> Controller Class Initialized
DEBUG - 2017-04-26 12:23:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:23:50 --> Model Class Initialized
DEBUG - 2017-04-26 12:23:50 --> Pagination Class Initialized
INFO - 2017-04-26 12:23:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:23:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:23:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-26 12:23:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:23:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:23:53 --> Final output sent to browser
DEBUG - 2017-04-26 12:23:53 --> Total execution time: 3.4164
INFO - 2017-04-26 12:23:59 --> Config Class Initialized
INFO - 2017-04-26 12:23:59 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:23:59 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:23:59 --> Utf8 Class Initialized
INFO - 2017-04-26 12:23:59 --> URI Class Initialized
INFO - 2017-04-26 12:23:59 --> Router Class Initialized
INFO - 2017-04-26 12:23:59 --> Output Class Initialized
INFO - 2017-04-26 12:23:59 --> Security Class Initialized
DEBUG - 2017-04-26 12:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:23:59 --> Input Class Initialized
INFO - 2017-04-26 12:23:59 --> Language Class Initialized
INFO - 2017-04-26 12:23:59 --> Loader Class Initialized
INFO - 2017-04-26 12:23:59 --> Helper loaded: url_helper
INFO - 2017-04-26 12:23:59 --> Helper loaded: form_helper
INFO - 2017-04-26 12:23:59 --> Helper loaded: html_helper
INFO - 2017-04-26 12:23:59 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:23:59 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:23:59 --> Database Driver Class Initialized
INFO - 2017-04-26 12:23:59 --> Parser Class Initialized
DEBUG - 2017-04-26 12:23:59 --> Session Class Initialized
INFO - 2017-04-26 12:23:59 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:23:59 --> Session routines successfully run
INFO - 2017-04-26 12:23:59 --> Form Validation Class Initialized
INFO - 2017-04-26 12:23:59 --> Controller Class Initialized
DEBUG - 2017-04-26 12:23:59 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:23:59 --> Model Class Initialized
DEBUG - 2017-04-26 12:23:59 --> Pagination Class Initialized
INFO - 2017-04-26 12:23:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:23:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:24:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-26 12:24:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:24:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:24:00 --> Final output sent to browser
DEBUG - 2017-04-26 12:24:00 --> Total execution time: 0.6286
INFO - 2017-04-26 12:24:00 --> Config Class Initialized
INFO - 2017-04-26 12:24:00 --> Config Class Initialized
INFO - 2017-04-26 12:24:00 --> Hooks Class Initialized
INFO - 2017-04-26 12:24:00 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:24:00 --> UTF-8 Support Enabled
DEBUG - 2017-04-26 12:24:00 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:24:00 --> Utf8 Class Initialized
INFO - 2017-04-26 12:24:00 --> Utf8 Class Initialized
INFO - 2017-04-26 12:24:00 --> URI Class Initialized
INFO - 2017-04-26 12:24:00 --> URI Class Initialized
INFO - 2017-04-26 12:24:00 --> Router Class Initialized
INFO - 2017-04-26 12:24:00 --> Router Class Initialized
INFO - 2017-04-26 12:24:00 --> Output Class Initialized
INFO - 2017-04-26 12:24:00 --> Output Class Initialized
INFO - 2017-04-26 12:24:00 --> Security Class Initialized
INFO - 2017-04-26 12:24:00 --> Security Class Initialized
DEBUG - 2017-04-26 12:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-26 12:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:24:00 --> Input Class Initialized
INFO - 2017-04-26 12:24:00 --> Input Class Initialized
INFO - 2017-04-26 12:24:00 --> Language Class Initialized
INFO - 2017-04-26 12:24:00 --> Language Class Initialized
ERROR - 2017-04-26 12:24:00 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-26 12:24:00 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 12:24:00 --> Config Class Initialized
INFO - 2017-04-26 12:24:00 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:24:00 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:24:00 --> Utf8 Class Initialized
INFO - 2017-04-26 12:24:00 --> URI Class Initialized
INFO - 2017-04-26 12:24:00 --> Router Class Initialized
INFO - 2017-04-26 12:24:00 --> Output Class Initialized
INFO - 2017-04-26 12:24:00 --> Security Class Initialized
DEBUG - 2017-04-26 12:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:24:00 --> Input Class Initialized
INFO - 2017-04-26 12:24:00 --> Language Class Initialized
ERROR - 2017-04-26 12:24:00 --> 404 Page Not Found: Default/assets
INFO - 2017-04-26 12:24:34 --> Config Class Initialized
INFO - 2017-04-26 12:24:34 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:24:34 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:24:34 --> Utf8 Class Initialized
INFO - 2017-04-26 12:24:34 --> URI Class Initialized
INFO - 2017-04-26 12:24:34 --> Router Class Initialized
INFO - 2017-04-26 12:24:34 --> Output Class Initialized
INFO - 2017-04-26 12:24:34 --> Security Class Initialized
DEBUG - 2017-04-26 12:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:24:34 --> Input Class Initialized
INFO - 2017-04-26 12:24:34 --> Language Class Initialized
INFO - 2017-04-26 12:24:34 --> Loader Class Initialized
INFO - 2017-04-26 12:24:34 --> Helper loaded: url_helper
INFO - 2017-04-26 12:24:35 --> Helper loaded: form_helper
INFO - 2017-04-26 12:24:35 --> Helper loaded: html_helper
INFO - 2017-04-26 12:24:35 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:24:35 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:24:35 --> Database Driver Class Initialized
INFO - 2017-04-26 12:24:35 --> Parser Class Initialized
DEBUG - 2017-04-26 12:24:35 --> Session Class Initialized
INFO - 2017-04-26 12:24:35 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:24:35 --> Session routines successfully run
INFO - 2017-04-26 12:24:35 --> Form Validation Class Initialized
INFO - 2017-04-26 12:24:35 --> Controller Class Initialized
DEBUG - 2017-04-26 12:24:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:24:35 --> Model Class Initialized
DEBUG - 2017-04-26 12:24:35 --> Pagination Class Initialized
INFO - 2017-04-26 12:24:35 --> Config Class Initialized
INFO - 2017-04-26 12:24:35 --> Hooks Class Initialized
DEBUG - 2017-04-26 12:24:35 --> UTF-8 Support Enabled
INFO - 2017-04-26 12:24:35 --> Utf8 Class Initialized
INFO - 2017-04-26 12:24:35 --> URI Class Initialized
INFO - 2017-04-26 12:24:35 --> Router Class Initialized
INFO - 2017-04-26 12:24:35 --> Output Class Initialized
INFO - 2017-04-26 12:24:35 --> Security Class Initialized
DEBUG - 2017-04-26 12:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 12:24:35 --> Input Class Initialized
INFO - 2017-04-26 12:24:35 --> Language Class Initialized
INFO - 2017-04-26 12:24:35 --> Loader Class Initialized
INFO - 2017-04-26 12:24:35 --> Helper loaded: url_helper
INFO - 2017-04-26 12:24:35 --> Helper loaded: form_helper
INFO - 2017-04-26 12:24:35 --> Helper loaded: html_helper
INFO - 2017-04-26 12:24:35 --> Helper loaded: custom_helper
INFO - 2017-04-26 12:24:35 --> Helper loaded: cache_helper
INFO - 2017-04-26 12:24:35 --> Database Driver Class Initialized
INFO - 2017-04-26 12:24:35 --> Parser Class Initialized
DEBUG - 2017-04-26 12:24:35 --> Session Class Initialized
INFO - 2017-04-26 12:24:35 --> Helper loaded: string_helper
DEBUG - 2017-04-26 12:24:35 --> Session routines successfully run
INFO - 2017-04-26 12:24:35 --> Form Validation Class Initialized
INFO - 2017-04-26 12:24:35 --> Controller Class Initialized
DEBUG - 2017-04-26 12:24:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-26 12:24:35 --> Model Class Initialized
DEBUG - 2017-04-26 12:24:35 --> Pagination Class Initialized
INFO - 2017-04-26 12:24:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-26 12:24:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-26 12:24:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-04-26 12:24:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-26 12:24:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 12:24:35 --> Final output sent to browser
DEBUG - 2017-04-26 12:24:35 --> Total execution time: 0.5559
INFO - 2017-04-26 13:43:14 --> Config Class Initialized
INFO - 2017-04-26 13:43:14 --> Hooks Class Initialized
DEBUG - 2017-04-26 13:43:14 --> UTF-8 Support Enabled
INFO - 2017-04-26 13:43:14 --> Utf8 Class Initialized
INFO - 2017-04-26 13:43:14 --> URI Class Initialized
INFO - 2017-04-26 13:43:14 --> Router Class Initialized
INFO - 2017-04-26 13:43:14 --> Output Class Initialized
INFO - 2017-04-26 13:43:14 --> Security Class Initialized
DEBUG - 2017-04-26 13:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 13:43:14 --> Input Class Initialized
INFO - 2017-04-26 13:43:14 --> Language Class Initialized
INFO - 2017-04-26 13:43:14 --> Loader Class Initialized
INFO - 2017-04-26 13:43:14 --> Helper loaded: url_helper
INFO - 2017-04-26 13:43:14 --> Helper loaded: form_helper
INFO - 2017-04-26 13:43:14 --> Helper loaded: html_helper
INFO - 2017-04-26 13:43:14 --> Helper loaded: custom_helper
INFO - 2017-04-26 13:43:14 --> Helper loaded: cache_helper
INFO - 2017-04-26 13:43:14 --> Database Driver Class Initialized
INFO - 2017-04-26 13:43:14 --> Parser Class Initialized
DEBUG - 2017-04-26 13:43:14 --> Session Class Initialized
INFO - 2017-04-26 13:43:14 --> Helper loaded: string_helper
DEBUG - 2017-04-26 13:43:14 --> Session routines successfully run
INFO - 2017-04-26 13:43:14 --> Form Validation Class Initialized
INFO - 2017-04-26 13:43:14 --> Controller Class Initialized
INFO - 2017-04-26 13:43:14 --> Model Class Initialized
INFO - 2017-04-26 13:43:14 --> Config Class Initialized
INFO - 2017-04-26 13:43:14 --> Hooks Class Initialized
DEBUG - 2017-04-26 13:43:14 --> UTF-8 Support Enabled
INFO - 2017-04-26 13:43:14 --> Utf8 Class Initialized
INFO - 2017-04-26 13:43:15 --> URI Class Initialized
INFO - 2017-04-26 13:43:15 --> Router Class Initialized
INFO - 2017-04-26 13:43:15 --> Output Class Initialized
INFO - 2017-04-26 13:43:15 --> Security Class Initialized
DEBUG - 2017-04-26 13:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 13:43:15 --> Input Class Initialized
INFO - 2017-04-26 13:43:15 --> Language Class Initialized
INFO - 2017-04-26 13:43:15 --> Loader Class Initialized
INFO - 2017-04-26 13:43:15 --> Helper loaded: url_helper
INFO - 2017-04-26 13:43:15 --> Helper loaded: form_helper
INFO - 2017-04-26 13:43:15 --> Helper loaded: html_helper
INFO - 2017-04-26 13:43:15 --> Helper loaded: custom_helper
INFO - 2017-04-26 13:43:15 --> Helper loaded: cache_helper
INFO - 2017-04-26 13:43:15 --> Database Driver Class Initialized
INFO - 2017-04-26 13:43:15 --> Parser Class Initialized
DEBUG - 2017-04-26 13:43:15 --> Session Class Initialized
INFO - 2017-04-26 13:43:15 --> Helper loaded: string_helper
ERROR - 2017-04-26 13:43:15 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-26 13:43:15 --> Session routines successfully run
INFO - 2017-04-26 13:43:15 --> Form Validation Class Initialized
INFO - 2017-04-26 13:43:15 --> Controller Class Initialized
INFO - 2017-04-26 13:43:15 --> Model Class Initialized
INFO - 2017-04-26 13:43:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-26 13:43:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 13:43:15 --> Final output sent to browser
DEBUG - 2017-04-26 13:43:15 --> Total execution time: 0.5864
INFO - 2017-04-26 13:43:24 --> Config Class Initialized
INFO - 2017-04-26 13:43:24 --> Hooks Class Initialized
DEBUG - 2017-04-26 13:43:24 --> UTF-8 Support Enabled
INFO - 2017-04-26 13:43:24 --> Utf8 Class Initialized
INFO - 2017-04-26 13:43:24 --> URI Class Initialized
INFO - 2017-04-26 13:43:24 --> Router Class Initialized
INFO - 2017-04-26 13:43:24 --> Output Class Initialized
INFO - 2017-04-26 13:43:24 --> Security Class Initialized
DEBUG - 2017-04-26 13:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 13:43:24 --> Input Class Initialized
INFO - 2017-04-26 13:43:24 --> Language Class Initialized
INFO - 2017-04-26 13:43:24 --> Loader Class Initialized
INFO - 2017-04-26 13:43:24 --> Helper loaded: url_helper
INFO - 2017-04-26 13:43:24 --> Helper loaded: form_helper
INFO - 2017-04-26 13:43:24 --> Helper loaded: html_helper
INFO - 2017-04-26 13:43:24 --> Helper loaded: custom_helper
INFO - 2017-04-26 13:43:24 --> Helper loaded: cache_helper
INFO - 2017-04-26 13:43:24 --> Database Driver Class Initialized
INFO - 2017-04-26 13:43:25 --> Parser Class Initialized
DEBUG - 2017-04-26 13:43:25 --> Session Class Initialized
INFO - 2017-04-26 13:43:25 --> Helper loaded: string_helper
DEBUG - 2017-04-26 13:43:25 --> Session routines successfully run
INFO - 2017-04-26 13:43:25 --> Form Validation Class Initialized
INFO - 2017-04-26 13:43:25 --> Controller Class Initialized
INFO - 2017-04-26 13:43:25 --> Model Class Initialized
INFO - 2017-04-26 13:43:25 --> Config Class Initialized
INFO - 2017-04-26 13:43:25 --> Hooks Class Initialized
DEBUG - 2017-04-26 13:43:25 --> UTF-8 Support Enabled
INFO - 2017-04-26 13:43:25 --> Utf8 Class Initialized
INFO - 2017-04-26 13:43:25 --> URI Class Initialized
INFO - 2017-04-26 13:43:25 --> Router Class Initialized
INFO - 2017-04-26 13:43:25 --> Output Class Initialized
INFO - 2017-04-26 13:43:25 --> Security Class Initialized
DEBUG - 2017-04-26 13:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-26 13:43:25 --> Input Class Initialized
INFO - 2017-04-26 13:43:25 --> Language Class Initialized
INFO - 2017-04-26 13:43:25 --> Loader Class Initialized
INFO - 2017-04-26 13:43:25 --> Helper loaded: url_helper
INFO - 2017-04-26 13:43:25 --> Helper loaded: form_helper
INFO - 2017-04-26 13:43:25 --> Helper loaded: html_helper
INFO - 2017-04-26 13:43:25 --> Helper loaded: custom_helper
INFO - 2017-04-26 13:43:25 --> Helper loaded: cache_helper
INFO - 2017-04-26 13:43:25 --> Database Driver Class Initialized
INFO - 2017-04-26 13:43:25 --> Parser Class Initialized
DEBUG - 2017-04-26 13:43:25 --> Session Class Initialized
INFO - 2017-04-26 13:43:25 --> Helper loaded: string_helper
ERROR - 2017-04-26 13:43:25 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-26 13:43:25 --> Session routines successfully run
INFO - 2017-04-26 13:43:25 --> Form Validation Class Initialized
INFO - 2017-04-26 13:43:25 --> Controller Class Initialized
INFO - 2017-04-26 13:43:25 --> Model Class Initialized
INFO - 2017-04-26 13:43:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-26 13:43:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-26 13:43:25 --> Final output sent to browser
DEBUG - 2017-04-26 13:43:25 --> Total execution time: 0.4885
