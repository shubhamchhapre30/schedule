<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-05-09 12:05:04 --> Config Class Initialized
INFO - 2017-05-09 12:05:04 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:05 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:05 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:05 --> URI Class Initialized
DEBUG - 2017-05-09 12:05:05 --> No URI present. Default controller set.
INFO - 2017-05-09 12:05:05 --> Router Class Initialized
INFO - 2017-05-09 12:05:05 --> Output Class Initialized
INFO - 2017-05-09 12:05:05 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:05 --> Input Class Initialized
INFO - 2017-05-09 12:05:05 --> Language Class Initialized
INFO - 2017-05-09 12:05:05 --> Loader Class Initialized
INFO - 2017-05-09 12:05:05 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:05 --> Helper loaded: form_helper
INFO - 2017-05-09 12:05:05 --> Helper loaded: html_helper
INFO - 2017-05-09 12:05:05 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:05:05 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:05:05 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:05 --> Parser Class Initialized
DEBUG - 2017-05-09 12:05:05 --> Session Class Initialized
INFO - 2017-05-09 12:05:05 --> Helper loaded: string_helper
ERROR - 2017-05-09 12:05:05 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-09 12:05:05 --> Session routines successfully run
INFO - 2017-05-09 12:05:05 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:05 --> Controller Class Initialized
INFO - 2017-05-09 12:05:05 --> Model Class Initialized
INFO - 2017-05-09 12:05:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-09 12:05:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-09 12:05:05 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:05 --> Total execution time: 0.5784
INFO - 2017-05-09 12:05:23 --> Config Class Initialized
INFO - 2017-05-09 12:05:23 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:23 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:23 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:23 --> URI Class Initialized
INFO - 2017-05-09 12:05:23 --> Router Class Initialized
INFO - 2017-05-09 12:05:23 --> Output Class Initialized
INFO - 2017-05-09 12:05:23 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:23 --> Input Class Initialized
INFO - 2017-05-09 12:05:23 --> Language Class Initialized
INFO - 2017-05-09 12:05:23 --> Loader Class Initialized
INFO - 2017-05-09 12:05:23 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:23 --> Helper loaded: form_helper
INFO - 2017-05-09 12:05:23 --> Helper loaded: html_helper
INFO - 2017-05-09 12:05:23 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:05:23 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:05:23 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:23 --> Parser Class Initialized
DEBUG - 2017-05-09 12:05:23 --> Session Class Initialized
INFO - 2017-05-09 12:05:23 --> Helper loaded: string_helper
ERROR - 2017-05-09 12:05:23 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-09 12:05:23 --> Session routines successfully run
INFO - 2017-05-09 12:05:23 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:23 --> Controller Class Initialized
INFO - 2017-05-09 12:05:23 --> Model Class Initialized
INFO - 2017-05-09 12:05:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-09 12:05:26 --> Config Class Initialized
INFO - 2017-05-09 12:05:26 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:26 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:26 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:26 --> URI Class Initialized
INFO - 2017-05-09 12:05:26 --> Router Class Initialized
INFO - 2017-05-09 12:05:26 --> Output Class Initialized
INFO - 2017-05-09 12:05:26 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:26 --> Input Class Initialized
INFO - 2017-05-09 12:05:26 --> Language Class Initialized
INFO - 2017-05-09 12:05:26 --> Loader Class Initialized
INFO - 2017-05-09 12:05:26 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: form_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: html_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:05:26 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:26 --> Parser Class Initialized
DEBUG - 2017-05-09 12:05:26 --> Session Class Initialized
INFO - 2017-05-09 12:05:26 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:05:26 --> Session routines successfully run
INFO - 2017-05-09 12:05:26 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:26 --> Controller Class Initialized
INFO - 2017-05-09 12:05:26 --> Model Class Initialized
INFO - 2017-05-09 12:05:26 --> Config Class Initialized
INFO - 2017-05-09 12:05:26 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:26 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:26 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:26 --> URI Class Initialized
INFO - 2017-05-09 12:05:26 --> Router Class Initialized
INFO - 2017-05-09 12:05:26 --> Output Class Initialized
INFO - 2017-05-09 12:05:26 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:26 --> Input Class Initialized
INFO - 2017-05-09 12:05:26 --> Language Class Initialized
INFO - 2017-05-09 12:05:26 --> Loader Class Initialized
INFO - 2017-05-09 12:05:26 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: form_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: html_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:05:26 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:26 --> Parser Class Initialized
DEBUG - 2017-05-09 12:05:26 --> Session Class Initialized
INFO - 2017-05-09 12:05:26 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:05:26 --> Session routines successfully run
INFO - 2017-05-09 12:05:26 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:26 --> Controller Class Initialized
INFO - 2017-05-09 12:05:26 --> Model Class Initialized
INFO - 2017-05-09 12:05:26 --> Config Class Initialized
INFO - 2017-05-09 12:05:26 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:26 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:26 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:26 --> URI Class Initialized
INFO - 2017-05-09 12:05:26 --> Router Class Initialized
INFO - 2017-05-09 12:05:26 --> Output Class Initialized
INFO - 2017-05-09 12:05:26 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:26 --> Input Class Initialized
INFO - 2017-05-09 12:05:26 --> Language Class Initialized
INFO - 2017-05-09 12:05:26 --> Loader Class Initialized
INFO - 2017-05-09 12:05:26 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: form_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: html_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:05:26 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:05:26 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:26 --> Parser Class Initialized
DEBUG - 2017-05-09 12:05:26 --> Session Class Initialized
INFO - 2017-05-09 12:05:26 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:05:26 --> Session routines successfully run
INFO - 2017-05-09 12:05:26 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:26 --> Controller Class Initialized
DEBUG - 2017-05-09 12:05:26 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-09 12:05:26 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:27 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-09 12:05:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-09 12:05:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-05-09 12:05:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-09 12:05:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-09 12:05:27 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:27 --> Total execution time: 0.3763
INFO - 2017-05-09 12:05:30 --> Config Class Initialized
INFO - 2017-05-09 12:05:30 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:30 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:30 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:30 --> URI Class Initialized
INFO - 2017-05-09 12:05:30 --> Router Class Initialized
INFO - 2017-05-09 12:05:30 --> Output Class Initialized
INFO - 2017-05-09 12:05:30 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:30 --> Input Class Initialized
INFO - 2017-05-09 12:05:30 --> Language Class Initialized
INFO - 2017-05-09 12:05:30 --> Loader Class Initialized
INFO - 2017-05-09 12:05:30 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:30 --> Helper loaded: form_helper
INFO - 2017-05-09 12:05:30 --> Helper loaded: html_helper
INFO - 2017-05-09 12:05:30 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:05:30 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:05:30 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:30 --> Parser Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session Class Initialized
INFO - 2017-05-09 12:05:30 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:05:30 --> Session routines successfully run
INFO - 2017-05-09 12:05:30 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:30 --> Controller Class Initialized
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:30 --> Config Class Initialized
INFO - 2017-05-09 12:05:30 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:30 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:30 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:30 --> URI Class Initialized
INFO - 2017-05-09 12:05:30 --> Router Class Initialized
INFO - 2017-05-09 12:05:30 --> Output Class Initialized
INFO - 2017-05-09 12:05:30 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:30 --> Input Class Initialized
INFO - 2017-05-09 12:05:30 --> Language Class Initialized
INFO - 2017-05-09 12:05:30 --> Loader Class Initialized
INFO - 2017-05-09 12:05:30 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:30 --> Helper loaded: form_helper
INFO - 2017-05-09 12:05:30 --> Helper loaded: html_helper
INFO - 2017-05-09 12:05:30 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:05:30 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:05:30 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:30 --> Parser Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session Class Initialized
INFO - 2017-05-09 12:05:30 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:05:30 --> Session routines successfully run
INFO - 2017-05-09 12:05:30 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:30 --> Controller Class Initialized
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-09 12:05:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-09 12:05:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/list_color.php
INFO - 2017-05-09 12:05:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-09 12:05:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-09 12:05:30 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:30 --> Total execution time: 0.3440
INFO - 2017-05-09 12:05:34 --> Config Class Initialized
INFO - 2017-05-09 12:05:34 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:34 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:34 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:34 --> URI Class Initialized
INFO - 2017-05-09 12:05:34 --> Router Class Initialized
INFO - 2017-05-09 12:05:34 --> Output Class Initialized
INFO - 2017-05-09 12:05:34 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:34 --> Input Class Initialized
INFO - 2017-05-09 12:05:34 --> Language Class Initialized
INFO - 2017-05-09 12:05:34 --> Loader Class Initialized
INFO - 2017-05-09 12:05:34 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:34 --> Helper loaded: form_helper
INFO - 2017-05-09 12:05:34 --> Helper loaded: html_helper
INFO - 2017-05-09 12:05:34 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:05:34 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:05:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:34 --> Parser Class Initialized
DEBUG - 2017-05-09 12:05:34 --> Session Class Initialized
INFO - 2017-05-09 12:05:34 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:05:34 --> Session routines successfully run
INFO - 2017-05-09 12:05:34 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:34 --> Controller Class Initialized
INFO - 2017-05-09 12:05:34 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:34 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-09 12:05:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-09 12:05:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/add_color.php
INFO - 2017-05-09 12:05:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-09 12:05:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-09 12:05:34 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:34 --> Total execution time: 0.1856
INFO - 2017-05-09 12:05:34 --> Config Class Initialized
INFO - 2017-05-09 12:05:34 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:34 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:34 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:34 --> URI Class Initialized
INFO - 2017-05-09 12:05:34 --> Router Class Initialized
INFO - 2017-05-09 12:05:34 --> Output Class Initialized
INFO - 2017-05-09 12:05:34 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:34 --> Input Class Initialized
INFO - 2017-05-09 12:05:34 --> Language Class Initialized
ERROR - 2017-05-09 12:05:34 --> 404 Page Not Found: Default/assets
INFO - 2017-05-09 12:05:34 --> Config Class Initialized
INFO - 2017-05-09 12:05:34 --> Hooks Class Initialized
INFO - 2017-05-09 12:05:34 --> Config Class Initialized
DEBUG - 2017-05-09 12:05:34 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:34 --> Hooks Class Initialized
INFO - 2017-05-09 12:05:34 --> Utf8 Class Initialized
DEBUG - 2017-05-09 12:05:34 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:34 --> URI Class Initialized
INFO - 2017-05-09 12:05:34 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:34 --> URI Class Initialized
INFO - 2017-05-09 12:05:34 --> Router Class Initialized
INFO - 2017-05-09 12:05:34 --> Router Class Initialized
INFO - 2017-05-09 12:05:34 --> Output Class Initialized
INFO - 2017-05-09 12:05:34 --> Output Class Initialized
INFO - 2017-05-09 12:05:34 --> Security Class Initialized
INFO - 2017-05-09 12:05:34 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 12:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:34 --> Input Class Initialized
INFO - 2017-05-09 12:05:34 --> Input Class Initialized
INFO - 2017-05-09 12:05:34 --> Language Class Initialized
INFO - 2017-05-09 12:05:34 --> Language Class Initialized
ERROR - 2017-05-09 12:05:34 --> 404 Page Not Found: Default/assets
ERROR - 2017-05-09 12:05:34 --> 404 Page Not Found: Default/assets
INFO - 2017-05-09 12:05:34 --> Config Class Initialized
INFO - 2017-05-09 12:05:34 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:34 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:34 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:34 --> URI Class Initialized
INFO - 2017-05-09 12:05:34 --> Router Class Initialized
INFO - 2017-05-09 12:05:34 --> Output Class Initialized
INFO - 2017-05-09 12:05:34 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:34 --> Input Class Initialized
INFO - 2017-05-09 12:05:34 --> Language Class Initialized
ERROR - 2017-05-09 12:05:34 --> 404 Page Not Found: Default/assets
INFO - 2017-05-09 12:05:37 --> Config Class Initialized
INFO - 2017-05-09 12:05:37 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:37 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:37 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:37 --> URI Class Initialized
INFO - 2017-05-09 12:05:37 --> Router Class Initialized
INFO - 2017-05-09 12:05:37 --> Output Class Initialized
INFO - 2017-05-09 12:05:37 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:37 --> Input Class Initialized
INFO - 2017-05-09 12:05:37 --> Language Class Initialized
INFO - 2017-05-09 12:05:37 --> Loader Class Initialized
INFO - 2017-05-09 12:05:37 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:37 --> Helper loaded: form_helper
INFO - 2017-05-09 12:05:37 --> Helper loaded: html_helper
INFO - 2017-05-09 12:05:37 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:05:37 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:05:37 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:37 --> Parser Class Initialized
DEBUG - 2017-05-09 12:05:37 --> Session Class Initialized
INFO - 2017-05-09 12:05:37 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:05:37 --> Session routines successfully run
INFO - 2017-05-09 12:05:37 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:37 --> Controller Class Initialized
INFO - 2017-05-09 12:05:38 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:38 --> Pagination Class Initialized
DEBUG - 2017-05-09 12:05:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-09 12:05:43 --> Config Class Initialized
INFO - 2017-05-09 12:05:43 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:43 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:43 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:43 --> URI Class Initialized
INFO - 2017-05-09 12:05:43 --> Router Class Initialized
INFO - 2017-05-09 12:05:43 --> Output Class Initialized
INFO - 2017-05-09 12:05:43 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:43 --> Input Class Initialized
INFO - 2017-05-09 12:05:43 --> Language Class Initialized
INFO - 2017-05-09 12:05:43 --> Loader Class Initialized
INFO - 2017-05-09 12:05:43 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:43 --> Helper loaded: form_helper
INFO - 2017-05-09 12:05:43 --> Helper loaded: html_helper
INFO - 2017-05-09 12:05:43 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:05:43 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:05:43 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:43 --> Parser Class Initialized
DEBUG - 2017-05-09 12:05:43 --> Session Class Initialized
INFO - 2017-05-09 12:05:43 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:05:43 --> Session routines successfully run
INFO - 2017-05-09 12:05:43 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:43 --> Controller Class Initialized
INFO - 2017-05-09 12:05:43 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:43 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-09 12:05:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-09 12:05:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/list_color.php
INFO - 2017-05-09 12:05:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-09 12:05:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-09 12:05:43 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:43 --> Total execution time: 0.2328
INFO - 2017-05-09 12:06:27 --> Config Class Initialized
INFO - 2017-05-09 12:06:27 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:06:27 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:06:27 --> Utf8 Class Initialized
INFO - 2017-05-09 12:06:27 --> URI Class Initialized
INFO - 2017-05-09 12:06:27 --> Router Class Initialized
INFO - 2017-05-09 12:06:27 --> Output Class Initialized
INFO - 2017-05-09 12:06:27 --> Security Class Initialized
DEBUG - 2017-05-09 12:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:06:27 --> Input Class Initialized
INFO - 2017-05-09 12:06:27 --> Language Class Initialized
INFO - 2017-05-09 12:06:27 --> Loader Class Initialized
INFO - 2017-05-09 12:06:27 --> Helper loaded: url_helper
INFO - 2017-05-09 12:06:27 --> Helper loaded: form_helper
INFO - 2017-05-09 12:06:27 --> Helper loaded: html_helper
INFO - 2017-05-09 12:06:27 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:06:27 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:06:27 --> Database Driver Class Initialized
INFO - 2017-05-09 12:06:27 --> Parser Class Initialized
DEBUG - 2017-05-09 12:06:27 --> Session Class Initialized
INFO - 2017-05-09 12:06:27 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:06:27 --> Session routines successfully run
INFO - 2017-05-09 12:06:27 --> Form Validation Class Initialized
INFO - 2017-05-09 12:06:27 --> Controller Class Initialized
INFO - 2017-05-09 12:06:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:27 --> Pagination Class Initialized
INFO - 2017-05-09 12:06:32 --> Config Class Initialized
INFO - 2017-05-09 12:06:32 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:06:32 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:06:32 --> Utf8 Class Initialized
INFO - 2017-05-09 12:06:32 --> URI Class Initialized
INFO - 2017-05-09 12:06:32 --> Router Class Initialized
INFO - 2017-05-09 12:06:32 --> Output Class Initialized
INFO - 2017-05-09 12:06:32 --> Security Class Initialized
DEBUG - 2017-05-09 12:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:06:32 --> Input Class Initialized
INFO - 2017-05-09 12:06:32 --> Language Class Initialized
INFO - 2017-05-09 12:06:32 --> Loader Class Initialized
INFO - 2017-05-09 12:06:32 --> Helper loaded: url_helper
INFO - 2017-05-09 12:06:32 --> Helper loaded: form_helper
INFO - 2017-05-09 12:06:32 --> Helper loaded: html_helper
INFO - 2017-05-09 12:06:32 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:06:32 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:06:32 --> Database Driver Class Initialized
INFO - 2017-05-09 12:06:32 --> Parser Class Initialized
DEBUG - 2017-05-09 12:06:32 --> Session Class Initialized
INFO - 2017-05-09 12:06:32 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:06:32 --> Session routines successfully run
INFO - 2017-05-09 12:06:32 --> Form Validation Class Initialized
INFO - 2017-05-09 12:06:32 --> Controller Class Initialized
INFO - 2017-05-09 12:06:32 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:32 --> Pagination Class Initialized
INFO - 2017-05-09 12:06:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-09 12:06:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-09 12:06:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/list_color.php
INFO - 2017-05-09 12:06:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-09 12:06:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-09 12:06:32 --> Final output sent to browser
DEBUG - 2017-05-09 12:06:32 --> Total execution time: 0.2400
INFO - 2017-05-09 12:22:24 --> Config Class Initialized
INFO - 2017-05-09 12:22:24 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:22:24 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:22:24 --> Utf8 Class Initialized
INFO - 2017-05-09 12:22:24 --> URI Class Initialized
INFO - 2017-05-09 12:22:24 --> Router Class Initialized
INFO - 2017-05-09 12:22:24 --> Output Class Initialized
INFO - 2017-05-09 12:22:24 --> Security Class Initialized
DEBUG - 2017-05-09 12:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:22:24 --> Input Class Initialized
INFO - 2017-05-09 12:22:24 --> Language Class Initialized
INFO - 2017-05-09 12:22:24 --> Loader Class Initialized
INFO - 2017-05-09 12:22:24 --> Helper loaded: url_helper
INFO - 2017-05-09 12:22:24 --> Helper loaded: form_helper
INFO - 2017-05-09 12:22:24 --> Helper loaded: html_helper
INFO - 2017-05-09 12:22:24 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:22:24 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:22:24 --> Database Driver Class Initialized
INFO - 2017-05-09 12:22:24 --> Parser Class Initialized
DEBUG - 2017-05-09 12:22:24 --> Session Class Initialized
INFO - 2017-05-09 12:22:24 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:22:24 --> Session routines successfully run
INFO - 2017-05-09 12:22:24 --> Form Validation Class Initialized
INFO - 2017-05-09 12:22:24 --> Controller Class Initialized
INFO - 2017-05-09 12:22:24 --> Model Class Initialized
DEBUG - 2017-05-09 12:22:24 --> Pagination Class Initialized
INFO - 2017-05-09 12:22:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-09 12:22:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-09 12:22:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/list_color.php
INFO - 2017-05-09 12:22:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-09 12:22:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-09 12:22:24 --> Final output sent to browser
DEBUG - 2017-05-09 12:22:24 --> Total execution time: 0.2120
INFO - 2017-05-09 12:22:27 --> Config Class Initialized
INFO - 2017-05-09 12:22:27 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:22:27 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:22:27 --> Utf8 Class Initialized
INFO - 2017-05-09 12:22:27 --> URI Class Initialized
INFO - 2017-05-09 12:22:27 --> Router Class Initialized
INFO - 2017-05-09 12:22:27 --> Output Class Initialized
INFO - 2017-05-09 12:22:27 --> Security Class Initialized
DEBUG - 2017-05-09 12:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:22:27 --> Input Class Initialized
INFO - 2017-05-09 12:22:27 --> Language Class Initialized
INFO - 2017-05-09 12:22:27 --> Loader Class Initialized
INFO - 2017-05-09 12:22:27 --> Helper loaded: url_helper
INFO - 2017-05-09 12:22:27 --> Helper loaded: form_helper
INFO - 2017-05-09 12:22:27 --> Helper loaded: html_helper
INFO - 2017-05-09 12:22:27 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:22:27 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:22:27 --> Database Driver Class Initialized
INFO - 2017-05-09 12:22:27 --> Parser Class Initialized
DEBUG - 2017-05-09 12:22:27 --> Session Class Initialized
INFO - 2017-05-09 12:22:27 --> Helper loaded: string_helper
DEBUG - 2017-05-09 12:22:27 --> Session routines successfully run
INFO - 2017-05-09 12:22:27 --> Form Validation Class Initialized
INFO - 2017-05-09 12:22:27 --> Controller Class Initialized
INFO - 2017-05-09 12:22:27 --> Model Class Initialized
INFO - 2017-05-09 12:22:27 --> Config Class Initialized
INFO - 2017-05-09 12:22:27 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:22:27 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:22:27 --> Utf8 Class Initialized
INFO - 2017-05-09 12:22:27 --> URI Class Initialized
INFO - 2017-05-09 12:22:27 --> Router Class Initialized
INFO - 2017-05-09 12:22:27 --> Output Class Initialized
INFO - 2017-05-09 12:22:27 --> Security Class Initialized
DEBUG - 2017-05-09 12:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:22:27 --> Input Class Initialized
INFO - 2017-05-09 12:22:27 --> Language Class Initialized
INFO - 2017-05-09 12:22:27 --> Loader Class Initialized
INFO - 2017-05-09 12:22:27 --> Helper loaded: url_helper
INFO - 2017-05-09 12:22:27 --> Helper loaded: form_helper
INFO - 2017-05-09 12:22:27 --> Helper loaded: html_helper
INFO - 2017-05-09 12:22:27 --> Helper loaded: custom_helper
INFO - 2017-05-09 12:22:27 --> Helper loaded: cache_helper
INFO - 2017-05-09 12:22:27 --> Database Driver Class Initialized
INFO - 2017-05-09 12:22:27 --> Parser Class Initialized
DEBUG - 2017-05-09 12:22:27 --> Session Class Initialized
INFO - 2017-05-09 12:22:27 --> Helper loaded: string_helper
ERROR - 2017-05-09 12:22:27 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-09 12:22:27 --> Session routines successfully run
INFO - 2017-05-09 12:22:27 --> Form Validation Class Initialized
INFO - 2017-05-09 12:22:27 --> Controller Class Initialized
INFO - 2017-05-09 12:22:27 --> Model Class Initialized
INFO - 2017-05-09 12:22:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-09 12:22:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-09 12:22:28 --> Final output sent to browser
DEBUG - 2017-05-09 12:22:28 --> Total execution time: 0.1874
