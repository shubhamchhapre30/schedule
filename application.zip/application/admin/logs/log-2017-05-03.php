<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-05-03 12:04:12 --> Config Class Initialized
INFO - 2017-05-03 12:04:12 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:04:12 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:04:12 --> Utf8 Class Initialized
INFO - 2017-05-03 12:04:12 --> URI Class Initialized
DEBUG - 2017-05-03 12:04:12 --> No URI present. Default controller set.
INFO - 2017-05-03 12:04:12 --> Router Class Initialized
INFO - 2017-05-03 12:04:12 --> Output Class Initialized
INFO - 2017-05-03 12:04:12 --> Security Class Initialized
DEBUG - 2017-05-03 12:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:04:12 --> Input Class Initialized
INFO - 2017-05-03 12:04:12 --> Language Class Initialized
INFO - 2017-05-03 12:04:12 --> Loader Class Initialized
INFO - 2017-05-03 12:04:12 --> Helper loaded: url_helper
INFO - 2017-05-03 12:04:12 --> Helper loaded: form_helper
INFO - 2017-05-03 12:04:12 --> Helper loaded: html_helper
INFO - 2017-05-03 12:04:12 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:04:12 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:04:12 --> Database Driver Class Initialized
INFO - 2017-05-03 12:04:12 --> Parser Class Initialized
DEBUG - 2017-05-03 12:04:12 --> Session Class Initialized
INFO - 2017-05-03 12:04:12 --> Helper loaded: string_helper
ERROR - 2017-05-03 12:04:12 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-03 12:04:13 --> Session routines successfully run
INFO - 2017-05-03 12:04:13 --> Form Validation Class Initialized
INFO - 2017-05-03 12:04:13 --> Controller Class Initialized
INFO - 2017-05-03 12:04:13 --> Model Class Initialized
INFO - 2017-05-03 12:04:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-03 12:04:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:04:13 --> Final output sent to browser
DEBUG - 2017-05-03 12:04:13 --> Total execution time: 0.2260
INFO - 2017-05-03 12:04:30 --> Config Class Initialized
INFO - 2017-05-03 12:04:30 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:04:30 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:04:30 --> Utf8 Class Initialized
INFO - 2017-05-03 12:04:30 --> URI Class Initialized
INFO - 2017-05-03 12:04:30 --> Router Class Initialized
INFO - 2017-05-03 12:04:30 --> Output Class Initialized
INFO - 2017-05-03 12:04:30 --> Security Class Initialized
DEBUG - 2017-05-03 12:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:04:30 --> Input Class Initialized
INFO - 2017-05-03 12:04:30 --> Language Class Initialized
INFO - 2017-05-03 12:04:30 --> Loader Class Initialized
INFO - 2017-05-03 12:04:30 --> Helper loaded: url_helper
INFO - 2017-05-03 12:04:30 --> Helper loaded: form_helper
INFO - 2017-05-03 12:04:30 --> Helper loaded: html_helper
INFO - 2017-05-03 12:04:30 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:04:30 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:04:30 --> Database Driver Class Initialized
INFO - 2017-05-03 12:04:30 --> Parser Class Initialized
DEBUG - 2017-05-03 12:04:30 --> Session Class Initialized
INFO - 2017-05-03 12:04:30 --> Helper loaded: string_helper
ERROR - 2017-05-03 12:04:30 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-03 12:04:30 --> Session routines successfully run
INFO - 2017-05-03 12:04:30 --> Form Validation Class Initialized
INFO - 2017-05-03 12:04:30 --> Controller Class Initialized
INFO - 2017-05-03 12:04:30 --> Model Class Initialized
INFO - 2017-05-03 12:04:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-03 12:04:32 --> Config Class Initialized
INFO - 2017-05-03 12:04:32 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:04:32 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:04:32 --> Utf8 Class Initialized
INFO - 2017-05-03 12:04:32 --> URI Class Initialized
INFO - 2017-05-03 12:04:32 --> Router Class Initialized
INFO - 2017-05-03 12:04:32 --> Output Class Initialized
INFO - 2017-05-03 12:04:32 --> Security Class Initialized
DEBUG - 2017-05-03 12:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:04:32 --> Input Class Initialized
INFO - 2017-05-03 12:04:32 --> Language Class Initialized
INFO - 2017-05-03 12:04:32 --> Loader Class Initialized
INFO - 2017-05-03 12:04:33 --> Helper loaded: url_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: form_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: html_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:04:33 --> Database Driver Class Initialized
INFO - 2017-05-03 12:04:33 --> Parser Class Initialized
DEBUG - 2017-05-03 12:04:33 --> Session Class Initialized
INFO - 2017-05-03 12:04:33 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:04:33 --> Session routines successfully run
INFO - 2017-05-03 12:04:33 --> Form Validation Class Initialized
INFO - 2017-05-03 12:04:33 --> Controller Class Initialized
INFO - 2017-05-03 12:04:33 --> Model Class Initialized
INFO - 2017-05-03 12:04:33 --> Config Class Initialized
INFO - 2017-05-03 12:04:33 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:04:33 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:04:33 --> Utf8 Class Initialized
INFO - 2017-05-03 12:04:33 --> URI Class Initialized
INFO - 2017-05-03 12:04:33 --> Router Class Initialized
INFO - 2017-05-03 12:04:33 --> Output Class Initialized
INFO - 2017-05-03 12:04:33 --> Security Class Initialized
DEBUG - 2017-05-03 12:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:04:33 --> Input Class Initialized
INFO - 2017-05-03 12:04:33 --> Language Class Initialized
INFO - 2017-05-03 12:04:33 --> Loader Class Initialized
INFO - 2017-05-03 12:04:33 --> Helper loaded: url_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: form_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: html_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:04:33 --> Database Driver Class Initialized
INFO - 2017-05-03 12:04:33 --> Parser Class Initialized
DEBUG - 2017-05-03 12:04:33 --> Session Class Initialized
INFO - 2017-05-03 12:04:33 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:04:33 --> Session routines successfully run
INFO - 2017-05-03 12:04:33 --> Form Validation Class Initialized
INFO - 2017-05-03 12:04:33 --> Controller Class Initialized
INFO - 2017-05-03 12:04:33 --> Model Class Initialized
INFO - 2017-05-03 12:04:33 --> Config Class Initialized
INFO - 2017-05-03 12:04:33 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:04:33 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:04:33 --> Utf8 Class Initialized
INFO - 2017-05-03 12:04:33 --> URI Class Initialized
INFO - 2017-05-03 12:04:33 --> Router Class Initialized
INFO - 2017-05-03 12:04:33 --> Output Class Initialized
INFO - 2017-05-03 12:04:33 --> Security Class Initialized
DEBUG - 2017-05-03 12:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:04:33 --> Input Class Initialized
INFO - 2017-05-03 12:04:33 --> Language Class Initialized
INFO - 2017-05-03 12:04:33 --> Loader Class Initialized
INFO - 2017-05-03 12:04:33 --> Helper loaded: url_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: form_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: html_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:04:33 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:04:33 --> Database Driver Class Initialized
INFO - 2017-05-03 12:04:33 --> Parser Class Initialized
DEBUG - 2017-05-03 12:04:33 --> Session Class Initialized
INFO - 2017-05-03 12:04:33 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:04:33 --> Session routines successfully run
INFO - 2017-05-03 12:04:33 --> Form Validation Class Initialized
INFO - 2017-05-03 12:04:33 --> Controller Class Initialized
DEBUG - 2017-05-03 12:04:33 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:04:33 --> Model Class Initialized
DEBUG - 2017-05-03 12:04:33 --> Pagination Class Initialized
INFO - 2017-05-03 12:04:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:04:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:04:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-05-03 12:04:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:04:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:04:33 --> Final output sent to browser
DEBUG - 2017-05-03 12:04:33 --> Total execution time: 0.2488
INFO - 2017-05-03 12:04:39 --> Config Class Initialized
INFO - 2017-05-03 12:04:39 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:04:39 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:04:39 --> Utf8 Class Initialized
INFO - 2017-05-03 12:04:39 --> URI Class Initialized
INFO - 2017-05-03 12:04:39 --> Router Class Initialized
INFO - 2017-05-03 12:04:39 --> Output Class Initialized
INFO - 2017-05-03 12:04:39 --> Security Class Initialized
DEBUG - 2017-05-03 12:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:04:39 --> Input Class Initialized
INFO - 2017-05-03 12:04:39 --> Language Class Initialized
INFO - 2017-05-03 12:04:39 --> Loader Class Initialized
INFO - 2017-05-03 12:04:39 --> Helper loaded: url_helper
INFO - 2017-05-03 12:04:39 --> Helper loaded: form_helper
INFO - 2017-05-03 12:04:39 --> Helper loaded: html_helper
INFO - 2017-05-03 12:04:39 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:04:39 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:04:39 --> Database Driver Class Initialized
INFO - 2017-05-03 12:04:39 --> Parser Class Initialized
DEBUG - 2017-05-03 12:04:39 --> Session Class Initialized
INFO - 2017-05-03 12:04:39 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:04:39 --> Session routines successfully run
INFO - 2017-05-03 12:04:39 --> Form Validation Class Initialized
INFO - 2017-05-03 12:04:39 --> Controller Class Initialized
DEBUG - 2017-05-03 12:04:39 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:04:39 --> Model Class Initialized
DEBUG - 2017-05-03 12:04:39 --> Pagination Class Initialized
INFO - 2017-05-03 12:04:39 --> Config Class Initialized
INFO - 2017-05-03 12:04:39 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:04:39 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:04:39 --> Utf8 Class Initialized
INFO - 2017-05-03 12:04:40 --> URI Class Initialized
INFO - 2017-05-03 12:04:40 --> Router Class Initialized
INFO - 2017-05-03 12:04:40 --> Output Class Initialized
INFO - 2017-05-03 12:04:40 --> Security Class Initialized
DEBUG - 2017-05-03 12:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:04:40 --> Input Class Initialized
INFO - 2017-05-03 12:04:40 --> Language Class Initialized
INFO - 2017-05-03 12:04:40 --> Loader Class Initialized
INFO - 2017-05-03 12:04:40 --> Helper loaded: url_helper
INFO - 2017-05-03 12:04:40 --> Helper loaded: form_helper
INFO - 2017-05-03 12:04:40 --> Helper loaded: html_helper
INFO - 2017-05-03 12:04:40 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:04:40 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:04:40 --> Database Driver Class Initialized
INFO - 2017-05-03 12:04:40 --> Parser Class Initialized
DEBUG - 2017-05-03 12:04:40 --> Session Class Initialized
INFO - 2017-05-03 12:04:40 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:04:40 --> Session routines successfully run
INFO - 2017-05-03 12:04:40 --> Form Validation Class Initialized
INFO - 2017-05-03 12:04:40 --> Controller Class Initialized
DEBUG - 2017-05-03 12:04:40 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:04:40 --> Model Class Initialized
DEBUG - 2017-05-03 12:04:40 --> Pagination Class Initialized
INFO - 2017-05-03 12:04:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:04:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:04:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:04:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:04:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:04:40 --> Final output sent to browser
DEBUG - 2017-05-03 12:04:40 --> Total execution time: 0.4900
INFO - 2017-05-03 12:05:58 --> Config Class Initialized
INFO - 2017-05-03 12:05:58 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:05:58 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:05:58 --> Utf8 Class Initialized
INFO - 2017-05-03 12:05:58 --> URI Class Initialized
INFO - 2017-05-03 12:05:58 --> Router Class Initialized
INFO - 2017-05-03 12:05:58 --> Output Class Initialized
INFO - 2017-05-03 12:05:58 --> Security Class Initialized
DEBUG - 2017-05-03 12:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:05:58 --> Input Class Initialized
INFO - 2017-05-03 12:05:58 --> Language Class Initialized
INFO - 2017-05-03 12:05:58 --> Loader Class Initialized
INFO - 2017-05-03 12:05:58 --> Helper loaded: url_helper
INFO - 2017-05-03 12:05:58 --> Helper loaded: form_helper
INFO - 2017-05-03 12:05:58 --> Helper loaded: html_helper
INFO - 2017-05-03 12:05:58 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:05:58 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:05:58 --> Database Driver Class Initialized
INFO - 2017-05-03 12:05:58 --> Parser Class Initialized
DEBUG - 2017-05-03 12:05:58 --> Session Class Initialized
INFO - 2017-05-03 12:05:58 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:05:58 --> Session routines successfully run
INFO - 2017-05-03 12:05:58 --> Form Validation Class Initialized
INFO - 2017-05-03 12:05:58 --> Controller Class Initialized
DEBUG - 2017-05-03 12:05:58 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:05:58 --> Model Class Initialized
DEBUG - 2017-05-03 12:05:58 --> Pagination Class Initialized
INFO - 2017-05-03 12:05:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:05:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:05:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:05:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:05:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:05:58 --> Final output sent to browser
DEBUG - 2017-05-03 12:05:58 --> Total execution time: 0.2169
INFO - 2017-05-03 12:06:00 --> Config Class Initialized
INFO - 2017-05-03 12:06:00 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:06:00 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:06:00 --> Utf8 Class Initialized
INFO - 2017-05-03 12:06:00 --> URI Class Initialized
INFO - 2017-05-03 12:06:00 --> Router Class Initialized
INFO - 2017-05-03 12:06:01 --> Output Class Initialized
INFO - 2017-05-03 12:06:01 --> Security Class Initialized
DEBUG - 2017-05-03 12:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:06:01 --> Input Class Initialized
INFO - 2017-05-03 12:06:01 --> Language Class Initialized
INFO - 2017-05-03 12:06:01 --> Loader Class Initialized
INFO - 2017-05-03 12:06:01 --> Helper loaded: url_helper
INFO - 2017-05-03 12:06:01 --> Helper loaded: form_helper
INFO - 2017-05-03 12:06:01 --> Helper loaded: html_helper
INFO - 2017-05-03 12:06:01 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:06:01 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:06:01 --> Database Driver Class Initialized
INFO - 2017-05-03 12:06:01 --> Parser Class Initialized
DEBUG - 2017-05-03 12:06:01 --> Session Class Initialized
INFO - 2017-05-03 12:06:01 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:06:01 --> Session routines successfully run
INFO - 2017-05-03 12:06:01 --> Form Validation Class Initialized
INFO - 2017-05-03 12:06:01 --> Controller Class Initialized
DEBUG - 2017-05-03 12:06:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:06:01 --> Model Class Initialized
DEBUG - 2017-05-03 12:06:01 --> Pagination Class Initialized
INFO - 2017-05-03 12:06:01 --> Config Class Initialized
INFO - 2017-05-03 12:06:01 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:06:01 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:06:01 --> Utf8 Class Initialized
INFO - 2017-05-03 12:06:01 --> URI Class Initialized
INFO - 2017-05-03 12:06:01 --> Router Class Initialized
INFO - 2017-05-03 12:06:01 --> Output Class Initialized
INFO - 2017-05-03 12:06:01 --> Security Class Initialized
DEBUG - 2017-05-03 12:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:06:01 --> Input Class Initialized
INFO - 2017-05-03 12:06:01 --> Language Class Initialized
INFO - 2017-05-03 12:06:01 --> Loader Class Initialized
INFO - 2017-05-03 12:06:01 --> Helper loaded: url_helper
INFO - 2017-05-03 12:06:01 --> Helper loaded: form_helper
INFO - 2017-05-03 12:06:01 --> Helper loaded: html_helper
INFO - 2017-05-03 12:06:01 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:06:01 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:06:01 --> Database Driver Class Initialized
INFO - 2017-05-03 12:06:01 --> Parser Class Initialized
DEBUG - 2017-05-03 12:06:01 --> Session Class Initialized
INFO - 2017-05-03 12:06:01 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:06:01 --> Session routines successfully run
INFO - 2017-05-03 12:06:01 --> Form Validation Class Initialized
INFO - 2017-05-03 12:06:01 --> Controller Class Initialized
DEBUG - 2017-05-03 12:06:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:06:01 --> Model Class Initialized
DEBUG - 2017-05-03 12:06:01 --> Pagination Class Initialized
INFO - 2017-05-03 12:06:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:06:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:06:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:06:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:06:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:06:01 --> Final output sent to browser
DEBUG - 2017-05-03 12:06:01 --> Total execution time: 0.2808
INFO - 2017-05-03 12:06:04 --> Config Class Initialized
INFO - 2017-05-03 12:06:04 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:06:04 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:06:04 --> Utf8 Class Initialized
INFO - 2017-05-03 12:06:04 --> URI Class Initialized
INFO - 2017-05-03 12:06:04 --> Router Class Initialized
INFO - 2017-05-03 12:06:04 --> Output Class Initialized
INFO - 2017-05-03 12:06:04 --> Security Class Initialized
DEBUG - 2017-05-03 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:06:04 --> Input Class Initialized
INFO - 2017-05-03 12:06:04 --> Language Class Initialized
INFO - 2017-05-03 12:06:04 --> Loader Class Initialized
INFO - 2017-05-03 12:06:04 --> Helper loaded: url_helper
INFO - 2017-05-03 12:06:04 --> Helper loaded: form_helper
INFO - 2017-05-03 12:06:04 --> Helper loaded: html_helper
INFO - 2017-05-03 12:06:04 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:06:04 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:06:04 --> Database Driver Class Initialized
INFO - 2017-05-03 12:06:04 --> Parser Class Initialized
DEBUG - 2017-05-03 12:06:04 --> Session Class Initialized
INFO - 2017-05-03 12:06:04 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:06:04 --> Session routines successfully run
INFO - 2017-05-03 12:06:04 --> Form Validation Class Initialized
INFO - 2017-05-03 12:06:04 --> Controller Class Initialized
DEBUG - 2017-05-03 12:06:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:06:04 --> Model Class Initialized
DEBUG - 2017-05-03 12:06:04 --> Pagination Class Initialized
INFO - 2017-05-03 12:06:04 --> Config Class Initialized
INFO - 2017-05-03 12:06:04 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:06:04 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:06:04 --> Utf8 Class Initialized
INFO - 2017-05-03 12:06:04 --> URI Class Initialized
INFO - 2017-05-03 12:06:04 --> Router Class Initialized
INFO - 2017-05-03 12:06:04 --> Output Class Initialized
INFO - 2017-05-03 12:06:04 --> Security Class Initialized
DEBUG - 2017-05-03 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:06:04 --> Input Class Initialized
INFO - 2017-05-03 12:06:04 --> Language Class Initialized
INFO - 2017-05-03 12:06:04 --> Loader Class Initialized
INFO - 2017-05-03 12:06:04 --> Helper loaded: url_helper
INFO - 2017-05-03 12:06:04 --> Helper loaded: form_helper
INFO - 2017-05-03 12:06:04 --> Helper loaded: html_helper
INFO - 2017-05-03 12:06:04 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:06:04 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:06:04 --> Database Driver Class Initialized
INFO - 2017-05-03 12:06:04 --> Parser Class Initialized
DEBUG - 2017-05-03 12:06:04 --> Session Class Initialized
INFO - 2017-05-03 12:06:04 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:06:04 --> Session routines successfully run
INFO - 2017-05-03 12:06:04 --> Form Validation Class Initialized
INFO - 2017-05-03 12:06:04 --> Controller Class Initialized
DEBUG - 2017-05-03 12:06:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:06:04 --> Model Class Initialized
DEBUG - 2017-05-03 12:06:04 --> Pagination Class Initialized
INFO - 2017-05-03 12:06:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:06:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:06:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-05-03 12:06:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:06:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:06:07 --> Final output sent to browser
DEBUG - 2017-05-03 12:06:07 --> Total execution time: 3.2392
INFO - 2017-05-03 12:06:09 --> Config Class Initialized
INFO - 2017-05-03 12:06:09 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:06:09 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:06:09 --> Utf8 Class Initialized
INFO - 2017-05-03 12:06:09 --> URI Class Initialized
INFO - 2017-05-03 12:06:09 --> Router Class Initialized
INFO - 2017-05-03 12:06:09 --> Output Class Initialized
INFO - 2017-05-03 12:06:09 --> Security Class Initialized
DEBUG - 2017-05-03 12:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:06:09 --> Input Class Initialized
INFO - 2017-05-03 12:06:09 --> Language Class Initialized
INFO - 2017-05-03 12:06:09 --> Loader Class Initialized
INFO - 2017-05-03 12:06:09 --> Helper loaded: url_helper
INFO - 2017-05-03 12:06:09 --> Helper loaded: form_helper
INFO - 2017-05-03 12:06:09 --> Helper loaded: html_helper
INFO - 2017-05-03 12:06:09 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:06:09 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:06:09 --> Database Driver Class Initialized
INFO - 2017-05-03 12:06:09 --> Parser Class Initialized
DEBUG - 2017-05-03 12:06:09 --> Session Class Initialized
INFO - 2017-05-03 12:06:09 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:06:09 --> Session routines successfully run
INFO - 2017-05-03 12:06:09 --> Form Validation Class Initialized
INFO - 2017-05-03 12:06:09 --> Controller Class Initialized
DEBUG - 2017-05-03 12:06:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:06:09 --> Model Class Initialized
DEBUG - 2017-05-03 12:06:10 --> Pagination Class Initialized
INFO - 2017-05-03 12:06:10 --> Config Class Initialized
INFO - 2017-05-03 12:06:10 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:06:10 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:06:10 --> Utf8 Class Initialized
INFO - 2017-05-03 12:06:10 --> URI Class Initialized
INFO - 2017-05-03 12:06:10 --> Router Class Initialized
INFO - 2017-05-03 12:06:10 --> Output Class Initialized
INFO - 2017-05-03 12:06:10 --> Security Class Initialized
DEBUG - 2017-05-03 12:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:06:10 --> Input Class Initialized
INFO - 2017-05-03 12:06:10 --> Language Class Initialized
INFO - 2017-05-03 12:06:10 --> Loader Class Initialized
INFO - 2017-05-03 12:06:10 --> Helper loaded: url_helper
INFO - 2017-05-03 12:06:10 --> Helper loaded: form_helper
INFO - 2017-05-03 12:06:10 --> Helper loaded: html_helper
INFO - 2017-05-03 12:06:10 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:06:10 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:06:10 --> Database Driver Class Initialized
INFO - 2017-05-03 12:06:10 --> Parser Class Initialized
DEBUG - 2017-05-03 12:06:10 --> Session Class Initialized
INFO - 2017-05-03 12:06:10 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:06:10 --> Session routines successfully run
INFO - 2017-05-03 12:06:10 --> Form Validation Class Initialized
INFO - 2017-05-03 12:06:10 --> Controller Class Initialized
DEBUG - 2017-05-03 12:06:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:06:10 --> Model Class Initialized
DEBUG - 2017-05-03 12:06:10 --> Pagination Class Initialized
INFO - 2017-05-03 12:06:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:06:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:06:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:06:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:06:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:06:10 --> Final output sent to browser
DEBUG - 2017-05-03 12:06:10 --> Total execution time: 0.2774
INFO - 2017-05-03 12:06:13 --> Config Class Initialized
INFO - 2017-05-03 12:06:13 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:06:13 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:06:13 --> Utf8 Class Initialized
INFO - 2017-05-03 12:06:13 --> URI Class Initialized
INFO - 2017-05-03 12:06:13 --> Router Class Initialized
INFO - 2017-05-03 12:06:13 --> Output Class Initialized
INFO - 2017-05-03 12:06:13 --> Security Class Initialized
DEBUG - 2017-05-03 12:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:06:13 --> Input Class Initialized
INFO - 2017-05-03 12:06:13 --> Language Class Initialized
INFO - 2017-05-03 12:06:13 --> Loader Class Initialized
INFO - 2017-05-03 12:06:13 --> Helper loaded: url_helper
INFO - 2017-05-03 12:06:13 --> Helper loaded: form_helper
INFO - 2017-05-03 12:06:13 --> Helper loaded: html_helper
INFO - 2017-05-03 12:06:13 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:06:13 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:06:13 --> Database Driver Class Initialized
INFO - 2017-05-03 12:06:13 --> Parser Class Initialized
DEBUG - 2017-05-03 12:06:13 --> Session Class Initialized
INFO - 2017-05-03 12:06:13 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:06:13 --> Session routines successfully run
INFO - 2017-05-03 12:06:13 --> Form Validation Class Initialized
INFO - 2017-05-03 12:06:13 --> Controller Class Initialized
DEBUG - 2017-05-03 12:06:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:06:13 --> Model Class Initialized
DEBUG - 2017-05-03 12:06:13 --> Pagination Class Initialized
INFO - 2017-05-03 12:06:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:06:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:06:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:06:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:06:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:06:13 --> Final output sent to browser
DEBUG - 2017-05-03 12:06:13 --> Total execution time: 0.2121
INFO - 2017-05-03 12:06:16 --> Config Class Initialized
INFO - 2017-05-03 12:06:16 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:06:16 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:06:16 --> Utf8 Class Initialized
INFO - 2017-05-03 12:06:16 --> URI Class Initialized
INFO - 2017-05-03 12:06:16 --> Router Class Initialized
INFO - 2017-05-03 12:06:16 --> Output Class Initialized
INFO - 2017-05-03 12:06:16 --> Security Class Initialized
DEBUG - 2017-05-03 12:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:06:16 --> Input Class Initialized
INFO - 2017-05-03 12:06:16 --> Language Class Initialized
INFO - 2017-05-03 12:06:16 --> Loader Class Initialized
INFO - 2017-05-03 12:06:16 --> Helper loaded: url_helper
INFO - 2017-05-03 12:06:16 --> Helper loaded: form_helper
INFO - 2017-05-03 12:06:16 --> Helper loaded: html_helper
INFO - 2017-05-03 12:06:16 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:06:16 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:06:16 --> Database Driver Class Initialized
INFO - 2017-05-03 12:06:16 --> Parser Class Initialized
DEBUG - 2017-05-03 12:06:16 --> Session Class Initialized
INFO - 2017-05-03 12:06:16 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:06:16 --> Session routines successfully run
INFO - 2017-05-03 12:06:16 --> Form Validation Class Initialized
INFO - 2017-05-03 12:06:16 --> Controller Class Initialized
DEBUG - 2017-05-03 12:06:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:06:16 --> Model Class Initialized
DEBUG - 2017-05-03 12:06:16 --> Pagination Class Initialized
INFO - 2017-05-03 12:06:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:06:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:06:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:06:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:06:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:06:16 --> Final output sent to browser
DEBUG - 2017-05-03 12:06:16 --> Total execution time: 0.2282
INFO - 2017-05-03 12:11:12 --> Config Class Initialized
INFO - 2017-05-03 12:11:12 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:11:12 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:11:12 --> Utf8 Class Initialized
INFO - 2017-05-03 12:11:12 --> URI Class Initialized
INFO - 2017-05-03 12:11:12 --> Router Class Initialized
INFO - 2017-05-03 12:11:12 --> Output Class Initialized
INFO - 2017-05-03 12:11:12 --> Security Class Initialized
DEBUG - 2017-05-03 12:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:11:12 --> Input Class Initialized
INFO - 2017-05-03 12:11:12 --> Language Class Initialized
INFO - 2017-05-03 12:11:12 --> Loader Class Initialized
INFO - 2017-05-03 12:11:12 --> Helper loaded: url_helper
INFO - 2017-05-03 12:11:12 --> Helper loaded: form_helper
INFO - 2017-05-03 12:11:12 --> Helper loaded: html_helper
INFO - 2017-05-03 12:11:12 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:11:12 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:11:12 --> Database Driver Class Initialized
INFO - 2017-05-03 12:11:12 --> Parser Class Initialized
DEBUG - 2017-05-03 12:11:12 --> Session Class Initialized
INFO - 2017-05-03 12:11:12 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:11:12 --> Session routines successfully run
INFO - 2017-05-03 12:11:12 --> Form Validation Class Initialized
INFO - 2017-05-03 12:11:12 --> Controller Class Initialized
DEBUG - 2017-05-03 12:11:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:11:13 --> Model Class Initialized
DEBUG - 2017-05-03 12:11:13 --> Pagination Class Initialized
ERROR - 2017-05-03 12:11:13 --> Query error: Unknown column 'company_id' in 'where clause' - Invalid query: SELECT *
FROM `app_registration`
WHERE `company_id` =0
INFO - 2017-05-03 12:11:13 --> Language file loaded: language/english/db_lang.php
INFO - 2017-05-03 12:11:42 --> Config Class Initialized
INFO - 2017-05-03 12:11:42 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:11:42 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:11:42 --> Utf8 Class Initialized
INFO - 2017-05-03 12:11:42 --> URI Class Initialized
INFO - 2017-05-03 12:11:42 --> Router Class Initialized
INFO - 2017-05-03 12:11:42 --> Output Class Initialized
INFO - 2017-05-03 12:11:42 --> Security Class Initialized
DEBUG - 2017-05-03 12:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:11:42 --> Input Class Initialized
INFO - 2017-05-03 12:11:42 --> Language Class Initialized
INFO - 2017-05-03 12:11:42 --> Loader Class Initialized
INFO - 2017-05-03 12:11:42 --> Helper loaded: url_helper
INFO - 2017-05-03 12:11:42 --> Helper loaded: form_helper
INFO - 2017-05-03 12:11:42 --> Helper loaded: html_helper
INFO - 2017-05-03 12:11:42 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:11:42 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:11:42 --> Database Driver Class Initialized
INFO - 2017-05-03 12:11:42 --> Parser Class Initialized
DEBUG - 2017-05-03 12:11:42 --> Session Class Initialized
INFO - 2017-05-03 12:11:42 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:11:42 --> Session routines successfully run
INFO - 2017-05-03 12:11:42 --> Form Validation Class Initialized
INFO - 2017-05-03 12:11:42 --> Controller Class Initialized
DEBUG - 2017-05-03 12:11:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:11:42 --> Model Class Initialized
DEBUG - 2017-05-03 12:11:42 --> Pagination Class Initialized
INFO - 2017-05-03 12:11:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:11:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-03 12:11:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 46
ERROR - 2017-05-03 12:11:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\ajax_api_company.php 47
INFO - 2017-05-03 12:11:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:11:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:11:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:11:42 --> Final output sent to browser
DEBUG - 2017-05-03 12:11:42 --> Total execution time: 0.2978
INFO - 2017-05-03 12:11:52 --> Config Class Initialized
INFO - 2017-05-03 12:11:52 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:11:52 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:11:52 --> Utf8 Class Initialized
INFO - 2017-05-03 12:11:52 --> URI Class Initialized
INFO - 2017-05-03 12:11:52 --> Router Class Initialized
INFO - 2017-05-03 12:11:52 --> Output Class Initialized
INFO - 2017-05-03 12:11:52 --> Security Class Initialized
DEBUG - 2017-05-03 12:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:11:52 --> Input Class Initialized
INFO - 2017-05-03 12:11:52 --> Language Class Initialized
INFO - 2017-05-03 12:11:53 --> Loader Class Initialized
INFO - 2017-05-03 12:11:53 --> Helper loaded: url_helper
INFO - 2017-05-03 12:11:53 --> Helper loaded: form_helper
INFO - 2017-05-03 12:11:53 --> Helper loaded: html_helper
INFO - 2017-05-03 12:11:53 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:11:53 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:11:53 --> Database Driver Class Initialized
INFO - 2017-05-03 12:11:53 --> Parser Class Initialized
DEBUG - 2017-05-03 12:11:53 --> Session Class Initialized
INFO - 2017-05-03 12:11:53 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:11:53 --> Session routines successfully run
INFO - 2017-05-03 12:11:53 --> Form Validation Class Initialized
INFO - 2017-05-03 12:11:53 --> Controller Class Initialized
DEBUG - 2017-05-03 12:11:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:11:53 --> Model Class Initialized
DEBUG - 2017-05-03 12:11:53 --> Pagination Class Initialized
INFO - 2017-05-03 12:11:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:11:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:11:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:11:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:11:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:11:53 --> Final output sent to browser
DEBUG - 2017-05-03 12:11:53 --> Total execution time: 0.2441
INFO - 2017-05-03 12:13:24 --> Config Class Initialized
INFO - 2017-05-03 12:13:24 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:13:24 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:13:24 --> Utf8 Class Initialized
INFO - 2017-05-03 12:13:24 --> URI Class Initialized
INFO - 2017-05-03 12:13:24 --> Router Class Initialized
INFO - 2017-05-03 12:13:24 --> Output Class Initialized
INFO - 2017-05-03 12:13:24 --> Security Class Initialized
DEBUG - 2017-05-03 12:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:13:25 --> Input Class Initialized
INFO - 2017-05-03 12:13:25 --> Language Class Initialized
INFO - 2017-05-03 12:13:25 --> Loader Class Initialized
INFO - 2017-05-03 12:13:25 --> Helper loaded: url_helper
INFO - 2017-05-03 12:13:25 --> Helper loaded: form_helper
INFO - 2017-05-03 12:13:25 --> Helper loaded: html_helper
INFO - 2017-05-03 12:13:25 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:13:25 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:13:25 --> Database Driver Class Initialized
INFO - 2017-05-03 12:13:25 --> Parser Class Initialized
DEBUG - 2017-05-03 12:13:25 --> Session Class Initialized
INFO - 2017-05-03 12:13:25 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:13:25 --> Session routines successfully run
INFO - 2017-05-03 12:13:25 --> Form Validation Class Initialized
INFO - 2017-05-03 12:13:25 --> Controller Class Initialized
DEBUG - 2017-05-03 12:13:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:13:25 --> Model Class Initialized
DEBUG - 2017-05-03 12:13:25 --> Pagination Class Initialized
INFO - 2017-05-03 12:13:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:13:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:13:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:13:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:13:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:13:25 --> Final output sent to browser
DEBUG - 2017-05-03 12:13:25 --> Total execution time: 0.5746
INFO - 2017-05-03 12:13:31 --> Config Class Initialized
INFO - 2017-05-03 12:13:31 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:13:31 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:13:31 --> Utf8 Class Initialized
INFO - 2017-05-03 12:13:31 --> URI Class Initialized
INFO - 2017-05-03 12:13:31 --> Router Class Initialized
INFO - 2017-05-03 12:13:31 --> Output Class Initialized
INFO - 2017-05-03 12:13:31 --> Security Class Initialized
DEBUG - 2017-05-03 12:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:13:31 --> Input Class Initialized
INFO - 2017-05-03 12:13:31 --> Language Class Initialized
INFO - 2017-05-03 12:13:31 --> Loader Class Initialized
INFO - 2017-05-03 12:13:31 --> Helper loaded: url_helper
INFO - 2017-05-03 12:13:31 --> Helper loaded: form_helper
INFO - 2017-05-03 12:13:31 --> Helper loaded: html_helper
INFO - 2017-05-03 12:13:31 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:13:31 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:13:31 --> Database Driver Class Initialized
INFO - 2017-05-03 12:13:31 --> Parser Class Initialized
DEBUG - 2017-05-03 12:13:31 --> Session Class Initialized
INFO - 2017-05-03 12:13:31 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:13:31 --> Session routines successfully run
INFO - 2017-05-03 12:13:31 --> Form Validation Class Initialized
INFO - 2017-05-03 12:13:31 --> Controller Class Initialized
DEBUG - 2017-05-03 12:13:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:13:31 --> Model Class Initialized
DEBUG - 2017-05-03 12:13:31 --> Pagination Class Initialized
INFO - 2017-05-03 12:13:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:13:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:13:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:13:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:13:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:13:31 --> Final output sent to browser
DEBUG - 2017-05-03 12:13:31 --> Total execution time: 0.2275
INFO - 2017-05-03 12:13:35 --> Config Class Initialized
INFO - 2017-05-03 12:13:35 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:13:35 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:13:35 --> Utf8 Class Initialized
INFO - 2017-05-03 12:13:35 --> URI Class Initialized
INFO - 2017-05-03 12:13:35 --> Router Class Initialized
INFO - 2017-05-03 12:13:35 --> Output Class Initialized
INFO - 2017-05-03 12:13:35 --> Security Class Initialized
DEBUG - 2017-05-03 12:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:13:35 --> Input Class Initialized
INFO - 2017-05-03 12:13:35 --> Language Class Initialized
INFO - 2017-05-03 12:13:35 --> Loader Class Initialized
INFO - 2017-05-03 12:13:35 --> Helper loaded: url_helper
INFO - 2017-05-03 12:13:35 --> Helper loaded: form_helper
INFO - 2017-05-03 12:13:35 --> Helper loaded: html_helper
INFO - 2017-05-03 12:13:35 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:13:35 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:13:35 --> Database Driver Class Initialized
INFO - 2017-05-03 12:13:35 --> Parser Class Initialized
DEBUG - 2017-05-03 12:13:35 --> Session Class Initialized
INFO - 2017-05-03 12:13:35 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:13:35 --> Session routines successfully run
INFO - 2017-05-03 12:13:35 --> Form Validation Class Initialized
INFO - 2017-05-03 12:13:35 --> Controller Class Initialized
DEBUG - 2017-05-03 12:13:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:13:35 --> Model Class Initialized
DEBUG - 2017-05-03 12:13:35 --> Pagination Class Initialized
INFO - 2017-05-03 12:13:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:13:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:13:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:13:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:13:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:13:35 --> Final output sent to browser
DEBUG - 2017-05-03 12:13:35 --> Total execution time: 0.2237
INFO - 2017-05-03 12:14:44 --> Config Class Initialized
INFO - 2017-05-03 12:14:44 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:14:44 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:14:44 --> Utf8 Class Initialized
INFO - 2017-05-03 12:14:44 --> URI Class Initialized
INFO - 2017-05-03 12:14:44 --> Router Class Initialized
INFO - 2017-05-03 12:14:44 --> Output Class Initialized
INFO - 2017-05-03 12:14:44 --> Security Class Initialized
DEBUG - 2017-05-03 12:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:14:44 --> Input Class Initialized
INFO - 2017-05-03 12:14:44 --> Language Class Initialized
INFO - 2017-05-03 12:14:44 --> Loader Class Initialized
INFO - 2017-05-03 12:14:44 --> Helper loaded: url_helper
INFO - 2017-05-03 12:14:44 --> Helper loaded: form_helper
INFO - 2017-05-03 12:14:44 --> Helper loaded: html_helper
INFO - 2017-05-03 12:14:44 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:14:44 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:14:44 --> Database Driver Class Initialized
INFO - 2017-05-03 12:14:44 --> Parser Class Initialized
DEBUG - 2017-05-03 12:14:44 --> Session Class Initialized
INFO - 2017-05-03 12:14:44 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:14:44 --> Session routines successfully run
INFO - 2017-05-03 12:14:44 --> Form Validation Class Initialized
INFO - 2017-05-03 12:14:44 --> Controller Class Initialized
DEBUG - 2017-05-03 12:14:44 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:14:44 --> Model Class Initialized
DEBUG - 2017-05-03 12:14:44 --> Pagination Class Initialized
INFO - 2017-05-03 12:14:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:14:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:14:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:14:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:14:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:14:44 --> Final output sent to browser
DEBUG - 2017-05-03 12:14:44 --> Total execution time: 0.2314
INFO - 2017-05-03 12:16:11 --> Config Class Initialized
INFO - 2017-05-03 12:16:11 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:16:11 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:16:11 --> Utf8 Class Initialized
INFO - 2017-05-03 12:16:11 --> URI Class Initialized
INFO - 2017-05-03 12:16:11 --> Router Class Initialized
INFO - 2017-05-03 12:16:11 --> Output Class Initialized
INFO - 2017-05-03 12:16:11 --> Security Class Initialized
DEBUG - 2017-05-03 12:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:16:11 --> Input Class Initialized
INFO - 2017-05-03 12:16:11 --> Language Class Initialized
INFO - 2017-05-03 12:16:11 --> Loader Class Initialized
INFO - 2017-05-03 12:16:11 --> Helper loaded: url_helper
INFO - 2017-05-03 12:16:11 --> Helper loaded: form_helper
INFO - 2017-05-03 12:16:11 --> Helper loaded: html_helper
INFO - 2017-05-03 12:16:11 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:16:11 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:16:11 --> Database Driver Class Initialized
INFO - 2017-05-03 12:16:11 --> Parser Class Initialized
DEBUG - 2017-05-03 12:16:11 --> Session Class Initialized
INFO - 2017-05-03 12:16:11 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:16:11 --> Session routines successfully run
INFO - 2017-05-03 12:16:11 --> Form Validation Class Initialized
INFO - 2017-05-03 12:16:11 --> Controller Class Initialized
DEBUG - 2017-05-03 12:16:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:16:11 --> Model Class Initialized
DEBUG - 2017-05-03 12:16:11 --> Pagination Class Initialized
INFO - 2017-05-03 12:16:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:16:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:16:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:16:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:16:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:16:12 --> Final output sent to browser
DEBUG - 2017-05-03 12:16:12 --> Total execution time: 0.4984
INFO - 2017-05-03 12:18:06 --> Config Class Initialized
INFO - 2017-05-03 12:18:06 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:18:06 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:18:06 --> Utf8 Class Initialized
INFO - 2017-05-03 12:18:06 --> URI Class Initialized
INFO - 2017-05-03 12:18:06 --> Router Class Initialized
INFO - 2017-05-03 12:18:06 --> Output Class Initialized
INFO - 2017-05-03 12:18:06 --> Security Class Initialized
DEBUG - 2017-05-03 12:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:18:06 --> Input Class Initialized
INFO - 2017-05-03 12:18:06 --> Language Class Initialized
INFO - 2017-05-03 12:18:06 --> Loader Class Initialized
INFO - 2017-05-03 12:18:06 --> Helper loaded: url_helper
INFO - 2017-05-03 12:18:06 --> Helper loaded: form_helper
INFO - 2017-05-03 12:18:06 --> Helper loaded: html_helper
INFO - 2017-05-03 12:18:06 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:18:06 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:18:06 --> Database Driver Class Initialized
INFO - 2017-05-03 12:18:06 --> Parser Class Initialized
DEBUG - 2017-05-03 12:18:06 --> Session Class Initialized
INFO - 2017-05-03 12:18:06 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:18:06 --> Session routines successfully run
INFO - 2017-05-03 12:18:06 --> Form Validation Class Initialized
INFO - 2017-05-03 12:18:06 --> Controller Class Initialized
DEBUG - 2017-05-03 12:18:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:18:06 --> Model Class Initialized
DEBUG - 2017-05-03 12:18:06 --> Pagination Class Initialized
INFO - 2017-05-03 12:18:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:18:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:18:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:18:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:18:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:18:06 --> Final output sent to browser
DEBUG - 2017-05-03 12:18:06 --> Total execution time: 0.2396
INFO - 2017-05-03 12:18:14 --> Config Class Initialized
INFO - 2017-05-03 12:18:14 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:18:14 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:18:14 --> Utf8 Class Initialized
INFO - 2017-05-03 12:18:14 --> URI Class Initialized
INFO - 2017-05-03 12:18:14 --> Router Class Initialized
INFO - 2017-05-03 12:18:14 --> Output Class Initialized
INFO - 2017-05-03 12:18:14 --> Security Class Initialized
DEBUG - 2017-05-03 12:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:18:14 --> Input Class Initialized
INFO - 2017-05-03 12:18:14 --> Language Class Initialized
INFO - 2017-05-03 12:18:14 --> Loader Class Initialized
INFO - 2017-05-03 12:18:14 --> Helper loaded: url_helper
INFO - 2017-05-03 12:18:14 --> Helper loaded: form_helper
INFO - 2017-05-03 12:18:14 --> Helper loaded: html_helper
INFO - 2017-05-03 12:18:14 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:18:14 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:18:14 --> Database Driver Class Initialized
INFO - 2017-05-03 12:18:14 --> Parser Class Initialized
DEBUG - 2017-05-03 12:18:14 --> Session Class Initialized
INFO - 2017-05-03 12:18:14 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:18:14 --> Session routines successfully run
INFO - 2017-05-03 12:18:14 --> Form Validation Class Initialized
INFO - 2017-05-03 12:18:14 --> Controller Class Initialized
DEBUG - 2017-05-03 12:18:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:18:14 --> Model Class Initialized
DEBUG - 2017-05-03 12:18:14 --> Pagination Class Initialized
INFO - 2017-05-03 12:18:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:18:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:18:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:18:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:18:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:18:14 --> Final output sent to browser
DEBUG - 2017-05-03 12:18:14 --> Total execution time: 0.2481
INFO - 2017-05-03 12:34:01 --> Config Class Initialized
INFO - 2017-05-03 12:34:01 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:34:01 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:34:01 --> Utf8 Class Initialized
INFO - 2017-05-03 12:34:01 --> URI Class Initialized
INFO - 2017-05-03 12:34:01 --> Router Class Initialized
INFO - 2017-05-03 12:34:01 --> Output Class Initialized
INFO - 2017-05-03 12:34:01 --> Security Class Initialized
DEBUG - 2017-05-03 12:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:34:01 --> Input Class Initialized
INFO - 2017-05-03 12:34:01 --> Language Class Initialized
INFO - 2017-05-03 12:34:01 --> Loader Class Initialized
INFO - 2017-05-03 12:34:01 --> Helper loaded: url_helper
INFO - 2017-05-03 12:34:01 --> Helper loaded: form_helper
INFO - 2017-05-03 12:34:01 --> Helper loaded: html_helper
INFO - 2017-05-03 12:34:01 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:34:01 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:34:01 --> Database Driver Class Initialized
INFO - 2017-05-03 12:34:01 --> Parser Class Initialized
DEBUG - 2017-05-03 12:34:01 --> Session Class Initialized
INFO - 2017-05-03 12:34:01 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:34:01 --> Session routines successfully run
INFO - 2017-05-03 12:34:01 --> Form Validation Class Initialized
INFO - 2017-05-03 12:34:01 --> Controller Class Initialized
DEBUG - 2017-05-03 12:34:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:34:01 --> Model Class Initialized
DEBUG - 2017-05-03 12:34:01 --> Pagination Class Initialized
INFO - 2017-05-03 12:34:01 --> Config Class Initialized
INFO - 2017-05-03 12:34:01 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:34:01 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:34:01 --> Utf8 Class Initialized
INFO - 2017-05-03 12:34:01 --> URI Class Initialized
INFO - 2017-05-03 12:34:01 --> Router Class Initialized
INFO - 2017-05-03 12:34:01 --> Output Class Initialized
INFO - 2017-05-03 12:34:01 --> Security Class Initialized
DEBUG - 2017-05-03 12:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:34:01 --> Input Class Initialized
INFO - 2017-05-03 12:34:01 --> Language Class Initialized
INFO - 2017-05-03 12:34:01 --> Loader Class Initialized
INFO - 2017-05-03 12:34:01 --> Helper loaded: url_helper
INFO - 2017-05-03 12:34:01 --> Helper loaded: form_helper
INFO - 2017-05-03 12:34:01 --> Helper loaded: html_helper
INFO - 2017-05-03 12:34:01 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:34:01 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:34:01 --> Database Driver Class Initialized
INFO - 2017-05-03 12:34:01 --> Parser Class Initialized
DEBUG - 2017-05-03 12:34:01 --> Session Class Initialized
INFO - 2017-05-03 12:34:01 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:34:01 --> Session routines successfully run
INFO - 2017-05-03 12:34:01 --> Form Validation Class Initialized
INFO - 2017-05-03 12:34:01 --> Controller Class Initialized
DEBUG - 2017-05-03 12:34:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:34:01 --> Model Class Initialized
DEBUG - 2017-05-03 12:34:01 --> Pagination Class Initialized
INFO - 2017-05-03 12:34:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:34:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2017-05-03 12:34:01 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
INFO - 2017-05-03 12:34:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/plan/list_plan.php
INFO - 2017-05-03 12:34:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:34:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:34:01 --> Final output sent to browser
DEBUG - 2017-05-03 12:34:01 --> Total execution time: 0.3392
INFO - 2017-05-03 12:34:04 --> Config Class Initialized
INFO - 2017-05-03 12:34:04 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:34:04 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:34:04 --> Utf8 Class Initialized
INFO - 2017-05-03 12:34:04 --> URI Class Initialized
INFO - 2017-05-03 12:34:04 --> Router Class Initialized
INFO - 2017-05-03 12:34:04 --> Output Class Initialized
INFO - 2017-05-03 12:34:04 --> Security Class Initialized
DEBUG - 2017-05-03 12:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:34:04 --> Input Class Initialized
INFO - 2017-05-03 12:34:04 --> Language Class Initialized
INFO - 2017-05-03 12:34:04 --> Loader Class Initialized
INFO - 2017-05-03 12:34:04 --> Helper loaded: url_helper
INFO - 2017-05-03 12:34:04 --> Helper loaded: form_helper
INFO - 2017-05-03 12:34:04 --> Helper loaded: html_helper
INFO - 2017-05-03 12:34:04 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:34:04 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:34:04 --> Database Driver Class Initialized
INFO - 2017-05-03 12:34:04 --> Parser Class Initialized
DEBUG - 2017-05-03 12:34:04 --> Session Class Initialized
INFO - 2017-05-03 12:34:04 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:34:04 --> Session routines successfully run
INFO - 2017-05-03 12:34:04 --> Form Validation Class Initialized
INFO - 2017-05-03 12:34:04 --> Controller Class Initialized
DEBUG - 2017-05-03 12:34:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:34:04 --> Model Class Initialized
DEBUG - 2017-05-03 12:34:04 --> Pagination Class Initialized
INFO - 2017-05-03 12:34:04 --> Config Class Initialized
INFO - 2017-05-03 12:34:04 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:34:04 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:34:04 --> Utf8 Class Initialized
INFO - 2017-05-03 12:34:04 --> URI Class Initialized
INFO - 2017-05-03 12:34:04 --> Router Class Initialized
INFO - 2017-05-03 12:34:04 --> Output Class Initialized
INFO - 2017-05-03 12:34:04 --> Security Class Initialized
DEBUG - 2017-05-03 12:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:34:04 --> Input Class Initialized
INFO - 2017-05-03 12:34:04 --> Language Class Initialized
INFO - 2017-05-03 12:34:04 --> Loader Class Initialized
INFO - 2017-05-03 12:34:04 --> Helper loaded: url_helper
INFO - 2017-05-03 12:34:04 --> Helper loaded: form_helper
INFO - 2017-05-03 12:34:04 --> Helper loaded: html_helper
INFO - 2017-05-03 12:34:04 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:34:04 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:34:04 --> Database Driver Class Initialized
INFO - 2017-05-03 12:34:04 --> Parser Class Initialized
DEBUG - 2017-05-03 12:34:04 --> Session Class Initialized
INFO - 2017-05-03 12:34:04 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:34:04 --> Session routines successfully run
INFO - 2017-05-03 12:34:04 --> Form Validation Class Initialized
INFO - 2017-05-03 12:34:04 --> Controller Class Initialized
DEBUG - 2017-05-03 12:34:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:34:04 --> Model Class Initialized
DEBUG - 2017-05-03 12:34:04 --> Pagination Class Initialized
INFO - 2017-05-03 12:34:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:34:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:34:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:34:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:34:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:34:04 --> Final output sent to browser
DEBUG - 2017-05-03 12:34:04 --> Total execution time: 0.2586
INFO - 2017-05-03 12:34:10 --> Config Class Initialized
INFO - 2017-05-03 12:34:10 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:34:10 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:34:10 --> Utf8 Class Initialized
INFO - 2017-05-03 12:34:10 --> URI Class Initialized
INFO - 2017-05-03 12:34:10 --> Router Class Initialized
INFO - 2017-05-03 12:34:10 --> Output Class Initialized
INFO - 2017-05-03 12:34:10 --> Security Class Initialized
DEBUG - 2017-05-03 12:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:34:10 --> Input Class Initialized
INFO - 2017-05-03 12:34:10 --> Language Class Initialized
INFO - 2017-05-03 12:34:10 --> Loader Class Initialized
INFO - 2017-05-03 12:34:10 --> Helper loaded: url_helper
INFO - 2017-05-03 12:34:10 --> Helper loaded: form_helper
INFO - 2017-05-03 12:34:10 --> Helper loaded: html_helper
INFO - 2017-05-03 12:34:10 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:34:10 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:34:10 --> Database Driver Class Initialized
INFO - 2017-05-03 12:34:10 --> Parser Class Initialized
DEBUG - 2017-05-03 12:34:10 --> Session Class Initialized
INFO - 2017-05-03 12:34:10 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:34:10 --> Session routines successfully run
INFO - 2017-05-03 12:34:10 --> Form Validation Class Initialized
INFO - 2017-05-03 12:34:10 --> Controller Class Initialized
DEBUG - 2017-05-03 12:34:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:34:10 --> Model Class Initialized
DEBUG - 2017-05-03 12:34:10 --> Pagination Class Initialized
INFO - 2017-05-03 12:34:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:34:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:34:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:34:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:34:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:34:10 --> Final output sent to browser
DEBUG - 2017-05-03 12:34:10 --> Total execution time: 0.2441
INFO - 2017-05-03 12:34:13 --> Config Class Initialized
INFO - 2017-05-03 12:34:13 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:34:13 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:34:13 --> Utf8 Class Initialized
INFO - 2017-05-03 12:34:13 --> URI Class Initialized
INFO - 2017-05-03 12:34:13 --> Router Class Initialized
INFO - 2017-05-03 12:34:13 --> Output Class Initialized
INFO - 2017-05-03 12:34:13 --> Security Class Initialized
DEBUG - 2017-05-03 12:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:34:13 --> Input Class Initialized
INFO - 2017-05-03 12:34:13 --> Language Class Initialized
INFO - 2017-05-03 12:34:13 --> Loader Class Initialized
INFO - 2017-05-03 12:34:13 --> Helper loaded: url_helper
INFO - 2017-05-03 12:34:13 --> Helper loaded: form_helper
INFO - 2017-05-03 12:34:13 --> Helper loaded: html_helper
INFO - 2017-05-03 12:34:13 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:34:13 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:34:13 --> Database Driver Class Initialized
INFO - 2017-05-03 12:34:13 --> Parser Class Initialized
DEBUG - 2017-05-03 12:34:13 --> Session Class Initialized
INFO - 2017-05-03 12:34:13 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:34:13 --> Session routines successfully run
INFO - 2017-05-03 12:34:13 --> Form Validation Class Initialized
INFO - 2017-05-03 12:34:13 --> Controller Class Initialized
DEBUG - 2017-05-03 12:34:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 12:34:13 --> Model Class Initialized
DEBUG - 2017-05-03 12:34:13 --> Pagination Class Initialized
INFO - 2017-05-03 12:34:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-03 12:34:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-03 12:34:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-03 12:34:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-03 12:34:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:34:13 --> Final output sent to browser
DEBUG - 2017-05-03 12:34:13 --> Total execution time: 0.2424
INFO - 2017-05-03 12:34:18 --> Config Class Initialized
INFO - 2017-05-03 12:34:18 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:34:18 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:34:18 --> Utf8 Class Initialized
INFO - 2017-05-03 12:34:18 --> URI Class Initialized
INFO - 2017-05-03 12:34:18 --> Router Class Initialized
INFO - 2017-05-03 12:34:18 --> Output Class Initialized
INFO - 2017-05-03 12:34:18 --> Security Class Initialized
DEBUG - 2017-05-03 12:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:34:18 --> Input Class Initialized
INFO - 2017-05-03 12:34:18 --> Language Class Initialized
INFO - 2017-05-03 12:34:18 --> Loader Class Initialized
INFO - 2017-05-03 12:34:18 --> Helper loaded: url_helper
INFO - 2017-05-03 12:34:18 --> Helper loaded: form_helper
INFO - 2017-05-03 12:34:18 --> Helper loaded: html_helper
INFO - 2017-05-03 12:34:18 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:34:18 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:34:18 --> Database Driver Class Initialized
INFO - 2017-05-03 12:34:18 --> Parser Class Initialized
DEBUG - 2017-05-03 12:34:18 --> Session Class Initialized
INFO - 2017-05-03 12:34:18 --> Helper loaded: string_helper
DEBUG - 2017-05-03 12:34:18 --> Session routines successfully run
INFO - 2017-05-03 12:34:18 --> Form Validation Class Initialized
INFO - 2017-05-03 12:34:18 --> Controller Class Initialized
INFO - 2017-05-03 12:34:18 --> Model Class Initialized
INFO - 2017-05-03 12:34:18 --> Config Class Initialized
INFO - 2017-05-03 12:34:18 --> Hooks Class Initialized
DEBUG - 2017-05-03 12:34:18 --> UTF-8 Support Enabled
INFO - 2017-05-03 12:34:18 --> Utf8 Class Initialized
INFO - 2017-05-03 12:34:18 --> URI Class Initialized
INFO - 2017-05-03 12:34:18 --> Router Class Initialized
INFO - 2017-05-03 12:34:18 --> Output Class Initialized
INFO - 2017-05-03 12:34:18 --> Security Class Initialized
DEBUG - 2017-05-03 12:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 12:34:18 --> Input Class Initialized
INFO - 2017-05-03 12:34:18 --> Language Class Initialized
INFO - 2017-05-03 12:34:18 --> Loader Class Initialized
INFO - 2017-05-03 12:34:18 --> Helper loaded: url_helper
INFO - 2017-05-03 12:34:18 --> Helper loaded: form_helper
INFO - 2017-05-03 12:34:18 --> Helper loaded: html_helper
INFO - 2017-05-03 12:34:18 --> Helper loaded: custom_helper
INFO - 2017-05-03 12:34:18 --> Helper loaded: cache_helper
INFO - 2017-05-03 12:34:18 --> Database Driver Class Initialized
INFO - 2017-05-03 12:34:18 --> Parser Class Initialized
DEBUG - 2017-05-03 12:34:18 --> Session Class Initialized
INFO - 2017-05-03 12:34:18 --> Helper loaded: string_helper
ERROR - 2017-05-03 12:34:18 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-03 12:34:18 --> Session routines successfully run
INFO - 2017-05-03 12:34:18 --> Form Validation Class Initialized
INFO - 2017-05-03 12:34:18 --> Controller Class Initialized
INFO - 2017-05-03 12:34:18 --> Model Class Initialized
INFO - 2017-05-03 12:34:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-03 12:34:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 12:34:18 --> Final output sent to browser
DEBUG - 2017-05-03 12:34:18 --> Total execution time: 0.2037
INFO - 2017-05-03 13:17:01 --> Config Class Initialized
INFO - 2017-05-03 13:17:02 --> Hooks Class Initialized
DEBUG - 2017-05-03 13:17:02 --> UTF-8 Support Enabled
INFO - 2017-05-03 13:17:02 --> Utf8 Class Initialized
INFO - 2017-05-03 13:17:02 --> URI Class Initialized
INFO - 2017-05-03 13:17:02 --> Router Class Initialized
INFO - 2017-05-03 13:17:02 --> Output Class Initialized
INFO - 2017-05-03 13:17:02 --> Security Class Initialized
DEBUG - 2017-05-03 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 13:17:02 --> Input Class Initialized
INFO - 2017-05-03 13:17:02 --> Language Class Initialized
INFO - 2017-05-03 13:17:02 --> Loader Class Initialized
INFO - 2017-05-03 13:17:02 --> Helper loaded: url_helper
INFO - 2017-05-03 13:17:02 --> Helper loaded: form_helper
INFO - 2017-05-03 13:17:02 --> Helper loaded: html_helper
INFO - 2017-05-03 13:17:02 --> Helper loaded: custom_helper
INFO - 2017-05-03 13:17:02 --> Helper loaded: cache_helper
INFO - 2017-05-03 13:17:02 --> Database Driver Class Initialized
INFO - 2017-05-03 13:17:02 --> Parser Class Initialized
DEBUG - 2017-05-03 13:17:02 --> Session Class Initialized
INFO - 2017-05-03 13:17:02 --> Helper loaded: string_helper
ERROR - 2017-05-03 13:17:02 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-03 13:17:02 --> Session routines successfully run
INFO - 2017-05-03 13:17:02 --> Form Validation Class Initialized
INFO - 2017-05-03 13:17:02 --> Controller Class Initialized
DEBUG - 2017-05-03 13:17:02 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-03 13:17:02 --> Model Class Initialized
DEBUG - 2017-05-03 13:17:02 --> Pagination Class Initialized
INFO - 2017-05-03 13:17:02 --> Config Class Initialized
INFO - 2017-05-03 13:17:02 --> Hooks Class Initialized
DEBUG - 2017-05-03 13:17:02 --> UTF-8 Support Enabled
INFO - 2017-05-03 13:17:02 --> Utf8 Class Initialized
INFO - 2017-05-03 13:17:02 --> URI Class Initialized
INFO - 2017-05-03 13:17:02 --> Router Class Initialized
INFO - 2017-05-03 13:17:02 --> Output Class Initialized
INFO - 2017-05-03 13:17:02 --> Security Class Initialized
DEBUG - 2017-05-03 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-03 13:17:02 --> Input Class Initialized
INFO - 2017-05-03 13:17:02 --> Language Class Initialized
INFO - 2017-05-03 13:17:02 --> Loader Class Initialized
INFO - 2017-05-03 13:17:02 --> Helper loaded: url_helper
INFO - 2017-05-03 13:17:02 --> Helper loaded: form_helper
INFO - 2017-05-03 13:17:02 --> Helper loaded: html_helper
INFO - 2017-05-03 13:17:02 --> Helper loaded: custom_helper
INFO - 2017-05-03 13:17:02 --> Helper loaded: cache_helper
INFO - 2017-05-03 13:17:02 --> Database Driver Class Initialized
INFO - 2017-05-03 13:17:02 --> Parser Class Initialized
DEBUG - 2017-05-03 13:17:02 --> Session Class Initialized
INFO - 2017-05-03 13:17:02 --> Helper loaded: string_helper
ERROR - 2017-05-03 13:17:02 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-03 13:17:02 --> Session routines successfully run
INFO - 2017-05-03 13:17:02 --> Form Validation Class Initialized
INFO - 2017-05-03 13:17:02 --> Controller Class Initialized
INFO - 2017-05-03 13:17:02 --> Model Class Initialized
INFO - 2017-05-03 13:17:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-03 13:17:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-03 13:17:02 --> Final output sent to browser
DEBUG - 2017-05-03 13:17:02 --> Total execution time: 0.2108
