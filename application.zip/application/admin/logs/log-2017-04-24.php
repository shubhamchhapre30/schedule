INFO - 2017-04-24 14:56:50 --> Config Class Initialized
INFO - 2017-04-24 14:56:50 --> Hooks Class Initialized
DEBUG - 2017-04-24 14:56:50 --> UTF-8 Support Enabled
INFO - 2017-04-24 14:56:50 --> Utf8 Class Initialized
INFO - 2017-04-24 14:56:50 --> URI Class Initialized
INFO - 2017-04-24 14:56:50 --> Router Class Initialized
INFO - 2017-04-24 14:56:50 --> Output Class Initialized
INFO - 2017-04-24 14:56:50 --> Security Class Initialized
DEBUG - 2017-04-24 14:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-24 14:56:50 --> Input Class Initialized
INFO - 2017-04-24 14:56:50 --> Language Class Initialized
INFO - 2017-04-24 14:56:50 --> Loader Class Initialized
INFO - 2017-04-24 14:56:50 --> Helper loaded: url_helper
INFO - 2017-04-24 14:56:50 --> Helper loaded: form_helper
INFO - 2017-04-24 14:56:50 --> Helper loaded: html_helper
INFO - 2017-04-24 14:56:50 --> Helper loaded: custom_helper
INFO - 2017-04-24 14:56:50 --> Helper loaded: cache_helper
INFO - 2017-04-24 14:56:50 --> Database Driver Class Initialized
INFO - 2017-04-24 14:56:50 --> Parser Class Initialized
DEBUG - 2017-04-24 14:56:50 --> Session Class Initialized
INFO - 2017-04-24 14:56:50 --> Helper loaded: string_helper
DEBUG - 2017-04-24 14:56:50 --> Session routines successfully run
INFO - 2017-04-24 14:56:50 --> Form Validation Class Initialized
INFO - 2017-04-24 14:56:50 --> Controller Class Initialized
INFO - 2017-04-24 14:56:50 --> Model Class Initialized
INFO - 2017-04-24 14:56:50 --> Config Class Initialized
INFO - 2017-04-24 14:56:50 --> Hooks Class Initialized
DEBUG - 2017-04-24 14:56:50 --> UTF-8 Support Enabled
INFO - 2017-04-24 14:56:50 --> Utf8 Class Initialized
INFO - 2017-04-24 14:56:50 --> URI Class Initialized
INFO - 2017-04-24 14:56:50 --> Router Class Initialized
INFO - 2017-04-24 14:56:50 --> Output Class Initialized
INFO - 2017-04-24 14:56:50 --> Security Class Initialized
DEBUG - 2017-04-24 14:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-24 14:56:50 --> Input Class Initialized
INFO - 2017-04-24 14:56:50 --> Language Class Initialized
INFO - 2017-04-24 14:56:50 --> Loader Class Initialized
INFO - 2017-04-24 14:56:50 --> Helper loaded: url_helper
INFO - 2017-04-24 14:56:50 --> Helper loaded: form_helper
INFO - 2017-04-24 14:56:50 --> Helper loaded: html_helper
INFO - 2017-04-24 14:56:50 --> Helper loaded: custom_helper
INFO - 2017-04-24 14:56:50 --> Helper loaded: cache_helper
INFO - 2017-04-24 14:56:50 --> Database Driver Class Initialized
INFO - 2017-04-24 14:56:50 --> Parser Class Initialized
DEBUG - 2017-04-24 14:56:50 --> Session Class Initialized
INFO - 2017-04-24 14:56:50 --> Helper loaded: string_helper
DEBUG - 2017-04-24 14:56:50 --> Session routines successfully run
INFO - 2017-04-24 14:56:50 --> Form Validation Class Initialized
INFO - 2017-04-24 14:56:50 --> Controller Class Initialized
INFO - 2017-04-24 14:56:50 --> Model Class Initialized
ERROR - 2017-04-24 14:56:50 --> Severity: Notice --> Undefined property: EmailTemplate::$EmailTemplate_model C:\xampp\htdocs\schedullo\application\admin\controllers\EmailTemplate.php 74
INFO - 2017-04-24 14:57:01 --> Config Class Initialized
INFO - 2017-04-24 14:57:01 --> Hooks Class Initialized
DEBUG - 2017-04-24 14:57:01 --> UTF-8 Support Enabled
INFO - 2017-04-24 14:57:01 --> Utf8 Class Initialized
INFO - 2017-04-24 14:57:01 --> URI Class Initialized
INFO - 2017-04-24 14:57:01 --> Router Class Initialized
INFO - 2017-04-24 14:57:01 --> Output Class Initialized
INFO - 2017-04-24 14:57:01 --> Security Class Initialized
DEBUG - 2017-04-24 14:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-24 14:57:01 --> Input Class Initialized
INFO - 2017-04-24 14:57:01 --> Language Class Initialized
INFO - 2017-04-24 14:57:01 --> Loader Class Initialized
INFO - 2017-04-24 14:57:01 --> Helper loaded: url_helper
INFO - 2017-04-24 14:57:01 --> Helper loaded: form_helper
INFO - 2017-04-24 14:57:01 --> Helper loaded: html_helper
INFO - 2017-04-24 14:57:01 --> Helper loaded: custom_helper
INFO - 2017-04-24 14:57:01 --> Helper loaded: cache_helper
INFO - 2017-04-24 14:57:01 --> Database Driver Class Initialized
INFO - 2017-04-24 14:57:01 --> Parser Class Initialized
DEBUG - 2017-04-24 14:57:01 --> Session Class Initialized
INFO - 2017-04-24 14:57:01 --> Helper loaded: string_helper
DEBUG - 2017-04-24 14:57:01 --> Session routines successfully run
INFO - 2017-04-24 14:57:01 --> Form Validation Class Initialized
INFO - 2017-04-24 14:57:01 --> Controller Class Initialized
INFO - 2017-04-24 14:57:02 --> Model Class Initialized
DEBUG - 2017-04-24 14:57:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-24 14:57:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
ERROR - 2017-04-24 14:57:02 --> Severity: Notice --> Undefined variable: site_version C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 79
ERROR - 2017-04-24 14:57:02 --> Severity: Notice --> Undefined variable: google_map_key C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 146
ERROR - 2017-04-24 14:57:02 --> Severity: Notice --> Undefined variable: default_longitude C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 153
ERROR - 2017-04-24 14:57:02 --> Severity: Notice --> Undefined variable: default_latitude C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 160
ERROR - 2017-04-24 14:57:02 --> Severity: Notice --> Undefined variable: order_cancellation_time C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 177
ERROR - 2017-04-24 14:57:02 --> Severity: Notice --> Undefined variable: order_close_time C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 182
ERROR - 2017-04-24 14:57:02 --> Severity: Notice --> Undefined variable: facebook_link C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 195
ERROR - 2017-04-24 14:57:02 --> Severity: Notice --> Undefined variable: twitter_link C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 202
ERROR - 2017-04-24 14:57:02 --> Severity: Notice --> Undefined variable: instagram_link C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 208
ERROR - 2017-04-24 14:57:02 --> Severity: Notice --> Undefined variable: skype_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 215
INFO - 2017-04-24 14:57:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/setting/add_site.php
INFO - 2017-04-24 14:57:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-24 14:57:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-24 14:57:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-24 14:57:02 --> Final output sent to browser
DEBUG - 2017-04-24 14:57:02 --> Total execution time: 0.1948
INFO - 2017-04-24 14:57:03 --> Config Class Initialized
INFO - 2017-04-24 14:57:03 --> Hooks Class Initialized
DEBUG - 2017-04-24 14:57:03 --> UTF-8 Support Enabled
INFO - 2017-04-24 14:57:03 --> Utf8 Class Initialized
INFO - 2017-04-24 14:57:03 --> URI Class Initialized
INFO - 2017-04-24 14:57:03 --> Router Class Initialized
INFO - 2017-04-24 14:57:03 --> Output Class Initialized
INFO - 2017-04-24 14:57:03 --> Security Class Initialized
DEBUG - 2017-04-24 14:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-24 14:57:03 --> Input Class Initialized
INFO - 2017-04-24 14:57:03 --> Language Class Initialized
INFO - 2017-04-24 14:57:03 --> Loader Class Initialized
INFO - 2017-04-24 14:57:03 --> Helper loaded: url_helper
INFO - 2017-04-24 14:57:03 --> Helper loaded: form_helper
INFO - 2017-04-24 14:57:03 --> Helper loaded: html_helper
INFO - 2017-04-24 14:57:03 --> Helper loaded: custom_helper
INFO - 2017-04-24 14:57:03 --> Helper loaded: cache_helper
INFO - 2017-04-24 14:57:03 --> Database Driver Class Initialized
INFO - 2017-04-24 14:57:03 --> Parser Class Initialized
DEBUG - 2017-04-24 14:57:03 --> Session Class Initialized
INFO - 2017-04-24 14:57:03 --> Helper loaded: string_helper
DEBUG - 2017-04-24 14:57:03 --> Session routines successfully run
INFO - 2017-04-24 14:57:03 --> Form Validation Class Initialized
INFO - 2017-04-24 14:57:03 --> Controller Class Initialized
INFO - 2017-04-24 14:57:03 --> Model Class Initialized
INFO - 2017-04-24 14:57:03 --> Config Class Initialized
INFO - 2017-04-24 14:57:03 --> Hooks Class Initialized
DEBUG - 2017-04-24 14:57:03 --> UTF-8 Support Enabled
INFO - 2017-04-24 14:57:03 --> Utf8 Class Initialized
INFO - 2017-04-24 14:57:03 --> URI Class Initialized
INFO - 2017-04-24 14:57:03 --> Router Class Initialized
INFO - 2017-04-24 14:57:03 --> Output Class Initialized
INFO - 2017-04-24 14:57:03 --> Security Class Initialized
DEBUG - 2017-04-24 14:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-24 14:57:03 --> Input Class Initialized
INFO - 2017-04-24 14:57:03 --> Language Class Initialized
INFO - 2017-04-24 14:57:03 --> Loader Class Initialized
INFO - 2017-04-24 14:57:03 --> Helper loaded: url_helper
INFO - 2017-04-24 14:57:03 --> Helper loaded: form_helper
INFO - 2017-04-24 14:57:03 --> Helper loaded: html_helper
INFO - 2017-04-24 14:57:03 --> Helper loaded: custom_helper
INFO - 2017-04-24 14:57:03 --> Helper loaded: cache_helper
INFO - 2017-04-24 14:57:03 --> Database Driver Class Initialized
INFO - 2017-04-24 14:57:03 --> Parser Class Initialized
DEBUG - 2017-04-24 14:57:03 --> Session Class Initialized
INFO - 2017-04-24 14:57:03 --> Helper loaded: string_helper
DEBUG - 2017-04-24 14:57:03 --> Session routines successfully run
INFO - 2017-04-24 14:57:03 --> Form Validation Class Initialized
INFO - 2017-04-24 14:57:03 --> Controller Class Initialized
INFO - 2017-04-24 14:57:03 --> Model Class Initialized
ERROR - 2017-04-24 14:57:03 --> Severity: Notice --> Undefined property: EmailTemplate::$EmailTemplate_model C:\xampp\htdocs\schedullo\application\admin\controllers\EmailTemplate.php 74
INFO - 2017-04-24 15:00:20 --> Config Class Initialized
INFO - 2017-04-24 15:00:20 --> Hooks Class Initialized
DEBUG - 2017-04-24 15:00:20 --> UTF-8 Support Enabled
INFO - 2017-04-24 15:00:20 --> Utf8 Class Initialized
INFO - 2017-04-24 15:00:20 --> URI Class Initialized
INFO - 2017-04-24 15:00:20 --> Router Class Initialized
INFO - 2017-04-24 15:00:20 --> Output Class Initialized
INFO - 2017-04-24 15:00:20 --> Security Class Initialized
DEBUG - 2017-04-24 15:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-24 15:00:20 --> Input Class Initialized
INFO - 2017-04-24 15:00:20 --> Language Class Initialized
INFO - 2017-04-24 15:00:20 --> Loader Class Initialized
INFO - 2017-04-24 15:00:20 --> Helper loaded: url_helper
INFO - 2017-04-24 15:00:20 --> Helper loaded: form_helper
INFO - 2017-04-24 15:00:20 --> Helper loaded: html_helper
INFO - 2017-04-24 15:00:20 --> Helper loaded: custom_helper
INFO - 2017-04-24 15:00:20 --> Helper loaded: cache_helper
INFO - 2017-04-24 15:00:20 --> Database Driver Class Initialized
INFO - 2017-04-24 15:00:20 --> Parser Class Initialized
DEBUG - 2017-04-24 15:00:20 --> Session Class Initialized
INFO - 2017-04-24 15:00:20 --> Helper loaded: string_helper
DEBUG - 2017-04-24 15:00:20 --> Session routines successfully run
INFO - 2017-04-24 15:00:20 --> Form Validation Class Initialized
INFO - 2017-04-24 15:00:20 --> Controller Class Initialized
INFO - 2017-04-24 15:00:20 --> Model Class Initialized
ERROR - 2017-04-24 15:00:20 --> Severity: Notice --> Undefined property: EmailTemplate::$EmailTemplate_model C:\xampp\htdocs\schedullo\application\admin\controllers\EmailTemplate.php 74
INFO - 2017-04-24 15:08:08 --> Config Class Initialized
INFO - 2017-04-24 15:08:08 --> Hooks Class Initialized
DEBUG - 2017-04-24 15:08:08 --> UTF-8 Support Enabled
INFO - 2017-04-24 15:08:08 --> Utf8 Class Initialized
INFO - 2017-04-24 15:08:08 --> URI Class Initialized
INFO - 2017-04-24 15:08:08 --> Router Class Initialized
INFO - 2017-04-24 15:08:08 --> Output Class Initialized
INFO - 2017-04-24 15:08:08 --> Security Class Initialized
DEBUG - 2017-04-24 15:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-24 15:08:08 --> Input Class Initialized
INFO - 2017-04-24 15:08:08 --> Language Class Initialized
INFO - 2017-04-24 15:08:08 --> Loader Class Initialized
INFO - 2017-04-24 15:08:08 --> Helper loaded: url_helper
INFO - 2017-04-24 15:08:08 --> Helper loaded: form_helper
INFO - 2017-04-24 15:08:08 --> Helper loaded: html_helper
INFO - 2017-04-24 15:08:08 --> Helper loaded: custom_helper
INFO - 2017-04-24 15:08:08 --> Helper loaded: cache_helper
INFO - 2017-04-24 15:08:08 --> Database Driver Class Initialized
INFO - 2017-04-24 15:08:08 --> Parser Class Initialized
DEBUG - 2017-04-24 15:08:08 --> Session Class Initialized
INFO - 2017-04-24 15:08:08 --> Helper loaded: string_helper
DEBUG - 2017-04-24 15:08:08 --> Session routines successfully run
INFO - 2017-04-24 15:08:08 --> Form Validation Class Initialized
INFO - 2017-04-24 15:08:08 --> Controller Class Initialized
INFO - 2017-04-24 15:08:08 --> Model Class Initialized
INFO - 2017-04-24 15:08:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-24 15:08:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-24 15:08:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2017-04-24 15:08:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-24 15:08:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-24 15:08:08 --> Final output sent to browser
DEBUG - 2017-04-24 15:08:09 --> Total execution time: 0.3559
INFO - 2017-04-24 15:14:04 --> Config Class Initialized
INFO - 2017-04-24 15:14:04 --> Hooks Class Initialized
DEBUG - 2017-04-24 15:14:04 --> UTF-8 Support Enabled
INFO - 2017-04-24 15:14:04 --> Utf8 Class Initialized
INFO - 2017-04-24 15:14:04 --> URI Class Initialized
INFO - 2017-04-24 15:14:04 --> Router Class Initialized
INFO - 2017-04-24 15:14:04 --> Output Class Initialized
INFO - 2017-04-24 15:14:04 --> Security Class Initialized
DEBUG - 2017-04-24 15:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-24 15:14:04 --> Input Class Initialized
INFO - 2017-04-24 15:14:04 --> Language Class Initialized
INFO - 2017-04-24 15:14:04 --> Loader Class Initialized
INFO - 2017-04-24 15:14:04 --> Helper loaded: url_helper
INFO - 2017-04-24 15:14:04 --> Helper loaded: form_helper
INFO - 2017-04-24 15:14:04 --> Helper loaded: html_helper
INFO - 2017-04-24 15:14:04 --> Helper loaded: custom_helper
INFO - 2017-04-24 15:14:04 --> Helper loaded: cache_helper
INFO - 2017-04-24 15:14:04 --> Database Driver Class Initialized
INFO - 2017-04-24 15:14:04 --> Parser Class Initialized
DEBUG - 2017-04-24 15:14:04 --> Session Class Initialized
INFO - 2017-04-24 15:14:04 --> Helper loaded: string_helper
DEBUG - 2017-04-24 15:14:04 --> Session routines successfully run
INFO - 2017-04-24 15:14:04 --> Form Validation Class Initialized
INFO - 2017-04-24 15:14:04 --> Controller Class Initialized
INFO - 2017-04-24 15:14:04 --> Model Class Initialized
INFO - 2017-04-24 15:14:04 --> Config Class Initialized
INFO - 2017-04-24 15:14:04 --> Hooks Class Initialized
DEBUG - 2017-04-24 15:14:04 --> UTF-8 Support Enabled
INFO - 2017-04-24 15:14:04 --> Utf8 Class Initialized
INFO - 2017-04-24 15:14:04 --> URI Class Initialized
INFO - 2017-04-24 15:14:04 --> Router Class Initialized
INFO - 2017-04-24 15:14:04 --> Output Class Initialized
INFO - 2017-04-24 15:14:04 --> Security Class Initialized
DEBUG - 2017-04-24 15:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-24 15:14:04 --> Input Class Initialized
INFO - 2017-04-24 15:14:04 --> Language Class Initialized
INFO - 2017-04-24 15:14:04 --> Loader Class Initialized
INFO - 2017-04-24 15:14:04 --> Helper loaded: url_helper
INFO - 2017-04-24 15:14:04 --> Helper loaded: form_helper
INFO - 2017-04-24 15:14:04 --> Helper loaded: html_helper
INFO - 2017-04-24 15:14:04 --> Helper loaded: custom_helper
INFO - 2017-04-24 15:14:04 --> Helper loaded: cache_helper
INFO - 2017-04-24 15:14:04 --> Database Driver Class Initialized
INFO - 2017-04-24 15:14:04 --> Parser Class Initialized
DEBUG - 2017-04-24 15:14:04 --> Session Class Initialized
INFO - 2017-04-24 15:14:04 --> Helper loaded: string_helper
DEBUG - 2017-04-24 15:14:04 --> Session routines successfully run
INFO - 2017-04-24 15:14:04 --> Form Validation Class Initialized
INFO - 2017-04-24 15:14:04 --> Controller Class Initialized
INFO - 2017-04-24 15:14:04 --> Model Class Initialized
INFO - 2017-04-24 15:14:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-24 15:14:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-24 15:14:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2017-04-24 15:14:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-24 15:14:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-24 15:14:04 --> Final output sent to browser
DEBUG - 2017-04-24 15:14:04 --> Total execution time: 0.1385
INFO - 2017-04-24 15:14:21 --> Config Class Initialized
INFO - 2017-04-24 15:14:21 --> Hooks Class Initialized
DEBUG - 2017-04-24 15:14:21 --> UTF-8 Support Enabled
INFO - 2017-04-24 15:14:21 --> Utf8 Class Initialized
INFO - 2017-04-24 15:14:21 --> URI Class Initialized
INFO - 2017-04-24 15:14:21 --> Router Class Initialized
INFO - 2017-04-24 15:14:21 --> Output Class Initialized
INFO - 2017-04-24 15:14:21 --> Security Class Initialized
DEBUG - 2017-04-24 15:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-24 15:14:21 --> Input Class Initialized
INFO - 2017-04-24 15:14:21 --> Language Class Initialized
INFO - 2017-04-24 15:14:21 --> Loader Class Initialized
INFO - 2017-04-24 15:14:21 --> Helper loaded: url_helper
INFO - 2017-04-24 15:14:21 --> Helper loaded: form_helper
INFO - 2017-04-24 15:14:21 --> Helper loaded: html_helper
INFO - 2017-04-24 15:14:21 --> Helper loaded: custom_helper
INFO - 2017-04-24 15:14:21 --> Helper loaded: cache_helper
INFO - 2017-04-24 15:14:21 --> Database Driver Class Initialized
INFO - 2017-04-24 15:14:21 --> Parser Class Initialized
DEBUG - 2017-04-24 15:14:21 --> Session Class Initialized
INFO - 2017-04-24 15:14:21 --> Helper loaded: string_helper
DEBUG - 2017-04-24 15:14:21 --> Session routines successfully run
INFO - 2017-04-24 15:14:21 --> Form Validation Class Initialized
INFO - 2017-04-24 15:14:21 --> Controller Class Initialized
INFO - 2017-04-24 15:14:21 --> Model Class Initialized
INFO - 2017-04-24 15:14:21 --> Config Class Initialized
INFO - 2017-04-24 15:14:21 --> Hooks Class Initialized
DEBUG - 2017-04-24 15:14:21 --> UTF-8 Support Enabled
INFO - 2017-04-24 15:14:21 --> Utf8 Class Initialized
INFO - 2017-04-24 15:14:21 --> URI Class Initialized
INFO - 2017-04-24 15:14:21 --> Router Class Initialized
INFO - 2017-04-24 15:14:21 --> Output Class Initialized
INFO - 2017-04-24 15:14:21 --> Security Class Initialized
DEBUG - 2017-04-24 15:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-24 15:14:21 --> Input Class Initialized
INFO - 2017-04-24 15:14:21 --> Language Class Initialized
INFO - 2017-04-24 15:14:21 --> Loader Class Initialized
INFO - 2017-04-24 15:14:21 --> Helper loaded: url_helper
INFO - 2017-04-24 15:14:21 --> Helper loaded: form_helper
INFO - 2017-04-24 15:14:21 --> Helper loaded: html_helper
INFO - 2017-04-24 15:14:21 --> Helper loaded: custom_helper
INFO - 2017-04-24 15:14:21 --> Helper loaded: cache_helper
INFO - 2017-04-24 15:14:21 --> Database Driver Class Initialized
INFO - 2017-04-24 15:14:21 --> Parser Class Initialized
DEBUG - 2017-04-24 15:14:21 --> Session Class Initialized
INFO - 2017-04-24 15:14:21 --> Helper loaded: string_helper
ERROR - 2017-04-24 15:14:21 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-24 15:14:21 --> Session routines successfully run
INFO - 2017-04-24 15:14:21 --> Form Validation Class Initialized
INFO - 2017-04-24 15:14:21 --> Controller Class Initialized
INFO - 2017-04-24 15:14:21 --> Model Class Initialized
INFO - 2017-04-24 15:14:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-24 15:14:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-24 15:14:21 --> Final output sent to browser
DEBUG - 2017-04-24 15:14:21 --> Total execution time: 0.1335
