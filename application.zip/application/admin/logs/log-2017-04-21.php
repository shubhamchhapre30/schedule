
INFO - 2017-04-21 14:43:36 --> Config Class Initialized
INFO - 2017-04-21 14:43:36 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:43:36 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:43:36 --> Utf8 Class Initialized
INFO - 2017-04-21 14:43:36 --> URI Class Initialized
DEBUG - 2017-04-21 14:43:36 --> No URI present. Default controller set.
INFO - 2017-04-21 14:43:36 --> Router Class Initialized
INFO - 2017-04-21 14:43:36 --> Output Class Initialized
INFO - 2017-04-21 14:43:36 --> Security Class Initialized
DEBUG - 2017-04-21 14:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:43:36 --> Input Class Initialized
INFO - 2017-04-21 14:43:36 --> Language Class Initialized
INFO - 2017-04-21 14:43:36 --> Loader Class Initialized
INFO - 2017-04-21 14:43:36 --> Helper loaded: url_helper
INFO - 2017-04-21 14:43:36 --> Helper loaded: form_helper
INFO - 2017-04-21 14:43:36 --> Helper loaded: html_helper
INFO - 2017-04-21 14:43:36 --> Helper loaded: custom_helper
INFO - 2017-04-21 14:43:36 --> Helper loaded: cache_helper
INFO - 2017-04-21 14:43:36 --> Database Driver Class Initialized
INFO - 2017-04-21 14:43:36 --> Parser Class Initialized
DEBUG - 2017-04-21 14:43:36 --> Session Class Initialized
INFO - 2017-04-21 14:43:36 --> Helper loaded: string_helper
DEBUG - 2017-04-21 14:43:36 --> Session routines successfully run
INFO - 2017-04-21 14:43:36 --> Form Validation Class Initialized
INFO - 2017-04-21 14:43:36 --> Controller Class Initialized
INFO - 2017-04-21 14:43:36 --> Model Class Initialized
INFO - 2017-04-21 14:43:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-21 14:43:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 14:43:36 --> Final output sent to browser
DEBUG - 2017-04-21 14:43:36 --> Total execution time: 0.2100
INFO - 2017-04-21 14:43:48 --> Config Class Initialized
INFO - 2017-04-21 14:43:48 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:43:48 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:43:48 --> Utf8 Class Initialized
INFO - 2017-04-21 14:43:48 --> URI Class Initialized
INFO - 2017-04-21 14:43:48 --> Router Class Initialized
INFO - 2017-04-21 14:43:48 --> Output Class Initialized
INFO - 2017-04-21 14:43:48 --> Security Class Initialized
DEBUG - 2017-04-21 14:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:43:48 --> Input Class Initialized
INFO - 2017-04-21 14:43:48 --> Language Class Initialized
ERROR - 2017-04-21 14:43:48 --> 404 Page Not Found: Schedullo/admin
INFO - 2017-04-21 14:51:04 --> Config Class Initialized
INFO - 2017-04-21 14:51:04 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:51:04 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:51:04 --> Utf8 Class Initialized
INFO - 2017-04-21 14:51:04 --> URI Class Initialized
INFO - 2017-04-21 14:51:04 --> Router Class Initialized
INFO - 2017-04-21 14:51:04 --> Output Class Initialized
INFO - 2017-04-21 14:51:04 --> Security Class Initialized
DEBUG - 2017-04-21 14:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:51:04 --> Input Class Initialized
INFO - 2017-04-21 14:51:04 --> Language Class Initialized
ERROR - 2017-04-21 14:51:04 --> 404 Page Not Found: Schedullo/admin
INFO - 2017-04-21 14:51:08 --> Config Class Initialized
INFO - 2017-04-21 14:51:08 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:51:08 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:51:08 --> Utf8 Class Initialized
INFO - 2017-04-21 14:51:08 --> URI Class Initialized
INFO - 2017-04-21 14:51:08 --> Router Class Initialized
INFO - 2017-04-21 14:51:08 --> Output Class Initialized
INFO - 2017-04-21 14:51:08 --> Security Class Initialized
DEBUG - 2017-04-21 14:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:51:08 --> Input Class Initialized
INFO - 2017-04-21 14:51:08 --> Language Class Initialized
ERROR - 2017-04-21 14:51:08 --> 404 Page Not Found: Schedullo/admin
INFO - 2017-04-21 14:51:39 --> Config Class Initialized
INFO - 2017-04-21 14:51:39 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:51:39 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:51:39 --> Utf8 Class Initialized
INFO - 2017-04-21 14:51:39 --> URI Class Initialized
DEBUG - 2017-04-21 14:51:39 --> No URI present. Default controller set.
INFO - 2017-04-21 14:51:39 --> Router Class Initialized
INFO - 2017-04-21 14:51:39 --> Output Class Initialized
INFO - 2017-04-21 14:51:39 --> Security Class Initialized
DEBUG - 2017-04-21 14:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:51:39 --> Input Class Initialized
INFO - 2017-04-21 14:51:39 --> Language Class Initialized
INFO - 2017-04-21 14:51:39 --> Loader Class Initialized
INFO - 2017-04-21 14:51:39 --> Helper loaded: url_helper
INFO - 2017-04-21 14:51:39 --> Helper loaded: form_helper
INFO - 2017-04-21 14:51:39 --> Helper loaded: html_helper
INFO - 2017-04-21 14:51:39 --> Helper loaded: custom_helper
INFO - 2017-04-21 14:51:39 --> Helper loaded: cache_helper
INFO - 2017-04-21 14:51:39 --> Database Driver Class Initialized
INFO - 2017-04-21 14:51:39 --> Parser Class Initialized
DEBUG - 2017-04-21 14:51:39 --> Session Class Initialized
INFO - 2017-04-21 14:51:39 --> Helper loaded: string_helper
ERROR - 2017-04-21 14:51:39 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-21 14:51:39 --> Session routines successfully run
INFO - 2017-04-21 14:51:39 --> Form Validation Class Initialized
INFO - 2017-04-21 14:51:39 --> Controller Class Initialized
INFO - 2017-04-21 14:51:39 --> Model Class Initialized
INFO - 2017-04-21 14:51:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-21 14:51:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 14:51:39 --> Final output sent to browser
DEBUG - 2017-04-21 14:51:39 --> Total execution time: 0.1488
INFO - 2017-04-21 14:51:52 --> Config Class Initialized
INFO - 2017-04-21 14:51:52 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:51:52 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:51:52 --> Utf8 Class Initialized
INFO - 2017-04-21 14:51:52 --> URI Class Initialized
INFO - 2017-04-21 14:51:52 --> Router Class Initialized
INFO - 2017-04-21 14:51:52 --> Output Class Initialized
INFO - 2017-04-21 14:51:52 --> Security Class Initialized
DEBUG - 2017-04-21 14:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:51:52 --> Input Class Initialized
INFO - 2017-04-21 14:51:52 --> Language Class Initialized
INFO - 2017-04-21 14:51:52 --> Loader Class Initialized
INFO - 2017-04-21 14:51:52 --> Helper loaded: url_helper
INFO - 2017-04-21 14:51:52 --> Helper loaded: form_helper
INFO - 2017-04-21 14:51:52 --> Helper loaded: html_helper
INFO - 2017-04-21 14:51:52 --> Helper loaded: custom_helper
INFO - 2017-04-21 14:51:52 --> Helper loaded: cache_helper
INFO - 2017-04-21 14:51:52 --> Database Driver Class Initialized
INFO - 2017-04-21 14:51:52 --> Parser Class Initialized
DEBUG - 2017-04-21 14:51:52 --> Session Class Initialized
INFO - 2017-04-21 14:51:52 --> Helper loaded: string_helper
DEBUG - 2017-04-21 14:51:52 --> Session routines successfully run
INFO - 2017-04-21 14:51:52 --> Form Validation Class Initialized
INFO - 2017-04-21 14:51:52 --> Controller Class Initialized
INFO - 2017-04-21 14:51:52 --> Model Class Initialized
INFO - 2017-04-21 14:51:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-04-21 14:51:52 --> Config Class Initialized
INFO - 2017-04-21 14:51:52 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:51:52 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:51:52 --> Utf8 Class Initialized
INFO - 2017-04-21 14:51:52 --> URI Class Initialized
INFO - 2017-04-21 14:51:52 --> Router Class Initialized
INFO - 2017-04-21 14:51:52 --> Output Class Initialized
INFO - 2017-04-21 14:51:52 --> Security Class Initialized
DEBUG - 2017-04-21 14:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:51:52 --> Input Class Initialized
INFO - 2017-04-21 14:51:52 --> Language Class Initialized
INFO - 2017-04-21 14:51:52 --> Loader Class Initialized
INFO - 2017-04-21 14:51:52 --> Helper loaded: url_helper
INFO - 2017-04-21 14:51:52 --> Helper loaded: form_helper
INFO - 2017-04-21 14:51:52 --> Helper loaded: html_helper
INFO - 2017-04-21 14:51:52 --> Helper loaded: custom_helper
INFO - 2017-04-21 14:51:52 --> Helper loaded: cache_helper
INFO - 2017-04-21 14:51:52 --> Database Driver Class Initialized
INFO - 2017-04-21 14:51:52 --> Parser Class Initialized
DEBUG - 2017-04-21 14:51:52 --> Session Class Initialized
INFO - 2017-04-21 14:51:52 --> Helper loaded: string_helper
DEBUG - 2017-04-21 14:51:52 --> Session routines successfully run
INFO - 2017-04-21 14:51:52 --> Form Validation Class Initialized
INFO - 2017-04-21 14:51:52 --> Controller Class Initialized
DEBUG - 2017-04-21 14:51:52 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 14:51:52 --> Model Class Initialized
DEBUG - 2017-04-21 14:51:52 --> Pagination Class Initialized
INFO - 2017-04-21 14:51:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 14:51:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 14:51:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-21 14:51:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 14:51:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 14:51:52 --> Final output sent to browser
DEBUG - 2017-04-21 14:51:52 --> Total execution time: 0.1481
INFO - 2017-04-21 14:52:18 --> Config Class Initialized
INFO - 2017-04-21 14:52:18 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:52:18 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:52:18 --> Utf8 Class Initialized
INFO - 2017-04-21 14:52:18 --> URI Class Initialized
INFO - 2017-04-21 14:52:18 --> Router Class Initialized
INFO - 2017-04-21 14:52:18 --> Output Class Initialized
INFO - 2017-04-21 14:52:18 --> Security Class Initialized
DEBUG - 2017-04-21 14:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:52:18 --> Input Class Initialized
INFO - 2017-04-21 14:52:18 --> Language Class Initialized
INFO - 2017-04-21 14:52:18 --> Loader Class Initialized
INFO - 2017-04-21 14:52:18 --> Helper loaded: url_helper
INFO - 2017-04-21 14:52:18 --> Helper loaded: form_helper
INFO - 2017-04-21 14:52:18 --> Helper loaded: html_helper
INFO - 2017-04-21 14:52:18 --> Helper loaded: custom_helper
INFO - 2017-04-21 14:52:18 --> Helper loaded: cache_helper
INFO - 2017-04-21 14:52:18 --> Database Driver Class Initialized
INFO - 2017-04-21 14:52:18 --> Parser Class Initialized
DEBUG - 2017-04-21 14:52:18 --> Session Class Initialized
INFO - 2017-04-21 14:52:18 --> Helper loaded: string_helper
DEBUG - 2017-04-21 14:52:18 --> Session routines successfully run
INFO - 2017-04-21 14:52:18 --> Form Validation Class Initialized
INFO - 2017-04-21 14:52:18 --> Controller Class Initialized
DEBUG - 2017-04-21 14:52:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 14:52:18 --> Model Class Initialized
DEBUG - 2017-04-21 14:52:18 --> Pagination Class Initialized
INFO - 2017-04-21 14:52:18 --> Config Class Initialized
INFO - 2017-04-21 14:52:18 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:52:18 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:52:18 --> Utf8 Class Initialized
INFO - 2017-04-21 14:52:18 --> URI Class Initialized
INFO - 2017-04-21 14:52:18 --> Router Class Initialized
INFO - 2017-04-21 14:52:18 --> Output Class Initialized
INFO - 2017-04-21 14:52:18 --> Security Class Initialized
DEBUG - 2017-04-21 14:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:52:18 --> Input Class Initialized
INFO - 2017-04-21 14:52:18 --> Language Class Initialized
INFO - 2017-04-21 14:52:18 --> Loader Class Initialized
INFO - 2017-04-21 14:52:18 --> Helper loaded: url_helper
INFO - 2017-04-21 14:52:18 --> Helper loaded: form_helper
INFO - 2017-04-21 14:52:18 --> Helper loaded: html_helper
INFO - 2017-04-21 14:52:18 --> Helper loaded: custom_helper
INFO - 2017-04-21 14:52:18 --> Helper loaded: cache_helper
INFO - 2017-04-21 14:52:18 --> Database Driver Class Initialized
INFO - 2017-04-21 14:52:18 --> Parser Class Initialized
DEBUG - 2017-04-21 14:52:18 --> Session Class Initialized
INFO - 2017-04-21 14:52:18 --> Helper loaded: string_helper
DEBUG - 2017-04-21 14:52:18 --> Session routines successfully run
INFO - 2017-04-21 14:52:18 --> Form Validation Class Initialized
INFO - 2017-04-21 14:52:18 --> Controller Class Initialized
DEBUG - 2017-04-21 14:52:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 14:52:18 --> Model Class Initialized
DEBUG - 2017-04-21 14:52:18 --> Pagination Class Initialized
INFO - 2017-04-21 14:52:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 14:52:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 14:52:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-21 14:52:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 14:52:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 14:52:21 --> Final output sent to browser
DEBUG - 2017-04-21 14:52:21 --> Total execution time: 3.1400
INFO - 2017-04-21 14:52:22 --> Config Class Initialized
INFO - 2017-04-21 14:52:22 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:52:22 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:52:22 --> Utf8 Class Initialized
INFO - 2017-04-21 14:52:22 --> URI Class Initialized
INFO - 2017-04-21 14:52:22 --> Router Class Initialized
INFO - 2017-04-21 14:52:22 --> Output Class Initialized
INFO - 2017-04-21 14:52:22 --> Security Class Initialized
DEBUG - 2017-04-21 14:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:52:22 --> Input Class Initialized
INFO - 2017-04-21 14:52:22 --> Language Class Initialized
ERROR - 2017-04-21 14:52:22 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 14:52:57 --> Config Class Initialized
INFO - 2017-04-21 14:52:57 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:52:57 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:52:57 --> Utf8 Class Initialized
INFO - 2017-04-21 14:52:57 --> URI Class Initialized
INFO - 2017-04-21 14:52:57 --> Router Class Initialized
INFO - 2017-04-21 14:52:57 --> Output Class Initialized
INFO - 2017-04-21 14:52:57 --> Security Class Initialized
DEBUG - 2017-04-21 14:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:52:57 --> Input Class Initialized
INFO - 2017-04-21 14:52:57 --> Language Class Initialized
INFO - 2017-04-21 14:52:57 --> Loader Class Initialized
INFO - 2017-04-21 14:52:57 --> Helper loaded: url_helper
INFO - 2017-04-21 14:52:57 --> Helper loaded: form_helper
INFO - 2017-04-21 14:52:57 --> Helper loaded: html_helper
INFO - 2017-04-21 14:52:57 --> Helper loaded: custom_helper
INFO - 2017-04-21 14:52:57 --> Helper loaded: cache_helper
INFO - 2017-04-21 14:52:57 --> Database Driver Class Initialized
INFO - 2017-04-21 14:52:57 --> Parser Class Initialized
DEBUG - 2017-04-21 14:52:57 --> Session Class Initialized
INFO - 2017-04-21 14:52:57 --> Helper loaded: string_helper
DEBUG - 2017-04-21 14:52:57 --> Session routines successfully run
INFO - 2017-04-21 14:52:57 --> Form Validation Class Initialized
INFO - 2017-04-21 14:52:57 --> Controller Class Initialized
DEBUG - 2017-04-21 14:52:57 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 14:52:57 --> Model Class Initialized
DEBUG - 2017-04-21 14:52:57 --> Pagination Class Initialized
INFO - 2017-04-21 14:52:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 14:52:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 14:52:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 14:52:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 14:52:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 14:52:58 --> Final output sent to browser
DEBUG - 2017-04-21 14:52:58 --> Total execution time: 0.2628
INFO - 2017-04-21 14:52:58 --> Config Class Initialized
INFO - 2017-04-21 14:52:58 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:52:58 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:52:58 --> Utf8 Class Initialized
INFO - 2017-04-21 14:52:58 --> URI Class Initialized
INFO - 2017-04-21 14:52:58 --> Router Class Initialized
INFO - 2017-04-21 14:52:58 --> Output Class Initialized
INFO - 2017-04-21 14:52:58 --> Config Class Initialized
INFO - 2017-04-21 14:52:58 --> Hooks Class Initialized
INFO - 2017-04-21 14:52:58 --> Security Class Initialized
DEBUG - 2017-04-21 14:52:58 --> UTF-8 Support Enabled
DEBUG - 2017-04-21 14:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:52:58 --> Utf8 Class Initialized
INFO - 2017-04-21 14:52:58 --> Input Class Initialized
INFO - 2017-04-21 14:52:58 --> Language Class Initialized
ERROR - 2017-04-21 14:52:58 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 14:52:58 --> URI Class Initialized
INFO - 2017-04-21 14:52:58 --> Router Class Initialized
INFO - 2017-04-21 14:52:58 --> Output Class Initialized
INFO - 2017-04-21 14:52:58 --> Security Class Initialized
DEBUG - 2017-04-21 14:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:52:58 --> Input Class Initialized
INFO - 2017-04-21 14:52:58 --> Language Class Initialized
ERROR - 2017-04-21 14:52:58 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 14:52:58 --> Config Class Initialized
INFO - 2017-04-21 14:52:58 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:52:58 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:52:58 --> Utf8 Class Initialized
INFO - 2017-04-21 14:52:58 --> URI Class Initialized
INFO - 2017-04-21 14:52:58 --> Router Class Initialized
INFO - 2017-04-21 14:52:58 --> Output Class Initialized
INFO - 2017-04-21 14:52:58 --> Security Class Initialized
DEBUG - 2017-04-21 14:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:52:58 --> Input Class Initialized
INFO - 2017-04-21 14:52:58 --> Language Class Initialized
ERROR - 2017-04-21 14:52:58 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 14:52:59 --> Config Class Initialized
INFO - 2017-04-21 14:52:59 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:52:59 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:52:59 --> Utf8 Class Initialized
INFO - 2017-04-21 14:52:59 --> URI Class Initialized
INFO - 2017-04-21 14:52:59 --> Router Class Initialized
INFO - 2017-04-21 14:52:59 --> Output Class Initialized
INFO - 2017-04-21 14:52:59 --> Security Class Initialized
DEBUG - 2017-04-21 14:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:52:59 --> Input Class Initialized
INFO - 2017-04-21 14:52:59 --> Language Class Initialized
ERROR - 2017-04-21 14:52:59 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 14:52:59 --> Config Class Initialized
INFO - 2017-04-21 14:52:59 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:52:59 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:52:59 --> Utf8 Class Initialized
INFO - 2017-04-21 14:52:59 --> URI Class Initialized
INFO - 2017-04-21 14:52:59 --> Router Class Initialized
INFO - 2017-04-21 14:52:59 --> Output Class Initialized
INFO - 2017-04-21 14:52:59 --> Security Class Initialized
DEBUG - 2017-04-21 14:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:52:59 --> Input Class Initialized
INFO - 2017-04-21 14:52:59 --> Language Class Initialized
ERROR - 2017-04-21 14:52:59 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 14:59:02 --> Config Class Initialized
INFO - 2017-04-21 14:59:02 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:59:02 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:59:02 --> Utf8 Class Initialized
INFO - 2017-04-21 14:59:02 --> URI Class Initialized
INFO - 2017-04-21 14:59:02 --> Router Class Initialized
INFO - 2017-04-21 14:59:02 --> Output Class Initialized
INFO - 2017-04-21 14:59:02 --> Security Class Initialized
DEBUG - 2017-04-21 14:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:59:02 --> Input Class Initialized
INFO - 2017-04-21 14:59:02 --> Language Class Initialized
INFO - 2017-04-21 14:59:02 --> Loader Class Initialized
INFO - 2017-04-21 14:59:02 --> Helper loaded: url_helper
INFO - 2017-04-21 14:59:02 --> Helper loaded: form_helper
INFO - 2017-04-21 14:59:02 --> Helper loaded: html_helper
INFO - 2017-04-21 14:59:02 --> Helper loaded: custom_helper
INFO - 2017-04-21 14:59:02 --> Helper loaded: cache_helper
INFO - 2017-04-21 14:59:02 --> Database Driver Class Initialized
INFO - 2017-04-21 14:59:02 --> Parser Class Initialized
DEBUG - 2017-04-21 14:59:02 --> Session Class Initialized
INFO - 2017-04-21 14:59:02 --> Helper loaded: string_helper
DEBUG - 2017-04-21 14:59:02 --> Session routines successfully run
INFO - 2017-04-21 14:59:02 --> Form Validation Class Initialized
INFO - 2017-04-21 14:59:02 --> Controller Class Initialized
DEBUG - 2017-04-21 14:59:02 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 14:59:02 --> Model Class Initialized
DEBUG - 2017-04-21 14:59:02 --> Pagination Class Initialized
INFO - 2017-04-21 14:59:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 14:59:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 14:59:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 14:59:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 14:59:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 14:59:02 --> Final output sent to browser
DEBUG - 2017-04-21 14:59:02 --> Total execution time: 0.2309
INFO - 2017-04-21 14:59:02 --> Config Class Initialized
INFO - 2017-04-21 14:59:02 --> Hooks Class Initialized
INFO - 2017-04-21 14:59:02 --> Config Class Initialized
DEBUG - 2017-04-21 14:59:02 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:59:02 --> Hooks Class Initialized
INFO - 2017-04-21 14:59:02 --> Utf8 Class Initialized
DEBUG - 2017-04-21 14:59:02 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:59:02 --> URI Class Initialized
INFO - 2017-04-21 14:59:02 --> Utf8 Class Initialized
INFO - 2017-04-21 14:59:02 --> URI Class Initialized
INFO - 2017-04-21 14:59:02 --> Router Class Initialized
INFO - 2017-04-21 14:59:02 --> Router Class Initialized
INFO - 2017-04-21 14:59:02 --> Output Class Initialized
INFO - 2017-04-21 14:59:02 --> Output Class Initialized
INFO - 2017-04-21 14:59:02 --> Security Class Initialized
INFO - 2017-04-21 14:59:02 --> Security Class Initialized
DEBUG - 2017-04-21 14:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-21 14:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:59:03 --> Input Class Initialized
INFO - 2017-04-21 14:59:03 --> Input Class Initialized
INFO - 2017-04-21 14:59:03 --> Language Class Initialized
INFO - 2017-04-21 14:59:03 --> Language Class Initialized
ERROR - 2017-04-21 14:59:03 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-21 14:59:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 14:59:03 --> Config Class Initialized
INFO - 2017-04-21 14:59:03 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:59:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:59:03 --> Utf8 Class Initialized
INFO - 2017-04-21 14:59:03 --> URI Class Initialized
INFO - 2017-04-21 14:59:03 --> Router Class Initialized
INFO - 2017-04-21 14:59:03 --> Output Class Initialized
INFO - 2017-04-21 14:59:03 --> Security Class Initialized
DEBUG - 2017-04-21 14:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:59:03 --> Input Class Initialized
INFO - 2017-04-21 14:59:03 --> Language Class Initialized
ERROR - 2017-04-21 14:59:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 14:59:03 --> Config Class Initialized
INFO - 2017-04-21 14:59:03 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:59:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:59:03 --> Utf8 Class Initialized
INFO - 2017-04-21 14:59:03 --> URI Class Initialized
INFO - 2017-04-21 14:59:03 --> Router Class Initialized
INFO - 2017-04-21 14:59:03 --> Output Class Initialized
INFO - 2017-04-21 14:59:03 --> Security Class Initialized
DEBUG - 2017-04-21 14:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:59:03 --> Input Class Initialized
INFO - 2017-04-21 14:59:03 --> Language Class Initialized
ERROR - 2017-04-21 14:59:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 14:59:04 --> Config Class Initialized
INFO - 2017-04-21 14:59:04 --> Hooks Class Initialized
DEBUG - 2017-04-21 14:59:04 --> UTF-8 Support Enabled
INFO - 2017-04-21 14:59:04 --> Utf8 Class Initialized
INFO - 2017-04-21 14:59:04 --> URI Class Initialized
INFO - 2017-04-21 14:59:04 --> Router Class Initialized
INFO - 2017-04-21 14:59:04 --> Output Class Initialized
INFO - 2017-04-21 14:59:04 --> Security Class Initialized
DEBUG - 2017-04-21 14:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 14:59:04 --> Input Class Initialized
INFO - 2017-04-21 14:59:04 --> Language Class Initialized
ERROR - 2017-04-21 14:59:04 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:00:57 --> Config Class Initialized
INFO - 2017-04-21 15:00:57 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:00:57 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:00:57 --> Utf8 Class Initialized
INFO - 2017-04-21 15:00:57 --> URI Class Initialized
INFO - 2017-04-21 15:00:57 --> Router Class Initialized
INFO - 2017-04-21 15:00:57 --> Output Class Initialized
INFO - 2017-04-21 15:00:57 --> Security Class Initialized
DEBUG - 2017-04-21 15:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:00:57 --> Input Class Initialized
INFO - 2017-04-21 15:00:57 --> Language Class Initialized
INFO - 2017-04-21 15:00:57 --> Loader Class Initialized
INFO - 2017-04-21 15:00:57 --> Helper loaded: url_helper
INFO - 2017-04-21 15:00:57 --> Helper loaded: form_helper
INFO - 2017-04-21 15:00:57 --> Helper loaded: html_helper
INFO - 2017-04-21 15:00:57 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:00:57 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:00:57 --> Database Driver Class Initialized
INFO - 2017-04-21 15:00:57 --> Parser Class Initialized
DEBUG - 2017-04-21 15:00:57 --> Session Class Initialized
INFO - 2017-04-21 15:00:57 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:00:57 --> Session routines successfully run
INFO - 2017-04-21 15:00:57 --> Form Validation Class Initialized
INFO - 2017-04-21 15:00:57 --> Controller Class Initialized
DEBUG - 2017-04-21 15:00:57 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:00:57 --> Model Class Initialized
DEBUG - 2017-04-21 15:00:57 --> Pagination Class Initialized
INFO - 2017-04-21 15:00:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:00:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:00:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:00:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:00:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:00:57 --> Final output sent to browser
DEBUG - 2017-04-21 15:00:57 --> Total execution time: 0.1701
INFO - 2017-04-21 15:00:58 --> Config Class Initialized
INFO - 2017-04-21 15:00:58 --> Hooks Class Initialized
INFO - 2017-04-21 15:00:58 --> Config Class Initialized
DEBUG - 2017-04-21 15:00:58 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:00:58 --> Hooks Class Initialized
INFO - 2017-04-21 15:00:58 --> Utf8 Class Initialized
DEBUG - 2017-04-21 15:00:58 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:00:58 --> URI Class Initialized
INFO - 2017-04-21 15:00:58 --> Utf8 Class Initialized
INFO - 2017-04-21 15:00:58 --> URI Class Initialized
INFO - 2017-04-21 15:00:58 --> Router Class Initialized
INFO - 2017-04-21 15:00:58 --> Router Class Initialized
INFO - 2017-04-21 15:00:58 --> Output Class Initialized
INFO - 2017-04-21 15:00:58 --> Output Class Initialized
INFO - 2017-04-21 15:00:58 --> Security Class Initialized
INFO - 2017-04-21 15:00:58 --> Security Class Initialized
DEBUG - 2017-04-21 15:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-21 15:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:00:58 --> Input Class Initialized
INFO - 2017-04-21 15:00:58 --> Input Class Initialized
INFO - 2017-04-21 15:00:58 --> Language Class Initialized
INFO - 2017-04-21 15:00:58 --> Language Class Initialized
ERROR - 2017-04-21 15:00:58 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-21 15:00:58 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:00:58 --> Config Class Initialized
INFO - 2017-04-21 15:00:58 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:00:58 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:00:58 --> Utf8 Class Initialized
INFO - 2017-04-21 15:00:58 --> URI Class Initialized
INFO - 2017-04-21 15:00:58 --> Router Class Initialized
INFO - 2017-04-21 15:00:58 --> Output Class Initialized
INFO - 2017-04-21 15:00:58 --> Security Class Initialized
DEBUG - 2017-04-21 15:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:00:58 --> Input Class Initialized
INFO - 2017-04-21 15:00:58 --> Language Class Initialized
ERROR - 2017-04-21 15:00:58 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:00:58 --> Config Class Initialized
INFO - 2017-04-21 15:00:58 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:00:58 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:00:58 --> Utf8 Class Initialized
INFO - 2017-04-21 15:00:58 --> URI Class Initialized
INFO - 2017-04-21 15:00:58 --> Router Class Initialized
INFO - 2017-04-21 15:00:58 --> Output Class Initialized
INFO - 2017-04-21 15:00:58 --> Security Class Initialized
DEBUG - 2017-04-21 15:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:00:58 --> Input Class Initialized
INFO - 2017-04-21 15:00:58 --> Language Class Initialized
ERROR - 2017-04-21 15:00:58 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:01:20 --> Config Class Initialized
INFO - 2017-04-21 15:01:20 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:01:20 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:01:20 --> Utf8 Class Initialized
INFO - 2017-04-21 15:01:20 --> URI Class Initialized
INFO - 2017-04-21 15:01:20 --> Router Class Initialized
INFO - 2017-04-21 15:01:20 --> Output Class Initialized
INFO - 2017-04-21 15:01:20 --> Security Class Initialized
DEBUG - 2017-04-21 15:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:01:20 --> Input Class Initialized
INFO - 2017-04-21 15:01:20 --> Language Class Initialized
INFO - 2017-04-21 15:01:20 --> Loader Class Initialized
INFO - 2017-04-21 15:01:20 --> Helper loaded: url_helper
INFO - 2017-04-21 15:01:20 --> Helper loaded: form_helper
INFO - 2017-04-21 15:01:20 --> Helper loaded: html_helper
INFO - 2017-04-21 15:01:20 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:01:20 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:01:20 --> Database Driver Class Initialized
INFO - 2017-04-21 15:01:20 --> Parser Class Initialized
DEBUG - 2017-04-21 15:01:20 --> Session Class Initialized
INFO - 2017-04-21 15:01:20 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:01:20 --> Session routines successfully run
INFO - 2017-04-21 15:01:20 --> Form Validation Class Initialized
INFO - 2017-04-21 15:01:20 --> Controller Class Initialized
DEBUG - 2017-04-21 15:01:20 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:01:20 --> Model Class Initialized
DEBUG - 2017-04-21 15:01:20 --> Pagination Class Initialized
INFO - 2017-04-21 15:01:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:01:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:01:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:01:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:01:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:01:20 --> Final output sent to browser
DEBUG - 2017-04-21 15:01:20 --> Total execution time: 0.4279
INFO - 2017-04-21 15:01:20 --> Config Class Initialized
INFO - 2017-04-21 15:01:20 --> Hooks Class Initialized
INFO - 2017-04-21 15:01:20 --> Config Class Initialized
DEBUG - 2017-04-21 15:01:20 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:01:20 --> Hooks Class Initialized
INFO - 2017-04-21 15:01:20 --> Utf8 Class Initialized
INFO - 2017-04-21 15:01:20 --> URI Class Initialized
DEBUG - 2017-04-21 15:01:20 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:01:20 --> Router Class Initialized
INFO - 2017-04-21 15:01:20 --> Utf8 Class Initialized
INFO - 2017-04-21 15:01:20 --> Output Class Initialized
INFO - 2017-04-21 15:01:20 --> Security Class Initialized
DEBUG - 2017-04-21 15:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:01:20 --> Input Class Initialized
INFO - 2017-04-21 15:01:20 --> Language Class Initialized
ERROR - 2017-04-21 15:01:20 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:01:20 --> URI Class Initialized
INFO - 2017-04-21 15:01:20 --> Router Class Initialized
INFO - 2017-04-21 15:01:20 --> Output Class Initialized
INFO - 2017-04-21 15:01:20 --> Security Class Initialized
DEBUG - 2017-04-21 15:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:01:20 --> Input Class Initialized
INFO - 2017-04-21 15:01:20 --> Language Class Initialized
ERROR - 2017-04-21 15:01:20 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:01:21 --> Config Class Initialized
INFO - 2017-04-21 15:01:21 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:01:21 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:01:21 --> Utf8 Class Initialized
INFO - 2017-04-21 15:01:21 --> URI Class Initialized
INFO - 2017-04-21 15:01:21 --> Router Class Initialized
INFO - 2017-04-21 15:01:21 --> Output Class Initialized
INFO - 2017-04-21 15:01:21 --> Security Class Initialized
DEBUG - 2017-04-21 15:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:01:21 --> Input Class Initialized
INFO - 2017-04-21 15:01:21 --> Language Class Initialized
ERROR - 2017-04-21 15:01:21 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:01:21 --> Config Class Initialized
INFO - 2017-04-21 15:01:21 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:01:21 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:01:21 --> Utf8 Class Initialized
INFO - 2017-04-21 15:01:21 --> URI Class Initialized
INFO - 2017-04-21 15:01:21 --> Router Class Initialized
INFO - 2017-04-21 15:01:21 --> Output Class Initialized
INFO - 2017-04-21 15:01:21 --> Security Class Initialized
DEBUG - 2017-04-21 15:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:01:21 --> Input Class Initialized
INFO - 2017-04-21 15:01:21 --> Language Class Initialized
ERROR - 2017-04-21 15:01:21 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:01:50 --> Config Class Initialized
INFO - 2017-04-21 15:01:50 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:01:50 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:01:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:01:50 --> URI Class Initialized
INFO - 2017-04-21 15:01:50 --> Router Class Initialized
INFO - 2017-04-21 15:01:50 --> Output Class Initialized
INFO - 2017-04-21 15:01:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:01:50 --> Input Class Initialized
INFO - 2017-04-21 15:01:50 --> Language Class Initialized
INFO - 2017-04-21 15:01:50 --> Loader Class Initialized
INFO - 2017-04-21 15:01:50 --> Helper loaded: url_helper
INFO - 2017-04-21 15:01:50 --> Helper loaded: form_helper
INFO - 2017-04-21 15:01:50 --> Helper loaded: html_helper
INFO - 2017-04-21 15:01:50 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:01:50 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:01:50 --> Database Driver Class Initialized
INFO - 2017-04-21 15:01:50 --> Parser Class Initialized
DEBUG - 2017-04-21 15:01:50 --> Session Class Initialized
INFO - 2017-04-21 15:01:50 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:01:50 --> Session routines successfully run
INFO - 2017-04-21 15:01:50 --> Form Validation Class Initialized
INFO - 2017-04-21 15:01:50 --> Controller Class Initialized
DEBUG - 2017-04-21 15:01:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:01:50 --> Model Class Initialized
DEBUG - 2017-04-21 15:01:50 --> Pagination Class Initialized
INFO - 2017-04-21 15:01:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:01:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:01:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:01:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:01:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:01:50 --> Final output sent to browser
DEBUG - 2017-04-21 15:01:50 --> Total execution time: 0.4312
INFO - 2017-04-21 15:01:50 --> Config Class Initialized
INFO - 2017-04-21 15:01:50 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:01:50 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:01:50 --> Config Class Initialized
INFO - 2017-04-21 15:01:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:01:50 --> URI Class Initialized
INFO - 2017-04-21 15:01:50 --> Router Class Initialized
INFO - 2017-04-21 15:01:50 --> Output Class Initialized
INFO - 2017-04-21 15:01:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:01:50 --> Input Class Initialized
INFO - 2017-04-21 15:01:50 --> Hooks Class Initialized
INFO - 2017-04-21 15:01:50 --> Language Class Initialized
DEBUG - 2017-04-21 15:01:50 --> UTF-8 Support Enabled
ERROR - 2017-04-21 15:01:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:01:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:01:50 --> URI Class Initialized
INFO - 2017-04-21 15:01:50 --> Router Class Initialized
INFO - 2017-04-21 15:01:50 --> Output Class Initialized
INFO - 2017-04-21 15:01:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:01:50 --> Input Class Initialized
INFO - 2017-04-21 15:01:50 --> Language Class Initialized
ERROR - 2017-04-21 15:01:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:01:51 --> Config Class Initialized
INFO - 2017-04-21 15:01:51 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:01:51 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:01:51 --> Utf8 Class Initialized
INFO - 2017-04-21 15:01:51 --> URI Class Initialized
INFO - 2017-04-21 15:01:51 --> Router Class Initialized
INFO - 2017-04-21 15:01:51 --> Output Class Initialized
INFO - 2017-04-21 15:01:51 --> Security Class Initialized
DEBUG - 2017-04-21 15:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:01:51 --> Input Class Initialized
INFO - 2017-04-21 15:01:51 --> Language Class Initialized
ERROR - 2017-04-21 15:01:51 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:01:51 --> Config Class Initialized
INFO - 2017-04-21 15:01:51 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:01:51 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:01:51 --> Utf8 Class Initialized
INFO - 2017-04-21 15:01:51 --> URI Class Initialized
INFO - 2017-04-21 15:01:51 --> Router Class Initialized
INFO - 2017-04-21 15:01:51 --> Output Class Initialized
INFO - 2017-04-21 15:01:51 --> Security Class Initialized
DEBUG - 2017-04-21 15:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:01:51 --> Input Class Initialized
INFO - 2017-04-21 15:01:51 --> Language Class Initialized
ERROR - 2017-04-21 15:01:51 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:02:07 --> Config Class Initialized
INFO - 2017-04-21 15:02:07 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:02:07 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:02:07 --> Utf8 Class Initialized
INFO - 2017-04-21 15:02:07 --> URI Class Initialized
INFO - 2017-04-21 15:02:07 --> Router Class Initialized
INFO - 2017-04-21 15:02:07 --> Output Class Initialized
INFO - 2017-04-21 15:02:07 --> Security Class Initialized
DEBUG - 2017-04-21 15:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:02:07 --> Input Class Initialized
INFO - 2017-04-21 15:02:07 --> Language Class Initialized
INFO - 2017-04-21 15:02:07 --> Loader Class Initialized
INFO - 2017-04-21 15:02:07 --> Helper loaded: url_helper
INFO - 2017-04-21 15:02:07 --> Helper loaded: form_helper
INFO - 2017-04-21 15:02:07 --> Helper loaded: html_helper
INFO - 2017-04-21 15:02:07 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:02:07 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:02:07 --> Database Driver Class Initialized
INFO - 2017-04-21 15:02:07 --> Parser Class Initialized
DEBUG - 2017-04-21 15:02:07 --> Session Class Initialized
INFO - 2017-04-21 15:02:07 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:02:07 --> Session routines successfully run
INFO - 2017-04-21 15:02:07 --> Form Validation Class Initialized
INFO - 2017-04-21 15:02:07 --> Controller Class Initialized
DEBUG - 2017-04-21 15:02:07 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:02:07 --> Model Class Initialized
DEBUG - 2017-04-21 15:02:07 --> Pagination Class Initialized
INFO - 2017-04-21 15:02:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:02:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:02:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:02:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:02:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:02:07 --> Final output sent to browser
DEBUG - 2017-04-21 15:02:07 --> Total execution time: 0.1903
INFO - 2017-04-21 15:02:07 --> Config Class Initialized
INFO - 2017-04-21 15:02:07 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:02:07 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:02:07 --> Config Class Initialized
INFO - 2017-04-21 15:02:07 --> Utf8 Class Initialized
INFO - 2017-04-21 15:02:07 --> Hooks Class Initialized
INFO - 2017-04-21 15:02:07 --> URI Class Initialized
DEBUG - 2017-04-21 15:02:07 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:02:07 --> Router Class Initialized
INFO - 2017-04-21 15:02:07 --> Utf8 Class Initialized
INFO - 2017-04-21 15:02:07 --> URI Class Initialized
INFO - 2017-04-21 15:02:07 --> Output Class Initialized
INFO - 2017-04-21 15:02:07 --> Router Class Initialized
INFO - 2017-04-21 15:02:07 --> Security Class Initialized
INFO - 2017-04-21 15:02:07 --> Output Class Initialized
DEBUG - 2017-04-21 15:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:02:07 --> Security Class Initialized
INFO - 2017-04-21 15:02:07 --> Input Class Initialized
INFO - 2017-04-21 15:02:07 --> Language Class Initialized
DEBUG - 2017-04-21 15:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-04-21 15:02:07 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:02:07 --> Input Class Initialized
INFO - 2017-04-21 15:02:07 --> Language Class Initialized
ERROR - 2017-04-21 15:02:07 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:02:08 --> Config Class Initialized
INFO - 2017-04-21 15:02:08 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:02:08 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:02:08 --> Utf8 Class Initialized
INFO - 2017-04-21 15:02:08 --> URI Class Initialized
INFO - 2017-04-21 15:02:08 --> Router Class Initialized
INFO - 2017-04-21 15:02:08 --> Output Class Initialized
INFO - 2017-04-21 15:02:08 --> Security Class Initialized
DEBUG - 2017-04-21 15:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:02:08 --> Input Class Initialized
INFO - 2017-04-21 15:02:08 --> Language Class Initialized
ERROR - 2017-04-21 15:02:08 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:02:08 --> Config Class Initialized
INFO - 2017-04-21 15:02:08 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:02:08 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:02:08 --> Utf8 Class Initialized
INFO - 2017-04-21 15:02:08 --> URI Class Initialized
INFO - 2017-04-21 15:02:08 --> Router Class Initialized
INFO - 2017-04-21 15:02:08 --> Output Class Initialized
INFO - 2017-04-21 15:02:08 --> Security Class Initialized
DEBUG - 2017-04-21 15:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:02:08 --> Input Class Initialized
INFO - 2017-04-21 15:02:08 --> Language Class Initialized
ERROR - 2017-04-21 15:02:08 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:02:15 --> Config Class Initialized
INFO - 2017-04-21 15:02:15 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:02:15 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:02:15 --> Utf8 Class Initialized
INFO - 2017-04-21 15:02:15 --> URI Class Initialized
INFO - 2017-04-21 15:02:15 --> Router Class Initialized
INFO - 2017-04-21 15:02:15 --> Output Class Initialized
INFO - 2017-04-21 15:02:15 --> Security Class Initialized
DEBUG - 2017-04-21 15:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:02:15 --> Input Class Initialized
INFO - 2017-04-21 15:02:15 --> Language Class Initialized
INFO - 2017-04-21 15:02:15 --> Loader Class Initialized
INFO - 2017-04-21 15:02:15 --> Helper loaded: url_helper
INFO - 2017-04-21 15:02:15 --> Helper loaded: form_helper
INFO - 2017-04-21 15:02:15 --> Helper loaded: html_helper
INFO - 2017-04-21 15:02:15 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:02:15 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:02:15 --> Database Driver Class Initialized
INFO - 2017-04-21 15:02:15 --> Parser Class Initialized
DEBUG - 2017-04-21 15:02:15 --> Session Class Initialized
INFO - 2017-04-21 15:02:15 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:02:15 --> Session routines successfully run
INFO - 2017-04-21 15:02:15 --> Form Validation Class Initialized
INFO - 2017-04-21 15:02:15 --> Controller Class Initialized
DEBUG - 2017-04-21 15:02:15 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:02:15 --> Model Class Initialized
DEBUG - 2017-04-21 15:02:15 --> Pagination Class Initialized
INFO - 2017-04-21 15:02:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:02:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:02:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:02:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:02:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:02:15 --> Final output sent to browser
DEBUG - 2017-04-21 15:02:15 --> Total execution time: 0.2066
INFO - 2017-04-21 15:02:15 --> Config Class Initialized
INFO - 2017-04-21 15:02:15 --> Hooks Class Initialized
INFO - 2017-04-21 15:02:15 --> Config Class Initialized
DEBUG - 2017-04-21 15:02:15 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:02:15 --> Hooks Class Initialized
INFO - 2017-04-21 15:02:15 --> Utf8 Class Initialized
DEBUG - 2017-04-21 15:02:15 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:02:15 --> URI Class Initialized
INFO - 2017-04-21 15:02:15 --> Utf8 Class Initialized
INFO - 2017-04-21 15:02:15 --> URI Class Initialized
INFO - 2017-04-21 15:02:15 --> Router Class Initialized
INFO - 2017-04-21 15:02:15 --> Router Class Initialized
INFO - 2017-04-21 15:02:15 --> Output Class Initialized
INFO - 2017-04-21 15:02:15 --> Output Class Initialized
INFO - 2017-04-21 15:02:15 --> Security Class Initialized
INFO - 2017-04-21 15:02:15 --> Security Class Initialized
DEBUG - 2017-04-21 15:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-21 15:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:02:15 --> Input Class Initialized
INFO - 2017-04-21 15:02:15 --> Input Class Initialized
INFO - 2017-04-21 15:02:15 --> Language Class Initialized
INFO - 2017-04-21 15:02:15 --> Language Class Initialized
ERROR - 2017-04-21 15:02:15 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-21 15:02:15 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:02:15 --> Config Class Initialized
INFO - 2017-04-21 15:02:15 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:02:15 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:02:15 --> Utf8 Class Initialized
INFO - 2017-04-21 15:02:15 --> URI Class Initialized
INFO - 2017-04-21 15:02:15 --> Router Class Initialized
INFO - 2017-04-21 15:02:15 --> Output Class Initialized
INFO - 2017-04-21 15:02:15 --> Security Class Initialized
DEBUG - 2017-04-21 15:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:02:15 --> Input Class Initialized
INFO - 2017-04-21 15:02:15 --> Language Class Initialized
ERROR - 2017-04-21 15:02:15 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:02:15 --> Config Class Initialized
INFO - 2017-04-21 15:02:15 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:02:15 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:02:15 --> Utf8 Class Initialized
INFO - 2017-04-21 15:02:15 --> URI Class Initialized
INFO - 2017-04-21 15:02:15 --> Router Class Initialized
INFO - 2017-04-21 15:02:15 --> Output Class Initialized
INFO - 2017-04-21 15:02:15 --> Security Class Initialized
DEBUG - 2017-04-21 15:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:02:15 --> Input Class Initialized
INFO - 2017-04-21 15:02:15 --> Language Class Initialized
ERROR - 2017-04-21 15:02:15 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:06:14 --> Config Class Initialized
INFO - 2017-04-21 15:06:14 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:06:14 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:06:14 --> Utf8 Class Initialized
INFO - 2017-04-21 15:06:14 --> URI Class Initialized
INFO - 2017-04-21 15:06:14 --> Router Class Initialized
INFO - 2017-04-21 15:06:14 --> Output Class Initialized
INFO - 2017-04-21 15:06:14 --> Security Class Initialized
DEBUG - 2017-04-21 15:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:06:14 --> Input Class Initialized
INFO - 2017-04-21 15:06:14 --> Language Class Initialized
INFO - 2017-04-21 15:06:14 --> Loader Class Initialized
INFO - 2017-04-21 15:06:14 --> Helper loaded: url_helper
INFO - 2017-04-21 15:06:14 --> Helper loaded: form_helper
INFO - 2017-04-21 15:06:14 --> Helper loaded: html_helper
INFO - 2017-04-21 15:06:14 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:06:14 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:06:14 --> Database Driver Class Initialized
INFO - 2017-04-21 15:06:14 --> Parser Class Initialized
DEBUG - 2017-04-21 15:06:14 --> Session Class Initialized
INFO - 2017-04-21 15:06:14 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:06:14 --> Session routines successfully run
INFO - 2017-04-21 15:06:14 --> Form Validation Class Initialized
INFO - 2017-04-21 15:06:14 --> Controller Class Initialized
DEBUG - 2017-04-21 15:06:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:06:14 --> Model Class Initialized
DEBUG - 2017-04-21 15:06:14 --> Pagination Class Initialized
INFO - 2017-04-21 15:06:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:06:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:06:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:06:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:06:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:06:14 --> Final output sent to browser
DEBUG - 2017-04-21 15:06:14 --> Total execution time: 0.1814
INFO - 2017-04-21 15:06:14 --> Config Class Initialized
INFO - 2017-04-21 15:06:14 --> Config Class Initialized
INFO - 2017-04-21 15:06:14 --> Hooks Class Initialized
INFO - 2017-04-21 15:06:14 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:06:14 --> UTF-8 Support Enabled
DEBUG - 2017-04-21 15:06:14 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:06:14 --> Utf8 Class Initialized
INFO - 2017-04-21 15:06:14 --> Utf8 Class Initialized
INFO - 2017-04-21 15:06:14 --> URI Class Initialized
INFO - 2017-04-21 15:06:14 --> URI Class Initialized
INFO - 2017-04-21 15:06:14 --> Router Class Initialized
INFO - 2017-04-21 15:06:14 --> Router Class Initialized
INFO - 2017-04-21 15:06:14 --> Output Class Initialized
INFO - 2017-04-21 15:06:14 --> Output Class Initialized
INFO - 2017-04-21 15:06:14 --> Security Class Initialized
INFO - 2017-04-21 15:06:14 --> Security Class Initialized
DEBUG - 2017-04-21 15:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-21 15:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:06:14 --> Input Class Initialized
INFO - 2017-04-21 15:06:14 --> Input Class Initialized
INFO - 2017-04-21 15:06:14 --> Language Class Initialized
INFO - 2017-04-21 15:06:14 --> Language Class Initialized
ERROR - 2017-04-21 15:06:14 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-21 15:06:14 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:06:15 --> Config Class Initialized
INFO - 2017-04-21 15:06:15 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:06:15 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:06:15 --> Utf8 Class Initialized
INFO - 2017-04-21 15:06:15 --> URI Class Initialized
INFO - 2017-04-21 15:06:15 --> Router Class Initialized
INFO - 2017-04-21 15:06:15 --> Output Class Initialized
INFO - 2017-04-21 15:06:15 --> Security Class Initialized
DEBUG - 2017-04-21 15:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:06:15 --> Input Class Initialized
INFO - 2017-04-21 15:06:15 --> Language Class Initialized
ERROR - 2017-04-21 15:06:15 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:06:15 --> Config Class Initialized
INFO - 2017-04-21 15:06:15 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:06:15 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:06:15 --> Utf8 Class Initialized
INFO - 2017-04-21 15:06:15 --> URI Class Initialized
INFO - 2017-04-21 15:06:15 --> Router Class Initialized
INFO - 2017-04-21 15:06:15 --> Output Class Initialized
INFO - 2017-04-21 15:06:15 --> Security Class Initialized
DEBUG - 2017-04-21 15:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:06:15 --> Input Class Initialized
INFO - 2017-04-21 15:06:15 --> Language Class Initialized
ERROR - 2017-04-21 15:06:15 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:06:46 --> Config Class Initialized
INFO - 2017-04-21 15:06:46 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:06:46 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:06:46 --> Utf8 Class Initialized
INFO - 2017-04-21 15:06:46 --> URI Class Initialized
INFO - 2017-04-21 15:06:46 --> Router Class Initialized
INFO - 2017-04-21 15:06:46 --> Output Class Initialized
INFO - 2017-04-21 15:06:46 --> Security Class Initialized
DEBUG - 2017-04-21 15:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:06:46 --> Input Class Initialized
INFO - 2017-04-21 15:06:46 --> Language Class Initialized
INFO - 2017-04-21 15:06:46 --> Loader Class Initialized
INFO - 2017-04-21 15:06:46 --> Helper loaded: url_helper
INFO - 2017-04-21 15:06:46 --> Helper loaded: form_helper
INFO - 2017-04-21 15:06:46 --> Helper loaded: html_helper
INFO - 2017-04-21 15:06:46 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:06:46 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:06:46 --> Database Driver Class Initialized
INFO - 2017-04-21 15:06:46 --> Parser Class Initialized
DEBUG - 2017-04-21 15:06:46 --> Session Class Initialized
INFO - 2017-04-21 15:06:46 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:06:46 --> Session routines successfully run
INFO - 2017-04-21 15:06:46 --> Form Validation Class Initialized
INFO - 2017-04-21 15:06:46 --> Controller Class Initialized
DEBUG - 2017-04-21 15:06:46 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:06:46 --> Model Class Initialized
DEBUG - 2017-04-21 15:06:46 --> Pagination Class Initialized
INFO - 2017-04-21 15:06:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:06:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:06:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:06:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:06:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:06:46 --> Final output sent to browser
DEBUG - 2017-04-21 15:06:46 --> Total execution time: 0.2401
INFO - 2017-04-21 15:06:47 --> Config Class Initialized
INFO - 2017-04-21 15:06:47 --> Config Class Initialized
INFO - 2017-04-21 15:06:47 --> Hooks Class Initialized
INFO - 2017-04-21 15:06:47 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:06:47 --> UTF-8 Support Enabled
DEBUG - 2017-04-21 15:06:47 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:06:47 --> Utf8 Class Initialized
INFO - 2017-04-21 15:06:47 --> Utf8 Class Initialized
INFO - 2017-04-21 15:06:47 --> URI Class Initialized
INFO - 2017-04-21 15:06:47 --> URI Class Initialized
INFO - 2017-04-21 15:06:47 --> Router Class Initialized
INFO - 2017-04-21 15:06:47 --> Router Class Initialized
INFO - 2017-04-21 15:06:47 --> Output Class Initialized
INFO - 2017-04-21 15:06:47 --> Output Class Initialized
INFO - 2017-04-21 15:06:47 --> Security Class Initialized
INFO - 2017-04-21 15:06:47 --> Security Class Initialized
DEBUG - 2017-04-21 15:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-21 15:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:06:47 --> Input Class Initialized
INFO - 2017-04-21 15:06:47 --> Input Class Initialized
INFO - 2017-04-21 15:06:47 --> Language Class Initialized
ERROR - 2017-04-21 15:06:47 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:06:47 --> Language Class Initialized
ERROR - 2017-04-21 15:06:47 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:06:47 --> Config Class Initialized
INFO - 2017-04-21 15:06:47 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:06:47 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:06:47 --> Utf8 Class Initialized
INFO - 2017-04-21 15:06:47 --> URI Class Initialized
INFO - 2017-04-21 15:06:47 --> Router Class Initialized
INFO - 2017-04-21 15:06:47 --> Output Class Initialized
INFO - 2017-04-21 15:06:47 --> Security Class Initialized
DEBUG - 2017-04-21 15:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:06:47 --> Input Class Initialized
INFO - 2017-04-21 15:06:47 --> Language Class Initialized
ERROR - 2017-04-21 15:06:47 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:06:47 --> Config Class Initialized
INFO - 2017-04-21 15:06:47 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:06:47 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:06:47 --> Utf8 Class Initialized
INFO - 2017-04-21 15:06:47 --> URI Class Initialized
INFO - 2017-04-21 15:06:47 --> Router Class Initialized
INFO - 2017-04-21 15:06:47 --> Output Class Initialized
INFO - 2017-04-21 15:06:47 --> Security Class Initialized
DEBUG - 2017-04-21 15:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:06:47 --> Input Class Initialized
INFO - 2017-04-21 15:06:47 --> Language Class Initialized
ERROR - 2017-04-21 15:06:47 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:07:06 --> Config Class Initialized
INFO - 2017-04-21 15:07:06 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:07:06 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:07:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:06 --> URI Class Initialized
INFO - 2017-04-21 15:07:06 --> Router Class Initialized
INFO - 2017-04-21 15:07:06 --> Output Class Initialized
INFO - 2017-04-21 15:07:06 --> Security Class Initialized
DEBUG - 2017-04-21 15:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:07:06 --> Input Class Initialized
INFO - 2017-04-21 15:07:06 --> Language Class Initialized
INFO - 2017-04-21 15:07:06 --> Loader Class Initialized
INFO - 2017-04-21 15:07:06 --> Helper loaded: url_helper
INFO - 2017-04-21 15:07:06 --> Helper loaded: form_helper
INFO - 2017-04-21 15:07:06 --> Helper loaded: html_helper
INFO - 2017-04-21 15:07:06 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:07:06 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:07:06 --> Database Driver Class Initialized
INFO - 2017-04-21 15:07:06 --> Parser Class Initialized
DEBUG - 2017-04-21 15:07:06 --> Session Class Initialized
INFO - 2017-04-21 15:07:06 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:07:06 --> Session routines successfully run
INFO - 2017-04-21 15:07:06 --> Form Validation Class Initialized
INFO - 2017-04-21 15:07:06 --> Controller Class Initialized
DEBUG - 2017-04-21 15:07:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:07:06 --> Model Class Initialized
DEBUG - 2017-04-21 15:07:06 --> Pagination Class Initialized
INFO - 2017-04-21 15:07:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:07:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:07:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:07:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:07:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:07:06 --> Final output sent to browser
DEBUG - 2017-04-21 15:07:06 --> Total execution time: 0.2309
INFO - 2017-04-21 15:07:06 --> Config Class Initialized
INFO - 2017-04-21 15:07:06 --> Config Class Initialized
INFO - 2017-04-21 15:07:06 --> Hooks Class Initialized
INFO - 2017-04-21 15:07:06 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:07:06 --> UTF-8 Support Enabled
DEBUG - 2017-04-21 15:07:06 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:07:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:06 --> URI Class Initialized
INFO - 2017-04-21 15:07:06 --> URI Class Initialized
INFO - 2017-04-21 15:07:06 --> Router Class Initialized
INFO - 2017-04-21 15:07:06 --> Router Class Initialized
INFO - 2017-04-21 15:07:06 --> Output Class Initialized
INFO - 2017-04-21 15:07:06 --> Output Class Initialized
INFO - 2017-04-21 15:07:06 --> Security Class Initialized
INFO - 2017-04-21 15:07:06 --> Security Class Initialized
DEBUG - 2017-04-21 15:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-21 15:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:07:06 --> Input Class Initialized
INFO - 2017-04-21 15:07:06 --> Input Class Initialized
INFO - 2017-04-21 15:07:06 --> Language Class Initialized
INFO - 2017-04-21 15:07:06 --> Language Class Initialized
ERROR - 2017-04-21 15:07:06 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-21 15:07:06 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:07:07 --> Config Class Initialized
INFO - 2017-04-21 15:07:07 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:07:07 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:07:07 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:07 --> URI Class Initialized
INFO - 2017-04-21 15:07:07 --> Router Class Initialized
INFO - 2017-04-21 15:07:07 --> Output Class Initialized
INFO - 2017-04-21 15:07:07 --> Security Class Initialized
DEBUG - 2017-04-21 15:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:07:07 --> Input Class Initialized
INFO - 2017-04-21 15:07:07 --> Language Class Initialized
ERROR - 2017-04-21 15:07:07 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:07:07 --> Config Class Initialized
INFO - 2017-04-21 15:07:07 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:07:07 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:07:07 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:07 --> URI Class Initialized
INFO - 2017-04-21 15:07:07 --> Router Class Initialized
INFO - 2017-04-21 15:07:07 --> Output Class Initialized
INFO - 2017-04-21 15:07:07 --> Security Class Initialized
DEBUG - 2017-04-21 15:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:07:07 --> Input Class Initialized
INFO - 2017-04-21 15:07:07 --> Language Class Initialized
ERROR - 2017-04-21 15:07:07 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:07:26 --> Config Class Initialized
INFO - 2017-04-21 15:07:26 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:07:26 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:07:26 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:26 --> URI Class Initialized
DEBUG - 2017-04-21 15:07:26 --> No URI present. Default controller set.
INFO - 2017-04-21 15:07:26 --> Router Class Initialized
INFO - 2017-04-21 15:07:26 --> Output Class Initialized
INFO - 2017-04-21 15:07:26 --> Security Class Initialized
DEBUG - 2017-04-21 15:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:07:26 --> Input Class Initialized
INFO - 2017-04-21 15:07:26 --> Language Class Initialized
INFO - 2017-04-21 15:07:26 --> Loader Class Initialized
INFO - 2017-04-21 15:07:26 --> Helper loaded: url_helper
INFO - 2017-04-21 15:07:26 --> Helper loaded: form_helper
INFO - 2017-04-21 15:07:26 --> Helper loaded: html_helper
INFO - 2017-04-21 15:07:26 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:07:26 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:07:26 --> Database Driver Class Initialized
INFO - 2017-04-21 15:07:26 --> Parser Class Initialized
DEBUG - 2017-04-21 15:07:26 --> Session Class Initialized
INFO - 2017-04-21 15:07:26 --> Helper loaded: string_helper
ERROR - 2017-04-21 15:07:26 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-21 15:07:26 --> Session routines successfully run
INFO - 2017-04-21 15:07:26 --> Form Validation Class Initialized
INFO - 2017-04-21 15:07:26 --> Controller Class Initialized
INFO - 2017-04-21 15:07:26 --> Model Class Initialized
INFO - 2017-04-21 15:07:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-21 15:07:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:07:26 --> Final output sent to browser
DEBUG - 2017-04-21 15:07:26 --> Total execution time: 0.1770
INFO - 2017-04-21 15:07:37 --> Config Class Initialized
INFO - 2017-04-21 15:07:37 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:07:37 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:07:37 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:37 --> URI Class Initialized
INFO - 2017-04-21 15:07:37 --> Router Class Initialized
INFO - 2017-04-21 15:07:37 --> Output Class Initialized
INFO - 2017-04-21 15:07:37 --> Security Class Initialized
DEBUG - 2017-04-21 15:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:07:37 --> Input Class Initialized
INFO - 2017-04-21 15:07:37 --> Language Class Initialized
INFO - 2017-04-21 15:07:37 --> Loader Class Initialized
INFO - 2017-04-21 15:07:37 --> Helper loaded: url_helper
INFO - 2017-04-21 15:07:37 --> Helper loaded: form_helper
INFO - 2017-04-21 15:07:37 --> Helper loaded: html_helper
INFO - 2017-04-21 15:07:37 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:07:37 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:07:37 --> Database Driver Class Initialized
INFO - 2017-04-21 15:07:37 --> Parser Class Initialized
DEBUG - 2017-04-21 15:07:37 --> Session Class Initialized
INFO - 2017-04-21 15:07:37 --> Helper loaded: string_helper
ERROR - 2017-04-21 15:07:37 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-21 15:07:37 --> Session routines successfully run
INFO - 2017-04-21 15:07:37 --> Form Validation Class Initialized
INFO - 2017-04-21 15:07:37 --> Controller Class Initialized
INFO - 2017-04-21 15:07:37 --> Model Class Initialized
INFO - 2017-04-21 15:07:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-04-21 15:07:37 --> Config Class Initialized
INFO - 2017-04-21 15:07:37 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:07:37 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:07:37 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:37 --> URI Class Initialized
INFO - 2017-04-21 15:07:37 --> Router Class Initialized
INFO - 2017-04-21 15:07:37 --> Output Class Initialized
INFO - 2017-04-21 15:07:37 --> Security Class Initialized
DEBUG - 2017-04-21 15:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:07:37 --> Input Class Initialized
INFO - 2017-04-21 15:07:37 --> Language Class Initialized
INFO - 2017-04-21 15:07:37 --> Loader Class Initialized
INFO - 2017-04-21 15:07:37 --> Helper loaded: url_helper
INFO - 2017-04-21 15:07:37 --> Helper loaded: form_helper
INFO - 2017-04-21 15:07:37 --> Helper loaded: html_helper
INFO - 2017-04-21 15:07:37 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:07:37 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:07:37 --> Database Driver Class Initialized
INFO - 2017-04-21 15:07:37 --> Parser Class Initialized
DEBUG - 2017-04-21 15:07:37 --> Session Class Initialized
INFO - 2017-04-21 15:07:37 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:07:37 --> Session routines successfully run
INFO - 2017-04-21 15:07:37 --> Form Validation Class Initialized
INFO - 2017-04-21 15:07:37 --> Controller Class Initialized
DEBUG - 2017-04-21 15:07:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:07:37 --> Model Class Initialized
DEBUG - 2017-04-21 15:07:37 --> Pagination Class Initialized
INFO - 2017-04-21 15:07:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:07:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:07:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-21 15:07:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:07:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:07:37 --> Final output sent to browser
DEBUG - 2017-04-21 15:07:37 --> Total execution time: 0.1782
INFO - 2017-04-21 15:07:41 --> Config Class Initialized
INFO - 2017-04-21 15:07:41 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:07:41 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:07:41 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:41 --> URI Class Initialized
INFO - 2017-04-21 15:07:41 --> Router Class Initialized
INFO - 2017-04-21 15:07:41 --> Output Class Initialized
INFO - 2017-04-21 15:07:41 --> Security Class Initialized
DEBUG - 2017-04-21 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:07:41 --> Input Class Initialized
INFO - 2017-04-21 15:07:41 --> Language Class Initialized
INFO - 2017-04-21 15:07:41 --> Loader Class Initialized
INFO - 2017-04-21 15:07:41 --> Helper loaded: url_helper
INFO - 2017-04-21 15:07:41 --> Helper loaded: form_helper
INFO - 2017-04-21 15:07:41 --> Helper loaded: html_helper
INFO - 2017-04-21 15:07:41 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:07:41 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:07:41 --> Database Driver Class Initialized
INFO - 2017-04-21 15:07:41 --> Parser Class Initialized
DEBUG - 2017-04-21 15:07:41 --> Session Class Initialized
INFO - 2017-04-21 15:07:41 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:07:41 --> Session routines successfully run
INFO - 2017-04-21 15:07:41 --> Form Validation Class Initialized
INFO - 2017-04-21 15:07:41 --> Controller Class Initialized
DEBUG - 2017-04-21 15:07:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:07:41 --> Model Class Initialized
DEBUG - 2017-04-21 15:07:41 --> Pagination Class Initialized
INFO - 2017-04-21 15:07:41 --> Config Class Initialized
INFO - 2017-04-21 15:07:41 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:07:41 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:07:41 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:41 --> URI Class Initialized
INFO - 2017-04-21 15:07:41 --> Router Class Initialized
INFO - 2017-04-21 15:07:41 --> Output Class Initialized
INFO - 2017-04-21 15:07:41 --> Security Class Initialized
DEBUG - 2017-04-21 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:07:41 --> Input Class Initialized
INFO - 2017-04-21 15:07:41 --> Language Class Initialized
INFO - 2017-04-21 15:07:41 --> Loader Class Initialized
INFO - 2017-04-21 15:07:41 --> Helper loaded: url_helper
INFO - 2017-04-21 15:07:41 --> Helper loaded: form_helper
INFO - 2017-04-21 15:07:41 --> Helper loaded: html_helper
INFO - 2017-04-21 15:07:41 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:07:41 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:07:41 --> Database Driver Class Initialized
INFO - 2017-04-21 15:07:41 --> Parser Class Initialized
DEBUG - 2017-04-21 15:07:41 --> Session Class Initialized
INFO - 2017-04-21 15:07:41 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:07:41 --> Session routines successfully run
INFO - 2017-04-21 15:07:41 --> Form Validation Class Initialized
INFO - 2017-04-21 15:07:41 --> Controller Class Initialized
DEBUG - 2017-04-21 15:07:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:07:41 --> Model Class Initialized
DEBUG - 2017-04-21 15:07:41 --> Pagination Class Initialized
INFO - 2017-04-21 15:07:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:07:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:07:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-21 15:07:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:07:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:07:45 --> Final output sent to browser
DEBUG - 2017-04-21 15:07:45 --> Total execution time: 3.8705
INFO - 2017-04-21 15:07:51 --> Config Class Initialized
INFO - 2017-04-21 15:07:51 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:07:51 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:07:51 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:51 --> URI Class Initialized
INFO - 2017-04-21 15:07:51 --> Router Class Initialized
INFO - 2017-04-21 15:07:51 --> Output Class Initialized
INFO - 2017-04-21 15:07:51 --> Security Class Initialized
DEBUG - 2017-04-21 15:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:07:51 --> Input Class Initialized
INFO - 2017-04-21 15:07:51 --> Language Class Initialized
INFO - 2017-04-21 15:07:51 --> Loader Class Initialized
INFO - 2017-04-21 15:07:51 --> Helper loaded: url_helper
INFO - 2017-04-21 15:07:51 --> Helper loaded: form_helper
INFO - 2017-04-21 15:07:51 --> Helper loaded: html_helper
INFO - 2017-04-21 15:07:51 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:07:51 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:07:51 --> Database Driver Class Initialized
INFO - 2017-04-21 15:07:51 --> Parser Class Initialized
DEBUG - 2017-04-21 15:07:51 --> Session Class Initialized
INFO - 2017-04-21 15:07:51 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:07:51 --> Session routines successfully run
INFO - 2017-04-21 15:07:51 --> Form Validation Class Initialized
INFO - 2017-04-21 15:07:51 --> Controller Class Initialized
DEBUG - 2017-04-21 15:07:51 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:07:51 --> Model Class Initialized
DEBUG - 2017-04-21 15:07:51 --> Pagination Class Initialized
INFO - 2017-04-21 15:07:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:07:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:07:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:07:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:07:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:07:51 --> Final output sent to browser
DEBUG - 2017-04-21 15:07:51 --> Total execution time: 0.1622
INFO - 2017-04-21 15:07:51 --> Config Class Initialized
INFO - 2017-04-21 15:07:51 --> Config Class Initialized
INFO - 2017-04-21 15:07:51 --> Hooks Class Initialized
INFO - 2017-04-21 15:07:51 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:07:51 --> UTF-8 Support Enabled
DEBUG - 2017-04-21 15:07:51 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:07:51 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:51 --> Utf8 Class Initialized
INFO - 2017-04-21 15:07:51 --> URI Class Initialized
INFO - 2017-04-21 15:07:51 --> URI Class Initialized
INFO - 2017-04-21 15:07:51 --> Router Class Initialized
INFO - 2017-04-21 15:07:51 --> Router Class Initialized
INFO - 2017-04-21 15:07:51 --> Output Class Initialized
INFO - 2017-04-21 15:07:51 --> Output Class Initialized
INFO - 2017-04-21 15:07:51 --> Security Class Initialized
INFO - 2017-04-21 15:07:51 --> Security Class Initialized
DEBUG - 2017-04-21 15:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-21 15:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:07:51 --> Input Class Initialized
INFO - 2017-04-21 15:07:51 --> Input Class Initialized
INFO - 2017-04-21 15:07:51 --> Language Class Initialized
INFO - 2017-04-21 15:07:51 --> Language Class Initialized
ERROR - 2017-04-21 15:07:51 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-21 15:07:51 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:11:32 --> Config Class Initialized
INFO - 2017-04-21 15:11:32 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:11:32 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:11:32 --> Utf8 Class Initialized
INFO - 2017-04-21 15:11:32 --> URI Class Initialized
INFO - 2017-04-21 15:11:32 --> Router Class Initialized
INFO - 2017-04-21 15:11:32 --> Output Class Initialized
INFO - 2017-04-21 15:11:32 --> Security Class Initialized
DEBUG - 2017-04-21 15:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:11:32 --> Input Class Initialized
INFO - 2017-04-21 15:11:32 --> Language Class Initialized
INFO - 2017-04-21 15:11:32 --> Loader Class Initialized
INFO - 2017-04-21 15:11:32 --> Helper loaded: url_helper
INFO - 2017-04-21 15:11:32 --> Helper loaded: form_helper
INFO - 2017-04-21 15:11:32 --> Helper loaded: html_helper
INFO - 2017-04-21 15:11:32 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:11:32 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:11:32 --> Database Driver Class Initialized
INFO - 2017-04-21 15:11:32 --> Parser Class Initialized
DEBUG - 2017-04-21 15:11:32 --> Session Class Initialized
INFO - 2017-04-21 15:11:32 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:11:32 --> Session routines successfully run
INFO - 2017-04-21 15:11:32 --> Form Validation Class Initialized
INFO - 2017-04-21 15:11:32 --> Controller Class Initialized
DEBUG - 2017-04-21 15:11:32 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:11:32 --> Model Class Initialized
DEBUG - 2017-04-21 15:11:32 --> Pagination Class Initialized
INFO - 2017-04-21 15:11:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:11:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:11:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:11:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:11:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:11:32 --> Final output sent to browser
DEBUG - 2017-04-21 15:11:32 --> Total execution time: 0.2617
INFO - 2017-04-21 15:11:32 --> Config Class Initialized
INFO - 2017-04-21 15:11:32 --> Hooks Class Initialized
INFO - 2017-04-21 15:11:32 --> Config Class Initialized
DEBUG - 2017-04-21 15:11:32 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:11:32 --> Hooks Class Initialized
INFO - 2017-04-21 15:11:32 --> Utf8 Class Initialized
DEBUG - 2017-04-21 15:11:32 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:11:32 --> Utf8 Class Initialized
INFO - 2017-04-21 15:11:32 --> URI Class Initialized
INFO - 2017-04-21 15:11:32 --> Router Class Initialized
INFO - 2017-04-21 15:11:32 --> URI Class Initialized
INFO - 2017-04-21 15:11:32 --> Output Class Initialized
INFO - 2017-04-21 15:11:32 --> Router Class Initialized
INFO - 2017-04-21 15:11:32 --> Security Class Initialized
INFO - 2017-04-21 15:11:32 --> Output Class Initialized
DEBUG - 2017-04-21 15:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:11:32 --> Security Class Initialized
INFO - 2017-04-21 15:11:32 --> Input Class Initialized
DEBUG - 2017-04-21 15:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:11:32 --> Language Class Initialized
INFO - 2017-04-21 15:11:32 --> Input Class Initialized
INFO - 2017-04-21 15:11:32 --> Language Class Initialized
ERROR - 2017-04-21 15:11:32 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-21 15:11:32 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:11:33 --> Config Class Initialized
INFO - 2017-04-21 15:11:33 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:11:33 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:11:33 --> Utf8 Class Initialized
INFO - 2017-04-21 15:11:33 --> URI Class Initialized
INFO - 2017-04-21 15:11:33 --> Router Class Initialized
INFO - 2017-04-21 15:11:33 --> Output Class Initialized
INFO - 2017-04-21 15:11:33 --> Security Class Initialized
DEBUG - 2017-04-21 15:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:11:33 --> Input Class Initialized
INFO - 2017-04-21 15:11:33 --> Language Class Initialized
ERROR - 2017-04-21 15:11:33 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:11:33 --> Config Class Initialized
INFO - 2017-04-21 15:11:33 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:11:33 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:11:33 --> Utf8 Class Initialized
INFO - 2017-04-21 15:11:33 --> URI Class Initialized
INFO - 2017-04-21 15:11:33 --> Router Class Initialized
INFO - 2017-04-21 15:11:33 --> Output Class Initialized
INFO - 2017-04-21 15:11:33 --> Security Class Initialized
DEBUG - 2017-04-21 15:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:11:33 --> Input Class Initialized
INFO - 2017-04-21 15:11:33 --> Language Class Initialized
ERROR - 2017-04-21 15:11:33 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:15:03 --> Config Class Initialized
INFO - 2017-04-21 15:15:03 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:15:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:15:03 --> Utf8 Class Initialized
INFO - 2017-04-21 15:15:03 --> URI Class Initialized
INFO - 2017-04-21 15:15:03 --> Router Class Initialized
INFO - 2017-04-21 15:15:03 --> Output Class Initialized
INFO - 2017-04-21 15:15:03 --> Security Class Initialized
DEBUG - 2017-04-21 15:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:15:03 --> Input Class Initialized
INFO - 2017-04-21 15:15:03 --> Language Class Initialized
INFO - 2017-04-21 15:15:03 --> Loader Class Initialized
INFO - 2017-04-21 15:15:03 --> Helper loaded: url_helper
INFO - 2017-04-21 15:15:03 --> Helper loaded: form_helper
INFO - 2017-04-21 15:15:03 --> Helper loaded: html_helper
INFO - 2017-04-21 15:15:03 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:15:03 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:15:03 --> Database Driver Class Initialized
INFO - 2017-04-21 15:15:03 --> Parser Class Initialized
DEBUG - 2017-04-21 15:15:03 --> Session Class Initialized
INFO - 2017-04-21 15:15:03 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:15:03 --> Session routines successfully run
INFO - 2017-04-21 15:15:03 --> Form Validation Class Initialized
INFO - 2017-04-21 15:15:03 --> Controller Class Initialized
DEBUG - 2017-04-21 15:15:03 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:15:03 --> Model Class Initialized
DEBUG - 2017-04-21 15:15:03 --> Pagination Class Initialized
INFO - 2017-04-21 15:15:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:15:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:15:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:15:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:15:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:15:03 --> Final output sent to browser
DEBUG - 2017-04-21 15:15:03 --> Total execution time: 0.1783
INFO - 2017-04-21 15:15:03 --> Config Class Initialized
INFO - 2017-04-21 15:15:03 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:15:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:15:03 --> Utf8 Class Initialized
INFO - 2017-04-21 15:15:03 --> URI Class Initialized
INFO - 2017-04-21 15:15:03 --> Router Class Initialized
INFO - 2017-04-21 15:15:03 --> Output Class Initialized
INFO - 2017-04-21 15:15:03 --> Security Class Initialized
DEBUG - 2017-04-21 15:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:15:03 --> Input Class Initialized
INFO - 2017-04-21 15:15:03 --> Language Class Initialized
ERROR - 2017-04-21 15:15:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:15:03 --> Config Class Initialized
INFO - 2017-04-21 15:15:03 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:15:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:15:03 --> Utf8 Class Initialized
INFO - 2017-04-21 15:15:03 --> URI Class Initialized
INFO - 2017-04-21 15:15:03 --> Router Class Initialized
INFO - 2017-04-21 15:15:03 --> Output Class Initialized
INFO - 2017-04-21 15:15:03 --> Security Class Initialized
DEBUG - 2017-04-21 15:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:15:03 --> Input Class Initialized
INFO - 2017-04-21 15:15:03 --> Language Class Initialized
ERROR - 2017-04-21 15:15:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:15:03 --> Config Class Initialized
INFO - 2017-04-21 15:15:03 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:15:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:15:03 --> Utf8 Class Initialized
INFO - 2017-04-21 15:15:03 --> URI Class Initialized
INFO - 2017-04-21 15:15:03 --> Router Class Initialized
INFO - 2017-04-21 15:15:03 --> Output Class Initialized
INFO - 2017-04-21 15:15:03 --> Security Class Initialized
DEBUG - 2017-04-21 15:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:15:03 --> Input Class Initialized
INFO - 2017-04-21 15:15:03 --> Language Class Initialized
ERROR - 2017-04-21 15:15:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:15:03 --> Config Class Initialized
INFO - 2017-04-21 15:15:03 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:15:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:15:03 --> Utf8 Class Initialized
INFO - 2017-04-21 15:15:03 --> URI Class Initialized
INFO - 2017-04-21 15:15:03 --> Router Class Initialized
INFO - 2017-04-21 15:15:03 --> Output Class Initialized
INFO - 2017-04-21 15:15:03 --> Security Class Initialized
DEBUG - 2017-04-21 15:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:15:03 --> Input Class Initialized
INFO - 2017-04-21 15:15:03 --> Language Class Initialized
ERROR - 2017-04-21 15:15:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:16:29 --> Config Class Initialized
INFO - 2017-04-21 15:16:29 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:16:29 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:16:29 --> Utf8 Class Initialized
INFO - 2017-04-21 15:16:29 --> URI Class Initialized
INFO - 2017-04-21 15:16:29 --> Router Class Initialized
INFO - 2017-04-21 15:16:29 --> Output Class Initialized
INFO - 2017-04-21 15:16:29 --> Security Class Initialized
DEBUG - 2017-04-21 15:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:16:29 --> Input Class Initialized
INFO - 2017-04-21 15:16:29 --> Language Class Initialized
INFO - 2017-04-21 15:16:29 --> Loader Class Initialized
INFO - 2017-04-21 15:16:29 --> Helper loaded: url_helper
INFO - 2017-04-21 15:16:29 --> Helper loaded: form_helper
INFO - 2017-04-21 15:16:29 --> Helper loaded: html_helper
INFO - 2017-04-21 15:16:29 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:16:29 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:16:29 --> Database Driver Class Initialized
INFO - 2017-04-21 15:16:29 --> Parser Class Initialized
DEBUG - 2017-04-21 15:16:29 --> Session Class Initialized
INFO - 2017-04-21 15:16:29 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:16:29 --> Session routines successfully run
INFO - 2017-04-21 15:16:29 --> Form Validation Class Initialized
INFO - 2017-04-21 15:16:29 --> Controller Class Initialized
DEBUG - 2017-04-21 15:16:29 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:16:29 --> Model Class Initialized
DEBUG - 2017-04-21 15:16:29 --> Pagination Class Initialized
INFO - 2017-04-21 15:16:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:16:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:16:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:16:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:16:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:16:29 --> Final output sent to browser
DEBUG - 2017-04-21 15:16:29 --> Total execution time: 0.2022
INFO - 2017-04-21 15:16:30 --> Config Class Initialized
INFO - 2017-04-21 15:16:30 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:16:30 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:16:30 --> Utf8 Class Initialized
INFO - 2017-04-21 15:16:30 --> URI Class Initialized
INFO - 2017-04-21 15:16:30 --> Router Class Initialized
INFO - 2017-04-21 15:16:30 --> Output Class Initialized
INFO - 2017-04-21 15:16:30 --> Security Class Initialized
DEBUG - 2017-04-21 15:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:16:30 --> Input Class Initialized
INFO - 2017-04-21 15:16:30 --> Language Class Initialized
ERROR - 2017-04-21 15:16:30 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:16:30 --> Config Class Initialized
INFO - 2017-04-21 15:16:30 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:16:30 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:16:30 --> Utf8 Class Initialized
INFO - 2017-04-21 15:16:30 --> URI Class Initialized
INFO - 2017-04-21 15:16:30 --> Router Class Initialized
INFO - 2017-04-21 15:16:30 --> Output Class Initialized
INFO - 2017-04-21 15:16:30 --> Security Class Initialized
DEBUG - 2017-04-21 15:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:16:30 --> Input Class Initialized
INFO - 2017-04-21 15:16:30 --> Language Class Initialized
ERROR - 2017-04-21 15:16:30 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:16:30 --> Config Class Initialized
INFO - 2017-04-21 15:16:30 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:16:30 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:16:30 --> Utf8 Class Initialized
INFO - 2017-04-21 15:16:30 --> URI Class Initialized
INFO - 2017-04-21 15:16:30 --> Router Class Initialized
INFO - 2017-04-21 15:16:30 --> Output Class Initialized
INFO - 2017-04-21 15:16:30 --> Security Class Initialized
DEBUG - 2017-04-21 15:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:16:30 --> Input Class Initialized
INFO - 2017-04-21 15:16:30 --> Language Class Initialized
ERROR - 2017-04-21 15:16:30 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:16:30 --> Config Class Initialized
INFO - 2017-04-21 15:16:30 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:16:30 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:16:30 --> Utf8 Class Initialized
INFO - 2017-04-21 15:16:30 --> URI Class Initialized
INFO - 2017-04-21 15:16:30 --> Router Class Initialized
INFO - 2017-04-21 15:16:30 --> Output Class Initialized
INFO - 2017-04-21 15:16:30 --> Security Class Initialized
DEBUG - 2017-04-21 15:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:16:30 --> Input Class Initialized
INFO - 2017-04-21 15:16:30 --> Language Class Initialized
ERROR - 2017-04-21 15:16:30 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:17:29 --> Config Class Initialized
INFO - 2017-04-21 15:17:29 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:17:29 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:17:29 --> Utf8 Class Initialized
INFO - 2017-04-21 15:17:29 --> URI Class Initialized
INFO - 2017-04-21 15:17:30 --> Router Class Initialized
INFO - 2017-04-21 15:17:30 --> Output Class Initialized
INFO - 2017-04-21 15:17:30 --> Security Class Initialized
DEBUG - 2017-04-21 15:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:17:30 --> Input Class Initialized
INFO - 2017-04-21 15:17:30 --> Language Class Initialized
INFO - 2017-04-21 15:17:30 --> Loader Class Initialized
INFO - 2017-04-21 15:17:30 --> Helper loaded: url_helper
INFO - 2017-04-21 15:17:30 --> Helper loaded: form_helper
INFO - 2017-04-21 15:17:30 --> Helper loaded: html_helper
INFO - 2017-04-21 15:17:30 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:17:30 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:17:30 --> Database Driver Class Initialized
INFO - 2017-04-21 15:17:30 --> Parser Class Initialized
DEBUG - 2017-04-21 15:17:30 --> Session Class Initialized
INFO - 2017-04-21 15:17:30 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:17:30 --> Session routines successfully run
INFO - 2017-04-21 15:17:30 --> Form Validation Class Initialized
INFO - 2017-04-21 15:17:30 --> Controller Class Initialized
DEBUG - 2017-04-21 15:17:30 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:17:30 --> Model Class Initialized
DEBUG - 2017-04-21 15:17:30 --> Pagination Class Initialized
INFO - 2017-04-21 15:17:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:17:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:17:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:17:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:17:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:17:30 --> Final output sent to browser
DEBUG - 2017-04-21 15:17:30 --> Total execution time: 0.1791
INFO - 2017-04-21 15:17:30 --> Config Class Initialized
INFO - 2017-04-21 15:17:30 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:17:30 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:17:30 --> Utf8 Class Initialized
INFO - 2017-04-21 15:17:30 --> URI Class Initialized
INFO - 2017-04-21 15:17:30 --> Router Class Initialized
INFO - 2017-04-21 15:17:30 --> Output Class Initialized
INFO - 2017-04-21 15:17:30 --> Security Class Initialized
DEBUG - 2017-04-21 15:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:17:30 --> Input Class Initialized
INFO - 2017-04-21 15:17:30 --> Language Class Initialized
ERROR - 2017-04-21 15:17:30 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:17:30 --> Config Class Initialized
INFO - 2017-04-21 15:17:30 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:17:30 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:17:30 --> Utf8 Class Initialized
INFO - 2017-04-21 15:17:30 --> URI Class Initialized
INFO - 2017-04-21 15:17:30 --> Router Class Initialized
INFO - 2017-04-21 15:17:30 --> Output Class Initialized
INFO - 2017-04-21 15:17:30 --> Security Class Initialized
DEBUG - 2017-04-21 15:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:17:30 --> Input Class Initialized
INFO - 2017-04-21 15:17:30 --> Language Class Initialized
ERROR - 2017-04-21 15:17:30 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:17:30 --> Config Class Initialized
INFO - 2017-04-21 15:17:30 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:17:30 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:17:30 --> Utf8 Class Initialized
INFO - 2017-04-21 15:17:30 --> URI Class Initialized
INFO - 2017-04-21 15:17:30 --> Router Class Initialized
INFO - 2017-04-21 15:17:30 --> Output Class Initialized
INFO - 2017-04-21 15:17:30 --> Security Class Initialized
DEBUG - 2017-04-21 15:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:17:30 --> Input Class Initialized
INFO - 2017-04-21 15:17:30 --> Language Class Initialized
ERROR - 2017-04-21 15:17:30 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:17:30 --> Config Class Initialized
INFO - 2017-04-21 15:17:30 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:17:30 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:17:30 --> Utf8 Class Initialized
INFO - 2017-04-21 15:17:30 --> URI Class Initialized
INFO - 2017-04-21 15:17:30 --> Router Class Initialized
INFO - 2017-04-21 15:17:30 --> Output Class Initialized
INFO - 2017-04-21 15:17:30 --> Security Class Initialized
DEBUG - 2017-04-21 15:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:17:30 --> Input Class Initialized
INFO - 2017-04-21 15:17:30 --> Language Class Initialized
ERROR - 2017-04-21 15:17:31 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:18:34 --> Config Class Initialized
INFO - 2017-04-21 15:18:34 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:18:34 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:18:34 --> Utf8 Class Initialized
INFO - 2017-04-21 15:18:34 --> URI Class Initialized
INFO - 2017-04-21 15:18:35 --> Router Class Initialized
INFO - 2017-04-21 15:18:35 --> Output Class Initialized
INFO - 2017-04-21 15:18:35 --> Security Class Initialized
DEBUG - 2017-04-21 15:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:18:35 --> Input Class Initialized
INFO - 2017-04-21 15:18:35 --> Language Class Initialized
INFO - 2017-04-21 15:18:35 --> Loader Class Initialized
INFO - 2017-04-21 15:18:35 --> Helper loaded: url_helper
INFO - 2017-04-21 15:18:35 --> Helper loaded: form_helper
INFO - 2017-04-21 15:18:35 --> Helper loaded: html_helper
INFO - 2017-04-21 15:18:35 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:18:35 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:18:35 --> Database Driver Class Initialized
INFO - 2017-04-21 15:18:35 --> Parser Class Initialized
DEBUG - 2017-04-21 15:18:35 --> Session Class Initialized
INFO - 2017-04-21 15:18:35 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:18:35 --> Session routines successfully run
INFO - 2017-04-21 15:18:35 --> Form Validation Class Initialized
INFO - 2017-04-21 15:18:35 --> Controller Class Initialized
DEBUG - 2017-04-21 15:18:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:18:35 --> Model Class Initialized
DEBUG - 2017-04-21 15:18:35 --> Pagination Class Initialized
INFO - 2017-04-21 15:18:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:18:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:18:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:18:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:18:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:18:35 --> Final output sent to browser
DEBUG - 2017-04-21 15:18:35 --> Total execution time: 0.5066
INFO - 2017-04-21 15:18:35 --> Config Class Initialized
INFO - 2017-04-21 15:18:35 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:18:35 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:18:35 --> Utf8 Class Initialized
INFO - 2017-04-21 15:18:35 --> URI Class Initialized
INFO - 2017-04-21 15:18:35 --> Router Class Initialized
INFO - 2017-04-21 15:18:35 --> Output Class Initialized
INFO - 2017-04-21 15:18:35 --> Security Class Initialized
DEBUG - 2017-04-21 15:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:18:35 --> Input Class Initialized
INFO - 2017-04-21 15:18:35 --> Language Class Initialized
ERROR - 2017-04-21 15:18:35 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:18:35 --> Config Class Initialized
INFO - 2017-04-21 15:18:35 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:18:35 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:18:35 --> Utf8 Class Initialized
INFO - 2017-04-21 15:18:35 --> URI Class Initialized
INFO - 2017-04-21 15:18:35 --> Router Class Initialized
INFO - 2017-04-21 15:18:35 --> Output Class Initialized
INFO - 2017-04-21 15:18:35 --> Security Class Initialized
DEBUG - 2017-04-21 15:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:18:35 --> Input Class Initialized
INFO - 2017-04-21 15:18:35 --> Language Class Initialized
ERROR - 2017-04-21 15:18:35 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:18:35 --> Config Class Initialized
INFO - 2017-04-21 15:18:35 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:18:35 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:18:35 --> Utf8 Class Initialized
INFO - 2017-04-21 15:18:35 --> URI Class Initialized
INFO - 2017-04-21 15:18:35 --> Router Class Initialized
INFO - 2017-04-21 15:18:35 --> Output Class Initialized
INFO - 2017-04-21 15:18:35 --> Security Class Initialized
DEBUG - 2017-04-21 15:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:18:35 --> Input Class Initialized
INFO - 2017-04-21 15:18:35 --> Language Class Initialized
ERROR - 2017-04-21 15:18:35 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:18:35 --> Config Class Initialized
INFO - 2017-04-21 15:18:35 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:18:35 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:18:35 --> Utf8 Class Initialized
INFO - 2017-04-21 15:18:35 --> URI Class Initialized
INFO - 2017-04-21 15:18:35 --> Router Class Initialized
INFO - 2017-04-21 15:18:36 --> Output Class Initialized
INFO - 2017-04-21 15:18:36 --> Security Class Initialized
DEBUG - 2017-04-21 15:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:18:36 --> Input Class Initialized
INFO - 2017-04-21 15:18:36 --> Language Class Initialized
ERROR - 2017-04-21 15:18:36 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:18:38 --> Config Class Initialized
INFO - 2017-04-21 15:18:38 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:18:38 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:18:38 --> Utf8 Class Initialized
INFO - 2017-04-21 15:18:38 --> URI Class Initialized
INFO - 2017-04-21 15:18:38 --> Router Class Initialized
INFO - 2017-04-21 15:18:38 --> Output Class Initialized
INFO - 2017-04-21 15:18:38 --> Security Class Initialized
DEBUG - 2017-04-21 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:18:38 --> Input Class Initialized
INFO - 2017-04-21 15:18:38 --> Language Class Initialized
INFO - 2017-04-21 15:18:38 --> Loader Class Initialized
INFO - 2017-04-21 15:18:38 --> Helper loaded: url_helper
INFO - 2017-04-21 15:18:38 --> Helper loaded: form_helper
INFO - 2017-04-21 15:18:38 --> Helper loaded: html_helper
INFO - 2017-04-21 15:18:38 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:18:38 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:18:38 --> Database Driver Class Initialized
INFO - 2017-04-21 15:18:38 --> Parser Class Initialized
DEBUG - 2017-04-21 15:18:38 --> Session Class Initialized
INFO - 2017-04-21 15:18:38 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:18:38 --> Session routines successfully run
INFO - 2017-04-21 15:18:38 --> Form Validation Class Initialized
INFO - 2017-04-21 15:18:38 --> Controller Class Initialized
DEBUG - 2017-04-21 15:18:38 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:18:38 --> Model Class Initialized
DEBUG - 2017-04-21 15:18:38 --> Pagination Class Initialized
INFO - 2017-04-21 15:18:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:18:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:18:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:18:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:18:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:18:38 --> Final output sent to browser
DEBUG - 2017-04-21 15:18:38 --> Total execution time: 0.1975
INFO - 2017-04-21 15:18:38 --> Config Class Initialized
INFO - 2017-04-21 15:18:38 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:18:38 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:18:38 --> Utf8 Class Initialized
INFO - 2017-04-21 15:18:38 --> URI Class Initialized
INFO - 2017-04-21 15:18:38 --> Router Class Initialized
INFO - 2017-04-21 15:18:38 --> Output Class Initialized
INFO - 2017-04-21 15:18:38 --> Security Class Initialized
DEBUG - 2017-04-21 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:18:38 --> Input Class Initialized
INFO - 2017-04-21 15:18:38 --> Language Class Initialized
ERROR - 2017-04-21 15:18:38 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:18:38 --> Config Class Initialized
INFO - 2017-04-21 15:18:38 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:18:38 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:18:38 --> Utf8 Class Initialized
INFO - 2017-04-21 15:18:38 --> URI Class Initialized
INFO - 2017-04-21 15:18:38 --> Router Class Initialized
INFO - 2017-04-21 15:18:38 --> Output Class Initialized
INFO - 2017-04-21 15:18:38 --> Security Class Initialized
DEBUG - 2017-04-21 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:18:38 --> Input Class Initialized
INFO - 2017-04-21 15:18:38 --> Language Class Initialized
ERROR - 2017-04-21 15:18:38 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:18:38 --> Config Class Initialized
INFO - 2017-04-21 15:18:38 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:18:38 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:18:38 --> Utf8 Class Initialized
INFO - 2017-04-21 15:18:38 --> URI Class Initialized
INFO - 2017-04-21 15:18:38 --> Router Class Initialized
INFO - 2017-04-21 15:18:38 --> Output Class Initialized
INFO - 2017-04-21 15:18:38 --> Security Class Initialized
DEBUG - 2017-04-21 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:18:38 --> Input Class Initialized
INFO - 2017-04-21 15:18:38 --> Language Class Initialized
ERROR - 2017-04-21 15:18:38 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:18:38 --> Config Class Initialized
INFO - 2017-04-21 15:18:38 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:18:38 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:18:38 --> Utf8 Class Initialized
INFO - 2017-04-21 15:18:38 --> URI Class Initialized
INFO - 2017-04-21 15:18:38 --> Router Class Initialized
INFO - 2017-04-21 15:18:38 --> Output Class Initialized
INFO - 2017-04-21 15:18:38 --> Security Class Initialized
DEBUG - 2017-04-21 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:18:38 --> Input Class Initialized
INFO - 2017-04-21 15:18:38 --> Language Class Initialized
ERROR - 2017-04-21 15:18:38 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:19:49 --> Config Class Initialized
INFO - 2017-04-21 15:19:49 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:19:49 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:19:49 --> Utf8 Class Initialized
INFO - 2017-04-21 15:19:49 --> URI Class Initialized
INFO - 2017-04-21 15:19:49 --> Router Class Initialized
INFO - 2017-04-21 15:19:49 --> Output Class Initialized
INFO - 2017-04-21 15:19:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:19:50 --> Input Class Initialized
INFO - 2017-04-21 15:19:50 --> Language Class Initialized
INFO - 2017-04-21 15:19:50 --> Loader Class Initialized
INFO - 2017-04-21 15:19:50 --> Helper loaded: url_helper
INFO - 2017-04-21 15:19:50 --> Helper loaded: form_helper
INFO - 2017-04-21 15:19:50 --> Helper loaded: html_helper
INFO - 2017-04-21 15:19:50 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:19:50 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:19:50 --> Database Driver Class Initialized
INFO - 2017-04-21 15:19:50 --> Parser Class Initialized
DEBUG - 2017-04-21 15:19:50 --> Session Class Initialized
INFO - 2017-04-21 15:19:50 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:19:50 --> Session routines successfully run
INFO - 2017-04-21 15:19:50 --> Form Validation Class Initialized
INFO - 2017-04-21 15:19:50 --> Controller Class Initialized
DEBUG - 2017-04-21 15:19:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:19:50 --> Model Class Initialized
DEBUG - 2017-04-21 15:19:50 --> Pagination Class Initialized
INFO - 2017-04-21 15:19:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:19:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:19:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:19:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:19:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:19:50 --> Final output sent to browser
DEBUG - 2017-04-21 15:19:50 --> Total execution time: 0.4923
INFO - 2017-04-21 15:19:50 --> Config Class Initialized
INFO - 2017-04-21 15:19:50 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:19:50 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:19:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:19:50 --> URI Class Initialized
INFO - 2017-04-21 15:19:50 --> Router Class Initialized
INFO - 2017-04-21 15:19:50 --> Output Class Initialized
INFO - 2017-04-21 15:19:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:19:50 --> Input Class Initialized
INFO - 2017-04-21 15:19:50 --> Language Class Initialized
ERROR - 2017-04-21 15:19:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:19:50 --> Config Class Initialized
INFO - 2017-04-21 15:19:50 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:19:50 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:19:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:19:50 --> URI Class Initialized
INFO - 2017-04-21 15:19:50 --> Router Class Initialized
INFO - 2017-04-21 15:19:50 --> Output Class Initialized
INFO - 2017-04-21 15:19:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:19:50 --> Input Class Initialized
INFO - 2017-04-21 15:19:50 --> Language Class Initialized
ERROR - 2017-04-21 15:19:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:19:50 --> Config Class Initialized
INFO - 2017-04-21 15:19:50 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:19:50 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:19:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:19:50 --> URI Class Initialized
INFO - 2017-04-21 15:19:50 --> Router Class Initialized
INFO - 2017-04-21 15:19:50 --> Output Class Initialized
INFO - 2017-04-21 15:19:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:19:50 --> Input Class Initialized
INFO - 2017-04-21 15:19:50 --> Language Class Initialized
ERROR - 2017-04-21 15:19:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:19:50 --> Config Class Initialized
INFO - 2017-04-21 15:19:50 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:19:50 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:19:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:19:50 --> URI Class Initialized
INFO - 2017-04-21 15:19:50 --> Router Class Initialized
INFO - 2017-04-21 15:19:50 --> Output Class Initialized
INFO - 2017-04-21 15:19:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:19:50 --> Input Class Initialized
INFO - 2017-04-21 15:19:50 --> Language Class Initialized
ERROR - 2017-04-21 15:19:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:20:05 --> Config Class Initialized
INFO - 2017-04-21 15:20:05 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:20:05 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:20:05 --> Utf8 Class Initialized
INFO - 2017-04-21 15:20:05 --> URI Class Initialized
INFO - 2017-04-21 15:20:05 --> Router Class Initialized
INFO - 2017-04-21 15:20:05 --> Output Class Initialized
INFO - 2017-04-21 15:20:05 --> Security Class Initialized
DEBUG - 2017-04-21 15:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:20:05 --> Input Class Initialized
INFO - 2017-04-21 15:20:05 --> Language Class Initialized
INFO - 2017-04-21 15:20:05 --> Loader Class Initialized
INFO - 2017-04-21 15:20:05 --> Helper loaded: url_helper
INFO - 2017-04-21 15:20:05 --> Helper loaded: form_helper
INFO - 2017-04-21 15:20:05 --> Helper loaded: html_helper
INFO - 2017-04-21 15:20:05 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:20:05 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:20:05 --> Database Driver Class Initialized
INFO - 2017-04-21 15:20:05 --> Parser Class Initialized
DEBUG - 2017-04-21 15:20:05 --> Session Class Initialized
INFO - 2017-04-21 15:20:05 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:20:05 --> Session routines successfully run
INFO - 2017-04-21 15:20:05 --> Form Validation Class Initialized
INFO - 2017-04-21 15:20:05 --> Controller Class Initialized
DEBUG - 2017-04-21 15:20:05 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:20:05 --> Model Class Initialized
DEBUG - 2017-04-21 15:20:05 --> Pagination Class Initialized
INFO - 2017-04-21 15:20:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:20:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:20:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:20:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:20:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:20:05 --> Final output sent to browser
DEBUG - 2017-04-21 15:20:05 --> Total execution time: 0.1954
INFO - 2017-04-21 15:20:05 --> Config Class Initialized
INFO - 2017-04-21 15:20:05 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:20:05 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:20:05 --> Utf8 Class Initialized
INFO - 2017-04-21 15:20:05 --> URI Class Initialized
INFO - 2017-04-21 15:20:05 --> Router Class Initialized
INFO - 2017-04-21 15:20:05 --> Output Class Initialized
INFO - 2017-04-21 15:20:05 --> Security Class Initialized
DEBUG - 2017-04-21 15:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:20:05 --> Input Class Initialized
INFO - 2017-04-21 15:20:05 --> Language Class Initialized
ERROR - 2017-04-21 15:20:05 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:20:05 --> Config Class Initialized
INFO - 2017-04-21 15:20:05 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:20:05 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:20:05 --> Utf8 Class Initialized
INFO - 2017-04-21 15:20:05 --> URI Class Initialized
INFO - 2017-04-21 15:20:06 --> Router Class Initialized
INFO - 2017-04-21 15:20:06 --> Output Class Initialized
INFO - 2017-04-21 15:20:06 --> Security Class Initialized
DEBUG - 2017-04-21 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:20:06 --> Input Class Initialized
INFO - 2017-04-21 15:20:06 --> Language Class Initialized
ERROR - 2017-04-21 15:20:06 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:20:06 --> Config Class Initialized
INFO - 2017-04-21 15:20:06 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:20:06 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:20:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:20:06 --> URI Class Initialized
INFO - 2017-04-21 15:20:06 --> Router Class Initialized
INFO - 2017-04-21 15:20:06 --> Output Class Initialized
INFO - 2017-04-21 15:20:06 --> Security Class Initialized
DEBUG - 2017-04-21 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:20:06 --> Input Class Initialized
INFO - 2017-04-21 15:20:06 --> Language Class Initialized
ERROR - 2017-04-21 15:20:06 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:20:06 --> Config Class Initialized
INFO - 2017-04-21 15:20:06 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:20:06 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:20:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:20:06 --> URI Class Initialized
INFO - 2017-04-21 15:20:06 --> Router Class Initialized
INFO - 2017-04-21 15:20:06 --> Output Class Initialized
INFO - 2017-04-21 15:20:06 --> Security Class Initialized
DEBUG - 2017-04-21 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:20:06 --> Input Class Initialized
INFO - 2017-04-21 15:20:06 --> Language Class Initialized
ERROR - 2017-04-21 15:20:06 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:20:45 --> Config Class Initialized
INFO - 2017-04-21 15:20:45 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:20:45 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:20:45 --> Utf8 Class Initialized
INFO - 2017-04-21 15:20:45 --> URI Class Initialized
INFO - 2017-04-21 15:20:45 --> Router Class Initialized
INFO - 2017-04-21 15:20:45 --> Output Class Initialized
INFO - 2017-04-21 15:20:45 --> Security Class Initialized
DEBUG - 2017-04-21 15:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:20:45 --> Input Class Initialized
INFO - 2017-04-21 15:20:45 --> Language Class Initialized
INFO - 2017-04-21 15:20:45 --> Loader Class Initialized
INFO - 2017-04-21 15:20:45 --> Helper loaded: url_helper
INFO - 2017-04-21 15:20:45 --> Helper loaded: form_helper
INFO - 2017-04-21 15:20:45 --> Helper loaded: html_helper
INFO - 2017-04-21 15:20:45 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:20:45 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:20:45 --> Database Driver Class Initialized
INFO - 2017-04-21 15:20:45 --> Parser Class Initialized
DEBUG - 2017-04-21 15:20:45 --> Session Class Initialized
INFO - 2017-04-21 15:20:45 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:20:45 --> Session routines successfully run
INFO - 2017-04-21 15:20:45 --> Form Validation Class Initialized
INFO - 2017-04-21 15:20:45 --> Controller Class Initialized
DEBUG - 2017-04-21 15:20:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:20:45 --> Model Class Initialized
DEBUG - 2017-04-21 15:20:45 --> Pagination Class Initialized
INFO - 2017-04-21 15:20:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:20:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:20:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:20:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:20:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:20:45 --> Final output sent to browser
DEBUG - 2017-04-21 15:20:45 --> Total execution time: 0.1596
INFO - 2017-04-21 15:20:45 --> Config Class Initialized
INFO - 2017-04-21 15:20:45 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:20:45 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:20:45 --> Utf8 Class Initialized
INFO - 2017-04-21 15:20:45 --> URI Class Initialized
INFO - 2017-04-21 15:20:45 --> Router Class Initialized
INFO - 2017-04-21 15:20:45 --> Output Class Initialized
INFO - 2017-04-21 15:20:45 --> Security Class Initialized
DEBUG - 2017-04-21 15:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:20:45 --> Input Class Initialized
INFO - 2017-04-21 15:20:45 --> Language Class Initialized
ERROR - 2017-04-21 15:20:45 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:20:45 --> Config Class Initialized
INFO - 2017-04-21 15:20:45 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:20:45 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:20:45 --> Utf8 Class Initialized
INFO - 2017-04-21 15:20:45 --> URI Class Initialized
INFO - 2017-04-21 15:20:45 --> Router Class Initialized
INFO - 2017-04-21 15:20:45 --> Output Class Initialized
INFO - 2017-04-21 15:20:45 --> Security Class Initialized
DEBUG - 2017-04-21 15:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:20:45 --> Input Class Initialized
INFO - 2017-04-21 15:20:45 --> Language Class Initialized
ERROR - 2017-04-21 15:20:45 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:20:45 --> Config Class Initialized
INFO - 2017-04-21 15:20:45 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:20:45 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:20:45 --> Utf8 Class Initialized
INFO - 2017-04-21 15:20:45 --> URI Class Initialized
INFO - 2017-04-21 15:20:45 --> Router Class Initialized
INFO - 2017-04-21 15:20:45 --> Output Class Initialized
INFO - 2017-04-21 15:20:45 --> Security Class Initialized
DEBUG - 2017-04-21 15:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:20:45 --> Input Class Initialized
INFO - 2017-04-21 15:20:45 --> Language Class Initialized
ERROR - 2017-04-21 15:20:45 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:20:45 --> Config Class Initialized
INFO - 2017-04-21 15:20:45 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:20:45 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:20:45 --> Utf8 Class Initialized
INFO - 2017-04-21 15:20:45 --> URI Class Initialized
INFO - 2017-04-21 15:20:45 --> Router Class Initialized
INFO - 2017-04-21 15:20:45 --> Output Class Initialized
INFO - 2017-04-21 15:20:45 --> Security Class Initialized
DEBUG - 2017-04-21 15:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:20:45 --> Input Class Initialized
INFO - 2017-04-21 15:20:45 --> Language Class Initialized
ERROR - 2017-04-21 15:20:45 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:21:03 --> Config Class Initialized
INFO - 2017-04-21 15:21:03 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:03 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:03 --> URI Class Initialized
INFO - 2017-04-21 15:21:03 --> Router Class Initialized
INFO - 2017-04-21 15:21:03 --> Output Class Initialized
INFO - 2017-04-21 15:21:03 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:03 --> Input Class Initialized
INFO - 2017-04-21 15:21:03 --> Language Class Initialized
INFO - 2017-04-21 15:21:03 --> Loader Class Initialized
INFO - 2017-04-21 15:21:03 --> Helper loaded: url_helper
INFO - 2017-04-21 15:21:03 --> Helper loaded: form_helper
INFO - 2017-04-21 15:21:03 --> Helper loaded: html_helper
INFO - 2017-04-21 15:21:03 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:21:03 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:21:03 --> Database Driver Class Initialized
INFO - 2017-04-21 15:21:03 --> Parser Class Initialized
DEBUG - 2017-04-21 15:21:03 --> Session Class Initialized
INFO - 2017-04-21 15:21:03 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:21:03 --> Session routines successfully run
INFO - 2017-04-21 15:21:03 --> Form Validation Class Initialized
INFO - 2017-04-21 15:21:03 --> Controller Class Initialized
DEBUG - 2017-04-21 15:21:03 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:21:03 --> Model Class Initialized
DEBUG - 2017-04-21 15:21:03 --> Pagination Class Initialized
INFO - 2017-04-21 15:21:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:21:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:21:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:21:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:21:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:21:03 --> Final output sent to browser
DEBUG - 2017-04-21 15:21:03 --> Total execution time: 0.1976
INFO - 2017-04-21 15:21:03 --> Config Class Initialized
INFO - 2017-04-21 15:21:03 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:03 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:03 --> Config Class Initialized
INFO - 2017-04-21 15:21:03 --> Hooks Class Initialized
INFO - 2017-04-21 15:21:03 --> URI Class Initialized
INFO - 2017-04-21 15:21:03 --> Router Class Initialized
DEBUG - 2017-04-21 15:21:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:03 --> Output Class Initialized
INFO - 2017-04-21 15:21:03 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:03 --> URI Class Initialized
INFO - 2017-04-21 15:21:03 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:03 --> Router Class Initialized
INFO - 2017-04-21 15:21:03 --> Input Class Initialized
INFO - 2017-04-21 15:21:03 --> Output Class Initialized
INFO - 2017-04-21 15:21:03 --> Language Class Initialized
INFO - 2017-04-21 15:21:03 --> Security Class Initialized
ERROR - 2017-04-21 15:21:03 --> 404 Page Not Found: Default/assets
DEBUG - 2017-04-21 15:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:03 --> Input Class Initialized
INFO - 2017-04-21 15:21:03 --> Language Class Initialized
ERROR - 2017-04-21 15:21:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:21:03 --> Config Class Initialized
INFO - 2017-04-21 15:21:03 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:03 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:03 --> URI Class Initialized
INFO - 2017-04-21 15:21:03 --> Router Class Initialized
INFO - 2017-04-21 15:21:03 --> Output Class Initialized
INFO - 2017-04-21 15:21:03 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:03 --> Input Class Initialized
INFO - 2017-04-21 15:21:03 --> Language Class Initialized
ERROR - 2017-04-21 15:21:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:21:03 --> Config Class Initialized
INFO - 2017-04-21 15:21:03 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:03 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:03 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:03 --> URI Class Initialized
INFO - 2017-04-21 15:21:03 --> Router Class Initialized
INFO - 2017-04-21 15:21:03 --> Output Class Initialized
INFO - 2017-04-21 15:21:03 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:03 --> Input Class Initialized
INFO - 2017-04-21 15:21:03 --> Language Class Initialized
ERROR - 2017-04-21 15:21:04 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:21:06 --> Config Class Initialized
INFO - 2017-04-21 15:21:06 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:06 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:06 --> URI Class Initialized
INFO - 2017-04-21 15:21:06 --> Router Class Initialized
INFO - 2017-04-21 15:21:06 --> Output Class Initialized
INFO - 2017-04-21 15:21:06 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:06 --> Input Class Initialized
INFO - 2017-04-21 15:21:06 --> Language Class Initialized
INFO - 2017-04-21 15:21:06 --> Loader Class Initialized
INFO - 2017-04-21 15:21:06 --> Helper loaded: url_helper
INFO - 2017-04-21 15:21:06 --> Helper loaded: form_helper
INFO - 2017-04-21 15:21:06 --> Helper loaded: html_helper
INFO - 2017-04-21 15:21:06 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:21:06 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:21:06 --> Database Driver Class Initialized
INFO - 2017-04-21 15:21:06 --> Parser Class Initialized
DEBUG - 2017-04-21 15:21:06 --> Session Class Initialized
INFO - 2017-04-21 15:21:06 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:21:06 --> Session routines successfully run
INFO - 2017-04-21 15:21:06 --> Form Validation Class Initialized
INFO - 2017-04-21 15:21:06 --> Controller Class Initialized
DEBUG - 2017-04-21 15:21:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:21:06 --> Model Class Initialized
DEBUG - 2017-04-21 15:21:06 --> Pagination Class Initialized
INFO - 2017-04-21 15:21:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:21:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:21:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:21:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:21:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:21:06 --> Final output sent to browser
DEBUG - 2017-04-21 15:21:06 --> Total execution time: 0.1773
INFO - 2017-04-21 15:21:06 --> Config Class Initialized
INFO - 2017-04-21 15:21:06 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:06 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:06 --> URI Class Initialized
INFO - 2017-04-21 15:21:06 --> Router Class Initialized
INFO - 2017-04-21 15:21:06 --> Config Class Initialized
INFO - 2017-04-21 15:21:06 --> Output Class Initialized
INFO - 2017-04-21 15:21:06 --> Hooks Class Initialized
INFO - 2017-04-21 15:21:06 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:06 --> UTF-8 Support Enabled
DEBUG - 2017-04-21 15:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:06 --> Input Class Initialized
INFO - 2017-04-21 15:21:06 --> URI Class Initialized
INFO - 2017-04-21 15:21:06 --> Language Class Initialized
INFO - 2017-04-21 15:21:06 --> Router Class Initialized
ERROR - 2017-04-21 15:21:06 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:21:06 --> Output Class Initialized
INFO - 2017-04-21 15:21:06 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:06 --> Input Class Initialized
INFO - 2017-04-21 15:21:06 --> Language Class Initialized
ERROR - 2017-04-21 15:21:06 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:21:09 --> Config Class Initialized
INFO - 2017-04-21 15:21:09 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:09 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:09 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:09 --> URI Class Initialized
INFO - 2017-04-21 15:21:09 --> Router Class Initialized
INFO - 2017-04-21 15:21:09 --> Output Class Initialized
INFO - 2017-04-21 15:21:09 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:09 --> Input Class Initialized
INFO - 2017-04-21 15:21:09 --> Language Class Initialized
INFO - 2017-04-21 15:21:09 --> Loader Class Initialized
INFO - 2017-04-21 15:21:09 --> Helper loaded: url_helper
INFO - 2017-04-21 15:21:09 --> Helper loaded: form_helper
INFO - 2017-04-21 15:21:09 --> Helper loaded: html_helper
INFO - 2017-04-21 15:21:09 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:21:09 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:21:09 --> Database Driver Class Initialized
INFO - 2017-04-21 15:21:09 --> Parser Class Initialized
DEBUG - 2017-04-21 15:21:09 --> Session Class Initialized
INFO - 2017-04-21 15:21:09 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:21:09 --> Session routines successfully run
INFO - 2017-04-21 15:21:09 --> Form Validation Class Initialized
INFO - 2017-04-21 15:21:09 --> Controller Class Initialized
DEBUG - 2017-04-21 15:21:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:21:09 --> Model Class Initialized
DEBUG - 2017-04-21 15:21:09 --> Pagination Class Initialized
INFO - 2017-04-21 15:21:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:21:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:21:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:21:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:21:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:21:09 --> Final output sent to browser
DEBUG - 2017-04-21 15:21:09 --> Total execution time: 0.2127
INFO - 2017-04-21 15:21:10 --> Config Class Initialized
INFO - 2017-04-21 15:21:10 --> Config Class Initialized
INFO - 2017-04-21 15:21:10 --> Hooks Class Initialized
INFO - 2017-04-21 15:21:10 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:10 --> UTF-8 Support Enabled
DEBUG - 2017-04-21 15:21:10 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:10 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:10 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:10 --> URI Class Initialized
INFO - 2017-04-21 15:21:10 --> URI Class Initialized
INFO - 2017-04-21 15:21:10 --> Router Class Initialized
INFO - 2017-04-21 15:21:10 --> Router Class Initialized
INFO - 2017-04-21 15:21:10 --> Output Class Initialized
INFO - 2017-04-21 15:21:10 --> Output Class Initialized
INFO - 2017-04-21 15:21:10 --> Security Class Initialized
INFO - 2017-04-21 15:21:10 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-21 15:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:10 --> Input Class Initialized
INFO - 2017-04-21 15:21:10 --> Input Class Initialized
INFO - 2017-04-21 15:21:10 --> Language Class Initialized
INFO - 2017-04-21 15:21:10 --> Language Class Initialized
ERROR - 2017-04-21 15:21:10 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-21 15:21:10 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:21:10 --> Config Class Initialized
INFO - 2017-04-21 15:21:10 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:10 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:10 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:10 --> URI Class Initialized
INFO - 2017-04-21 15:21:10 --> Router Class Initialized
INFO - 2017-04-21 15:21:10 --> Output Class Initialized
INFO - 2017-04-21 15:21:10 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:10 --> Input Class Initialized
INFO - 2017-04-21 15:21:10 --> Language Class Initialized
ERROR - 2017-04-21 15:21:10 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:21:10 --> Config Class Initialized
INFO - 2017-04-21 15:21:10 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:10 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:10 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:10 --> URI Class Initialized
INFO - 2017-04-21 15:21:10 --> Router Class Initialized
INFO - 2017-04-21 15:21:10 --> Output Class Initialized
INFO - 2017-04-21 15:21:10 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:10 --> Input Class Initialized
INFO - 2017-04-21 15:21:10 --> Language Class Initialized
ERROR - 2017-04-21 15:21:10 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:21:12 --> Config Class Initialized
INFO - 2017-04-21 15:21:12 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:12 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:12 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:12 --> URI Class Initialized
INFO - 2017-04-21 15:21:12 --> Router Class Initialized
INFO - 2017-04-21 15:21:12 --> Output Class Initialized
INFO - 2017-04-21 15:21:12 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:12 --> Input Class Initialized
INFO - 2017-04-21 15:21:12 --> Language Class Initialized
INFO - 2017-04-21 15:21:12 --> Loader Class Initialized
INFO - 2017-04-21 15:21:12 --> Helper loaded: url_helper
INFO - 2017-04-21 15:21:12 --> Helper loaded: form_helper
INFO - 2017-04-21 15:21:12 --> Helper loaded: html_helper
INFO - 2017-04-21 15:21:12 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:21:12 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:21:12 --> Database Driver Class Initialized
INFO - 2017-04-21 15:21:12 --> Parser Class Initialized
DEBUG - 2017-04-21 15:21:12 --> Session Class Initialized
INFO - 2017-04-21 15:21:12 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:21:12 --> Session routines successfully run
INFO - 2017-04-21 15:21:12 --> Form Validation Class Initialized
INFO - 2017-04-21 15:21:12 --> Controller Class Initialized
DEBUG - 2017-04-21 15:21:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:21:12 --> Model Class Initialized
DEBUG - 2017-04-21 15:21:12 --> Pagination Class Initialized
INFO - 2017-04-21 15:21:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:21:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:21:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:21:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:21:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:21:12 --> Final output sent to browser
DEBUG - 2017-04-21 15:21:12 --> Total execution time: 0.1608
INFO - 2017-04-21 15:21:12 --> Config Class Initialized
INFO - 2017-04-21 15:21:12 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:12 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:12 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:12 --> URI Class Initialized
INFO - 2017-04-21 15:21:12 --> Router Class Initialized
INFO - 2017-04-21 15:21:12 --> Output Class Initialized
INFO - 2017-04-21 15:21:12 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:12 --> Input Class Initialized
INFO - 2017-04-21 15:21:12 --> Config Class Initialized
INFO - 2017-04-21 15:21:12 --> Language Class Initialized
INFO - 2017-04-21 15:21:12 --> Hooks Class Initialized
ERROR - 2017-04-21 15:21:12 --> 404 Page Not Found: Default/assets
DEBUG - 2017-04-21 15:21:12 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:12 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:12 --> URI Class Initialized
INFO - 2017-04-21 15:21:12 --> Router Class Initialized
INFO - 2017-04-21 15:21:12 --> Output Class Initialized
INFO - 2017-04-21 15:21:12 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:12 --> Input Class Initialized
INFO - 2017-04-21 15:21:12 --> Language Class Initialized
ERROR - 2017-04-21 15:21:12 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:21:12 --> Config Class Initialized
INFO - 2017-04-21 15:21:12 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:12 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:12 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:12 --> URI Class Initialized
INFO - 2017-04-21 15:21:12 --> Router Class Initialized
INFO - 2017-04-21 15:21:12 --> Output Class Initialized
INFO - 2017-04-21 15:21:12 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:12 --> Input Class Initialized
INFO - 2017-04-21 15:21:13 --> Language Class Initialized
ERROR - 2017-04-21 15:21:13 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:21:13 --> Config Class Initialized
INFO - 2017-04-21 15:21:13 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:21:13 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:21:13 --> Utf8 Class Initialized
INFO - 2017-04-21 15:21:13 --> URI Class Initialized
INFO - 2017-04-21 15:21:13 --> Router Class Initialized
INFO - 2017-04-21 15:21:13 --> Output Class Initialized
INFO - 2017-04-21 15:21:13 --> Security Class Initialized
DEBUG - 2017-04-21 15:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:21:13 --> Input Class Initialized
INFO - 2017-04-21 15:21:13 --> Language Class Initialized
ERROR - 2017-04-21 15:21:13 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:24:20 --> Config Class Initialized
INFO - 2017-04-21 15:24:20 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:24:20 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:24:20 --> Utf8 Class Initialized
INFO - 2017-04-21 15:24:20 --> URI Class Initialized
INFO - 2017-04-21 15:24:20 --> Router Class Initialized
INFO - 2017-04-21 15:24:20 --> Output Class Initialized
INFO - 2017-04-21 15:24:20 --> Security Class Initialized
DEBUG - 2017-04-21 15:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:24:20 --> Input Class Initialized
INFO - 2017-04-21 15:24:20 --> Language Class Initialized
INFO - 2017-04-21 15:24:20 --> Loader Class Initialized
INFO - 2017-04-21 15:24:20 --> Helper loaded: url_helper
INFO - 2017-04-21 15:24:20 --> Helper loaded: form_helper
INFO - 2017-04-21 15:24:20 --> Helper loaded: html_helper
INFO - 2017-04-21 15:24:20 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:24:20 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:24:20 --> Database Driver Class Initialized
INFO - 2017-04-21 15:24:20 --> Parser Class Initialized
DEBUG - 2017-04-21 15:24:20 --> Session Class Initialized
INFO - 2017-04-21 15:24:20 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:24:20 --> Session routines successfully run
INFO - 2017-04-21 15:24:20 --> Form Validation Class Initialized
INFO - 2017-04-21 15:24:20 --> Controller Class Initialized
DEBUG - 2017-04-21 15:24:20 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:24:20 --> Model Class Initialized
DEBUG - 2017-04-21 15:24:20 --> Pagination Class Initialized
INFO - 2017-04-21 15:24:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:24:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:24:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:24:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:24:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:24:20 --> Final output sent to browser
DEBUG - 2017-04-21 15:24:20 --> Total execution time: 0.1782
INFO - 2017-04-21 15:24:20 --> Config Class Initialized
INFO - 2017-04-21 15:24:20 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:24:20 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:24:20 --> Utf8 Class Initialized
INFO - 2017-04-21 15:24:20 --> URI Class Initialized
INFO - 2017-04-21 15:24:20 --> Router Class Initialized
INFO - 2017-04-21 15:24:20 --> Output Class Initialized
INFO - 2017-04-21 15:24:20 --> Security Class Initialized
DEBUG - 2017-04-21 15:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:24:20 --> Input Class Initialized
INFO - 2017-04-21 15:24:20 --> Language Class Initialized
ERROR - 2017-04-21 15:24:20 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:24:20 --> Config Class Initialized
INFO - 2017-04-21 15:24:20 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:24:21 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:24:21 --> Utf8 Class Initialized
INFO - 2017-04-21 15:24:21 --> URI Class Initialized
INFO - 2017-04-21 15:24:21 --> Router Class Initialized
INFO - 2017-04-21 15:24:21 --> Output Class Initialized
INFO - 2017-04-21 15:24:21 --> Security Class Initialized
DEBUG - 2017-04-21 15:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:24:21 --> Input Class Initialized
INFO - 2017-04-21 15:24:21 --> Language Class Initialized
ERROR - 2017-04-21 15:24:21 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:24:32 --> Config Class Initialized
INFO - 2017-04-21 15:24:32 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:24:32 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:24:32 --> Utf8 Class Initialized
INFO - 2017-04-21 15:24:32 --> URI Class Initialized
INFO - 2017-04-21 15:24:32 --> Router Class Initialized
INFO - 2017-04-21 15:24:32 --> Output Class Initialized
INFO - 2017-04-21 15:24:32 --> Security Class Initialized
DEBUG - 2017-04-21 15:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:24:32 --> Input Class Initialized
INFO - 2017-04-21 15:24:32 --> Language Class Initialized
INFO - 2017-04-21 15:24:32 --> Loader Class Initialized
INFO - 2017-04-21 15:24:32 --> Helper loaded: url_helper
INFO - 2017-04-21 15:24:32 --> Helper loaded: form_helper
INFO - 2017-04-21 15:24:32 --> Helper loaded: html_helper
INFO - 2017-04-21 15:24:32 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:24:32 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:24:32 --> Database Driver Class Initialized
INFO - 2017-04-21 15:24:32 --> Parser Class Initialized
DEBUG - 2017-04-21 15:24:32 --> Session Class Initialized
INFO - 2017-04-21 15:24:32 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:24:32 --> Session routines successfully run
INFO - 2017-04-21 15:24:32 --> Form Validation Class Initialized
INFO - 2017-04-21 15:24:32 --> Controller Class Initialized
DEBUG - 2017-04-21 15:24:32 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:24:32 --> Model Class Initialized
DEBUG - 2017-04-21 15:24:32 --> Pagination Class Initialized
INFO - 2017-04-21 15:24:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:24:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:24:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:24:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:24:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:24:32 --> Final output sent to browser
DEBUG - 2017-04-21 15:24:32 --> Total execution time: 0.2434
INFO - 2017-04-21 15:24:32 --> Config Class Initialized
INFO - 2017-04-21 15:24:32 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:24:33 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:24:33 --> Utf8 Class Initialized
INFO - 2017-04-21 15:24:33 --> URI Class Initialized
INFO - 2017-04-21 15:24:33 --> Router Class Initialized
INFO - 2017-04-21 15:24:33 --> Output Class Initialized
INFO - 2017-04-21 15:24:33 --> Security Class Initialized
DEBUG - 2017-04-21 15:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:24:33 --> Input Class Initialized
INFO - 2017-04-21 15:24:33 --> Language Class Initialized
ERROR - 2017-04-21 15:24:33 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:24:33 --> Config Class Initialized
INFO - 2017-04-21 15:24:33 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:24:33 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:24:33 --> Utf8 Class Initialized
INFO - 2017-04-21 15:24:33 --> URI Class Initialized
INFO - 2017-04-21 15:24:33 --> Router Class Initialized
INFO - 2017-04-21 15:24:33 --> Output Class Initialized
INFO - 2017-04-21 15:24:33 --> Security Class Initialized
DEBUG - 2017-04-21 15:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:24:33 --> Input Class Initialized
INFO - 2017-04-21 15:24:33 --> Language Class Initialized
ERROR - 2017-04-21 15:24:33 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:24:33 --> Config Class Initialized
INFO - 2017-04-21 15:24:33 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:24:33 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:24:33 --> Utf8 Class Initialized
INFO - 2017-04-21 15:24:33 --> URI Class Initialized
INFO - 2017-04-21 15:24:33 --> Router Class Initialized
INFO - 2017-04-21 15:24:33 --> Output Class Initialized
INFO - 2017-04-21 15:24:33 --> Security Class Initialized
DEBUG - 2017-04-21 15:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:24:33 --> Input Class Initialized
INFO - 2017-04-21 15:24:33 --> Language Class Initialized
ERROR - 2017-04-21 15:24:33 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:24:33 --> Config Class Initialized
INFO - 2017-04-21 15:24:33 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:24:33 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:24:33 --> Utf8 Class Initialized
INFO - 2017-04-21 15:24:33 --> URI Class Initialized
INFO - 2017-04-21 15:24:33 --> Router Class Initialized
INFO - 2017-04-21 15:24:33 --> Output Class Initialized
INFO - 2017-04-21 15:24:33 --> Security Class Initialized
DEBUG - 2017-04-21 15:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:24:33 --> Input Class Initialized
INFO - 2017-04-21 15:24:33 --> Language Class Initialized
ERROR - 2017-04-21 15:24:33 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:28:50 --> Config Class Initialized
INFO - 2017-04-21 15:28:50 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:28:50 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:28:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:28:50 --> URI Class Initialized
INFO - 2017-04-21 15:28:50 --> Router Class Initialized
INFO - 2017-04-21 15:28:50 --> Output Class Initialized
INFO - 2017-04-21 15:28:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:28:50 --> Input Class Initialized
INFO - 2017-04-21 15:28:50 --> Language Class Initialized
INFO - 2017-04-21 15:28:50 --> Loader Class Initialized
INFO - 2017-04-21 15:28:50 --> Helper loaded: url_helper
INFO - 2017-04-21 15:28:50 --> Helper loaded: form_helper
INFO - 2017-04-21 15:28:50 --> Helper loaded: html_helper
INFO - 2017-04-21 15:28:50 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:28:50 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:28:50 --> Database Driver Class Initialized
INFO - 2017-04-21 15:28:50 --> Parser Class Initialized
DEBUG - 2017-04-21 15:28:50 --> Session Class Initialized
INFO - 2017-04-21 15:28:50 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:28:50 --> Session routines successfully run
INFO - 2017-04-21 15:28:50 --> Form Validation Class Initialized
INFO - 2017-04-21 15:28:50 --> Controller Class Initialized
DEBUG - 2017-04-21 15:28:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:28:50 --> Model Class Initialized
DEBUG - 2017-04-21 15:28:50 --> Pagination Class Initialized
INFO - 2017-04-21 15:28:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:28:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-21 15:28:50 --> Severity: Notice --> Use of undefined constant company_id - assumed 'company_id' C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 524
INFO - 2017-04-21 15:28:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:28:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:28:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:28:50 --> Final output sent to browser
DEBUG - 2017-04-21 15:28:50 --> Total execution time: 0.2372
INFO - 2017-04-21 15:28:50 --> Config Class Initialized
INFO - 2017-04-21 15:28:50 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:28:50 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:28:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:28:50 --> URI Class Initialized
INFO - 2017-04-21 15:28:50 --> Router Class Initialized
INFO - 2017-04-21 15:28:50 --> Output Class Initialized
INFO - 2017-04-21 15:28:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:28:50 --> Input Class Initialized
INFO - 2017-04-21 15:28:50 --> Language Class Initialized
ERROR - 2017-04-21 15:28:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:28:50 --> Config Class Initialized
INFO - 2017-04-21 15:28:50 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:28:50 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:28:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:28:50 --> URI Class Initialized
INFO - 2017-04-21 15:28:50 --> Router Class Initialized
INFO - 2017-04-21 15:28:50 --> Output Class Initialized
INFO - 2017-04-21 15:28:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:28:50 --> Input Class Initialized
INFO - 2017-04-21 15:28:50 --> Language Class Initialized
ERROR - 2017-04-21 15:28:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:28:50 --> Config Class Initialized
INFO - 2017-04-21 15:28:50 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:28:50 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:28:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:28:50 --> URI Class Initialized
INFO - 2017-04-21 15:28:50 --> Router Class Initialized
INFO - 2017-04-21 15:28:50 --> Output Class Initialized
INFO - 2017-04-21 15:28:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:28:50 --> Input Class Initialized
INFO - 2017-04-21 15:28:50 --> Language Class Initialized
ERROR - 2017-04-21 15:28:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:28:50 --> Config Class Initialized
INFO - 2017-04-21 15:28:50 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:28:50 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:28:50 --> Utf8 Class Initialized
INFO - 2017-04-21 15:28:50 --> URI Class Initialized
INFO - 2017-04-21 15:28:50 --> Router Class Initialized
INFO - 2017-04-21 15:28:50 --> Output Class Initialized
INFO - 2017-04-21 15:28:50 --> Security Class Initialized
DEBUG - 2017-04-21 15:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:28:50 --> Input Class Initialized
INFO - 2017-04-21 15:28:50 --> Language Class Initialized
ERROR - 2017-04-21 15:28:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:30:05 --> Config Class Initialized
INFO - 2017-04-21 15:30:05 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:30:05 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:30:05 --> Utf8 Class Initialized
INFO - 2017-04-21 15:30:05 --> URI Class Initialized
INFO - 2017-04-21 15:30:05 --> Router Class Initialized
INFO - 2017-04-21 15:30:05 --> Output Class Initialized
INFO - 2017-04-21 15:30:05 --> Security Class Initialized
DEBUG - 2017-04-21 15:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:30:05 --> Input Class Initialized
INFO - 2017-04-21 15:30:05 --> Language Class Initialized
INFO - 2017-04-21 15:30:05 --> Loader Class Initialized
INFO - 2017-04-21 15:30:05 --> Helper loaded: url_helper
INFO - 2017-04-21 15:30:05 --> Helper loaded: form_helper
INFO - 2017-04-21 15:30:05 --> Helper loaded: html_helper
INFO - 2017-04-21 15:30:05 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:30:05 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:30:05 --> Database Driver Class Initialized
INFO - 2017-04-21 15:30:05 --> Parser Class Initialized
DEBUG - 2017-04-21 15:30:05 --> Session Class Initialized
INFO - 2017-04-21 15:30:05 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:30:05 --> Session routines successfully run
INFO - 2017-04-21 15:30:05 --> Form Validation Class Initialized
INFO - 2017-04-21 15:30:05 --> Controller Class Initialized
DEBUG - 2017-04-21 15:30:05 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:30:05 --> Model Class Initialized
DEBUG - 2017-04-21 15:30:05 --> Pagination Class Initialized
INFO - 2017-04-21 15:30:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:30:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-21 15:30:05 --> Severity: Notice --> Use of undefined constant company_id - assumed 'company_id' C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 524
INFO - 2017-04-21 15:30:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:30:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:30:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:30:05 --> Final output sent to browser
DEBUG - 2017-04-21 15:30:05 --> Total execution time: 0.1612
INFO - 2017-04-21 15:30:06 --> Config Class Initialized
INFO - 2017-04-21 15:30:06 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:30:06 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:30:06 --> Config Class Initialized
INFO - 2017-04-21 15:30:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:30:06 --> Hooks Class Initialized
INFO - 2017-04-21 15:30:06 --> URI Class Initialized
DEBUG - 2017-04-21 15:30:06 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:30:06 --> Router Class Initialized
INFO - 2017-04-21 15:30:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:30:06 --> URI Class Initialized
INFO - 2017-04-21 15:30:06 --> Output Class Initialized
INFO - 2017-04-21 15:30:06 --> Router Class Initialized
INFO - 2017-04-21 15:30:06 --> Security Class Initialized
INFO - 2017-04-21 15:30:06 --> Output Class Initialized
DEBUG - 2017-04-21 15:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:30:06 --> Security Class Initialized
INFO - 2017-04-21 15:30:06 --> Input Class Initialized
INFO - 2017-04-21 15:30:06 --> Language Class Initialized
DEBUG - 2017-04-21 15:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-04-21 15:30:06 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:30:06 --> Input Class Initialized
INFO - 2017-04-21 15:30:06 --> Language Class Initialized
ERROR - 2017-04-21 15:30:06 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:30:06 --> Config Class Initialized
INFO - 2017-04-21 15:30:06 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:30:06 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:30:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:30:06 --> URI Class Initialized
INFO - 2017-04-21 15:30:06 --> Router Class Initialized
INFO - 2017-04-21 15:30:06 --> Output Class Initialized
INFO - 2017-04-21 15:30:06 --> Security Class Initialized
DEBUG - 2017-04-21 15:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:30:06 --> Input Class Initialized
INFO - 2017-04-21 15:30:06 --> Language Class Initialized
ERROR - 2017-04-21 15:30:06 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:30:06 --> Config Class Initialized
INFO - 2017-04-21 15:30:06 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:30:06 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:30:06 --> Utf8 Class Initialized
INFO - 2017-04-21 15:30:06 --> URI Class Initialized
INFO - 2017-04-21 15:30:06 --> Router Class Initialized
INFO - 2017-04-21 15:30:06 --> Output Class Initialized
INFO - 2017-04-21 15:30:06 --> Security Class Initialized
DEBUG - 2017-04-21 15:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:30:06 --> Input Class Initialized
INFO - 2017-04-21 15:30:06 --> Language Class Initialized
ERROR - 2017-04-21 15:30:06 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:30:35 --> Config Class Initialized
INFO - 2017-04-21 15:30:35 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:30:35 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:30:35 --> Utf8 Class Initialized
INFO - 2017-04-21 15:30:35 --> URI Class Initialized
INFO - 2017-04-21 15:30:35 --> Router Class Initialized
INFO - 2017-04-21 15:30:35 --> Output Class Initialized
INFO - 2017-04-21 15:30:35 --> Security Class Initialized
DEBUG - 2017-04-21 15:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:30:35 --> Input Class Initialized
INFO - 2017-04-21 15:30:35 --> Language Class Initialized
INFO - 2017-04-21 15:30:35 --> Loader Class Initialized
INFO - 2017-04-21 15:30:35 --> Helper loaded: url_helper
INFO - 2017-04-21 15:30:35 --> Helper loaded: form_helper
INFO - 2017-04-21 15:30:35 --> Helper loaded: html_helper
INFO - 2017-04-21 15:30:35 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:30:35 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:30:35 --> Database Driver Class Initialized
INFO - 2017-04-21 15:30:35 --> Parser Class Initialized
DEBUG - 2017-04-21 15:30:35 --> Session Class Initialized
INFO - 2017-04-21 15:30:35 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:30:35 --> Session routines successfully run
INFO - 2017-04-21 15:30:35 --> Form Validation Class Initialized
INFO - 2017-04-21 15:30:35 --> Controller Class Initialized
DEBUG - 2017-04-21 15:30:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:30:35 --> Model Class Initialized
DEBUG - 2017-04-21 15:30:35 --> Pagination Class Initialized
INFO - 2017-04-21 15:30:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:30:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-21 15:30:35 --> Severity: Notice --> Use of undefined constant company_id - assumed 'company_id' C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 524
INFO - 2017-04-21 15:30:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:30:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:30:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:30:35 --> Final output sent to browser
DEBUG - 2017-04-21 15:30:35 --> Total execution time: 0.1905
INFO - 2017-04-21 15:46:23 --> Config Class Initialized
INFO - 2017-04-21 15:46:23 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:46:23 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:46:23 --> Utf8 Class Initialized
INFO - 2017-04-21 15:46:23 --> URI Class Initialized
INFO - 2017-04-21 15:46:23 --> Router Class Initialized
INFO - 2017-04-21 15:46:23 --> Output Class Initialized
INFO - 2017-04-21 15:46:23 --> Security Class Initialized
DEBUG - 2017-04-21 15:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:46:23 --> Input Class Initialized
INFO - 2017-04-21 15:46:23 --> Language Class Initialized
INFO - 2017-04-21 15:46:23 --> Loader Class Initialized
INFO - 2017-04-21 15:46:23 --> Helper loaded: url_helper
INFO - 2017-04-21 15:46:23 --> Helper loaded: form_helper
INFO - 2017-04-21 15:46:23 --> Helper loaded: html_helper
INFO - 2017-04-21 15:46:23 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:46:23 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:46:23 --> Database Driver Class Initialized
INFO - 2017-04-21 15:46:23 --> Parser Class Initialized
DEBUG - 2017-04-21 15:46:23 --> Session Class Initialized
INFO - 2017-04-21 15:46:23 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:46:23 --> Session routines successfully run
INFO - 2017-04-21 15:46:23 --> Form Validation Class Initialized
INFO - 2017-04-21 15:46:23 --> Controller Class Initialized
DEBUG - 2017-04-21 15:46:23 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:46:23 --> Model Class Initialized
DEBUG - 2017-04-21 15:46:23 --> Pagination Class Initialized
INFO - 2017-04-21 15:46:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:46:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:46:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:46:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:46:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:46:23 --> Final output sent to browser
DEBUG - 2017-04-21 15:46:23 --> Total execution time: 0.3578
INFO - 2017-04-21 15:46:23 --> Config Class Initialized
INFO - 2017-04-21 15:46:23 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:46:23 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:46:23 --> Utf8 Class Initialized
INFO - 2017-04-21 15:46:23 --> URI Class Initialized
INFO - 2017-04-21 15:46:23 --> Router Class Initialized
INFO - 2017-04-21 15:46:23 --> Output Class Initialized
INFO - 2017-04-21 15:46:23 --> Security Class Initialized
DEBUG - 2017-04-21 15:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:46:23 --> Input Class Initialized
INFO - 2017-04-21 15:46:23 --> Language Class Initialized
ERROR - 2017-04-21 15:46:23 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:46:23 --> Config Class Initialized
INFO - 2017-04-21 15:46:24 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:46:24 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:46:24 --> Utf8 Class Initialized
INFO - 2017-04-21 15:46:24 --> URI Class Initialized
INFO - 2017-04-21 15:46:24 --> Router Class Initialized
INFO - 2017-04-21 15:46:24 --> Output Class Initialized
INFO - 2017-04-21 15:46:24 --> Security Class Initialized
DEBUG - 2017-04-21 15:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:46:24 --> Input Class Initialized
INFO - 2017-04-21 15:46:24 --> Language Class Initialized
ERROR - 2017-04-21 15:46:24 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:46:24 --> Config Class Initialized
INFO - 2017-04-21 15:46:24 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:46:24 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:46:24 --> Utf8 Class Initialized
INFO - 2017-04-21 15:46:24 --> URI Class Initialized
INFO - 2017-04-21 15:46:24 --> Router Class Initialized
INFO - 2017-04-21 15:46:24 --> Output Class Initialized
INFO - 2017-04-21 15:46:24 --> Security Class Initialized
DEBUG - 2017-04-21 15:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:46:24 --> Input Class Initialized
INFO - 2017-04-21 15:46:24 --> Language Class Initialized
ERROR - 2017-04-21 15:46:24 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:46:24 --> Config Class Initialized
INFO - 2017-04-21 15:46:24 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:46:24 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:46:24 --> Utf8 Class Initialized
INFO - 2017-04-21 15:46:24 --> URI Class Initialized
INFO - 2017-04-21 15:46:24 --> Router Class Initialized
INFO - 2017-04-21 15:46:24 --> Output Class Initialized
INFO - 2017-04-21 15:46:24 --> Security Class Initialized
DEBUG - 2017-04-21 15:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:46:24 --> Input Class Initialized
INFO - 2017-04-21 15:46:24 --> Language Class Initialized
ERROR - 2017-04-21 15:46:24 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:46:34 --> Config Class Initialized
INFO - 2017-04-21 15:46:34 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:46:34 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:46:34 --> Utf8 Class Initialized
INFO - 2017-04-21 15:46:34 --> URI Class Initialized
INFO - 2017-04-21 15:46:34 --> Router Class Initialized
INFO - 2017-04-21 15:46:34 --> Output Class Initialized
INFO - 2017-04-21 15:46:34 --> Security Class Initialized
DEBUG - 2017-04-21 15:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:46:34 --> Input Class Initialized
INFO - 2017-04-21 15:46:34 --> Language Class Initialized
INFO - 2017-04-21 15:46:34 --> Loader Class Initialized
INFO - 2017-04-21 15:46:34 --> Helper loaded: url_helper
INFO - 2017-04-21 15:46:34 --> Helper loaded: form_helper
INFO - 2017-04-21 15:46:34 --> Helper loaded: html_helper
INFO - 2017-04-21 15:46:34 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:46:34 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:46:34 --> Database Driver Class Initialized
INFO - 2017-04-21 15:46:34 --> Parser Class Initialized
DEBUG - 2017-04-21 15:46:34 --> Session Class Initialized
INFO - 2017-04-21 15:46:34 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:46:34 --> Session routines successfully run
INFO - 2017-04-21 15:46:34 --> Form Validation Class Initialized
INFO - 2017-04-21 15:46:34 --> Controller Class Initialized
DEBUG - 2017-04-21 15:46:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:46:34 --> Model Class Initialized
DEBUG - 2017-04-21 15:46:34 --> Pagination Class Initialized
INFO - 2017-04-21 15:46:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:46:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:46:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:46:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:46:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:46:34 --> Final output sent to browser
DEBUG - 2017-04-21 15:46:34 --> Total execution time: 0.1617
INFO - 2017-04-21 15:46:34 --> Config Class Initialized
INFO - 2017-04-21 15:46:34 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:46:34 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:46:34 --> Utf8 Class Initialized
INFO - 2017-04-21 15:46:34 --> URI Class Initialized
INFO - 2017-04-21 15:46:34 --> Router Class Initialized
INFO - 2017-04-21 15:46:34 --> Output Class Initialized
INFO - 2017-04-21 15:46:34 --> Security Class Initialized
DEBUG - 2017-04-21 15:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:46:34 --> Input Class Initialized
INFO - 2017-04-21 15:46:34 --> Language Class Initialized
ERROR - 2017-04-21 15:46:34 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:46:34 --> Config Class Initialized
INFO - 2017-04-21 15:46:34 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:46:34 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:46:35 --> Utf8 Class Initialized
INFO - 2017-04-21 15:46:35 --> URI Class Initialized
INFO - 2017-04-21 15:46:35 --> Router Class Initialized
INFO - 2017-04-21 15:46:35 --> Output Class Initialized
INFO - 2017-04-21 15:46:35 --> Security Class Initialized
DEBUG - 2017-04-21 15:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:46:35 --> Input Class Initialized
INFO - 2017-04-21 15:46:35 --> Language Class Initialized
ERROR - 2017-04-21 15:46:35 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:46:35 --> Config Class Initialized
INFO - 2017-04-21 15:46:35 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:46:35 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:46:35 --> Utf8 Class Initialized
INFO - 2017-04-21 15:46:35 --> URI Class Initialized
INFO - 2017-04-21 15:46:35 --> Router Class Initialized
INFO - 2017-04-21 15:46:35 --> Output Class Initialized
INFO - 2017-04-21 15:46:35 --> Security Class Initialized
DEBUG - 2017-04-21 15:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:46:35 --> Input Class Initialized
INFO - 2017-04-21 15:46:35 --> Language Class Initialized
ERROR - 2017-04-21 15:46:35 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:46:35 --> Config Class Initialized
INFO - 2017-04-21 15:46:35 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:46:35 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:46:35 --> Utf8 Class Initialized
INFO - 2017-04-21 15:46:35 --> URI Class Initialized
INFO - 2017-04-21 15:46:35 --> Router Class Initialized
INFO - 2017-04-21 15:46:35 --> Output Class Initialized
INFO - 2017-04-21 15:46:35 --> Security Class Initialized
DEBUG - 2017-04-21 15:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:46:35 --> Input Class Initialized
INFO - 2017-04-21 15:46:35 --> Language Class Initialized
ERROR - 2017-04-21 15:46:35 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:47:55 --> Config Class Initialized
INFO - 2017-04-21 15:47:55 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:47:55 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:47:55 --> Utf8 Class Initialized
INFO - 2017-04-21 15:47:55 --> URI Class Initialized
INFO - 2017-04-21 15:47:55 --> Router Class Initialized
INFO - 2017-04-21 15:47:55 --> Output Class Initialized
INFO - 2017-04-21 15:47:55 --> Security Class Initialized
DEBUG - 2017-04-21 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:47:55 --> Input Class Initialized
INFO - 2017-04-21 15:47:55 --> Language Class Initialized
INFO - 2017-04-21 15:47:55 --> Loader Class Initialized
INFO - 2017-04-21 15:47:55 --> Helper loaded: url_helper
INFO - 2017-04-21 15:47:55 --> Helper loaded: form_helper
INFO - 2017-04-21 15:47:55 --> Helper loaded: html_helper
INFO - 2017-04-21 15:47:55 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:47:55 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:47:55 --> Database Driver Class Initialized
INFO - 2017-04-21 15:47:55 --> Parser Class Initialized
DEBUG - 2017-04-21 15:47:55 --> Session Class Initialized
INFO - 2017-04-21 15:47:55 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:47:55 --> Session routines successfully run
INFO - 2017-04-21 15:47:55 --> Form Validation Class Initialized
INFO - 2017-04-21 15:47:55 --> Controller Class Initialized
DEBUG - 2017-04-21 15:47:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:47:55 --> Model Class Initialized
DEBUG - 2017-04-21 15:47:55 --> Pagination Class Initialized
INFO - 2017-04-21 15:47:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:47:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:47:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:47:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:47:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:47:55 --> Final output sent to browser
DEBUG - 2017-04-21 15:47:55 --> Total execution time: 0.1907
INFO - 2017-04-21 15:47:55 --> Config Class Initialized
INFO - 2017-04-21 15:47:55 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:47:55 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:47:55 --> Utf8 Class Initialized
INFO - 2017-04-21 15:47:55 --> URI Class Initialized
INFO - 2017-04-21 15:47:55 --> Router Class Initialized
INFO - 2017-04-21 15:47:55 --> Output Class Initialized
INFO - 2017-04-21 15:47:55 --> Security Class Initialized
DEBUG - 2017-04-21 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:47:55 --> Input Class Initialized
INFO - 2017-04-21 15:47:55 --> Language Class Initialized
ERROR - 2017-04-21 15:47:55 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:47:55 --> Config Class Initialized
INFO - 2017-04-21 15:47:55 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:47:55 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:47:55 --> Utf8 Class Initialized
INFO - 2017-04-21 15:47:55 --> URI Class Initialized
INFO - 2017-04-21 15:47:55 --> Router Class Initialized
INFO - 2017-04-21 15:47:55 --> Output Class Initialized
INFO - 2017-04-21 15:47:55 --> Security Class Initialized
DEBUG - 2017-04-21 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:47:55 --> Input Class Initialized
INFO - 2017-04-21 15:47:55 --> Language Class Initialized
ERROR - 2017-04-21 15:47:55 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:47:55 --> Config Class Initialized
INFO - 2017-04-21 15:47:55 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:47:55 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:47:55 --> Utf8 Class Initialized
INFO - 2017-04-21 15:47:55 --> URI Class Initialized
INFO - 2017-04-21 15:47:55 --> Router Class Initialized
INFO - 2017-04-21 15:47:55 --> Output Class Initialized
INFO - 2017-04-21 15:47:55 --> Security Class Initialized
DEBUG - 2017-04-21 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:47:55 --> Input Class Initialized
INFO - 2017-04-21 15:47:55 --> Language Class Initialized
ERROR - 2017-04-21 15:47:55 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:47:55 --> Config Class Initialized
INFO - 2017-04-21 15:47:55 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:47:55 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:47:55 --> Utf8 Class Initialized
INFO - 2017-04-21 15:47:55 --> URI Class Initialized
INFO - 2017-04-21 15:47:55 --> Router Class Initialized
INFO - 2017-04-21 15:47:55 --> Output Class Initialized
INFO - 2017-04-21 15:47:56 --> Security Class Initialized
DEBUG - 2017-04-21 15:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:47:56 --> Input Class Initialized
INFO - 2017-04-21 15:47:56 --> Language Class Initialized
ERROR - 2017-04-21 15:47:56 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:48:26 --> Config Class Initialized
INFO - 2017-04-21 15:48:26 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:48:26 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:48:26 --> Utf8 Class Initialized
INFO - 2017-04-21 15:48:26 --> URI Class Initialized
INFO - 2017-04-21 15:48:26 --> Router Class Initialized
INFO - 2017-04-21 15:48:26 --> Output Class Initialized
INFO - 2017-04-21 15:48:26 --> Security Class Initialized
DEBUG - 2017-04-21 15:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:48:26 --> Input Class Initialized
INFO - 2017-04-21 15:48:26 --> Language Class Initialized
INFO - 2017-04-21 15:48:26 --> Loader Class Initialized
INFO - 2017-04-21 15:48:26 --> Helper loaded: url_helper
INFO - 2017-04-21 15:48:26 --> Helper loaded: form_helper
INFO - 2017-04-21 15:48:26 --> Helper loaded: html_helper
INFO - 2017-04-21 15:48:26 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:48:26 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:48:26 --> Database Driver Class Initialized
INFO - 2017-04-21 15:48:26 --> Parser Class Initialized
DEBUG - 2017-04-21 15:48:26 --> Session Class Initialized
INFO - 2017-04-21 15:48:26 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:48:26 --> Session routines successfully run
INFO - 2017-04-21 15:48:26 --> Form Validation Class Initialized
INFO - 2017-04-21 15:48:26 --> Controller Class Initialized
DEBUG - 2017-04-21 15:48:26 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:48:26 --> Model Class Initialized
DEBUG - 2017-04-21 15:48:26 --> Pagination Class Initialized
INFO - 2017-04-21 15:48:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:48:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:48:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:48:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:48:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:48:26 --> Final output sent to browser
DEBUG - 2017-04-21 15:48:26 --> Total execution time: 0.1643
INFO - 2017-04-21 15:48:26 --> Config Class Initialized
INFO - 2017-04-21 15:48:26 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:48:26 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:48:26 --> Utf8 Class Initialized
INFO - 2017-04-21 15:48:26 --> URI Class Initialized
INFO - 2017-04-21 15:48:26 --> Router Class Initialized
INFO - 2017-04-21 15:48:26 --> Output Class Initialized
INFO - 2017-04-21 15:48:26 --> Security Class Initialized
DEBUG - 2017-04-21 15:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:48:26 --> Input Class Initialized
INFO - 2017-04-21 15:48:26 --> Language Class Initialized
ERROR - 2017-04-21 15:48:26 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:48:26 --> Config Class Initialized
INFO - 2017-04-21 15:48:26 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:48:26 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:48:26 --> Utf8 Class Initialized
INFO - 2017-04-21 15:48:26 --> URI Class Initialized
INFO - 2017-04-21 15:48:26 --> Router Class Initialized
INFO - 2017-04-21 15:48:26 --> Output Class Initialized
INFO - 2017-04-21 15:48:26 --> Security Class Initialized
DEBUG - 2017-04-21 15:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:48:26 --> Input Class Initialized
INFO - 2017-04-21 15:48:26 --> Language Class Initialized
ERROR - 2017-04-21 15:48:26 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:48:26 --> Config Class Initialized
INFO - 2017-04-21 15:48:26 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:48:26 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:48:26 --> Utf8 Class Initialized
INFO - 2017-04-21 15:48:26 --> URI Class Initialized
INFO - 2017-04-21 15:48:26 --> Router Class Initialized
INFO - 2017-04-21 15:48:26 --> Output Class Initialized
INFO - 2017-04-21 15:48:26 --> Security Class Initialized
DEBUG - 2017-04-21 15:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:48:26 --> Input Class Initialized
INFO - 2017-04-21 15:48:26 --> Language Class Initialized
ERROR - 2017-04-21 15:48:26 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:48:26 --> Config Class Initialized
INFO - 2017-04-21 15:48:26 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:48:26 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:48:26 --> Utf8 Class Initialized
INFO - 2017-04-21 15:48:26 --> URI Class Initialized
INFO - 2017-04-21 15:48:26 --> Router Class Initialized
INFO - 2017-04-21 15:48:26 --> Output Class Initialized
INFO - 2017-04-21 15:48:26 --> Security Class Initialized
DEBUG - 2017-04-21 15:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:48:26 --> Input Class Initialized
INFO - 2017-04-21 15:48:26 --> Language Class Initialized
ERROR - 2017-04-21 15:48:26 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:48:49 --> Config Class Initialized
INFO - 2017-04-21 15:48:49 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:48:49 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:48:49 --> Utf8 Class Initialized
INFO - 2017-04-21 15:48:49 --> URI Class Initialized
INFO - 2017-04-21 15:48:49 --> Router Class Initialized
INFO - 2017-04-21 15:48:49 --> Output Class Initialized
INFO - 2017-04-21 15:48:49 --> Security Class Initialized
DEBUG - 2017-04-21 15:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:48:49 --> Input Class Initialized
INFO - 2017-04-21 15:48:49 --> Language Class Initialized
INFO - 2017-04-21 15:48:49 --> Loader Class Initialized
INFO - 2017-04-21 15:48:49 --> Helper loaded: url_helper
INFO - 2017-04-21 15:48:49 --> Helper loaded: form_helper
INFO - 2017-04-21 15:48:49 --> Helper loaded: html_helper
INFO - 2017-04-21 15:48:49 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:48:49 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:48:49 --> Database Driver Class Initialized
INFO - 2017-04-21 15:48:49 --> Parser Class Initialized
DEBUG - 2017-04-21 15:48:49 --> Session Class Initialized
INFO - 2017-04-21 15:48:49 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:48:49 --> Session routines successfully run
INFO - 2017-04-21 15:48:49 --> Form Validation Class Initialized
INFO - 2017-04-21 15:48:49 --> Controller Class Initialized
DEBUG - 2017-04-21 15:48:49 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:48:49 --> Model Class Initialized
DEBUG - 2017-04-21 15:48:49 --> Pagination Class Initialized
INFO - 2017-04-21 15:48:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:48:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:48:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:48:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:48:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:48:49 --> Final output sent to browser
DEBUG - 2017-04-21 15:48:49 --> Total execution time: 0.1797
INFO - 2017-04-21 15:48:49 --> Config Class Initialized
INFO - 2017-04-21 15:48:49 --> Config Class Initialized
INFO - 2017-04-21 15:48:49 --> Hooks Class Initialized
INFO - 2017-04-21 15:48:49 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:48:49 --> UTF-8 Support Enabled
DEBUG - 2017-04-21 15:48:49 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:48:49 --> Utf8 Class Initialized
INFO - 2017-04-21 15:48:49 --> Utf8 Class Initialized
INFO - 2017-04-21 15:48:49 --> URI Class Initialized
INFO - 2017-04-21 15:48:49 --> URI Class Initialized
INFO - 2017-04-21 15:48:49 --> Router Class Initialized
INFO - 2017-04-21 15:48:49 --> Router Class Initialized
INFO - 2017-04-21 15:48:49 --> Output Class Initialized
INFO - 2017-04-21 15:48:49 --> Output Class Initialized
INFO - 2017-04-21 15:48:49 --> Security Class Initialized
INFO - 2017-04-21 15:48:49 --> Security Class Initialized
DEBUG - 2017-04-21 15:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-21 15:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:48:49 --> Input Class Initialized
INFO - 2017-04-21 15:48:49 --> Input Class Initialized
INFO - 2017-04-21 15:48:49 --> Language Class Initialized
INFO - 2017-04-21 15:48:49 --> Language Class Initialized
ERROR - 2017-04-21 15:48:49 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-21 15:48:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:49:13 --> Config Class Initialized
INFO - 2017-04-21 15:49:13 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:49:13 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:49:13 --> Utf8 Class Initialized
INFO - 2017-04-21 15:49:13 --> URI Class Initialized
INFO - 2017-04-21 15:49:13 --> Router Class Initialized
INFO - 2017-04-21 15:49:13 --> Output Class Initialized
INFO - 2017-04-21 15:49:13 --> Security Class Initialized
DEBUG - 2017-04-21 15:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:49:13 --> Input Class Initialized
INFO - 2017-04-21 15:49:13 --> Language Class Initialized
INFO - 2017-04-21 15:49:13 --> Loader Class Initialized
INFO - 2017-04-21 15:49:13 --> Helper loaded: url_helper
INFO - 2017-04-21 15:49:13 --> Helper loaded: form_helper
INFO - 2017-04-21 15:49:13 --> Helper loaded: html_helper
INFO - 2017-04-21 15:49:13 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:49:13 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:49:13 --> Database Driver Class Initialized
INFO - 2017-04-21 15:49:13 --> Parser Class Initialized
DEBUG - 2017-04-21 15:49:13 --> Session Class Initialized
INFO - 2017-04-21 15:49:13 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:49:13 --> Session routines successfully run
INFO - 2017-04-21 15:49:13 --> Form Validation Class Initialized
INFO - 2017-04-21 15:49:13 --> Controller Class Initialized
DEBUG - 2017-04-21 15:49:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:49:13 --> Model Class Initialized
DEBUG - 2017-04-21 15:49:13 --> Pagination Class Initialized
INFO - 2017-04-21 15:49:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:49:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:49:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:49:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:49:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:49:13 --> Final output sent to browser
DEBUG - 2017-04-21 15:49:13 --> Total execution time: 0.2468
INFO - 2017-04-21 15:49:13 --> Config Class Initialized
INFO - 2017-04-21 15:49:13 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:49:13 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:49:13 --> Utf8 Class Initialized
INFO - 2017-04-21 15:49:13 --> URI Class Initialized
INFO - 2017-04-21 15:49:13 --> Router Class Initialized
INFO - 2017-04-21 15:49:13 --> Output Class Initialized
INFO - 2017-04-21 15:49:13 --> Security Class Initialized
DEBUG - 2017-04-21 15:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:49:13 --> Input Class Initialized
INFO - 2017-04-21 15:49:13 --> Language Class Initialized
ERROR - 2017-04-21 15:49:13 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:49:14 --> Config Class Initialized
INFO - 2017-04-21 15:49:14 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:49:14 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:49:14 --> Utf8 Class Initialized
INFO - 2017-04-21 15:49:14 --> URI Class Initialized
INFO - 2017-04-21 15:49:14 --> Router Class Initialized
INFO - 2017-04-21 15:49:14 --> Output Class Initialized
INFO - 2017-04-21 15:49:14 --> Security Class Initialized
DEBUG - 2017-04-21 15:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:49:14 --> Input Class Initialized
INFO - 2017-04-21 15:49:14 --> Language Class Initialized
ERROR - 2017-04-21 15:49:14 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:49:17 --> Config Class Initialized
INFO - 2017-04-21 15:49:17 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:49:17 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:49:17 --> Utf8 Class Initialized
INFO - 2017-04-21 15:49:17 --> URI Class Initialized
INFO - 2017-04-21 15:49:17 --> Router Class Initialized
INFO - 2017-04-21 15:49:17 --> Output Class Initialized
INFO - 2017-04-21 15:49:17 --> Security Class Initialized
DEBUG - 2017-04-21 15:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:49:17 --> Input Class Initialized
INFO - 2017-04-21 15:49:17 --> Language Class Initialized
INFO - 2017-04-21 15:49:17 --> Loader Class Initialized
INFO - 2017-04-21 15:49:17 --> Helper loaded: url_helper
INFO - 2017-04-21 15:49:17 --> Helper loaded: form_helper
INFO - 2017-04-21 15:49:17 --> Helper loaded: html_helper
INFO - 2017-04-21 15:49:17 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:49:17 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:49:17 --> Database Driver Class Initialized
INFO - 2017-04-21 15:49:17 --> Parser Class Initialized
DEBUG - 2017-04-21 15:49:17 --> Session Class Initialized
INFO - 2017-04-21 15:49:17 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:49:17 --> Session routines successfully run
INFO - 2017-04-21 15:49:17 --> Form Validation Class Initialized
INFO - 2017-04-21 15:49:17 --> Controller Class Initialized
DEBUG - 2017-04-21 15:49:17 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:49:17 --> Model Class Initialized
DEBUG - 2017-04-21 15:49:17 --> Pagination Class Initialized
INFO - 2017-04-21 15:49:17 --> Final output sent to browser
DEBUG - 2017-04-21 15:49:17 --> Total execution time: 0.1130
INFO - 2017-04-21 15:49:22 --> Config Class Initialized
INFO - 2017-04-21 15:49:22 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:49:22 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:49:22 --> Utf8 Class Initialized
INFO - 2017-04-21 15:49:22 --> URI Class Initialized
INFO - 2017-04-21 15:49:22 --> Router Class Initialized
INFO - 2017-04-21 15:49:22 --> Output Class Initialized
INFO - 2017-04-21 15:49:22 --> Security Class Initialized
DEBUG - 2017-04-21 15:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:49:22 --> Input Class Initialized
INFO - 2017-04-21 15:49:22 --> Language Class Initialized
INFO - 2017-04-21 15:49:22 --> Loader Class Initialized
INFO - 2017-04-21 15:49:22 --> Helper loaded: url_helper
INFO - 2017-04-21 15:49:22 --> Helper loaded: form_helper
INFO - 2017-04-21 15:49:22 --> Helper loaded: html_helper
INFO - 2017-04-21 15:49:22 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:49:22 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:49:22 --> Database Driver Class Initialized
INFO - 2017-04-21 15:49:22 --> Parser Class Initialized
DEBUG - 2017-04-21 15:49:22 --> Session Class Initialized
INFO - 2017-04-21 15:49:22 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:49:22 --> Session routines successfully run
INFO - 2017-04-21 15:49:22 --> Form Validation Class Initialized
INFO - 2017-04-21 15:49:22 --> Controller Class Initialized
DEBUG - 2017-04-21 15:49:22 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:49:22 --> Model Class Initialized
DEBUG - 2017-04-21 15:49:22 --> Pagination Class Initialized
INFO - 2017-04-21 15:49:22 --> Final output sent to browser
DEBUG - 2017-04-21 15:49:22 --> Total execution time: 0.1310
INFO - 2017-04-21 15:56:53 --> Config Class Initialized
INFO - 2017-04-21 15:56:53 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:56:53 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:56:53 --> Utf8 Class Initialized
INFO - 2017-04-21 15:56:53 --> URI Class Initialized
INFO - 2017-04-21 15:56:53 --> Router Class Initialized
INFO - 2017-04-21 15:56:53 --> Output Class Initialized
INFO - 2017-04-21 15:56:53 --> Security Class Initialized
DEBUG - 2017-04-21 15:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:56:53 --> Input Class Initialized
INFO - 2017-04-21 15:56:53 --> Language Class Initialized
INFO - 2017-04-21 15:56:53 --> Loader Class Initialized
INFO - 2017-04-21 15:56:53 --> Helper loaded: url_helper
INFO - 2017-04-21 15:56:53 --> Helper loaded: form_helper
INFO - 2017-04-21 15:56:53 --> Helper loaded: html_helper
INFO - 2017-04-21 15:56:53 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:56:53 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:56:53 --> Database Driver Class Initialized
INFO - 2017-04-21 15:56:53 --> Parser Class Initialized
DEBUG - 2017-04-21 15:56:53 --> Session Class Initialized
INFO - 2017-04-21 15:56:53 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:56:53 --> Session routines successfully run
INFO - 2017-04-21 15:56:53 --> Form Validation Class Initialized
INFO - 2017-04-21 15:56:53 --> Controller Class Initialized
DEBUG - 2017-04-21 15:56:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:56:53 --> Model Class Initialized
DEBUG - 2017-04-21 15:56:53 --> Pagination Class Initialized
INFO - 2017-04-21 15:56:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:56:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:56:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:56:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:56:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:56:53 --> Final output sent to browser
DEBUG - 2017-04-21 15:56:53 --> Total execution time: 0.2842
INFO - 2017-04-21 15:56:53 --> Config Class Initialized
INFO - 2017-04-21 15:56:53 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:56:53 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:56:53 --> Utf8 Class Initialized
INFO - 2017-04-21 15:56:53 --> URI Class Initialized
INFO - 2017-04-21 15:56:53 --> Router Class Initialized
INFO - 2017-04-21 15:56:53 --> Output Class Initialized
INFO - 2017-04-21 15:56:53 --> Security Class Initialized
DEBUG - 2017-04-21 15:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:56:53 --> Input Class Initialized
INFO - 2017-04-21 15:56:53 --> Language Class Initialized
ERROR - 2017-04-21 15:56:53 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:56:53 --> Config Class Initialized
INFO - 2017-04-21 15:56:53 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:56:53 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:56:53 --> Utf8 Class Initialized
INFO - 2017-04-21 15:56:53 --> URI Class Initialized
INFO - 2017-04-21 15:56:53 --> Router Class Initialized
INFO - 2017-04-21 15:56:53 --> Output Class Initialized
INFO - 2017-04-21 15:56:53 --> Security Class Initialized
DEBUG - 2017-04-21 15:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:56:53 --> Input Class Initialized
INFO - 2017-04-21 15:56:53 --> Language Class Initialized
ERROR - 2017-04-21 15:56:53 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:56:53 --> Config Class Initialized
INFO - 2017-04-21 15:56:53 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:56:53 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:56:53 --> Utf8 Class Initialized
INFO - 2017-04-21 15:56:53 --> URI Class Initialized
INFO - 2017-04-21 15:56:53 --> Router Class Initialized
INFO - 2017-04-21 15:56:54 --> Output Class Initialized
INFO - 2017-04-21 15:56:54 --> Security Class Initialized
DEBUG - 2017-04-21 15:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:56:54 --> Input Class Initialized
INFO - 2017-04-21 15:56:54 --> Language Class Initialized
ERROR - 2017-04-21 15:56:54 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:56:54 --> Config Class Initialized
INFO - 2017-04-21 15:56:54 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:56:54 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:56:54 --> Utf8 Class Initialized
INFO - 2017-04-21 15:56:54 --> URI Class Initialized
INFO - 2017-04-21 15:56:54 --> Router Class Initialized
INFO - 2017-04-21 15:56:54 --> Output Class Initialized
INFO - 2017-04-21 15:56:54 --> Security Class Initialized
DEBUG - 2017-04-21 15:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:56:54 --> Input Class Initialized
INFO - 2017-04-21 15:56:54 --> Language Class Initialized
ERROR - 2017-04-21 15:56:54 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:57:02 --> Config Class Initialized
INFO - 2017-04-21 15:57:02 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:57:02 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:57:02 --> Utf8 Class Initialized
INFO - 2017-04-21 15:57:02 --> URI Class Initialized
INFO - 2017-04-21 15:57:02 --> Router Class Initialized
INFO - 2017-04-21 15:57:02 --> Output Class Initialized
INFO - 2017-04-21 15:57:02 --> Security Class Initialized
DEBUG - 2017-04-21 15:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:57:02 --> Input Class Initialized
INFO - 2017-04-21 15:57:02 --> Language Class Initialized
INFO - 2017-04-21 15:57:02 --> Loader Class Initialized
INFO - 2017-04-21 15:57:02 --> Helper loaded: url_helper
INFO - 2017-04-21 15:57:02 --> Helper loaded: form_helper
INFO - 2017-04-21 15:57:02 --> Helper loaded: html_helper
INFO - 2017-04-21 15:57:02 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:57:02 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:57:02 --> Database Driver Class Initialized
INFO - 2017-04-21 15:57:02 --> Parser Class Initialized
DEBUG - 2017-04-21 15:57:02 --> Session Class Initialized
INFO - 2017-04-21 15:57:02 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:57:02 --> Session routines successfully run
INFO - 2017-04-21 15:57:02 --> Form Validation Class Initialized
INFO - 2017-04-21 15:57:02 --> Controller Class Initialized
DEBUG - 2017-04-21 15:57:02 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:57:02 --> Model Class Initialized
DEBUG - 2017-04-21 15:57:02 --> Pagination Class Initialized
INFO - 2017-04-21 15:57:16 --> Config Class Initialized
INFO - 2017-04-21 15:57:16 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:57:16 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:57:16 --> Utf8 Class Initialized
INFO - 2017-04-21 15:57:16 --> URI Class Initialized
INFO - 2017-04-21 15:57:16 --> Router Class Initialized
INFO - 2017-04-21 15:57:16 --> Output Class Initialized
INFO - 2017-04-21 15:57:16 --> Security Class Initialized
DEBUG - 2017-04-21 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:57:16 --> Input Class Initialized
INFO - 2017-04-21 15:57:16 --> Language Class Initialized
INFO - 2017-04-21 15:57:16 --> Loader Class Initialized
INFO - 2017-04-21 15:57:16 --> Helper loaded: url_helper
INFO - 2017-04-21 15:57:16 --> Helper loaded: form_helper
INFO - 2017-04-21 15:57:16 --> Helper loaded: html_helper
INFO - 2017-04-21 15:57:16 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:57:16 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:57:16 --> Database Driver Class Initialized
INFO - 2017-04-21 15:57:16 --> Parser Class Initialized
DEBUG - 2017-04-21 15:57:16 --> Session Class Initialized
INFO - 2017-04-21 15:57:16 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:57:16 --> Session routines successfully run
INFO - 2017-04-21 15:57:16 --> Form Validation Class Initialized
INFO - 2017-04-21 15:57:16 --> Controller Class Initialized
DEBUG - 2017-04-21 15:57:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:57:16 --> Model Class Initialized
DEBUG - 2017-04-21 15:57:16 --> Pagination Class Initialized
INFO - 2017-04-21 15:58:00 --> Config Class Initialized
INFO - 2017-04-21 15:58:00 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:58:00 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:58:00 --> Utf8 Class Initialized
INFO - 2017-04-21 15:58:00 --> URI Class Initialized
INFO - 2017-04-21 15:58:00 --> Router Class Initialized
INFO - 2017-04-21 15:58:00 --> Output Class Initialized
INFO - 2017-04-21 15:58:00 --> Security Class Initialized
DEBUG - 2017-04-21 15:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:58:00 --> Input Class Initialized
INFO - 2017-04-21 15:58:00 --> Language Class Initialized
INFO - 2017-04-21 15:58:00 --> Loader Class Initialized
INFO - 2017-04-21 15:58:00 --> Helper loaded: url_helper
INFO - 2017-04-21 15:58:00 --> Helper loaded: form_helper
INFO - 2017-04-21 15:58:00 --> Helper loaded: html_helper
INFO - 2017-04-21 15:58:00 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:58:00 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:58:00 --> Database Driver Class Initialized
INFO - 2017-04-21 15:58:00 --> Parser Class Initialized
DEBUG - 2017-04-21 15:58:00 --> Session Class Initialized
INFO - 2017-04-21 15:58:00 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:58:00 --> Session routines successfully run
INFO - 2017-04-21 15:58:00 --> Form Validation Class Initialized
INFO - 2017-04-21 15:58:00 --> Controller Class Initialized
DEBUG - 2017-04-21 15:58:00 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:58:00 --> Model Class Initialized
DEBUG - 2017-04-21 15:58:00 --> Pagination Class Initialized
INFO - 2017-04-21 15:58:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:58:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:58:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:58:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:58:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:58:01 --> Final output sent to browser
DEBUG - 2017-04-21 15:58:01 --> Total execution time: 0.4323
INFO - 2017-04-21 15:58:01 --> Config Class Initialized
INFO - 2017-04-21 15:58:01 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:58:01 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:58:01 --> Utf8 Class Initialized
INFO - 2017-04-21 15:58:01 --> URI Class Initialized
INFO - 2017-04-21 15:58:01 --> Router Class Initialized
INFO - 2017-04-21 15:58:01 --> Output Class Initialized
INFO - 2017-04-21 15:58:01 --> Security Class Initialized
DEBUG - 2017-04-21 15:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:58:01 --> Input Class Initialized
INFO - 2017-04-21 15:58:01 --> Language Class Initialized
ERROR - 2017-04-21 15:58:01 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:58:01 --> Config Class Initialized
INFO - 2017-04-21 15:58:01 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:58:01 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:58:01 --> Utf8 Class Initialized
INFO - 2017-04-21 15:58:01 --> URI Class Initialized
INFO - 2017-04-21 15:58:01 --> Router Class Initialized
INFO - 2017-04-21 15:58:01 --> Output Class Initialized
INFO - 2017-04-21 15:58:01 --> Security Class Initialized
DEBUG - 2017-04-21 15:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:58:01 --> Input Class Initialized
INFO - 2017-04-21 15:58:01 --> Language Class Initialized
ERROR - 2017-04-21 15:58:01 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:58:01 --> Config Class Initialized
INFO - 2017-04-21 15:58:01 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:58:01 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:58:01 --> Utf8 Class Initialized
INFO - 2017-04-21 15:58:01 --> URI Class Initialized
INFO - 2017-04-21 15:58:01 --> Router Class Initialized
INFO - 2017-04-21 15:58:01 --> Output Class Initialized
INFO - 2017-04-21 15:58:01 --> Security Class Initialized
DEBUG - 2017-04-21 15:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:58:01 --> Input Class Initialized
INFO - 2017-04-21 15:58:01 --> Language Class Initialized
ERROR - 2017-04-21 15:58:01 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:58:01 --> Config Class Initialized
INFO - 2017-04-21 15:58:01 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:58:01 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:58:01 --> Utf8 Class Initialized
INFO - 2017-04-21 15:58:01 --> URI Class Initialized
INFO - 2017-04-21 15:58:01 --> Router Class Initialized
INFO - 2017-04-21 15:58:01 --> Output Class Initialized
INFO - 2017-04-21 15:58:01 --> Security Class Initialized
DEBUG - 2017-04-21 15:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:58:01 --> Input Class Initialized
INFO - 2017-04-21 15:58:01 --> Language Class Initialized
ERROR - 2017-04-21 15:58:01 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:58:29 --> Config Class Initialized
INFO - 2017-04-21 15:58:29 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:58:29 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:58:29 --> Utf8 Class Initialized
INFO - 2017-04-21 15:58:29 --> URI Class Initialized
INFO - 2017-04-21 15:58:29 --> Router Class Initialized
INFO - 2017-04-21 15:58:29 --> Output Class Initialized
INFO - 2017-04-21 15:58:29 --> Security Class Initialized
DEBUG - 2017-04-21 15:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:58:29 --> Input Class Initialized
INFO - 2017-04-21 15:58:29 --> Language Class Initialized
INFO - 2017-04-21 15:58:29 --> Loader Class Initialized
INFO - 2017-04-21 15:58:29 --> Helper loaded: url_helper
INFO - 2017-04-21 15:58:29 --> Helper loaded: form_helper
INFO - 2017-04-21 15:58:29 --> Helper loaded: html_helper
INFO - 2017-04-21 15:58:29 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:58:29 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:58:29 --> Database Driver Class Initialized
INFO - 2017-04-21 15:58:29 --> Parser Class Initialized
DEBUG - 2017-04-21 15:58:30 --> Session Class Initialized
INFO - 2017-04-21 15:58:30 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:58:30 --> Session routines successfully run
INFO - 2017-04-21 15:58:30 --> Form Validation Class Initialized
INFO - 2017-04-21 15:58:30 --> Controller Class Initialized
DEBUG - 2017-04-21 15:58:30 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:58:30 --> Model Class Initialized
DEBUG - 2017-04-21 15:58:30 --> Pagination Class Initialized
ERROR - 2017-04-21 15:58:30 --> Severity: Notice --> Use of undefined constant PRIVATEKEY - assumed 'PRIVATEKEY' C:\xampp\htdocs\schedullo\application\admin\controllers\Company.php 1135
ERROR - 2017-04-21 15:58:30 --> Severity: Notice --> Use of undefined constant PRIVATEKEY - assumed 'PRIVATEKEY' C:\xampp\htdocs\schedullo\application\admin\controllers\Company.php 1136
INFO - 2017-04-21 15:59:31 --> Config Class Initialized
INFO - 2017-04-21 15:59:31 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:59:31 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:59:31 --> Utf8 Class Initialized
INFO - 2017-04-21 15:59:31 --> URI Class Initialized
INFO - 2017-04-21 15:59:31 --> Router Class Initialized
INFO - 2017-04-21 15:59:31 --> Output Class Initialized
INFO - 2017-04-21 15:59:31 --> Security Class Initialized
DEBUG - 2017-04-21 15:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:59:31 --> Input Class Initialized
INFO - 2017-04-21 15:59:31 --> Language Class Initialized
INFO - 2017-04-21 15:59:31 --> Loader Class Initialized
INFO - 2017-04-21 15:59:31 --> Helper loaded: url_helper
INFO - 2017-04-21 15:59:31 --> Helper loaded: form_helper
INFO - 2017-04-21 15:59:31 --> Helper loaded: html_helper
INFO - 2017-04-21 15:59:31 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:59:31 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:59:31 --> Database Driver Class Initialized
INFO - 2017-04-21 15:59:31 --> Parser Class Initialized
DEBUG - 2017-04-21 15:59:31 --> Session Class Initialized
INFO - 2017-04-21 15:59:31 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:59:31 --> Session routines successfully run
INFO - 2017-04-21 15:59:31 --> Form Validation Class Initialized
INFO - 2017-04-21 15:59:31 --> Controller Class Initialized
DEBUG - 2017-04-21 15:59:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:59:31 --> Model Class Initialized
DEBUG - 2017-04-21 15:59:31 --> Pagination Class Initialized
INFO - 2017-04-21 15:59:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:59:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:59:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 15:59:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:59:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:59:31 --> Final output sent to browser
DEBUG - 2017-04-21 15:59:31 --> Total execution time: 0.2018
INFO - 2017-04-21 15:59:31 --> Config Class Initialized
INFO - 2017-04-21 15:59:31 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:59:31 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:59:31 --> Utf8 Class Initialized
INFO - 2017-04-21 15:59:31 --> URI Class Initialized
INFO - 2017-04-21 15:59:31 --> Router Class Initialized
INFO - 2017-04-21 15:59:31 --> Output Class Initialized
INFO - 2017-04-21 15:59:31 --> Security Class Initialized
DEBUG - 2017-04-21 15:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:59:31 --> Input Class Initialized
INFO - 2017-04-21 15:59:31 --> Language Class Initialized
ERROR - 2017-04-21 15:59:31 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:59:31 --> Config Class Initialized
INFO - 2017-04-21 15:59:31 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:59:31 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:59:31 --> Utf8 Class Initialized
INFO - 2017-04-21 15:59:31 --> URI Class Initialized
INFO - 2017-04-21 15:59:31 --> Router Class Initialized
INFO - 2017-04-21 15:59:31 --> Output Class Initialized
INFO - 2017-04-21 15:59:31 --> Security Class Initialized
DEBUG - 2017-04-21 15:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:59:31 --> Input Class Initialized
INFO - 2017-04-21 15:59:31 --> Language Class Initialized
ERROR - 2017-04-21 15:59:31 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:59:31 --> Config Class Initialized
INFO - 2017-04-21 15:59:31 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:59:31 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:59:31 --> Utf8 Class Initialized
INFO - 2017-04-21 15:59:31 --> URI Class Initialized
INFO - 2017-04-21 15:59:31 --> Router Class Initialized
INFO - 2017-04-21 15:59:31 --> Output Class Initialized
INFO - 2017-04-21 15:59:31 --> Security Class Initialized
DEBUG - 2017-04-21 15:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:59:31 --> Input Class Initialized
INFO - 2017-04-21 15:59:31 --> Language Class Initialized
ERROR - 2017-04-21 15:59:31 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:59:31 --> Config Class Initialized
INFO - 2017-04-21 15:59:31 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:59:31 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:59:31 --> Utf8 Class Initialized
INFO - 2017-04-21 15:59:31 --> URI Class Initialized
INFO - 2017-04-21 15:59:31 --> Router Class Initialized
INFO - 2017-04-21 15:59:31 --> Output Class Initialized
INFO - 2017-04-21 15:59:31 --> Security Class Initialized
DEBUG - 2017-04-21 15:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:59:31 --> Input Class Initialized
INFO - 2017-04-21 15:59:31 --> Language Class Initialized
ERROR - 2017-04-21 15:59:31 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 15:59:37 --> Config Class Initialized
INFO - 2017-04-21 15:59:37 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:59:37 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:59:37 --> Utf8 Class Initialized
INFO - 2017-04-21 15:59:37 --> URI Class Initialized
INFO - 2017-04-21 15:59:37 --> Router Class Initialized
INFO - 2017-04-21 15:59:37 --> Output Class Initialized
INFO - 2017-04-21 15:59:37 --> Security Class Initialized
DEBUG - 2017-04-21 15:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:59:37 --> Input Class Initialized
INFO - 2017-04-21 15:59:37 --> Language Class Initialized
INFO - 2017-04-21 15:59:37 --> Loader Class Initialized
INFO - 2017-04-21 15:59:37 --> Helper loaded: url_helper
INFO - 2017-04-21 15:59:37 --> Helper loaded: form_helper
INFO - 2017-04-21 15:59:37 --> Helper loaded: html_helper
INFO - 2017-04-21 15:59:37 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:59:37 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:59:37 --> Database Driver Class Initialized
INFO - 2017-04-21 15:59:37 --> Parser Class Initialized
DEBUG - 2017-04-21 15:59:37 --> Session Class Initialized
INFO - 2017-04-21 15:59:37 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:59:37 --> Session routines successfully run
INFO - 2017-04-21 15:59:37 --> Form Validation Class Initialized
INFO - 2017-04-21 15:59:37 --> Controller Class Initialized
DEBUG - 2017-04-21 15:59:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:59:37 --> Model Class Initialized
DEBUG - 2017-04-21 15:59:37 --> Pagination Class Initialized
INFO - 2017-04-21 15:59:41 --> Config Class Initialized
INFO - 2017-04-21 15:59:41 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:59:41 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:59:41 --> Utf8 Class Initialized
INFO - 2017-04-21 15:59:41 --> URI Class Initialized
INFO - 2017-04-21 15:59:41 --> Router Class Initialized
INFO - 2017-04-21 15:59:41 --> Output Class Initialized
INFO - 2017-04-21 15:59:41 --> Security Class Initialized
DEBUG - 2017-04-21 15:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:59:41 --> Input Class Initialized
INFO - 2017-04-21 15:59:41 --> Language Class Initialized
INFO - 2017-04-21 15:59:41 --> Loader Class Initialized
INFO - 2017-04-21 15:59:41 --> Helper loaded: url_helper
INFO - 2017-04-21 15:59:41 --> Helper loaded: form_helper
INFO - 2017-04-21 15:59:41 --> Helper loaded: html_helper
INFO - 2017-04-21 15:59:41 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:59:41 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:59:41 --> Database Driver Class Initialized
INFO - 2017-04-21 15:59:41 --> Parser Class Initialized
DEBUG - 2017-04-21 15:59:41 --> Session Class Initialized
INFO - 2017-04-21 15:59:41 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:59:41 --> Session routines successfully run
INFO - 2017-04-21 15:59:41 --> Form Validation Class Initialized
INFO - 2017-04-21 15:59:41 --> Controller Class Initialized
DEBUG - 2017-04-21 15:59:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:59:41 --> Model Class Initialized
DEBUG - 2017-04-21 15:59:41 --> Pagination Class Initialized
INFO - 2017-04-21 15:59:51 --> Config Class Initialized
INFO - 2017-04-21 15:59:51 --> Hooks Class Initialized
DEBUG - 2017-04-21 15:59:51 --> UTF-8 Support Enabled
INFO - 2017-04-21 15:59:51 --> Utf8 Class Initialized
INFO - 2017-04-21 15:59:51 --> URI Class Initialized
INFO - 2017-04-21 15:59:51 --> Router Class Initialized
INFO - 2017-04-21 15:59:51 --> Output Class Initialized
INFO - 2017-04-21 15:59:51 --> Security Class Initialized
DEBUG - 2017-04-21 15:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 15:59:51 --> Input Class Initialized
INFO - 2017-04-21 15:59:51 --> Language Class Initialized
INFO - 2017-04-21 15:59:51 --> Loader Class Initialized
INFO - 2017-04-21 15:59:51 --> Helper loaded: url_helper
INFO - 2017-04-21 15:59:51 --> Helper loaded: form_helper
INFO - 2017-04-21 15:59:51 --> Helper loaded: html_helper
INFO - 2017-04-21 15:59:51 --> Helper loaded: custom_helper
INFO - 2017-04-21 15:59:51 --> Helper loaded: cache_helper
INFO - 2017-04-21 15:59:51 --> Database Driver Class Initialized
INFO - 2017-04-21 15:59:51 --> Parser Class Initialized
DEBUG - 2017-04-21 15:59:51 --> Session Class Initialized
INFO - 2017-04-21 15:59:51 --> Helper loaded: string_helper
DEBUG - 2017-04-21 15:59:51 --> Session routines successfully run
INFO - 2017-04-21 15:59:51 --> Form Validation Class Initialized
INFO - 2017-04-21 15:59:51 --> Controller Class Initialized
DEBUG - 2017-04-21 15:59:51 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 15:59:51 --> Model Class Initialized
DEBUG - 2017-04-21 15:59:51 --> Pagination Class Initialized
INFO - 2017-04-21 15:59:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 15:59:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 15:59:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-21 15:59:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 15:59:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 15:59:54 --> Final output sent to browser
DEBUG - 2017-04-21 15:59:54 --> Total execution time: 3.4249
INFO - 2017-04-21 16:00:02 --> Config Class Initialized
INFO - 2017-04-21 16:00:02 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:00:02 --> Utf8 Class Initialized
INFO - 2017-04-21 16:00:02 --> URI Class Initialized
INFO - 2017-04-21 16:00:02 --> Router Class Initialized
INFO - 2017-04-21 16:00:02 --> Output Class Initialized
INFO - 2017-04-21 16:00:02 --> Security Class Initialized
DEBUG - 2017-04-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:00:02 --> Input Class Initialized
INFO - 2017-04-21 16:00:02 --> Language Class Initialized
INFO - 2017-04-21 16:00:02 --> Loader Class Initialized
INFO - 2017-04-21 16:00:02 --> Helper loaded: url_helper
INFO - 2017-04-21 16:00:02 --> Helper loaded: form_helper
INFO - 2017-04-21 16:00:02 --> Helper loaded: html_helper
INFO - 2017-04-21 16:00:02 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:00:02 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:00:02 --> Database Driver Class Initialized
INFO - 2017-04-21 16:00:02 --> Parser Class Initialized
DEBUG - 2017-04-21 16:00:02 --> Session Class Initialized
INFO - 2017-04-21 16:00:02 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:00:02 --> Session routines successfully run
INFO - 2017-04-21 16:00:02 --> Form Validation Class Initialized
INFO - 2017-04-21 16:00:02 --> Controller Class Initialized
DEBUG - 2017-04-21 16:00:02 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:00:02 --> Model Class Initialized
DEBUG - 2017-04-21 16:00:02 --> Pagination Class Initialized
INFO - 2017-04-21 16:00:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 16:00:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 16:00:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 16:00:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 16:00:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 16:00:02 --> Final output sent to browser
DEBUG - 2017-04-21 16:00:02 --> Total execution time: 0.3849
INFO - 2017-04-21 16:00:02 --> Config Class Initialized
INFO - 2017-04-21 16:00:02 --> Hooks Class Initialized
INFO - 2017-04-21 16:00:02 --> Config Class Initialized
DEBUG - 2017-04-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:00:02 --> Hooks Class Initialized
INFO - 2017-04-21 16:00:02 --> Utf8 Class Initialized
DEBUG - 2017-04-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:00:02 --> Utf8 Class Initialized
INFO - 2017-04-21 16:00:02 --> URI Class Initialized
INFO - 2017-04-21 16:00:02 --> URI Class Initialized
INFO - 2017-04-21 16:00:02 --> Router Class Initialized
INFO - 2017-04-21 16:00:02 --> Router Class Initialized
INFO - 2017-04-21 16:00:02 --> Output Class Initialized
INFO - 2017-04-21 16:00:02 --> Output Class Initialized
INFO - 2017-04-21 16:00:02 --> Security Class Initialized
INFO - 2017-04-21 16:00:02 --> Security Class Initialized
DEBUG - 2017-04-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:00:02 --> Input Class Initialized
INFO - 2017-04-21 16:00:02 --> Input Class Initialized
INFO - 2017-04-21 16:00:02 --> Language Class Initialized
INFO - 2017-04-21 16:00:02 --> Language Class Initialized
ERROR - 2017-04-21 16:00:02 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-21 16:00:02 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:00:02 --> Config Class Initialized
INFO - 2017-04-21 16:00:02 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:00:02 --> Utf8 Class Initialized
INFO - 2017-04-21 16:00:02 --> URI Class Initialized
INFO - 2017-04-21 16:00:02 --> Router Class Initialized
INFO - 2017-04-21 16:00:02 --> Output Class Initialized
INFO - 2017-04-21 16:00:02 --> Security Class Initialized
DEBUG - 2017-04-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:00:02 --> Input Class Initialized
INFO - 2017-04-21 16:00:02 --> Language Class Initialized
ERROR - 2017-04-21 16:00:02 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:00:09 --> Config Class Initialized
INFO - 2017-04-21 16:00:09 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:00:09 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:00:09 --> Utf8 Class Initialized
INFO - 2017-04-21 16:00:09 --> URI Class Initialized
INFO - 2017-04-21 16:00:09 --> Router Class Initialized
INFO - 2017-04-21 16:00:09 --> Output Class Initialized
INFO - 2017-04-21 16:00:09 --> Security Class Initialized
DEBUG - 2017-04-21 16:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:00:09 --> Input Class Initialized
INFO - 2017-04-21 16:00:09 --> Language Class Initialized
INFO - 2017-04-21 16:00:09 --> Loader Class Initialized
INFO - 2017-04-21 16:00:09 --> Helper loaded: url_helper
INFO - 2017-04-21 16:00:09 --> Helper loaded: form_helper
INFO - 2017-04-21 16:00:09 --> Helper loaded: html_helper
INFO - 2017-04-21 16:00:09 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:00:09 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:00:09 --> Database Driver Class Initialized
INFO - 2017-04-21 16:00:09 --> Parser Class Initialized
DEBUG - 2017-04-21 16:00:09 --> Session Class Initialized
INFO - 2017-04-21 16:00:09 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:00:09 --> Session routines successfully run
INFO - 2017-04-21 16:00:09 --> Form Validation Class Initialized
INFO - 2017-04-21 16:00:09 --> Controller Class Initialized
DEBUG - 2017-04-21 16:00:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:00:09 --> Model Class Initialized
DEBUG - 2017-04-21 16:00:09 --> Pagination Class Initialized
INFO - 2017-04-21 16:00:14 --> Config Class Initialized
INFO - 2017-04-21 16:00:14 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:00:14 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:00:14 --> Utf8 Class Initialized
INFO - 2017-04-21 16:00:14 --> URI Class Initialized
INFO - 2017-04-21 16:00:14 --> Router Class Initialized
INFO - 2017-04-21 16:00:14 --> Output Class Initialized
INFO - 2017-04-21 16:00:14 --> Security Class Initialized
DEBUG - 2017-04-21 16:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:00:14 --> Input Class Initialized
INFO - 2017-04-21 16:00:14 --> Language Class Initialized
INFO - 2017-04-21 16:00:14 --> Loader Class Initialized
INFO - 2017-04-21 16:00:14 --> Helper loaded: url_helper
INFO - 2017-04-21 16:00:14 --> Helper loaded: form_helper
INFO - 2017-04-21 16:00:14 --> Helper loaded: html_helper
INFO - 2017-04-21 16:00:14 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:00:14 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:00:14 --> Database Driver Class Initialized
INFO - 2017-04-21 16:00:14 --> Parser Class Initialized
DEBUG - 2017-04-21 16:00:14 --> Session Class Initialized
INFO - 2017-04-21 16:00:14 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:00:14 --> Session routines successfully run
INFO - 2017-04-21 16:00:14 --> Form Validation Class Initialized
INFO - 2017-04-21 16:00:14 --> Controller Class Initialized
DEBUG - 2017-04-21 16:00:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:00:14 --> Model Class Initialized
DEBUG - 2017-04-21 16:00:14 --> Pagination Class Initialized
INFO - 2017-04-21 16:00:17 --> Config Class Initialized
INFO - 2017-04-21 16:00:17 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:00:17 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:00:17 --> Utf8 Class Initialized
INFO - 2017-04-21 16:00:17 --> URI Class Initialized
INFO - 2017-04-21 16:00:17 --> Router Class Initialized
INFO - 2017-04-21 16:00:17 --> Output Class Initialized
INFO - 2017-04-21 16:00:17 --> Security Class Initialized
DEBUG - 2017-04-21 16:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:00:17 --> Input Class Initialized
INFO - 2017-04-21 16:00:17 --> Language Class Initialized
INFO - 2017-04-21 16:00:17 --> Loader Class Initialized
INFO - 2017-04-21 16:00:17 --> Helper loaded: url_helper
INFO - 2017-04-21 16:00:17 --> Helper loaded: form_helper
INFO - 2017-04-21 16:00:17 --> Helper loaded: html_helper
INFO - 2017-04-21 16:00:17 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:00:17 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:00:17 --> Database Driver Class Initialized
INFO - 2017-04-21 16:00:17 --> Parser Class Initialized
DEBUG - 2017-04-21 16:00:17 --> Session Class Initialized
INFO - 2017-04-21 16:00:17 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:00:17 --> Session routines successfully run
INFO - 2017-04-21 16:00:17 --> Form Validation Class Initialized
INFO - 2017-04-21 16:00:17 --> Controller Class Initialized
DEBUG - 2017-04-21 16:00:17 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:00:17 --> Model Class Initialized
DEBUG - 2017-04-21 16:00:17 --> Pagination Class Initialized
INFO - 2017-04-21 16:00:47 --> Config Class Initialized
INFO - 2017-04-21 16:00:47 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:00:47 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:00:47 --> Utf8 Class Initialized
INFO - 2017-04-21 16:00:47 --> URI Class Initialized
INFO - 2017-04-21 16:00:47 --> Router Class Initialized
INFO - 2017-04-21 16:00:47 --> Output Class Initialized
INFO - 2017-04-21 16:00:47 --> Security Class Initialized
DEBUG - 2017-04-21 16:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:00:47 --> Input Class Initialized
INFO - 2017-04-21 16:00:47 --> Language Class Initialized
INFO - 2017-04-21 16:00:47 --> Loader Class Initialized
INFO - 2017-04-21 16:00:47 --> Helper loaded: url_helper
INFO - 2017-04-21 16:00:47 --> Helper loaded: form_helper
INFO - 2017-04-21 16:00:47 --> Helper loaded: html_helper
INFO - 2017-04-21 16:00:47 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:00:47 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:00:47 --> Database Driver Class Initialized
INFO - 2017-04-21 16:00:47 --> Parser Class Initialized
DEBUG - 2017-04-21 16:00:47 --> Session Class Initialized
INFO - 2017-04-21 16:00:47 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:00:47 --> Session routines successfully run
INFO - 2017-04-21 16:00:47 --> Form Validation Class Initialized
INFO - 2017-04-21 16:00:47 --> Controller Class Initialized
INFO - 2017-04-21 16:00:47 --> Model Class Initialized
INFO - 2017-04-21 16:00:47 --> Config Class Initialized
INFO - 2017-04-21 16:00:47 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:00:47 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:00:47 --> Utf8 Class Initialized
INFO - 2017-04-21 16:00:47 --> URI Class Initialized
INFO - 2017-04-21 16:00:47 --> Router Class Initialized
INFO - 2017-04-21 16:00:47 --> Output Class Initialized
INFO - 2017-04-21 16:00:47 --> Security Class Initialized
DEBUG - 2017-04-21 16:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:00:47 --> Input Class Initialized
INFO - 2017-04-21 16:00:47 --> Language Class Initialized
INFO - 2017-04-21 16:00:47 --> Loader Class Initialized
INFO - 2017-04-21 16:00:47 --> Helper loaded: url_helper
INFO - 2017-04-21 16:00:47 --> Helper loaded: form_helper
INFO - 2017-04-21 16:00:47 --> Helper loaded: html_helper
INFO - 2017-04-21 16:00:47 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:00:47 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:00:47 --> Database Driver Class Initialized
INFO - 2017-04-21 16:00:47 --> Parser Class Initialized
DEBUG - 2017-04-21 16:00:47 --> Session Class Initialized
INFO - 2017-04-21 16:00:47 --> Helper loaded: string_helper
ERROR - 2017-04-21 16:00:47 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-21 16:00:47 --> Session routines successfully run
INFO - 2017-04-21 16:00:47 --> Form Validation Class Initialized
INFO - 2017-04-21 16:00:47 --> Controller Class Initialized
INFO - 2017-04-21 16:00:47 --> Model Class Initialized
INFO - 2017-04-21 16:00:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-21 16:00:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 16:00:47 --> Final output sent to browser
DEBUG - 2017-04-21 16:00:47 --> Total execution time: 0.1805
INFO - 2017-04-21 16:10:19 --> Config Class Initialized
INFO - 2017-04-21 16:10:19 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:10:19 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:10:19 --> Utf8 Class Initialized
INFO - 2017-04-21 16:10:19 --> URI Class Initialized
INFO - 2017-04-21 16:10:19 --> Router Class Initialized
INFO - 2017-04-21 16:10:19 --> Output Class Initialized
INFO - 2017-04-21 16:10:19 --> Security Class Initialized
DEBUG - 2017-04-21 16:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:10:19 --> Input Class Initialized
INFO - 2017-04-21 16:10:19 --> Language Class Initialized
INFO - 2017-04-21 16:10:19 --> Loader Class Initialized
INFO - 2017-04-21 16:10:19 --> Helper loaded: url_helper
INFO - 2017-04-21 16:10:19 --> Helper loaded: form_helper
INFO - 2017-04-21 16:10:19 --> Helper loaded: html_helper
INFO - 2017-04-21 16:10:19 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:10:19 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:10:19 --> Database Driver Class Initialized
INFO - 2017-04-21 16:10:19 --> Parser Class Initialized
DEBUG - 2017-04-21 16:10:19 --> Session Class Initialized
INFO - 2017-04-21 16:10:19 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:10:19 --> Session routines successfully run
INFO - 2017-04-21 16:10:19 --> Form Validation Class Initialized
INFO - 2017-04-21 16:10:19 --> Controller Class Initialized
DEBUG - 2017-04-21 16:10:19 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:10:19 --> Model Class Initialized
DEBUG - 2017-04-21 16:10:19 --> Pagination Class Initialized
INFO - 2017-04-21 16:10:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 16:10:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 16:10:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 16:10:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 16:10:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 16:10:19 --> Final output sent to browser
DEBUG - 2017-04-21 16:10:19 --> Total execution time: 0.2564
INFO - 2017-04-21 16:10:19 --> Config Class Initialized
INFO - 2017-04-21 16:10:19 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:10:19 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:10:19 --> Utf8 Class Initialized
INFO - 2017-04-21 16:10:19 --> URI Class Initialized
INFO - 2017-04-21 16:10:19 --> Router Class Initialized
INFO - 2017-04-21 16:10:19 --> Output Class Initialized
INFO - 2017-04-21 16:10:19 --> Security Class Initialized
DEBUG - 2017-04-21 16:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:10:19 --> Input Class Initialized
INFO - 2017-04-21 16:10:19 --> Language Class Initialized
ERROR - 2017-04-21 16:10:19 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:10:19 --> Config Class Initialized
INFO - 2017-04-21 16:10:19 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:10:19 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:10:19 --> Utf8 Class Initialized
INFO - 2017-04-21 16:10:19 --> URI Class Initialized
INFO - 2017-04-21 16:10:19 --> Router Class Initialized
INFO - 2017-04-21 16:10:19 --> Output Class Initialized
INFO - 2017-04-21 16:10:19 --> Security Class Initialized
DEBUG - 2017-04-21 16:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:10:19 --> Input Class Initialized
INFO - 2017-04-21 16:10:19 --> Language Class Initialized
ERROR - 2017-04-21 16:10:19 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:10:19 --> Config Class Initialized
INFO - 2017-04-21 16:10:19 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:10:19 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:10:19 --> Utf8 Class Initialized
INFO - 2017-04-21 16:10:19 --> URI Class Initialized
INFO - 2017-04-21 16:10:19 --> Router Class Initialized
INFO - 2017-04-21 16:10:19 --> Output Class Initialized
INFO - 2017-04-21 16:10:19 --> Security Class Initialized
DEBUG - 2017-04-21 16:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:10:19 --> Input Class Initialized
INFO - 2017-04-21 16:10:19 --> Language Class Initialized
ERROR - 2017-04-21 16:10:19 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:10:19 --> Config Class Initialized
INFO - 2017-04-21 16:10:19 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:10:19 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:10:19 --> Utf8 Class Initialized
INFO - 2017-04-21 16:10:19 --> URI Class Initialized
INFO - 2017-04-21 16:10:19 --> Router Class Initialized
INFO - 2017-04-21 16:10:19 --> Output Class Initialized
INFO - 2017-04-21 16:10:19 --> Security Class Initialized
DEBUG - 2017-04-21 16:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:10:19 --> Input Class Initialized
INFO - 2017-04-21 16:10:19 --> Language Class Initialized
ERROR - 2017-04-21 16:10:19 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:10:24 --> Config Class Initialized
INFO - 2017-04-21 16:10:24 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:10:24 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:10:24 --> Utf8 Class Initialized
INFO - 2017-04-21 16:10:24 --> URI Class Initialized
INFO - 2017-04-21 16:10:24 --> Router Class Initialized
INFO - 2017-04-21 16:10:24 --> Output Class Initialized
INFO - 2017-04-21 16:10:24 --> Security Class Initialized
DEBUG - 2017-04-21 16:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:10:24 --> Input Class Initialized
INFO - 2017-04-21 16:10:24 --> Language Class Initialized
INFO - 2017-04-21 16:10:24 --> Loader Class Initialized
INFO - 2017-04-21 16:10:24 --> Helper loaded: url_helper
INFO - 2017-04-21 16:10:24 --> Helper loaded: form_helper
INFO - 2017-04-21 16:10:24 --> Helper loaded: html_helper
INFO - 2017-04-21 16:10:24 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:10:24 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:10:24 --> Database Driver Class Initialized
INFO - 2017-04-21 16:10:24 --> Parser Class Initialized
DEBUG - 2017-04-21 16:10:24 --> Session Class Initialized
INFO - 2017-04-21 16:10:24 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:10:24 --> Session routines successfully run
INFO - 2017-04-21 16:10:24 --> Form Validation Class Initialized
INFO - 2017-04-21 16:10:24 --> Controller Class Initialized
DEBUG - 2017-04-21 16:10:24 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:10:24 --> Model Class Initialized
DEBUG - 2017-04-21 16:10:24 --> Pagination Class Initialized
INFO - 2017-04-21 16:10:38 --> Config Class Initialized
INFO - 2017-04-21 16:10:38 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:10:38 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:10:38 --> Utf8 Class Initialized
INFO - 2017-04-21 16:10:38 --> URI Class Initialized
INFO - 2017-04-21 16:10:38 --> Router Class Initialized
INFO - 2017-04-21 16:10:38 --> Output Class Initialized
INFO - 2017-04-21 16:10:38 --> Security Class Initialized
DEBUG - 2017-04-21 16:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:10:38 --> Input Class Initialized
INFO - 2017-04-21 16:10:38 --> Language Class Initialized
INFO - 2017-04-21 16:10:38 --> Loader Class Initialized
INFO - 2017-04-21 16:10:38 --> Helper loaded: url_helper
INFO - 2017-04-21 16:10:38 --> Helper loaded: form_helper
INFO - 2017-04-21 16:10:38 --> Helper loaded: html_helper
INFO - 2017-04-21 16:10:38 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:10:38 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:10:38 --> Database Driver Class Initialized
INFO - 2017-04-21 16:10:38 --> Parser Class Initialized
DEBUG - 2017-04-21 16:10:38 --> Session Class Initialized
INFO - 2017-04-21 16:10:38 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:10:38 --> Session routines successfully run
INFO - 2017-04-21 16:10:38 --> Form Validation Class Initialized
INFO - 2017-04-21 16:10:38 --> Controller Class Initialized
DEBUG - 2017-04-21 16:10:38 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:10:38 --> Model Class Initialized
DEBUG - 2017-04-21 16:10:38 --> Pagination Class Initialized
ERROR - 2017-04-21 16:10:38 --> Severity: Notice --> Undefined index: company_id C:\xampp\htdocs\schedullo\application\admin\controllers\Company.php 1133
ERROR - 2017-04-21 16:10:38 --> Severity: Notice --> Undefined index: client_id C:\xampp\htdocs\schedullo\application\admin\controllers\Company.php 1165
INFO - 2017-04-21 16:11:25 --> Config Class Initialized
INFO - 2017-04-21 16:11:25 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:11:25 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:11:25 --> Utf8 Class Initialized
INFO - 2017-04-21 16:11:25 --> URI Class Initialized
INFO - 2017-04-21 16:11:25 --> Router Class Initialized
INFO - 2017-04-21 16:11:25 --> Output Class Initialized
INFO - 2017-04-21 16:11:25 --> Security Class Initialized
DEBUG - 2017-04-21 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:11:25 --> Input Class Initialized
INFO - 2017-04-21 16:11:25 --> Language Class Initialized
INFO - 2017-04-21 16:11:25 --> Loader Class Initialized
INFO - 2017-04-21 16:11:25 --> Helper loaded: url_helper
INFO - 2017-04-21 16:11:25 --> Helper loaded: form_helper
INFO - 2017-04-21 16:11:25 --> Helper loaded: html_helper
INFO - 2017-04-21 16:11:25 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:11:25 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:11:25 --> Database Driver Class Initialized
INFO - 2017-04-21 16:11:25 --> Parser Class Initialized
DEBUG - 2017-04-21 16:11:25 --> Session Class Initialized
INFO - 2017-04-21 16:11:25 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:11:25 --> Session routines successfully run
INFO - 2017-04-21 16:11:25 --> Form Validation Class Initialized
INFO - 2017-04-21 16:11:25 --> Controller Class Initialized
DEBUG - 2017-04-21 16:11:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:11:25 --> Model Class Initialized
DEBUG - 2017-04-21 16:11:25 --> Pagination Class Initialized
INFO - 2017-04-21 16:11:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 16:11:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 16:11:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 16:11:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 16:11:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 16:11:25 --> Final output sent to browser
DEBUG - 2017-04-21 16:11:25 --> Total execution time: 0.1871
INFO - 2017-04-21 16:11:25 --> Config Class Initialized
INFO - 2017-04-21 16:11:25 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:11:25 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:11:25 --> Utf8 Class Initialized
INFO - 2017-04-21 16:11:25 --> URI Class Initialized
INFO - 2017-04-21 16:11:25 --> Router Class Initialized
INFO - 2017-04-21 16:11:25 --> Output Class Initialized
INFO - 2017-04-21 16:11:25 --> Security Class Initialized
DEBUG - 2017-04-21 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:11:25 --> Input Class Initialized
INFO - 2017-04-21 16:11:25 --> Language Class Initialized
ERROR - 2017-04-21 16:11:25 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:11:25 --> Config Class Initialized
INFO - 2017-04-21 16:11:25 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:11:25 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:11:25 --> Utf8 Class Initialized
INFO - 2017-04-21 16:11:25 --> URI Class Initialized
INFO - 2017-04-21 16:11:25 --> Router Class Initialized
INFO - 2017-04-21 16:11:25 --> Output Class Initialized
INFO - 2017-04-21 16:11:25 --> Security Class Initialized
DEBUG - 2017-04-21 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:11:25 --> Input Class Initialized
INFO - 2017-04-21 16:11:25 --> Language Class Initialized
ERROR - 2017-04-21 16:11:25 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:11:26 --> Config Class Initialized
INFO - 2017-04-21 16:11:26 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:11:26 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:11:26 --> Utf8 Class Initialized
INFO - 2017-04-21 16:11:26 --> URI Class Initialized
INFO - 2017-04-21 16:11:26 --> Router Class Initialized
INFO - 2017-04-21 16:11:26 --> Output Class Initialized
INFO - 2017-04-21 16:11:26 --> Security Class Initialized
DEBUG - 2017-04-21 16:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:11:26 --> Input Class Initialized
INFO - 2017-04-21 16:11:26 --> Language Class Initialized
ERROR - 2017-04-21 16:11:26 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:11:26 --> Config Class Initialized
INFO - 2017-04-21 16:11:26 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:11:26 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:11:26 --> Utf8 Class Initialized
INFO - 2017-04-21 16:11:26 --> URI Class Initialized
INFO - 2017-04-21 16:11:26 --> Router Class Initialized
INFO - 2017-04-21 16:11:26 --> Output Class Initialized
INFO - 2017-04-21 16:11:26 --> Security Class Initialized
DEBUG - 2017-04-21 16:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:11:26 --> Input Class Initialized
INFO - 2017-04-21 16:11:26 --> Language Class Initialized
ERROR - 2017-04-21 16:11:26 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:11:31 --> Config Class Initialized
INFO - 2017-04-21 16:11:31 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:11:31 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:11:31 --> Utf8 Class Initialized
INFO - 2017-04-21 16:11:31 --> URI Class Initialized
INFO - 2017-04-21 16:11:31 --> Router Class Initialized
INFO - 2017-04-21 16:11:31 --> Output Class Initialized
INFO - 2017-04-21 16:11:31 --> Security Class Initialized
DEBUG - 2017-04-21 16:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:11:31 --> Input Class Initialized
INFO - 2017-04-21 16:11:31 --> Language Class Initialized
INFO - 2017-04-21 16:11:31 --> Loader Class Initialized
INFO - 2017-04-21 16:11:31 --> Helper loaded: url_helper
INFO - 2017-04-21 16:11:31 --> Helper loaded: form_helper
INFO - 2017-04-21 16:11:31 --> Helper loaded: html_helper
INFO - 2017-04-21 16:11:31 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:11:31 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:11:31 --> Database Driver Class Initialized
INFO - 2017-04-21 16:11:31 --> Parser Class Initialized
DEBUG - 2017-04-21 16:11:31 --> Session Class Initialized
INFO - 2017-04-21 16:11:31 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:11:31 --> Session routines successfully run
INFO - 2017-04-21 16:11:31 --> Form Validation Class Initialized
INFO - 2017-04-21 16:11:31 --> Controller Class Initialized
DEBUG - 2017-04-21 16:11:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:11:31 --> Model Class Initialized
DEBUG - 2017-04-21 16:11:31 --> Pagination Class Initialized
INFO - 2017-04-21 16:11:53 --> Config Class Initialized
INFO - 2017-04-21 16:11:53 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:11:53 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:11:53 --> Utf8 Class Initialized
INFO - 2017-04-21 16:11:53 --> URI Class Initialized
INFO - 2017-04-21 16:11:53 --> Router Class Initialized
INFO - 2017-04-21 16:11:53 --> Output Class Initialized
INFO - 2017-04-21 16:11:53 --> Security Class Initialized
DEBUG - 2017-04-21 16:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:11:53 --> Input Class Initialized
INFO - 2017-04-21 16:11:53 --> Language Class Initialized
INFO - 2017-04-21 16:11:53 --> Loader Class Initialized
INFO - 2017-04-21 16:11:53 --> Helper loaded: url_helper
INFO - 2017-04-21 16:11:53 --> Helper loaded: form_helper
INFO - 2017-04-21 16:11:53 --> Helper loaded: html_helper
INFO - 2017-04-21 16:11:53 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:11:53 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:11:53 --> Database Driver Class Initialized
INFO - 2017-04-21 16:11:53 --> Parser Class Initialized
DEBUG - 2017-04-21 16:11:53 --> Session Class Initialized
INFO - 2017-04-21 16:11:53 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:11:53 --> Session routines successfully run
INFO - 2017-04-21 16:11:53 --> Form Validation Class Initialized
INFO - 2017-04-21 16:11:53 --> Controller Class Initialized
DEBUG - 2017-04-21 16:11:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:11:53 --> Model Class Initialized
DEBUG - 2017-04-21 16:11:53 --> Pagination Class Initialized
INFO - 2017-04-21 16:11:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 16:11:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 16:11:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-21 16:11:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 16:11:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 16:11:57 --> Final output sent to browser
DEBUG - 2017-04-21 16:11:57 --> Total execution time: 3.4706
INFO - 2017-04-21 16:12:10 --> Config Class Initialized
INFO - 2017-04-21 16:12:10 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:12:10 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:12:10 --> Utf8 Class Initialized
INFO - 2017-04-21 16:12:10 --> URI Class Initialized
INFO - 2017-04-21 16:12:10 --> Router Class Initialized
INFO - 2017-04-21 16:12:10 --> Output Class Initialized
INFO - 2017-04-21 16:12:10 --> Security Class Initialized
DEBUG - 2017-04-21 16:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:12:10 --> Input Class Initialized
INFO - 2017-04-21 16:12:10 --> Language Class Initialized
INFO - 2017-04-21 16:12:10 --> Loader Class Initialized
INFO - 2017-04-21 16:12:10 --> Helper loaded: url_helper
INFO - 2017-04-21 16:12:10 --> Helper loaded: form_helper
INFO - 2017-04-21 16:12:10 --> Helper loaded: html_helper
INFO - 2017-04-21 16:12:10 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:12:10 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:12:10 --> Database Driver Class Initialized
INFO - 2017-04-21 16:12:11 --> Parser Class Initialized
DEBUG - 2017-04-21 16:12:11 --> Session Class Initialized
INFO - 2017-04-21 16:12:11 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:12:11 --> Session routines successfully run
INFO - 2017-04-21 16:12:11 --> Form Validation Class Initialized
INFO - 2017-04-21 16:12:11 --> Controller Class Initialized
DEBUG - 2017-04-21 16:12:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:12:11 --> Model Class Initialized
DEBUG - 2017-04-21 16:12:11 --> Pagination Class Initialized
INFO - 2017-04-21 16:12:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 16:12:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 16:12:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 16:12:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 16:12:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 16:12:11 --> Final output sent to browser
DEBUG - 2017-04-21 16:12:11 --> Total execution time: 0.2166
INFO - 2017-04-21 16:12:11 --> Config Class Initialized
INFO - 2017-04-21 16:12:11 --> Config Class Initialized
INFO - 2017-04-21 16:12:11 --> Hooks Class Initialized
INFO - 2017-04-21 16:12:11 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:12:11 --> UTF-8 Support Enabled
DEBUG - 2017-04-21 16:12:11 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:12:11 --> Utf8 Class Initialized
INFO - 2017-04-21 16:12:11 --> Utf8 Class Initialized
INFO - 2017-04-21 16:12:11 --> URI Class Initialized
INFO - 2017-04-21 16:12:11 --> URI Class Initialized
INFO - 2017-04-21 16:12:11 --> Router Class Initialized
INFO - 2017-04-21 16:12:11 --> Router Class Initialized
INFO - 2017-04-21 16:12:11 --> Output Class Initialized
INFO - 2017-04-21 16:12:11 --> Output Class Initialized
INFO - 2017-04-21 16:12:11 --> Security Class Initialized
INFO - 2017-04-21 16:12:11 --> Security Class Initialized
DEBUG - 2017-04-21 16:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-21 16:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:12:11 --> Input Class Initialized
INFO - 2017-04-21 16:12:11 --> Input Class Initialized
INFO - 2017-04-21 16:12:11 --> Language Class Initialized
INFO - 2017-04-21 16:12:11 --> Language Class Initialized
ERROR - 2017-04-21 16:12:11 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-21 16:12:11 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:12:16 --> Config Class Initialized
INFO - 2017-04-21 16:12:16 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:12:16 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:12:16 --> Utf8 Class Initialized
INFO - 2017-04-21 16:12:16 --> URI Class Initialized
INFO - 2017-04-21 16:12:16 --> Router Class Initialized
INFO - 2017-04-21 16:12:16 --> Output Class Initialized
INFO - 2017-04-21 16:12:16 --> Security Class Initialized
DEBUG - 2017-04-21 16:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:12:16 --> Input Class Initialized
INFO - 2017-04-21 16:12:16 --> Language Class Initialized
INFO - 2017-04-21 16:12:16 --> Loader Class Initialized
INFO - 2017-04-21 16:12:16 --> Helper loaded: url_helper
INFO - 2017-04-21 16:12:16 --> Helper loaded: form_helper
INFO - 2017-04-21 16:12:16 --> Helper loaded: html_helper
INFO - 2017-04-21 16:12:16 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:12:16 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:12:16 --> Database Driver Class Initialized
INFO - 2017-04-21 16:12:16 --> Parser Class Initialized
DEBUG - 2017-04-21 16:12:16 --> Session Class Initialized
INFO - 2017-04-21 16:12:16 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:12:16 --> Session routines successfully run
INFO - 2017-04-21 16:12:16 --> Form Validation Class Initialized
INFO - 2017-04-21 16:12:16 --> Controller Class Initialized
DEBUG - 2017-04-21 16:12:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:12:16 --> Model Class Initialized
DEBUG - 2017-04-21 16:12:16 --> Pagination Class Initialized
INFO - 2017-04-21 16:12:31 --> Config Class Initialized
INFO - 2017-04-21 16:12:31 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:12:31 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:12:31 --> Utf8 Class Initialized
INFO - 2017-04-21 16:12:31 --> URI Class Initialized
INFO - 2017-04-21 16:12:31 --> Router Class Initialized
INFO - 2017-04-21 16:12:31 --> Output Class Initialized
INFO - 2017-04-21 16:12:31 --> Security Class Initialized
DEBUG - 2017-04-21 16:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:12:31 --> Input Class Initialized
INFO - 2017-04-21 16:12:31 --> Language Class Initialized
INFO - 2017-04-21 16:12:31 --> Loader Class Initialized
INFO - 2017-04-21 16:12:31 --> Helper loaded: url_helper
INFO - 2017-04-21 16:12:31 --> Helper loaded: form_helper
INFO - 2017-04-21 16:12:31 --> Helper loaded: html_helper
INFO - 2017-04-21 16:12:31 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:12:31 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:12:31 --> Database Driver Class Initialized
INFO - 2017-04-21 16:12:31 --> Parser Class Initialized
DEBUG - 2017-04-21 16:12:31 --> Session Class Initialized
INFO - 2017-04-21 16:12:31 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:12:31 --> Session routines successfully run
INFO - 2017-04-21 16:12:31 --> Form Validation Class Initialized
INFO - 2017-04-21 16:12:31 --> Controller Class Initialized
DEBUG - 2017-04-21 16:12:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:12:31 --> Model Class Initialized
DEBUG - 2017-04-21 16:12:31 --> Pagination Class Initialized
INFO - 2017-04-21 16:16:18 --> Config Class Initialized
INFO - 2017-04-21 16:16:18 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:16:18 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:16:18 --> Utf8 Class Initialized
INFO - 2017-04-21 16:16:18 --> URI Class Initialized
INFO - 2017-04-21 16:16:18 --> Router Class Initialized
INFO - 2017-04-21 16:16:18 --> Output Class Initialized
INFO - 2017-04-21 16:16:18 --> Security Class Initialized
DEBUG - 2017-04-21 16:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:16:18 --> Input Class Initialized
INFO - 2017-04-21 16:16:18 --> Language Class Initialized
INFO - 2017-04-21 16:16:18 --> Loader Class Initialized
INFO - 2017-04-21 16:16:18 --> Helper loaded: url_helper
INFO - 2017-04-21 16:16:18 --> Helper loaded: form_helper
INFO - 2017-04-21 16:16:18 --> Helper loaded: html_helper
INFO - 2017-04-21 16:16:18 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:16:18 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:16:18 --> Database Driver Class Initialized
INFO - 2017-04-21 16:16:18 --> Parser Class Initialized
DEBUG - 2017-04-21 16:16:18 --> Session Class Initialized
INFO - 2017-04-21 16:16:18 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:16:18 --> Session routines successfully run
INFO - 2017-04-21 16:16:18 --> Form Validation Class Initialized
INFO - 2017-04-21 16:16:18 --> Controller Class Initialized
DEBUG - 2017-04-21 16:16:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:16:18 --> Model Class Initialized
DEBUG - 2017-04-21 16:16:18 --> Pagination Class Initialized
INFO - 2017-04-21 16:17:18 --> Config Class Initialized
INFO - 2017-04-21 16:17:18 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:17:18 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:17:18 --> Utf8 Class Initialized
INFO - 2017-04-21 16:17:18 --> URI Class Initialized
INFO - 2017-04-21 16:17:18 --> Router Class Initialized
INFO - 2017-04-21 16:17:18 --> Output Class Initialized
INFO - 2017-04-21 16:17:18 --> Security Class Initialized
DEBUG - 2017-04-21 16:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:17:18 --> Input Class Initialized
INFO - 2017-04-21 16:17:18 --> Language Class Initialized
INFO - 2017-04-21 16:17:18 --> Loader Class Initialized
INFO - 2017-04-21 16:17:18 --> Helper loaded: url_helper
INFO - 2017-04-21 16:17:18 --> Helper loaded: form_helper
INFO - 2017-04-21 16:17:18 --> Helper loaded: html_helper
INFO - 2017-04-21 16:17:18 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:17:18 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:17:18 --> Database Driver Class Initialized
INFO - 2017-04-21 16:17:18 --> Parser Class Initialized
DEBUG - 2017-04-21 16:17:18 --> Session Class Initialized
INFO - 2017-04-21 16:17:18 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:17:18 --> Session routines successfully run
INFO - 2017-04-21 16:17:18 --> Form Validation Class Initialized
INFO - 2017-04-21 16:17:18 --> Controller Class Initialized
DEBUG - 2017-04-21 16:17:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:17:18 --> Model Class Initialized
DEBUG - 2017-04-21 16:17:18 --> Pagination Class Initialized
INFO - 2017-04-21 16:17:20 --> Config Class Initialized
INFO - 2017-04-21 16:17:20 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:17:20 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:17:20 --> Utf8 Class Initialized
INFO - 2017-04-21 16:17:20 --> URI Class Initialized
INFO - 2017-04-21 16:17:20 --> Router Class Initialized
INFO - 2017-04-21 16:17:20 --> Output Class Initialized
INFO - 2017-04-21 16:17:20 --> Security Class Initialized
DEBUG - 2017-04-21 16:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:17:20 --> Input Class Initialized
INFO - 2017-04-21 16:17:20 --> Language Class Initialized
INFO - 2017-04-21 16:17:20 --> Loader Class Initialized
INFO - 2017-04-21 16:17:20 --> Helper loaded: url_helper
INFO - 2017-04-21 16:17:20 --> Helper loaded: form_helper
INFO - 2017-04-21 16:17:20 --> Helper loaded: html_helper
INFO - 2017-04-21 16:17:20 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:17:20 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:17:20 --> Database Driver Class Initialized
INFO - 2017-04-21 16:17:20 --> Parser Class Initialized
DEBUG - 2017-04-21 16:17:20 --> Session Class Initialized
INFO - 2017-04-21 16:17:20 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:17:20 --> Session routines successfully run
INFO - 2017-04-21 16:17:20 --> Form Validation Class Initialized
INFO - 2017-04-21 16:17:20 --> Controller Class Initialized
DEBUG - 2017-04-21 16:17:20 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:17:20 --> Model Class Initialized
DEBUG - 2017-04-21 16:17:20 --> Pagination Class Initialized
INFO - 2017-04-21 16:17:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 16:17:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 16:17:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-21 16:17:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 16:17:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 16:17:23 --> Final output sent to browser
DEBUG - 2017-04-21 16:17:23 --> Total execution time: 3.3259
INFO - 2017-04-21 16:18:09 --> Config Class Initialized
INFO - 2017-04-21 16:18:09 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:18:09 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:18:09 --> Utf8 Class Initialized
INFO - 2017-04-21 16:18:09 --> URI Class Initialized
INFO - 2017-04-21 16:18:09 --> Router Class Initialized
INFO - 2017-04-21 16:18:09 --> Output Class Initialized
INFO - 2017-04-21 16:18:09 --> Security Class Initialized
DEBUG - 2017-04-21 16:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:18:09 --> Input Class Initialized
INFO - 2017-04-21 16:18:09 --> Language Class Initialized
INFO - 2017-04-21 16:18:09 --> Loader Class Initialized
INFO - 2017-04-21 16:18:09 --> Helper loaded: url_helper
INFO - 2017-04-21 16:18:09 --> Helper loaded: form_helper
INFO - 2017-04-21 16:18:09 --> Helper loaded: html_helper
INFO - 2017-04-21 16:18:09 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:18:09 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:18:09 --> Database Driver Class Initialized
INFO - 2017-04-21 16:18:09 --> Parser Class Initialized
DEBUG - 2017-04-21 16:18:09 --> Session Class Initialized
INFO - 2017-04-21 16:18:09 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:18:09 --> Session routines successfully run
INFO - 2017-04-21 16:18:09 --> Form Validation Class Initialized
INFO - 2017-04-21 16:18:09 --> Controller Class Initialized
DEBUG - 2017-04-21 16:18:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:18:09 --> Model Class Initialized
DEBUG - 2017-04-21 16:18:09 --> Pagination Class Initialized
INFO - 2017-04-21 16:18:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-21 16:18:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-21 16:18:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-21 16:18:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-21 16:18:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 16:18:09 --> Final output sent to browser
DEBUG - 2017-04-21 16:18:09 --> Total execution time: 0.3754
INFO - 2017-04-21 16:18:09 --> Config Class Initialized
INFO - 2017-04-21 16:18:09 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:18:09 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:18:09 --> Utf8 Class Initialized
INFO - 2017-04-21 16:18:09 --> Config Class Initialized
INFO - 2017-04-21 16:18:09 --> Hooks Class Initialized
INFO - 2017-04-21 16:18:09 --> URI Class Initialized
DEBUG - 2017-04-21 16:18:09 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:18:09 --> Router Class Initialized
INFO - 2017-04-21 16:18:09 --> Utf8 Class Initialized
INFO - 2017-04-21 16:18:09 --> Output Class Initialized
INFO - 2017-04-21 16:18:09 --> URI Class Initialized
INFO - 2017-04-21 16:18:09 --> Security Class Initialized
DEBUG - 2017-04-21 16:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:18:09 --> Input Class Initialized
INFO - 2017-04-21 16:18:09 --> Router Class Initialized
INFO - 2017-04-21 16:18:09 --> Language Class Initialized
INFO - 2017-04-21 16:18:09 --> Output Class Initialized
ERROR - 2017-04-21 16:18:09 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:18:09 --> Security Class Initialized
DEBUG - 2017-04-21 16:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:18:09 --> Input Class Initialized
INFO - 2017-04-21 16:18:09 --> Language Class Initialized
ERROR - 2017-04-21 16:18:09 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:18:09 --> Config Class Initialized
INFO - 2017-04-21 16:18:09 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:18:09 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:18:09 --> Utf8 Class Initialized
INFO - 2017-04-21 16:18:09 --> URI Class Initialized
INFO - 2017-04-21 16:18:09 --> Router Class Initialized
INFO - 2017-04-21 16:18:09 --> Output Class Initialized
INFO - 2017-04-21 16:18:09 --> Security Class Initialized
DEBUG - 2017-04-21 16:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:18:09 --> Input Class Initialized
INFO - 2017-04-21 16:18:09 --> Language Class Initialized
ERROR - 2017-04-21 16:18:09 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:18:09 --> Config Class Initialized
INFO - 2017-04-21 16:18:09 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:18:09 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:18:09 --> Utf8 Class Initialized
INFO - 2017-04-21 16:18:09 --> URI Class Initialized
INFO - 2017-04-21 16:18:09 --> Router Class Initialized
INFO - 2017-04-21 16:18:09 --> Output Class Initialized
INFO - 2017-04-21 16:18:09 --> Security Class Initialized
DEBUG - 2017-04-21 16:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:18:09 --> Input Class Initialized
INFO - 2017-04-21 16:18:09 --> Language Class Initialized
ERROR - 2017-04-21 16:18:09 --> 404 Page Not Found: Default/assets
INFO - 2017-04-21 16:18:16 --> Config Class Initialized
INFO - 2017-04-21 16:18:16 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:18:16 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:18:16 --> Utf8 Class Initialized
INFO - 2017-04-21 16:18:16 --> URI Class Initialized
INFO - 2017-04-21 16:18:16 --> Router Class Initialized
INFO - 2017-04-21 16:18:16 --> Output Class Initialized
INFO - 2017-04-21 16:18:16 --> Security Class Initialized
DEBUG - 2017-04-21 16:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:18:16 --> Input Class Initialized
INFO - 2017-04-21 16:18:16 --> Language Class Initialized
INFO - 2017-04-21 16:18:16 --> Loader Class Initialized
INFO - 2017-04-21 16:18:16 --> Helper loaded: url_helper
INFO - 2017-04-21 16:18:16 --> Helper loaded: form_helper
INFO - 2017-04-21 16:18:16 --> Helper loaded: html_helper
INFO - 2017-04-21 16:18:16 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:18:16 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:18:16 --> Database Driver Class Initialized
INFO - 2017-04-21 16:18:16 --> Parser Class Initialized
DEBUG - 2017-04-21 16:18:16 --> Session Class Initialized
INFO - 2017-04-21 16:18:16 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:18:16 --> Session routines successfully run
INFO - 2017-04-21 16:18:16 --> Form Validation Class Initialized
INFO - 2017-04-21 16:18:16 --> Controller Class Initialized
INFO - 2017-04-21 16:18:16 --> Model Class Initialized
INFO - 2017-04-21 16:18:16 --> Config Class Initialized
INFO - 2017-04-21 16:18:16 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:18:16 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:18:16 --> Utf8 Class Initialized
INFO - 2017-04-21 16:18:16 --> URI Class Initialized
INFO - 2017-04-21 16:18:16 --> Router Class Initialized
INFO - 2017-04-21 16:18:16 --> Output Class Initialized
INFO - 2017-04-21 16:18:16 --> Security Class Initialized
DEBUG - 2017-04-21 16:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:18:16 --> Input Class Initialized
INFO - 2017-04-21 16:18:16 --> Language Class Initialized
INFO - 2017-04-21 16:18:16 --> Loader Class Initialized
INFO - 2017-04-21 16:18:16 --> Helper loaded: url_helper
INFO - 2017-04-21 16:18:16 --> Helper loaded: form_helper
INFO - 2017-04-21 16:18:16 --> Helper loaded: html_helper
INFO - 2017-04-21 16:18:16 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:18:16 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:18:16 --> Database Driver Class Initialized
INFO - 2017-04-21 16:18:16 --> Parser Class Initialized
DEBUG - 2017-04-21 16:18:16 --> Session Class Initialized
INFO - 2017-04-21 16:18:16 --> Helper loaded: string_helper
ERROR - 2017-04-21 16:18:16 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-21 16:18:16 --> Session routines successfully run
INFO - 2017-04-21 16:18:16 --> Form Validation Class Initialized
INFO - 2017-04-21 16:18:16 --> Controller Class Initialized
INFO - 2017-04-21 16:18:16 --> Model Class Initialized
INFO - 2017-04-21 16:18:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-21 16:18:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 16:18:16 --> Final output sent to browser
DEBUG - 2017-04-21 16:18:16 --> Total execution time: 0.1590
INFO - 2017-04-21 16:18:19 --> Config Class Initialized
INFO - 2017-04-21 16:18:19 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:18:19 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:18:19 --> Utf8 Class Initialized
INFO - 2017-04-21 16:18:19 --> URI Class Initialized
INFO - 2017-04-21 16:18:19 --> Router Class Initialized
INFO - 2017-04-21 16:18:19 --> Output Class Initialized
INFO - 2017-04-21 16:18:19 --> Security Class Initialized
DEBUG - 2017-04-21 16:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:18:19 --> Input Class Initialized
INFO - 2017-04-21 16:18:19 --> Language Class Initialized
INFO - 2017-04-21 16:18:19 --> Loader Class Initialized
INFO - 2017-04-21 16:18:19 --> Helper loaded: url_helper
INFO - 2017-04-21 16:18:19 --> Helper loaded: form_helper
INFO - 2017-04-21 16:18:19 --> Helper loaded: html_helper
INFO - 2017-04-21 16:18:19 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:18:19 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:18:19 --> Database Driver Class Initialized
INFO - 2017-04-21 16:18:19 --> Parser Class Initialized
DEBUG - 2017-04-21 16:18:19 --> Session Class Initialized
INFO - 2017-04-21 16:18:19 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:18:19 --> Session routines successfully run
INFO - 2017-04-21 16:18:19 --> Form Validation Class Initialized
INFO - 2017-04-21 16:18:19 --> Controller Class Initialized
DEBUG - 2017-04-21 16:18:19 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-21 16:18:19 --> Model Class Initialized
DEBUG - 2017-04-21 16:18:19 --> Pagination Class Initialized
INFO - 2017-04-21 16:18:19 --> Config Class Initialized
INFO - 2017-04-21 16:18:19 --> Hooks Class Initialized
DEBUG - 2017-04-21 16:18:19 --> UTF-8 Support Enabled
INFO - 2017-04-21 16:18:19 --> Utf8 Class Initialized
INFO - 2017-04-21 16:18:19 --> URI Class Initialized
INFO - 2017-04-21 16:18:19 --> Router Class Initialized
INFO - 2017-04-21 16:18:19 --> Output Class Initialized
INFO - 2017-04-21 16:18:19 --> Security Class Initialized
DEBUG - 2017-04-21 16:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-21 16:18:19 --> Input Class Initialized
INFO - 2017-04-21 16:18:19 --> Language Class Initialized
INFO - 2017-04-21 16:18:19 --> Loader Class Initialized
INFO - 2017-04-21 16:18:19 --> Helper loaded: url_helper
INFO - 2017-04-21 16:18:19 --> Helper loaded: form_helper
INFO - 2017-04-21 16:18:19 --> Helper loaded: html_helper
INFO - 2017-04-21 16:18:19 --> Helper loaded: custom_helper
INFO - 2017-04-21 16:18:19 --> Helper loaded: cache_helper
INFO - 2017-04-21 16:18:19 --> Database Driver Class Initialized
INFO - 2017-04-21 16:18:19 --> Parser Class Initialized
DEBUG - 2017-04-21 16:18:19 --> Session Class Initialized
INFO - 2017-04-21 16:18:19 --> Helper loaded: string_helper
DEBUG - 2017-04-21 16:18:19 --> Session routines successfully run
INFO - 2017-04-21 16:18:19 --> Form Validation Class Initialized
INFO - 2017-04-21 16:18:19 --> Controller Class Initialized
INFO - 2017-04-21 16:18:19 --> Model Class Initialized
INFO - 2017-04-21 16:18:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-21 16:18:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-21 16:18:19 --> Final output sent to browser
DEBUG - 2017-04-21 16:18:19 --> Total execution time: 0.1381
