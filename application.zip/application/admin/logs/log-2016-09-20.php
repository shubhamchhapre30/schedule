<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-20 13:31:42 --> Config Class Initialized
INFO - 2016-09-20 13:31:42 --> Hooks Class Initialized
DEBUG - 2016-09-20 13:31:42 --> UTF-8 Support Enabled
INFO - 2016-09-20 13:31:42 --> Utf8 Class Initialized
INFO - 2016-09-20 13:31:42 --> URI Class Initialized
DEBUG - 2016-09-20 13:31:42 --> No URI present. Default controller set.
INFO - 2016-09-20 13:31:42 --> Router Class Initialized
INFO - 2016-09-20 13:31:42 --> Output Class Initialized
INFO - 2016-09-20 13:31:42 --> Security Class Initialized
DEBUG - 2016-09-20 13:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-20 13:31:42 --> Input Class Initialized
INFO - 2016-09-20 13:31:42 --> Language Class Initialized
INFO - 2016-09-20 13:31:42 --> Loader Class Initialized
INFO - 2016-09-20 13:31:42 --> Helper loaded: url_helper
INFO - 2016-09-20 13:31:42 --> Helper loaded: form_helper
INFO - 2016-09-20 13:31:42 --> Helper loaded: html_helper
INFO - 2016-09-20 13:31:42 --> Helper loaded: custom_helper
INFO - 2016-09-20 13:31:42 --> Helper loaded: cache_helper
INFO - 2016-09-20 13:31:42 --> Database Driver Class Initialized
INFO - 2016-09-20 13:31:42 --> Parser Class Initialized
DEBUG - 2016-09-20 13:31:42 --> Session Class Initialized
INFO - 2016-09-20 13:31:42 --> Helper loaded: string_helper
ERROR - 2016-09-20 13:31:42 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2016-09-20 13:31:42 --> Session routines successfully run
INFO - 2016-09-20 13:31:42 --> Form Validation Class Initialized
INFO - 2016-09-20 13:31:42 --> Controller Class Initialized
INFO - 2016-09-20 13:31:42 --> Model Class Initialized
INFO - 2016-09-20 13:31:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-20 13:31:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-20 13:31:42 --> Final output sent to browser
DEBUG - 2016-09-20 13:31:42 --> Total execution time: 0.3966
INFO - 2016-09-20 13:31:57 --> Config Class Initialized
INFO - 2016-09-20 13:31:57 --> Hooks Class Initialized
DEBUG - 2016-09-20 13:31:57 --> UTF-8 Support Enabled
INFO - 2016-09-20 13:31:57 --> Utf8 Class Initialized
INFO - 2016-09-20 13:31:57 --> URI Class Initialized
INFO - 2016-09-20 13:31:57 --> Router Class Initialized
INFO - 2016-09-20 13:31:57 --> Output Class Initialized
INFO - 2016-09-20 13:31:57 --> Security Class Initialized
DEBUG - 2016-09-20 13:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-20 13:31:57 --> Input Class Initialized
INFO - 2016-09-20 13:31:57 --> Language Class Initialized
ERROR - 2016-09-20 13:31:57 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-20 13:31:59 --> Config Class Initialized
INFO - 2016-09-20 13:32:00 --> Hooks Class Initialized
DEBUG - 2016-09-20 13:32:00 --> UTF-8 Support Enabled
INFO - 2016-09-20 13:32:00 --> Utf8 Class Initialized
INFO - 2016-09-20 13:32:00 --> URI Class Initialized
DEBUG - 2016-09-20 13:32:00 --> No URI present. Default controller set.
INFO - 2016-09-20 13:32:00 --> Router Class Initialized
INFO - 2016-09-20 13:32:00 --> Output Class Initialized
INFO - 2016-09-20 13:32:00 --> Security Class Initialized
DEBUG - 2016-09-20 13:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-20 13:32:00 --> Input Class Initialized
INFO - 2016-09-20 13:32:00 --> Language Class Initialized
INFO - 2016-09-20 13:32:00 --> Loader Class Initialized
INFO - 2016-09-20 13:32:00 --> Helper loaded: url_helper
INFO - 2016-09-20 13:32:00 --> Helper loaded: form_helper
INFO - 2016-09-20 13:32:00 --> Helper loaded: html_helper
INFO - 2016-09-20 13:32:00 --> Helper loaded: custom_helper
INFO - 2016-09-20 13:32:00 --> Helper loaded: cache_helper
INFO - 2016-09-20 13:32:00 --> Database Driver Class Initialized
INFO - 2016-09-20 13:32:00 --> Parser Class Initialized
DEBUG - 2016-09-20 13:32:00 --> Session Class Initialized
INFO - 2016-09-20 13:32:00 --> Helper loaded: string_helper
DEBUG - 2016-09-20 13:32:00 --> Session routines successfully run
INFO - 2016-09-20 13:32:00 --> Form Validation Class Initialized
INFO - 2016-09-20 13:32:00 --> Controller Class Initialized
INFO - 2016-09-20 13:32:00 --> Model Class Initialized
INFO - 2016-09-20 13:32:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-20 13:32:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-20 13:32:00 --> Final output sent to browser
DEBUG - 2016-09-20 13:32:00 --> Total execution time: 0.1524
INFO - 2016-09-20 13:36:21 --> Config Class Initialized
INFO - 2016-09-20 13:36:21 --> Hooks Class Initialized
DEBUG - 2016-09-20 13:36:22 --> UTF-8 Support Enabled
INFO - 2016-09-20 13:36:22 --> Utf8 Class Initialized
INFO - 2016-09-20 13:36:22 --> URI Class Initialized
DEBUG - 2016-09-20 13:36:22 --> No URI present. Default controller set.
INFO - 2016-09-20 13:36:22 --> Router Class Initialized
INFO - 2016-09-20 13:36:22 --> Output Class Initialized
INFO - 2016-09-20 13:36:22 --> Security Class Initialized
DEBUG - 2016-09-20 13:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-20 13:36:22 --> Input Class Initialized
INFO - 2016-09-20 13:36:22 --> Language Class Initialized
INFO - 2016-09-20 13:36:22 --> Loader Class Initialized
INFO - 2016-09-20 13:36:22 --> Helper loaded: url_helper
INFO - 2016-09-20 13:36:22 --> Helper loaded: form_helper
INFO - 2016-09-20 13:36:22 --> Helper loaded: html_helper
INFO - 2016-09-20 13:36:22 --> Helper loaded: custom_helper
INFO - 2016-09-20 13:36:22 --> Helper loaded: cache_helper
INFO - 2016-09-20 13:36:22 --> Database Driver Class Initialized
INFO - 2016-09-20 13:36:22 --> Parser Class Initialized
DEBUG - 2016-09-20 13:36:22 --> Session Class Initialized
INFO - 2016-09-20 13:36:22 --> Helper loaded: string_helper
DEBUG - 2016-09-20 13:36:22 --> Session routines successfully run
INFO - 2016-09-20 13:36:22 --> Form Validation Class Initialized
INFO - 2016-09-20 13:36:22 --> Controller Class Initialized
INFO - 2016-09-20 13:36:22 --> Model Class Initialized
INFO - 2016-09-20 13:36:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-20 13:36:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-20 13:36:22 --> Final output sent to browser
DEBUG - 2016-09-20 13:36:22 --> Total execution time: 0.1444
