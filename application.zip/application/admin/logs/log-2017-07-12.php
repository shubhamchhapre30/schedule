<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-12 07:04:07 --> Config Class Initialized
INFO - 2017-07-12 07:04:07 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:04:07 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:04:07 --> Utf8 Class Initialized
INFO - 2017-07-12 07:04:07 --> URI Class Initialized
DEBUG - 2017-07-12 07:04:07 --> No URI present. Default controller set.
INFO - 2017-07-12 07:04:07 --> Router Class Initialized
INFO - 2017-07-12 07:04:07 --> Output Class Initialized
INFO - 2017-07-12 07:04:07 --> Security Class Initialized
DEBUG - 2017-07-12 07:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:04:07 --> Input Class Initialized
INFO - 2017-07-12 07:04:07 --> Language Class Initialized
INFO - 2017-07-12 07:04:07 --> Loader Class Initialized
INFO - 2017-07-12 07:04:07 --> Helper loaded: url_helper
INFO - 2017-07-12 07:04:07 --> Helper loaded: form_helper
INFO - 2017-07-12 07:04:07 --> Helper loaded: html_helper
INFO - 2017-07-12 07:04:07 --> Helper loaded: custom_helper
INFO - 2017-07-12 07:04:07 --> Helper loaded: cache_helper
INFO - 2017-07-12 07:04:07 --> Database Driver Class Initialized
INFO - 2017-07-12 07:04:07 --> Parser Class Initialized
DEBUG - 2017-07-12 07:04:07 --> Session Class Initialized
INFO - 2017-07-12 07:04:07 --> Helper loaded: string_helper
ERROR - 2017-07-12 07:04:07 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-07-12 07:04:07 --> Session routines successfully run
INFO - 2017-07-12 07:04:07 --> Form Validation Class Initialized
INFO - 2017-07-12 07:04:07 --> Controller Class Initialized
INFO - 2017-07-12 07:04:07 --> Model Class Initialized
INFO - 2017-07-12 07:04:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-07-12 07:04:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-12 07:04:07 --> Final output sent to browser
DEBUG - 2017-07-12 07:04:07 --> Total execution time: 0.2396
INFO - 2017-07-12 07:04:07 --> Config Class Initialized
INFO - 2017-07-12 07:04:07 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:04:07 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:04:07 --> Utf8 Class Initialized
INFO - 2017-07-12 07:04:07 --> URI Class Initialized
INFO - 2017-07-12 07:04:07 --> Router Class Initialized
INFO - 2017-07-12 07:04:07 --> Output Class Initialized
INFO - 2017-07-12 07:04:07 --> Security Class Initialized
DEBUG - 2017-07-12 07:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:04:07 --> Input Class Initialized
INFO - 2017-07-12 07:04:07 --> Language Class Initialized
ERROR - 2017-07-12 07:04:07 --> 404 Page Not Found: Default/assets
INFO - 2017-07-12 07:04:08 --> Config Class Initialized
INFO - 2017-07-12 07:04:08 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:04:08 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:04:08 --> Utf8 Class Initialized
INFO - 2017-07-12 07:04:08 --> URI Class Initialized
INFO - 2017-07-12 07:04:08 --> Router Class Initialized
INFO - 2017-07-12 07:04:08 --> Output Class Initialized
INFO - 2017-07-12 07:04:08 --> Security Class Initialized
DEBUG - 2017-07-12 07:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:04:08 --> Input Class Initialized
INFO - 2017-07-12 07:04:08 --> Language Class Initialized
ERROR - 2017-07-12 07:04:08 --> 404 Page Not Found: Default/assets
INFO - 2017-07-12 07:04:22 --> Config Class Initialized
INFO - 2017-07-12 07:04:22 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:04:22 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:04:22 --> Utf8 Class Initialized
INFO - 2017-07-12 07:04:22 --> URI Class Initialized
INFO - 2017-07-12 07:04:22 --> Router Class Initialized
INFO - 2017-07-12 07:04:22 --> Output Class Initialized
INFO - 2017-07-12 07:04:22 --> Security Class Initialized
DEBUG - 2017-07-12 07:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:04:22 --> Input Class Initialized
INFO - 2017-07-12 07:04:22 --> Language Class Initialized
INFO - 2017-07-12 07:04:22 --> Loader Class Initialized
INFO - 2017-07-12 07:04:22 --> Helper loaded: url_helper
INFO - 2017-07-12 07:04:22 --> Helper loaded: form_helper
INFO - 2017-07-12 07:04:22 --> Helper loaded: html_helper
INFO - 2017-07-12 07:04:22 --> Helper loaded: custom_helper
INFO - 2017-07-12 07:04:22 --> Helper loaded: cache_helper
INFO - 2017-07-12 07:04:22 --> Database Driver Class Initialized
INFO - 2017-07-12 07:04:22 --> Parser Class Initialized
DEBUG - 2017-07-12 07:04:22 --> Session Class Initialized
INFO - 2017-07-12 07:04:22 --> Helper loaded: string_helper
DEBUG - 2017-07-12 07:04:22 --> Session routines successfully run
INFO - 2017-07-12 07:04:22 --> Form Validation Class Initialized
INFO - 2017-07-12 07:04:22 --> Controller Class Initialized
INFO - 2017-07-12 07:04:22 --> Model Class Initialized
INFO - 2017-07-12 07:04:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-12 07:04:22 --> Config Class Initialized
INFO - 2017-07-12 07:04:22 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:04:22 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:04:22 --> Utf8 Class Initialized
INFO - 2017-07-12 07:04:22 --> URI Class Initialized
INFO - 2017-07-12 07:04:22 --> Router Class Initialized
INFO - 2017-07-12 07:04:22 --> Output Class Initialized
INFO - 2017-07-12 07:04:22 --> Security Class Initialized
DEBUG - 2017-07-12 07:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:04:22 --> Input Class Initialized
INFO - 2017-07-12 07:04:22 --> Language Class Initialized
INFO - 2017-07-12 07:04:22 --> Loader Class Initialized
INFO - 2017-07-12 07:04:22 --> Helper loaded: url_helper
INFO - 2017-07-12 07:04:22 --> Helper loaded: form_helper
INFO - 2017-07-12 07:04:22 --> Helper loaded: html_helper
INFO - 2017-07-12 07:04:22 --> Helper loaded: custom_helper
INFO - 2017-07-12 07:04:22 --> Helper loaded: cache_helper
INFO - 2017-07-12 07:04:22 --> Database Driver Class Initialized
INFO - 2017-07-12 07:04:22 --> Parser Class Initialized
DEBUG - 2017-07-12 07:04:22 --> Session Class Initialized
INFO - 2017-07-12 07:04:22 --> Helper loaded: string_helper
DEBUG - 2017-07-12 07:04:22 --> Session routines successfully run
INFO - 2017-07-12 07:04:22 --> Form Validation Class Initialized
INFO - 2017-07-12 07:04:22 --> Controller Class Initialized
DEBUG - 2017-07-12 07:04:22 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-07-12 07:04:22 --> Model Class Initialized
DEBUG - 2017-07-12 07:04:22 --> Pagination Class Initialized
INFO - 2017-07-12 07:04:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-12 07:04:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-12 07:04:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-07-12 07:04:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-12 07:04:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-12 07:04:22 --> Final output sent to browser
DEBUG - 2017-07-12 07:04:22 --> Total execution time: 0.2599
INFO - 2017-07-12 07:04:29 --> Config Class Initialized
INFO - 2017-07-12 07:04:29 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:04:29 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:04:29 --> Utf8 Class Initialized
INFO - 2017-07-12 07:04:29 --> URI Class Initialized
INFO - 2017-07-12 07:04:29 --> Router Class Initialized
INFO - 2017-07-12 07:04:29 --> Output Class Initialized
INFO - 2017-07-12 07:04:29 --> Security Class Initialized
DEBUG - 2017-07-12 07:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:04:29 --> Input Class Initialized
INFO - 2017-07-12 07:04:29 --> Language Class Initialized
INFO - 2017-07-12 07:04:29 --> Loader Class Initialized
INFO - 2017-07-12 07:04:29 --> Helper loaded: url_helper
INFO - 2017-07-12 07:04:29 --> Helper loaded: form_helper
INFO - 2017-07-12 07:04:29 --> Helper loaded: html_helper
INFO - 2017-07-12 07:04:29 --> Helper loaded: custom_helper
INFO - 2017-07-12 07:04:29 --> Helper loaded: cache_helper
INFO - 2017-07-12 07:04:29 --> Database Driver Class Initialized
INFO - 2017-07-12 07:04:29 --> Parser Class Initialized
DEBUG - 2017-07-12 07:04:29 --> Session Class Initialized
INFO - 2017-07-12 07:04:29 --> Helper loaded: string_helper
DEBUG - 2017-07-12 07:04:29 --> Session routines successfully run
INFO - 2017-07-12 07:04:29 --> Form Validation Class Initialized
INFO - 2017-07-12 07:04:29 --> Controller Class Initialized
INFO - 2017-07-12 07:04:29 --> Model Class Initialized
INFO - 2017-07-12 07:04:29 --> Config Class Initialized
INFO - 2017-07-12 07:04:29 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:04:29 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:04:29 --> Utf8 Class Initialized
INFO - 2017-07-12 07:04:29 --> URI Class Initialized
INFO - 2017-07-12 07:04:29 --> Router Class Initialized
INFO - 2017-07-12 07:04:29 --> Output Class Initialized
INFO - 2017-07-12 07:04:29 --> Security Class Initialized
DEBUG - 2017-07-12 07:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:04:29 --> Input Class Initialized
INFO - 2017-07-12 07:04:29 --> Language Class Initialized
INFO - 2017-07-12 07:04:29 --> Loader Class Initialized
INFO - 2017-07-12 07:04:29 --> Helper loaded: url_helper
INFO - 2017-07-12 07:04:29 --> Helper loaded: form_helper
INFO - 2017-07-12 07:04:29 --> Helper loaded: html_helper
INFO - 2017-07-12 07:04:29 --> Helper loaded: custom_helper
INFO - 2017-07-12 07:04:29 --> Helper loaded: cache_helper
INFO - 2017-07-12 07:04:29 --> Database Driver Class Initialized
INFO - 2017-07-12 07:04:29 --> Parser Class Initialized
DEBUG - 2017-07-12 07:04:29 --> Session Class Initialized
INFO - 2017-07-12 07:04:29 --> Helper loaded: string_helper
DEBUG - 2017-07-12 07:04:29 --> Session routines successfully run
INFO - 2017-07-12 07:04:29 --> Form Validation Class Initialized
INFO - 2017-07-12 07:04:29 --> Controller Class Initialized
INFO - 2017-07-12 07:04:29 --> Model Class Initialized
INFO - 2017-07-12 07:04:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-12 07:04:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-12 07:04:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2017-07-12 07:04:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-12 07:04:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-12 07:04:29 --> Final output sent to browser
DEBUG - 2017-07-12 07:04:29 --> Total execution time: 0.2370
INFO - 2017-07-12 07:04:34 --> Config Class Initialized
INFO - 2017-07-12 07:04:34 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:04:34 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:04:34 --> Utf8 Class Initialized
INFO - 2017-07-12 07:04:34 --> URI Class Initialized
INFO - 2017-07-12 07:04:34 --> Router Class Initialized
INFO - 2017-07-12 07:04:34 --> Output Class Initialized
INFO - 2017-07-12 07:04:34 --> Security Class Initialized
DEBUG - 2017-07-12 07:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:04:34 --> Input Class Initialized
INFO - 2017-07-12 07:04:34 --> Language Class Initialized
INFO - 2017-07-12 07:04:34 --> Loader Class Initialized
INFO - 2017-07-12 07:04:34 --> Helper loaded: url_helper
INFO - 2017-07-12 07:04:34 --> Helper loaded: form_helper
INFO - 2017-07-12 07:04:34 --> Helper loaded: html_helper
INFO - 2017-07-12 07:04:34 --> Helper loaded: custom_helper
INFO - 2017-07-12 07:04:34 --> Helper loaded: cache_helper
INFO - 2017-07-12 07:04:34 --> Database Driver Class Initialized
INFO - 2017-07-12 07:04:34 --> Parser Class Initialized
DEBUG - 2017-07-12 07:04:34 --> Session Class Initialized
INFO - 2017-07-12 07:04:34 --> Helper loaded: string_helper
DEBUG - 2017-07-12 07:04:34 --> Session routines successfully run
INFO - 2017-07-12 07:04:34 --> Form Validation Class Initialized
INFO - 2017-07-12 07:04:34 --> Controller Class Initialized
INFO - 2017-07-12 07:04:34 --> Model Class Initialized
DEBUG - 2017-07-12 07:04:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-07-12 07:04:34 --> Severity: Notice --> Undefined index: sandgrid_id C:\xampp\htdocs\schedullo\application\admin\controllers\EmailTemplate.php 409
INFO - 2017-07-12 07:04:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-12 07:04:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-12 07:04:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/addEmailTemplate.php
INFO - 2017-07-12 07:04:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-12 07:04:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-12 07:04:34 --> Final output sent to browser
DEBUG - 2017-07-12 07:04:34 --> Total execution time: 0.2133
INFO - 2017-07-12 07:05:03 --> Config Class Initialized
INFO - 2017-07-12 07:05:03 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:05:03 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:05:03 --> Utf8 Class Initialized
INFO - 2017-07-12 07:05:03 --> URI Class Initialized
INFO - 2017-07-12 07:05:03 --> Router Class Initialized
INFO - 2017-07-12 07:05:03 --> Output Class Initialized
INFO - 2017-07-12 07:05:03 --> Security Class Initialized
DEBUG - 2017-07-12 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:05:04 --> Input Class Initialized
INFO - 2017-07-12 07:05:04 --> Language Class Initialized
INFO - 2017-07-12 07:05:04 --> Loader Class Initialized
INFO - 2017-07-12 07:05:04 --> Helper loaded: url_helper
INFO - 2017-07-12 07:05:04 --> Helper loaded: form_helper
INFO - 2017-07-12 07:05:04 --> Helper loaded: html_helper
INFO - 2017-07-12 07:05:04 --> Helper loaded: custom_helper
INFO - 2017-07-12 07:05:04 --> Helper loaded: cache_helper
INFO - 2017-07-12 07:05:04 --> Database Driver Class Initialized
INFO - 2017-07-12 07:05:04 --> Parser Class Initialized
DEBUG - 2017-07-12 07:05:04 --> Session Class Initialized
INFO - 2017-07-12 07:05:04 --> Helper loaded: string_helper
DEBUG - 2017-07-12 07:05:04 --> Session routines successfully run
INFO - 2017-07-12 07:05:04 --> Form Validation Class Initialized
INFO - 2017-07-12 07:05:04 --> Controller Class Initialized
INFO - 2017-07-12 07:05:04 --> Model Class Initialized
INFO - 2017-07-12 07:05:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-12 07:05:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-12 07:05:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2017-07-12 07:05:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-12 07:05:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-12 07:05:04 --> Final output sent to browser
DEBUG - 2017-07-12 07:05:04 --> Total execution time: 0.1942
INFO - 2017-07-12 07:06:10 --> Config Class Initialized
INFO - 2017-07-12 07:06:10 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:06:10 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:06:10 --> Utf8 Class Initialized
INFO - 2017-07-12 07:06:10 --> URI Class Initialized
INFO - 2017-07-12 07:06:10 --> Router Class Initialized
INFO - 2017-07-12 07:06:10 --> Output Class Initialized
INFO - 2017-07-12 07:06:10 --> Security Class Initialized
DEBUG - 2017-07-12 07:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:06:10 --> Input Class Initialized
INFO - 2017-07-12 07:06:10 --> Language Class Initialized
INFO - 2017-07-12 07:06:10 --> Loader Class Initialized
INFO - 2017-07-12 07:06:10 --> Helper loaded: url_helper
INFO - 2017-07-12 07:06:10 --> Helper loaded: form_helper
INFO - 2017-07-12 07:06:10 --> Helper loaded: html_helper
INFO - 2017-07-12 07:06:10 --> Helper loaded: custom_helper
INFO - 2017-07-12 07:06:10 --> Helper loaded: cache_helper
INFO - 2017-07-12 07:06:10 --> Database Driver Class Initialized
INFO - 2017-07-12 07:06:10 --> Parser Class Initialized
DEBUG - 2017-07-12 07:06:10 --> Session Class Initialized
INFO - 2017-07-12 07:06:10 --> Helper loaded: string_helper
DEBUG - 2017-07-12 07:06:10 --> Session routines successfully run
INFO - 2017-07-12 07:06:10 --> Form Validation Class Initialized
INFO - 2017-07-12 07:06:10 --> Controller Class Initialized
INFO - 2017-07-12 07:06:10 --> Model Class Initialized
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-12 07:06:10 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
INFO - 2017-07-12 07:06:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/EmailTemplatelistAjax.php
INFO - 2017-07-12 07:06:13 --> Config Class Initialized
INFO - 2017-07-12 07:06:13 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:06:13 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:06:13 --> Utf8 Class Initialized
INFO - 2017-07-12 07:06:13 --> URI Class Initialized
INFO - 2017-07-12 07:06:13 --> Router Class Initialized
INFO - 2017-07-12 07:06:13 --> Output Class Initialized
INFO - 2017-07-12 07:06:13 --> Security Class Initialized
DEBUG - 2017-07-12 07:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:06:13 --> Input Class Initialized
INFO - 2017-07-12 07:06:13 --> Language Class Initialized
INFO - 2017-07-12 07:06:13 --> Loader Class Initialized
INFO - 2017-07-12 07:06:13 --> Helper loaded: url_helper
INFO - 2017-07-12 07:06:13 --> Helper loaded: form_helper
INFO - 2017-07-12 07:06:13 --> Helper loaded: html_helper
INFO - 2017-07-12 07:06:13 --> Helper loaded: custom_helper
INFO - 2017-07-12 07:06:13 --> Helper loaded: cache_helper
INFO - 2017-07-12 07:06:13 --> Database Driver Class Initialized
INFO - 2017-07-12 07:06:13 --> Parser Class Initialized
DEBUG - 2017-07-12 07:06:13 --> Session Class Initialized
INFO - 2017-07-12 07:06:13 --> Helper loaded: string_helper
DEBUG - 2017-07-12 07:06:13 --> Session routines successfully run
INFO - 2017-07-12 07:06:13 --> Form Validation Class Initialized
INFO - 2017-07-12 07:06:13 --> Controller Class Initialized
INFO - 2017-07-12 07:06:13 --> Model Class Initialized
DEBUG - 2017-07-12 07:06:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-07-12 07:06:13 --> Severity: Notice --> Undefined index: sandgrid_id C:\xampp\htdocs\schedullo\application\admin\controllers\EmailTemplate.php 409
INFO - 2017-07-12 07:06:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-12 07:06:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-12 07:06:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/addEmailTemplate.php
INFO - 2017-07-12 07:06:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-12 07:06:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-12 07:06:13 --> Final output sent to browser
DEBUG - 2017-07-12 07:06:13 --> Total execution time: 0.2527
INFO - 2017-07-12 07:18:47 --> Config Class Initialized
INFO - 2017-07-12 07:18:47 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:18:47 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:18:47 --> Utf8 Class Initialized
INFO - 2017-07-12 07:18:47 --> URI Class Initialized
INFO - 2017-07-12 07:18:47 --> Router Class Initialized
INFO - 2017-07-12 07:18:47 --> Output Class Initialized
INFO - 2017-07-12 07:18:47 --> Security Class Initialized
DEBUG - 2017-07-12 07:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:18:47 --> Input Class Initialized
INFO - 2017-07-12 07:18:47 --> Language Class Initialized
INFO - 2017-07-12 07:18:47 --> Loader Class Initialized
INFO - 2017-07-12 07:18:47 --> Helper loaded: url_helper
INFO - 2017-07-12 07:18:47 --> Helper loaded: form_helper
INFO - 2017-07-12 07:18:47 --> Helper loaded: html_helper
INFO - 2017-07-12 07:18:48 --> Helper loaded: custom_helper
INFO - 2017-07-12 07:18:48 --> Helper loaded: cache_helper
INFO - 2017-07-12 07:18:48 --> Database Driver Class Initialized
INFO - 2017-07-12 07:18:48 --> Parser Class Initialized
DEBUG - 2017-07-12 07:18:48 --> Session Class Initialized
INFO - 2017-07-12 07:18:48 --> Helper loaded: string_helper
DEBUG - 2017-07-12 07:18:48 --> Session routines successfully run
INFO - 2017-07-12 07:18:48 --> Form Validation Class Initialized
INFO - 2017-07-12 07:18:48 --> Controller Class Initialized
INFO - 2017-07-12 07:18:48 --> Model Class Initialized
DEBUG - 2017-07-12 07:18:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-07-12 07:18:48 --> Severity: Notice --> Undefined index: sandgrid_id C:\xampp\htdocs\schedullo\application\admin\controllers\EmailTemplate.php 409
INFO - 2017-07-12 07:18:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-12 07:18:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-12 07:18:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/addEmailTemplate.php
INFO - 2017-07-12 07:18:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-12 07:18:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-12 07:18:48 --> Final output sent to browser
DEBUG - 2017-07-12 07:18:48 --> Total execution time: 1.0469
INFO - 2017-07-12 07:27:24 --> Config Class Initialized
INFO - 2017-07-12 07:27:24 --> Hooks Class Initialized
DEBUG - 2017-07-12 07:27:24 --> UTF-8 Support Enabled
INFO - 2017-07-12 07:27:24 --> Utf8 Class Initialized
INFO - 2017-07-12 07:27:24 --> URI Class Initialized
INFO - 2017-07-12 07:27:24 --> Router Class Initialized
INFO - 2017-07-12 07:27:24 --> Output Class Initialized
INFO - 2017-07-12 07:27:24 --> Security Class Initialized
DEBUG - 2017-07-12 07:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 07:27:24 --> Input Class Initialized
INFO - 2017-07-12 07:27:24 --> Language Class Initialized
INFO - 2017-07-12 07:27:24 --> Loader Class Initialized
INFO - 2017-07-12 07:27:24 --> Helper loaded: url_helper
INFO - 2017-07-12 07:27:24 --> Helper loaded: form_helper
INFO - 2017-07-12 07:27:24 --> Helper loaded: html_helper
INFO - 2017-07-12 07:27:24 --> Helper loaded: custom_helper
INFO - 2017-07-12 07:27:24 --> Helper loaded: cache_helper
INFO - 2017-07-12 07:27:24 --> Database Driver Class Initialized
INFO - 2017-07-12 07:27:24 --> Parser Class Initialized
DEBUG - 2017-07-12 07:27:24 --> Session Class Initialized
INFO - 2017-07-12 07:27:24 --> Helper loaded: string_helper
DEBUG - 2017-07-12 07:27:24 --> Session routines successfully run
INFO - 2017-07-12 07:27:24 --> Form Validation Class Initialized
INFO - 2017-07-12 07:27:24 --> Controller Class Initialized
INFO - 2017-07-12 07:27:24 --> Model Class Initialized
DEBUG - 2017-07-12 07:27:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-12 07:27:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-12 07:27:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-12 07:27:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/addEmailTemplate.php
INFO - 2017-07-12 07:27:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-12 07:27:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-12 07:27:25 --> Final output sent to browser
DEBUG - 2017-07-12 07:27:25 --> Total execution time: 0.8811
INFO - 2017-07-12 08:52:37 --> Config Class Initialized
INFO - 2017-07-12 08:52:37 --> Hooks Class Initialized
DEBUG - 2017-07-12 08:52:37 --> UTF-8 Support Enabled
INFO - 2017-07-12 08:52:37 --> Utf8 Class Initialized
INFO - 2017-07-12 08:52:37 --> URI Class Initialized
INFO - 2017-07-12 08:52:37 --> Router Class Initialized
INFO - 2017-07-12 08:52:37 --> Output Class Initialized
INFO - 2017-07-12 08:52:37 --> Security Class Initialized
DEBUG - 2017-07-12 08:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 08:52:37 --> Input Class Initialized
INFO - 2017-07-12 08:52:37 --> Language Class Initialized
INFO - 2017-07-12 08:52:37 --> Loader Class Initialized
INFO - 2017-07-12 08:52:37 --> Helper loaded: url_helper
INFO - 2017-07-12 08:52:37 --> Helper loaded: form_helper
INFO - 2017-07-12 08:52:37 --> Helper loaded: html_helper
INFO - 2017-07-12 08:52:37 --> Helper loaded: custom_helper
INFO - 2017-07-12 08:52:37 --> Helper loaded: cache_helper
INFO - 2017-07-12 08:52:37 --> Database Driver Class Initialized
INFO - 2017-07-12 08:52:37 --> Parser Class Initialized
DEBUG - 2017-07-12 08:52:38 --> Session Class Initialized
INFO - 2017-07-12 08:52:38 --> Helper loaded: string_helper
DEBUG - 2017-07-12 08:52:38 --> Session routines successfully run
INFO - 2017-07-12 08:52:38 --> Form Validation Class Initialized
INFO - 2017-07-12 08:52:38 --> Controller Class Initialized
INFO - 2017-07-12 08:52:38 --> Model Class Initialized
INFO - 2017-07-12 08:52:38 --> Config Class Initialized
INFO - 2017-07-12 08:52:38 --> Hooks Class Initialized
DEBUG - 2017-07-12 08:52:38 --> UTF-8 Support Enabled
INFO - 2017-07-12 08:52:38 --> Utf8 Class Initialized
INFO - 2017-07-12 08:52:38 --> URI Class Initialized
INFO - 2017-07-12 08:52:38 --> Router Class Initialized
INFO - 2017-07-12 08:52:38 --> Output Class Initialized
INFO - 2017-07-12 08:52:38 --> Security Class Initialized
DEBUG - 2017-07-12 08:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 08:52:38 --> Input Class Initialized
INFO - 2017-07-12 08:52:38 --> Language Class Initialized
INFO - 2017-07-12 08:52:38 --> Loader Class Initialized
INFO - 2017-07-12 08:52:38 --> Helper loaded: url_helper
INFO - 2017-07-12 08:52:38 --> Helper loaded: form_helper
INFO - 2017-07-12 08:52:38 --> Helper loaded: html_helper
INFO - 2017-07-12 08:52:38 --> Helper loaded: custom_helper
INFO - 2017-07-12 08:52:38 --> Helper loaded: cache_helper
INFO - 2017-07-12 08:52:38 --> Database Driver Class Initialized
INFO - 2017-07-12 08:52:38 --> Parser Class Initialized
DEBUG - 2017-07-12 08:52:38 --> Session Class Initialized
INFO - 2017-07-12 08:52:38 --> Helper loaded: string_helper
ERROR - 2017-07-12 08:52:38 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-07-12 08:52:38 --> Session routines successfully run
INFO - 2017-07-12 08:52:38 --> Form Validation Class Initialized
INFO - 2017-07-12 08:52:38 --> Controller Class Initialized
INFO - 2017-07-12 08:52:38 --> Model Class Initialized
INFO - 2017-07-12 08:52:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-07-12 08:52:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-12 08:52:38 --> Final output sent to browser
DEBUG - 2017-07-12 08:52:38 --> Total execution time: 0.3428
INFO - 2017-07-12 08:52:39 --> Config Class Initialized
INFO - 2017-07-12 08:52:39 --> Hooks Class Initialized
DEBUG - 2017-07-12 08:52:39 --> UTF-8 Support Enabled
INFO - 2017-07-12 08:52:39 --> Utf8 Class Initialized
INFO - 2017-07-12 08:52:39 --> URI Class Initialized
INFO - 2017-07-12 08:52:39 --> Router Class Initialized
INFO - 2017-07-12 08:52:39 --> Output Class Initialized
INFO - 2017-07-12 08:52:39 --> Security Class Initialized
DEBUG - 2017-07-12 08:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-12 08:52:39 --> Input Class Initialized
INFO - 2017-07-12 08:52:39 --> Language Class Initialized
ERROR - 2017-07-12 08:52:39 --> 404 Page Not Found: Default/assets
