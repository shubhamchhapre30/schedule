<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-05-01 07:47:06 --> Config Class Initialized
INFO - 2017-05-01 07:47:06 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:47:06 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:47:06 --> Utf8 Class Initialized
INFO - 2017-05-01 07:47:06 --> URI Class Initialized
DEBUG - 2017-05-01 07:47:06 --> No URI present. Default controller set.
INFO - 2017-05-01 07:47:06 --> Router Class Initialized
INFO - 2017-05-01 07:47:06 --> Output Class Initialized
INFO - 2017-05-01 07:47:06 --> Security Class Initialized
DEBUG - 2017-05-01 07:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:47:06 --> Input Class Initialized
INFO - 2017-05-01 07:47:06 --> Language Class Initialized
INFO - 2017-05-01 07:47:06 --> Loader Class Initialized
INFO - 2017-05-01 07:47:07 --> Helper loaded: url_helper
INFO - 2017-05-01 07:47:07 --> Helper loaded: form_helper
INFO - 2017-05-01 07:47:07 --> Helper loaded: html_helper
INFO - 2017-05-01 07:47:07 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:47:07 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:47:07 --> Database Driver Class Initialized
INFO - 2017-05-01 07:47:07 --> Parser Class Initialized
DEBUG - 2017-05-01 07:47:07 --> Session Class Initialized
INFO - 2017-05-01 07:47:07 --> Helper loaded: string_helper
ERROR - 2017-05-01 07:47:07 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-01 07:47:07 --> Session routines successfully run
INFO - 2017-05-01 07:47:07 --> Form Validation Class Initialized
INFO - 2017-05-01 07:47:07 --> Controller Class Initialized
INFO - 2017-05-01 07:47:07 --> Model Class Initialized
INFO - 2017-05-01 07:47:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-01 07:47:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 07:47:07 --> Final output sent to browser
DEBUG - 2017-05-01 07:47:07 --> Total execution time: 0.3704
INFO - 2017-05-01 07:47:23 --> Config Class Initialized
INFO - 2017-05-01 07:47:23 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:47:23 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:47:23 --> Utf8 Class Initialized
INFO - 2017-05-01 07:47:23 --> URI Class Initialized
INFO - 2017-05-01 07:47:23 --> Router Class Initialized
INFO - 2017-05-01 07:47:23 --> Output Class Initialized
INFO - 2017-05-01 07:47:23 --> Security Class Initialized
DEBUG - 2017-05-01 07:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:47:23 --> Input Class Initialized
INFO - 2017-05-01 07:47:23 --> Language Class Initialized
INFO - 2017-05-01 07:47:23 --> Loader Class Initialized
INFO - 2017-05-01 07:47:23 --> Helper loaded: url_helper
INFO - 2017-05-01 07:47:23 --> Helper loaded: form_helper
INFO - 2017-05-01 07:47:23 --> Helper loaded: html_helper
INFO - 2017-05-01 07:47:23 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:47:23 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:47:23 --> Database Driver Class Initialized
INFO - 2017-05-01 07:47:23 --> Parser Class Initialized
DEBUG - 2017-05-01 07:47:23 --> Session Class Initialized
INFO - 2017-05-01 07:47:23 --> Helper loaded: string_helper
ERROR - 2017-05-01 07:47:23 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-01 07:47:23 --> Session routines successfully run
INFO - 2017-05-01 07:47:23 --> Form Validation Class Initialized
INFO - 2017-05-01 07:47:23 --> Controller Class Initialized
INFO - 2017-05-01 07:47:23 --> Model Class Initialized
INFO - 2017-05-01 07:47:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-01 07:47:26 --> Config Class Initialized
INFO - 2017-05-01 07:47:26 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:47:26 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:47:26 --> Utf8 Class Initialized
INFO - 2017-05-01 07:47:26 --> URI Class Initialized
INFO - 2017-05-01 07:47:26 --> Router Class Initialized
INFO - 2017-05-01 07:47:26 --> Output Class Initialized
INFO - 2017-05-01 07:47:26 --> Security Class Initialized
DEBUG - 2017-05-01 07:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:47:26 --> Input Class Initialized
INFO - 2017-05-01 07:47:26 --> Language Class Initialized
INFO - 2017-05-01 07:47:26 --> Loader Class Initialized
INFO - 2017-05-01 07:47:26 --> Helper loaded: url_helper
INFO - 2017-05-01 07:47:26 --> Helper loaded: form_helper
INFO - 2017-05-01 07:47:26 --> Helper loaded: html_helper
INFO - 2017-05-01 07:47:26 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:47:26 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:47:26 --> Database Driver Class Initialized
INFO - 2017-05-01 07:47:26 --> Parser Class Initialized
DEBUG - 2017-05-01 07:47:26 --> Session Class Initialized
INFO - 2017-05-01 07:47:26 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:47:26 --> Session routines successfully run
INFO - 2017-05-01 07:47:26 --> Form Validation Class Initialized
INFO - 2017-05-01 07:47:26 --> Controller Class Initialized
INFO - 2017-05-01 07:47:26 --> Model Class Initialized
INFO - 2017-05-01 07:47:26 --> Config Class Initialized
INFO - 2017-05-01 07:47:26 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:47:26 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:47:26 --> Utf8 Class Initialized
INFO - 2017-05-01 07:47:26 --> URI Class Initialized
INFO - 2017-05-01 07:47:26 --> Router Class Initialized
INFO - 2017-05-01 07:47:26 --> Output Class Initialized
INFO - 2017-05-01 07:47:26 --> Security Class Initialized
DEBUG - 2017-05-01 07:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:47:26 --> Input Class Initialized
INFO - 2017-05-01 07:47:26 --> Language Class Initialized
INFO - 2017-05-01 07:47:26 --> Loader Class Initialized
INFO - 2017-05-01 07:47:26 --> Helper loaded: url_helper
INFO - 2017-05-01 07:47:26 --> Helper loaded: form_helper
INFO - 2017-05-01 07:47:26 --> Helper loaded: html_helper
INFO - 2017-05-01 07:47:26 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:47:26 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:47:26 --> Database Driver Class Initialized
INFO - 2017-05-01 07:47:26 --> Parser Class Initialized
DEBUG - 2017-05-01 07:47:26 --> Session Class Initialized
INFO - 2017-05-01 07:47:26 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:47:26 --> Session routines successfully run
INFO - 2017-05-01 07:47:26 --> Form Validation Class Initialized
INFO - 2017-05-01 07:47:26 --> Controller Class Initialized
INFO - 2017-05-01 07:47:26 --> Model Class Initialized
INFO - 2017-05-01 07:47:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-01 07:47:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 07:47:26 --> Final output sent to browser
DEBUG - 2017-05-01 07:47:26 --> Total execution time: 0.1635
INFO - 2017-05-01 07:47:40 --> Config Class Initialized
INFO - 2017-05-01 07:47:40 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:47:40 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:47:40 --> Utf8 Class Initialized
INFO - 2017-05-01 07:47:40 --> URI Class Initialized
INFO - 2017-05-01 07:47:40 --> Router Class Initialized
INFO - 2017-05-01 07:47:40 --> Output Class Initialized
INFO - 2017-05-01 07:47:40 --> Security Class Initialized
DEBUG - 2017-05-01 07:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:47:40 --> Input Class Initialized
INFO - 2017-05-01 07:47:40 --> Language Class Initialized
INFO - 2017-05-01 07:47:40 --> Loader Class Initialized
INFO - 2017-05-01 07:47:40 --> Helper loaded: url_helper
INFO - 2017-05-01 07:47:40 --> Helper loaded: form_helper
INFO - 2017-05-01 07:47:40 --> Helper loaded: html_helper
INFO - 2017-05-01 07:47:40 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:47:40 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:47:40 --> Database Driver Class Initialized
INFO - 2017-05-01 07:47:40 --> Parser Class Initialized
DEBUG - 2017-05-01 07:47:40 --> Session Class Initialized
INFO - 2017-05-01 07:47:40 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:47:40 --> Session routines successfully run
INFO - 2017-05-01 07:47:40 --> Form Validation Class Initialized
INFO - 2017-05-01 07:47:40 --> Controller Class Initialized
INFO - 2017-05-01 07:47:40 --> Model Class Initialized
INFO - 2017-05-01 07:47:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-01 07:47:45 --> Config Class Initialized
INFO - 2017-05-01 07:47:45 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:47:45 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:47:45 --> Utf8 Class Initialized
INFO - 2017-05-01 07:47:45 --> URI Class Initialized
INFO - 2017-05-01 07:47:45 --> Router Class Initialized
INFO - 2017-05-01 07:47:45 --> Output Class Initialized
INFO - 2017-05-01 07:47:45 --> Security Class Initialized
DEBUG - 2017-05-01 07:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:47:45 --> Input Class Initialized
INFO - 2017-05-01 07:47:45 --> Language Class Initialized
INFO - 2017-05-01 07:47:45 --> Loader Class Initialized
INFO - 2017-05-01 07:47:45 --> Helper loaded: url_helper
INFO - 2017-05-01 07:47:45 --> Helper loaded: form_helper
INFO - 2017-05-01 07:47:45 --> Helper loaded: html_helper
INFO - 2017-05-01 07:47:45 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:47:45 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:47:45 --> Database Driver Class Initialized
INFO - 2017-05-01 07:47:45 --> Parser Class Initialized
DEBUG - 2017-05-01 07:47:45 --> Session Class Initialized
INFO - 2017-05-01 07:47:45 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:47:45 --> Session routines successfully run
INFO - 2017-05-01 07:47:45 --> Form Validation Class Initialized
INFO - 2017-05-01 07:47:45 --> Controller Class Initialized
INFO - 2017-05-01 07:47:45 --> Model Class Initialized
INFO - 2017-05-01 07:47:45 --> Config Class Initialized
INFO - 2017-05-01 07:47:45 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:47:45 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:47:45 --> Utf8 Class Initialized
INFO - 2017-05-01 07:47:45 --> URI Class Initialized
INFO - 2017-05-01 07:47:45 --> Router Class Initialized
INFO - 2017-05-01 07:47:45 --> Output Class Initialized
INFO - 2017-05-01 07:47:45 --> Security Class Initialized
DEBUG - 2017-05-01 07:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:47:45 --> Input Class Initialized
INFO - 2017-05-01 07:47:45 --> Language Class Initialized
INFO - 2017-05-01 07:47:45 --> Loader Class Initialized
INFO - 2017-05-01 07:47:45 --> Helper loaded: url_helper
INFO - 2017-05-01 07:47:45 --> Helper loaded: form_helper
INFO - 2017-05-01 07:47:45 --> Helper loaded: html_helper
INFO - 2017-05-01 07:47:45 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:47:45 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:47:45 --> Database Driver Class Initialized
INFO - 2017-05-01 07:47:45 --> Parser Class Initialized
DEBUG - 2017-05-01 07:47:45 --> Session Class Initialized
INFO - 2017-05-01 07:47:45 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:47:45 --> Session routines successfully run
INFO - 2017-05-01 07:47:45 --> Form Validation Class Initialized
INFO - 2017-05-01 07:47:45 --> Controller Class Initialized
INFO - 2017-05-01 07:47:45 --> Model Class Initialized
INFO - 2017-05-01 07:47:45 --> Config Class Initialized
INFO - 2017-05-01 07:47:45 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:47:45 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:47:45 --> Utf8 Class Initialized
INFO - 2017-05-01 07:47:45 --> URI Class Initialized
INFO - 2017-05-01 07:47:45 --> Router Class Initialized
INFO - 2017-05-01 07:47:46 --> Output Class Initialized
INFO - 2017-05-01 07:47:46 --> Security Class Initialized
DEBUG - 2017-05-01 07:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:47:46 --> Input Class Initialized
INFO - 2017-05-01 07:47:46 --> Language Class Initialized
INFO - 2017-05-01 07:47:46 --> Loader Class Initialized
INFO - 2017-05-01 07:47:46 --> Helper loaded: url_helper
INFO - 2017-05-01 07:47:46 --> Helper loaded: form_helper
INFO - 2017-05-01 07:47:46 --> Helper loaded: html_helper
INFO - 2017-05-01 07:47:46 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:47:46 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:47:46 --> Database Driver Class Initialized
INFO - 2017-05-01 07:47:46 --> Parser Class Initialized
DEBUG - 2017-05-01 07:47:46 --> Session Class Initialized
INFO - 2017-05-01 07:47:46 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:47:46 --> Session routines successfully run
INFO - 2017-05-01 07:47:46 --> Form Validation Class Initialized
INFO - 2017-05-01 07:47:46 --> Controller Class Initialized
DEBUG - 2017-05-01 07:47:46 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 07:47:46 --> Model Class Initialized
DEBUG - 2017-05-01 07:47:46 --> Pagination Class Initialized
INFO - 2017-05-01 07:47:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-01 07:47:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-01 07:47:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-05-01 07:47:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-01 07:47:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 07:47:46 --> Final output sent to browser
DEBUG - 2017-05-01 07:47:46 --> Total execution time: 0.3028
INFO - 2017-05-01 07:47:48 --> Config Class Initialized
INFO - 2017-05-01 07:47:48 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:47:48 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:47:48 --> Utf8 Class Initialized
INFO - 2017-05-01 07:47:48 --> URI Class Initialized
INFO - 2017-05-01 07:47:48 --> Router Class Initialized
INFO - 2017-05-01 07:47:48 --> Output Class Initialized
INFO - 2017-05-01 07:47:48 --> Security Class Initialized
DEBUG - 2017-05-01 07:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:47:48 --> Input Class Initialized
INFO - 2017-05-01 07:47:48 --> Language Class Initialized
INFO - 2017-05-01 07:47:48 --> Loader Class Initialized
INFO - 2017-05-01 07:47:48 --> Helper loaded: url_helper
INFO - 2017-05-01 07:47:48 --> Helper loaded: form_helper
INFO - 2017-05-01 07:47:48 --> Helper loaded: html_helper
INFO - 2017-05-01 07:47:48 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:47:48 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:47:48 --> Database Driver Class Initialized
INFO - 2017-05-01 07:47:48 --> Parser Class Initialized
DEBUG - 2017-05-01 07:47:48 --> Session Class Initialized
INFO - 2017-05-01 07:47:48 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:47:48 --> Session routines successfully run
INFO - 2017-05-01 07:47:48 --> Form Validation Class Initialized
INFO - 2017-05-01 07:47:48 --> Controller Class Initialized
DEBUG - 2017-05-01 07:47:48 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 07:47:48 --> Model Class Initialized
DEBUG - 2017-05-01 07:47:48 --> Pagination Class Initialized
INFO - 2017-05-01 07:47:48 --> Config Class Initialized
INFO - 2017-05-01 07:47:48 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:47:48 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:47:48 --> Utf8 Class Initialized
INFO - 2017-05-01 07:47:48 --> URI Class Initialized
INFO - 2017-05-01 07:47:48 --> Router Class Initialized
INFO - 2017-05-01 07:47:48 --> Output Class Initialized
INFO - 2017-05-01 07:47:48 --> Security Class Initialized
DEBUG - 2017-05-01 07:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:47:48 --> Input Class Initialized
INFO - 2017-05-01 07:47:48 --> Language Class Initialized
INFO - 2017-05-01 07:47:48 --> Loader Class Initialized
INFO - 2017-05-01 07:47:48 --> Helper loaded: url_helper
INFO - 2017-05-01 07:47:48 --> Helper loaded: form_helper
INFO - 2017-05-01 07:47:48 --> Helper loaded: html_helper
INFO - 2017-05-01 07:47:48 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:47:48 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:47:48 --> Database Driver Class Initialized
INFO - 2017-05-01 07:47:48 --> Parser Class Initialized
DEBUG - 2017-05-01 07:47:48 --> Session Class Initialized
INFO - 2017-05-01 07:47:48 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:47:48 --> Session routines successfully run
INFO - 2017-05-01 07:47:48 --> Form Validation Class Initialized
INFO - 2017-05-01 07:47:48 --> Controller Class Initialized
DEBUG - 2017-05-01 07:47:48 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 07:47:48 --> Model Class Initialized
DEBUG - 2017-05-01 07:47:48 --> Pagination Class Initialized
INFO - 2017-05-01 07:47:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-01 07:47:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-01 07:47:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-01 07:47:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-01 07:47:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 07:47:48 --> Final output sent to browser
DEBUG - 2017-05-01 07:47:48 --> Total execution time: 0.2908
INFO - 2017-05-01 07:48:00 --> Config Class Initialized
INFO - 2017-05-01 07:48:00 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:48:00 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:48:00 --> Utf8 Class Initialized
INFO - 2017-05-01 07:48:00 --> URI Class Initialized
INFO - 2017-05-01 07:48:00 --> Router Class Initialized
INFO - 2017-05-01 07:48:00 --> Output Class Initialized
INFO - 2017-05-01 07:48:00 --> Security Class Initialized
DEBUG - 2017-05-01 07:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:48:00 --> Input Class Initialized
INFO - 2017-05-01 07:48:00 --> Language Class Initialized
INFO - 2017-05-01 07:48:00 --> Loader Class Initialized
INFO - 2017-05-01 07:48:00 --> Helper loaded: url_helper
INFO - 2017-05-01 07:48:00 --> Helper loaded: form_helper
INFO - 2017-05-01 07:48:00 --> Helper loaded: html_helper
INFO - 2017-05-01 07:48:00 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:48:00 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:48:00 --> Database Driver Class Initialized
INFO - 2017-05-01 07:48:00 --> Parser Class Initialized
DEBUG - 2017-05-01 07:48:00 --> Session Class Initialized
INFO - 2017-05-01 07:48:00 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:48:00 --> Session routines successfully run
INFO - 2017-05-01 07:48:00 --> Form Validation Class Initialized
INFO - 2017-05-01 07:48:00 --> Controller Class Initialized
DEBUG - 2017-05-01 07:48:00 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 07:48:00 --> Model Class Initialized
DEBUG - 2017-05-01 07:48:00 --> Pagination Class Initialized
INFO - 2017-05-01 07:48:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-01 07:48:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-01 07:48:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-01 07:48:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-01 07:48:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 07:48:00 --> Final output sent to browser
DEBUG - 2017-05-01 07:48:00 --> Total execution time: 0.2106
INFO - 2017-05-01 07:48:04 --> Config Class Initialized
INFO - 2017-05-01 07:48:04 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:48:04 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:48:04 --> Utf8 Class Initialized
INFO - 2017-05-01 07:48:04 --> URI Class Initialized
INFO - 2017-05-01 07:48:04 --> Router Class Initialized
INFO - 2017-05-01 07:48:04 --> Output Class Initialized
INFO - 2017-05-01 07:48:04 --> Security Class Initialized
DEBUG - 2017-05-01 07:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:48:04 --> Input Class Initialized
INFO - 2017-05-01 07:48:04 --> Language Class Initialized
INFO - 2017-05-01 07:48:04 --> Loader Class Initialized
INFO - 2017-05-01 07:48:04 --> Helper loaded: url_helper
INFO - 2017-05-01 07:48:04 --> Helper loaded: form_helper
INFO - 2017-05-01 07:48:04 --> Helper loaded: html_helper
INFO - 2017-05-01 07:48:04 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:48:04 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:48:04 --> Database Driver Class Initialized
INFO - 2017-05-01 07:48:04 --> Parser Class Initialized
DEBUG - 2017-05-01 07:48:04 --> Session Class Initialized
INFO - 2017-05-01 07:48:04 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:48:04 --> Session routines successfully run
INFO - 2017-05-01 07:48:04 --> Form Validation Class Initialized
INFO - 2017-05-01 07:48:04 --> Controller Class Initialized
DEBUG - 2017-05-01 07:48:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 07:48:04 --> Model Class Initialized
DEBUG - 2017-05-01 07:48:04 --> Pagination Class Initialized
INFO - 2017-05-01 07:48:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-01 07:48:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-01 07:48:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-01 07:48:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-01 07:48:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 07:48:04 --> Final output sent to browser
DEBUG - 2017-05-01 07:48:04 --> Total execution time: 0.2071
INFO - 2017-05-01 07:48:07 --> Config Class Initialized
INFO - 2017-05-01 07:48:07 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:48:07 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:48:07 --> Utf8 Class Initialized
INFO - 2017-05-01 07:48:07 --> URI Class Initialized
INFO - 2017-05-01 07:48:07 --> Router Class Initialized
INFO - 2017-05-01 07:48:07 --> Output Class Initialized
INFO - 2017-05-01 07:48:07 --> Security Class Initialized
DEBUG - 2017-05-01 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:48:07 --> Input Class Initialized
INFO - 2017-05-01 07:48:07 --> Language Class Initialized
INFO - 2017-05-01 07:48:07 --> Loader Class Initialized
INFO - 2017-05-01 07:48:07 --> Helper loaded: url_helper
INFO - 2017-05-01 07:48:07 --> Helper loaded: form_helper
INFO - 2017-05-01 07:48:07 --> Helper loaded: html_helper
INFO - 2017-05-01 07:48:07 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:48:07 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:48:07 --> Database Driver Class Initialized
INFO - 2017-05-01 07:48:07 --> Parser Class Initialized
DEBUG - 2017-05-01 07:48:07 --> Session Class Initialized
INFO - 2017-05-01 07:48:07 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:48:07 --> Session routines successfully run
INFO - 2017-05-01 07:48:07 --> Form Validation Class Initialized
INFO - 2017-05-01 07:48:07 --> Controller Class Initialized
DEBUG - 2017-05-01 07:48:07 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 07:48:07 --> Model Class Initialized
DEBUG - 2017-05-01 07:48:07 --> Pagination Class Initialized
INFO - 2017-05-01 07:48:07 --> Config Class Initialized
INFO - 2017-05-01 07:48:07 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:48:07 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:48:07 --> Utf8 Class Initialized
INFO - 2017-05-01 07:48:07 --> URI Class Initialized
INFO - 2017-05-01 07:48:07 --> Router Class Initialized
INFO - 2017-05-01 07:48:07 --> Output Class Initialized
INFO - 2017-05-01 07:48:07 --> Security Class Initialized
DEBUG - 2017-05-01 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:48:07 --> Input Class Initialized
INFO - 2017-05-01 07:48:07 --> Language Class Initialized
INFO - 2017-05-01 07:48:07 --> Loader Class Initialized
INFO - 2017-05-01 07:48:07 --> Helper loaded: url_helper
INFO - 2017-05-01 07:48:07 --> Helper loaded: form_helper
INFO - 2017-05-01 07:48:07 --> Helper loaded: html_helper
INFO - 2017-05-01 07:48:07 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:48:07 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:48:07 --> Database Driver Class Initialized
INFO - 2017-05-01 07:48:07 --> Parser Class Initialized
DEBUG - 2017-05-01 07:48:07 --> Session Class Initialized
INFO - 2017-05-01 07:48:07 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:48:07 --> Session routines successfully run
INFO - 2017-05-01 07:48:07 --> Form Validation Class Initialized
INFO - 2017-05-01 07:48:07 --> Controller Class Initialized
DEBUG - 2017-05-01 07:48:07 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 07:48:07 --> Model Class Initialized
DEBUG - 2017-05-01 07:48:07 --> Pagination Class Initialized
INFO - 2017-05-01 07:48:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-01 07:48:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-01 07:48:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-01 07:48:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-01 07:48:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 07:48:08 --> Final output sent to browser
DEBUG - 2017-05-01 07:48:08 --> Total execution time: 0.2157
INFO - 2017-05-01 07:48:10 --> Config Class Initialized
INFO - 2017-05-01 07:48:10 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:48:10 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:48:10 --> Utf8 Class Initialized
INFO - 2017-05-01 07:48:10 --> URI Class Initialized
INFO - 2017-05-01 07:48:10 --> Router Class Initialized
INFO - 2017-05-01 07:48:10 --> Output Class Initialized
INFO - 2017-05-01 07:48:10 --> Security Class Initialized
DEBUG - 2017-05-01 07:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:48:10 --> Input Class Initialized
INFO - 2017-05-01 07:48:10 --> Language Class Initialized
INFO - 2017-05-01 07:48:10 --> Loader Class Initialized
INFO - 2017-05-01 07:48:10 --> Helper loaded: url_helper
INFO - 2017-05-01 07:48:10 --> Helper loaded: form_helper
INFO - 2017-05-01 07:48:10 --> Helper loaded: html_helper
INFO - 2017-05-01 07:48:10 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:48:10 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:48:10 --> Database Driver Class Initialized
INFO - 2017-05-01 07:48:10 --> Parser Class Initialized
DEBUG - 2017-05-01 07:48:10 --> Session Class Initialized
INFO - 2017-05-01 07:48:10 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:48:10 --> Session routines successfully run
INFO - 2017-05-01 07:48:10 --> Form Validation Class Initialized
INFO - 2017-05-01 07:48:10 --> Controller Class Initialized
INFO - 2017-05-01 07:48:10 --> Model Class Initialized
DEBUG - 2017-05-01 07:48:10 --> Pagination Class Initialized
INFO - 2017-05-01 07:48:10 --> Config Class Initialized
INFO - 2017-05-01 07:48:10 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:48:10 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:48:10 --> Utf8 Class Initialized
INFO - 2017-05-01 07:48:10 --> URI Class Initialized
INFO - 2017-05-01 07:48:10 --> Router Class Initialized
INFO - 2017-05-01 07:48:10 --> Output Class Initialized
INFO - 2017-05-01 07:48:10 --> Security Class Initialized
DEBUG - 2017-05-01 07:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:48:10 --> Input Class Initialized
INFO - 2017-05-01 07:48:10 --> Language Class Initialized
INFO - 2017-05-01 07:48:10 --> Loader Class Initialized
INFO - 2017-05-01 07:48:11 --> Helper loaded: url_helper
INFO - 2017-05-01 07:48:11 --> Helper loaded: form_helper
INFO - 2017-05-01 07:48:11 --> Helper loaded: html_helper
INFO - 2017-05-01 07:48:11 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:48:11 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:48:11 --> Database Driver Class Initialized
INFO - 2017-05-01 07:48:11 --> Parser Class Initialized
DEBUG - 2017-05-01 07:48:11 --> Session Class Initialized
INFO - 2017-05-01 07:48:11 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:48:11 --> Session routines successfully run
INFO - 2017-05-01 07:48:11 --> Form Validation Class Initialized
INFO - 2017-05-01 07:48:11 --> Controller Class Initialized
INFO - 2017-05-01 07:48:11 --> Model Class Initialized
DEBUG - 2017-05-01 07:48:11 --> Pagination Class Initialized
INFO - 2017-05-01 07:48:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-01 07:48:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-01 07:48:11 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 287
ERROR - 2017-05-01 07:48:11 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 288
ERROR - 2017-05-01 07:48:11 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 289
ERROR - 2017-05-01 07:48:11 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 290
INFO - 2017-05-01 07:48:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/Plan_subscription/list_plan_subscription.php
INFO - 2017-05-01 07:48:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-01 07:48:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 07:48:11 --> Final output sent to browser
DEBUG - 2017-05-01 07:48:11 --> Total execution time: 0.4012
INFO - 2017-05-01 07:48:12 --> Config Class Initialized
INFO - 2017-05-01 07:48:12 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:48:12 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:48:12 --> Utf8 Class Initialized
INFO - 2017-05-01 07:48:12 --> URI Class Initialized
INFO - 2017-05-01 07:48:12 --> Router Class Initialized
INFO - 2017-05-01 07:48:12 --> Output Class Initialized
INFO - 2017-05-01 07:48:12 --> Security Class Initialized
DEBUG - 2017-05-01 07:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:48:12 --> Input Class Initialized
INFO - 2017-05-01 07:48:12 --> Language Class Initialized
INFO - 2017-05-01 07:48:12 --> Loader Class Initialized
INFO - 2017-05-01 07:48:12 --> Helper loaded: url_helper
INFO - 2017-05-01 07:48:12 --> Helper loaded: form_helper
INFO - 2017-05-01 07:48:12 --> Helper loaded: html_helper
INFO - 2017-05-01 07:48:12 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:48:12 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:48:12 --> Database Driver Class Initialized
INFO - 2017-05-01 07:48:12 --> Parser Class Initialized
DEBUG - 2017-05-01 07:48:12 --> Session Class Initialized
INFO - 2017-05-01 07:48:12 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:48:12 --> Session routines successfully run
INFO - 2017-05-01 07:48:12 --> Form Validation Class Initialized
INFO - 2017-05-01 07:48:12 --> Controller Class Initialized
DEBUG - 2017-05-01 07:48:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 07:48:12 --> Model Class Initialized
DEBUG - 2017-05-01 07:48:12 --> Pagination Class Initialized
INFO - 2017-05-01 07:48:12 --> Config Class Initialized
INFO - 2017-05-01 07:48:12 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:48:12 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:48:12 --> Utf8 Class Initialized
INFO - 2017-05-01 07:48:12 --> URI Class Initialized
INFO - 2017-05-01 07:48:12 --> Router Class Initialized
INFO - 2017-05-01 07:48:12 --> Output Class Initialized
INFO - 2017-05-01 07:48:12 --> Security Class Initialized
DEBUG - 2017-05-01 07:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:48:12 --> Input Class Initialized
INFO - 2017-05-01 07:48:12 --> Language Class Initialized
INFO - 2017-05-01 07:48:12 --> Loader Class Initialized
INFO - 2017-05-01 07:48:12 --> Helper loaded: url_helper
INFO - 2017-05-01 07:48:12 --> Helper loaded: form_helper
INFO - 2017-05-01 07:48:12 --> Helper loaded: html_helper
INFO - 2017-05-01 07:48:12 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:48:12 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:48:12 --> Database Driver Class Initialized
INFO - 2017-05-01 07:48:12 --> Parser Class Initialized
DEBUG - 2017-05-01 07:48:12 --> Session Class Initialized
INFO - 2017-05-01 07:48:12 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:48:12 --> Session routines successfully run
INFO - 2017-05-01 07:48:13 --> Form Validation Class Initialized
INFO - 2017-05-01 07:48:13 --> Controller Class Initialized
DEBUG - 2017-05-01 07:48:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 07:48:13 --> Model Class Initialized
DEBUG - 2017-05-01 07:48:13 --> Pagination Class Initialized
INFO - 2017-05-01 07:48:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-01 07:48:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-01 07:48:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-01 07:48:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-01 07:48:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 07:48:13 --> Final output sent to browser
DEBUG - 2017-05-01 07:48:13 --> Total execution time: 0.2336
INFO - 2017-05-01 07:48:30 --> Config Class Initialized
INFO - 2017-05-01 07:48:30 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:48:30 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:48:30 --> Utf8 Class Initialized
INFO - 2017-05-01 07:48:30 --> URI Class Initialized
INFO - 2017-05-01 07:48:30 --> Router Class Initialized
INFO - 2017-05-01 07:48:30 --> Output Class Initialized
INFO - 2017-05-01 07:48:30 --> Security Class Initialized
DEBUG - 2017-05-01 07:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:48:30 --> Input Class Initialized
INFO - 2017-05-01 07:48:30 --> Language Class Initialized
INFO - 2017-05-01 07:48:30 --> Loader Class Initialized
INFO - 2017-05-01 07:48:30 --> Helper loaded: url_helper
INFO - 2017-05-01 07:48:30 --> Helper loaded: form_helper
INFO - 2017-05-01 07:48:30 --> Helper loaded: html_helper
INFO - 2017-05-01 07:48:30 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:48:30 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:48:30 --> Database Driver Class Initialized
INFO - 2017-05-01 07:48:30 --> Parser Class Initialized
DEBUG - 2017-05-01 07:48:30 --> Session Class Initialized
INFO - 2017-05-01 07:48:30 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:48:30 --> Session routines successfully run
INFO - 2017-05-01 07:48:30 --> Form Validation Class Initialized
INFO - 2017-05-01 07:48:30 --> Controller Class Initialized
DEBUG - 2017-05-01 07:48:30 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 07:48:30 --> Model Class Initialized
DEBUG - 2017-05-01 07:48:30 --> Pagination Class Initialized
INFO - 2017-05-01 07:48:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-01 07:48:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-01 07:48:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-01 07:48:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-01 07:48:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 07:48:31 --> Final output sent to browser
DEBUG - 2017-05-01 07:48:31 --> Total execution time: 0.4396
INFO - 2017-05-01 07:48:44 --> Config Class Initialized
INFO - 2017-05-01 07:48:44 --> Hooks Class Initialized
DEBUG - 2017-05-01 07:48:44 --> UTF-8 Support Enabled
INFO - 2017-05-01 07:48:44 --> Utf8 Class Initialized
INFO - 2017-05-01 07:48:44 --> URI Class Initialized
INFO - 2017-05-01 07:48:44 --> Router Class Initialized
INFO - 2017-05-01 07:48:44 --> Output Class Initialized
INFO - 2017-05-01 07:48:44 --> Security Class Initialized
DEBUG - 2017-05-01 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 07:48:44 --> Input Class Initialized
INFO - 2017-05-01 07:48:44 --> Language Class Initialized
INFO - 2017-05-01 07:48:44 --> Loader Class Initialized
INFO - 2017-05-01 07:48:44 --> Helper loaded: url_helper
INFO - 2017-05-01 07:48:44 --> Helper loaded: form_helper
INFO - 2017-05-01 07:48:44 --> Helper loaded: html_helper
INFO - 2017-05-01 07:48:44 --> Helper loaded: custom_helper
INFO - 2017-05-01 07:48:44 --> Helper loaded: cache_helper
INFO - 2017-05-01 07:48:44 --> Database Driver Class Initialized
INFO - 2017-05-01 07:48:44 --> Parser Class Initialized
DEBUG - 2017-05-01 07:48:44 --> Session Class Initialized
INFO - 2017-05-01 07:48:44 --> Helper loaded: string_helper
DEBUG - 2017-05-01 07:48:44 --> Session routines successfully run
INFO - 2017-05-01 07:48:44 --> Form Validation Class Initialized
INFO - 2017-05-01 07:48:44 --> Controller Class Initialized
DEBUG - 2017-05-01 07:48:44 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 07:48:44 --> Model Class Initialized
DEBUG - 2017-05-01 07:48:44 --> Pagination Class Initialized
INFO - 2017-05-01 08:02:17 --> Config Class Initialized
INFO - 2017-05-01 08:02:17 --> Hooks Class Initialized
DEBUG - 2017-05-01 08:02:17 --> UTF-8 Support Enabled
INFO - 2017-05-01 08:02:17 --> Utf8 Class Initialized
INFO - 2017-05-01 08:02:17 --> URI Class Initialized
INFO - 2017-05-01 08:02:17 --> Router Class Initialized
INFO - 2017-05-01 08:02:17 --> Output Class Initialized
INFO - 2017-05-01 08:02:17 --> Security Class Initialized
DEBUG - 2017-05-01 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 08:02:17 --> Input Class Initialized
INFO - 2017-05-01 08:02:17 --> Language Class Initialized
INFO - 2017-05-01 08:02:17 --> Loader Class Initialized
INFO - 2017-05-01 08:02:17 --> Helper loaded: url_helper
INFO - 2017-05-01 08:02:17 --> Helper loaded: form_helper
INFO - 2017-05-01 08:02:17 --> Helper loaded: html_helper
INFO - 2017-05-01 08:02:17 --> Helper loaded: custom_helper
INFO - 2017-05-01 08:02:17 --> Helper loaded: cache_helper
INFO - 2017-05-01 08:02:17 --> Database Driver Class Initialized
INFO - 2017-05-01 08:02:17 --> Parser Class Initialized
DEBUG - 2017-05-01 08:02:17 --> Session Class Initialized
INFO - 2017-05-01 08:02:17 --> Helper loaded: string_helper
DEBUG - 2017-05-01 08:02:17 --> Session routines successfully run
INFO - 2017-05-01 08:02:17 --> Form Validation Class Initialized
INFO - 2017-05-01 08:02:17 --> Controller Class Initialized
DEBUG - 2017-05-01 08:02:17 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 08:02:17 --> Model Class Initialized
DEBUG - 2017-05-01 08:02:17 --> Pagination Class Initialized
INFO - 2017-05-01 08:02:47 --> Config Class Initialized
INFO - 2017-05-01 08:02:47 --> Hooks Class Initialized
DEBUG - 2017-05-01 08:02:47 --> UTF-8 Support Enabled
INFO - 2017-05-01 08:02:47 --> Utf8 Class Initialized
INFO - 2017-05-01 08:02:47 --> URI Class Initialized
INFO - 2017-05-01 08:02:47 --> Router Class Initialized
INFO - 2017-05-01 08:02:47 --> Output Class Initialized
INFO - 2017-05-01 08:02:47 --> Security Class Initialized
DEBUG - 2017-05-01 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 08:02:47 --> Input Class Initialized
INFO - 2017-05-01 08:02:47 --> Language Class Initialized
INFO - 2017-05-01 08:02:47 --> Loader Class Initialized
INFO - 2017-05-01 08:02:47 --> Helper loaded: url_helper
INFO - 2017-05-01 08:02:47 --> Helper loaded: form_helper
INFO - 2017-05-01 08:02:47 --> Helper loaded: html_helper
INFO - 2017-05-01 08:02:47 --> Helper loaded: custom_helper
INFO - 2017-05-01 08:02:47 --> Helper loaded: cache_helper
INFO - 2017-05-01 08:02:47 --> Database Driver Class Initialized
INFO - 2017-05-01 08:02:47 --> Parser Class Initialized
DEBUG - 2017-05-01 08:02:47 --> Session Class Initialized
INFO - 2017-05-01 08:02:47 --> Helper loaded: string_helper
DEBUG - 2017-05-01 08:02:47 --> Session routines successfully run
INFO - 2017-05-01 08:02:47 --> Form Validation Class Initialized
INFO - 2017-05-01 08:02:47 --> Controller Class Initialized
DEBUG - 2017-05-01 08:02:47 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 08:02:47 --> Model Class Initialized
DEBUG - 2017-05-01 08:02:47 --> Pagination Class Initialized
INFO - 2017-05-01 08:02:48 --> Config Class Initialized
INFO - 2017-05-01 08:02:48 --> Hooks Class Initialized
DEBUG - 2017-05-01 08:02:48 --> UTF-8 Support Enabled
INFO - 2017-05-01 08:02:48 --> Utf8 Class Initialized
INFO - 2017-05-01 08:02:48 --> URI Class Initialized
INFO - 2017-05-01 08:02:48 --> Router Class Initialized
INFO - 2017-05-01 08:02:48 --> Output Class Initialized
INFO - 2017-05-01 08:02:48 --> Security Class Initialized
DEBUG - 2017-05-01 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 08:02:48 --> Input Class Initialized
INFO - 2017-05-01 08:02:48 --> Language Class Initialized
INFO - 2017-05-01 08:02:48 --> Loader Class Initialized
INFO - 2017-05-01 08:02:48 --> Helper loaded: url_helper
INFO - 2017-05-01 08:02:48 --> Helper loaded: form_helper
INFO - 2017-05-01 08:02:48 --> Helper loaded: html_helper
INFO - 2017-05-01 08:02:48 --> Helper loaded: custom_helper
INFO - 2017-05-01 08:02:48 --> Helper loaded: cache_helper
INFO - 2017-05-01 08:02:48 --> Database Driver Class Initialized
INFO - 2017-05-01 08:02:48 --> Parser Class Initialized
DEBUG - 2017-05-01 08:02:48 --> Session Class Initialized
INFO - 2017-05-01 08:02:48 --> Helper loaded: string_helper
DEBUG - 2017-05-01 08:02:48 --> Session routines successfully run
INFO - 2017-05-01 08:02:48 --> Form Validation Class Initialized
INFO - 2017-05-01 08:02:48 --> Controller Class Initialized
DEBUG - 2017-05-01 08:02:48 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 08:02:48 --> Model Class Initialized
DEBUG - 2017-05-01 08:02:48 --> Pagination Class Initialized
INFO - 2017-05-01 08:02:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-01 08:02:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-01 08:02:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-01 08:02:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-01 08:02:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 08:02:49 --> Final output sent to browser
DEBUG - 2017-05-01 08:02:49 --> Total execution time: 0.2302
INFO - 2017-05-01 08:03:12 --> Config Class Initialized
INFO - 2017-05-01 08:03:12 --> Hooks Class Initialized
DEBUG - 2017-05-01 08:03:12 --> UTF-8 Support Enabled
INFO - 2017-05-01 08:03:12 --> Utf8 Class Initialized
INFO - 2017-05-01 08:03:12 --> URI Class Initialized
INFO - 2017-05-01 08:03:12 --> Router Class Initialized
INFO - 2017-05-01 08:03:12 --> Output Class Initialized
INFO - 2017-05-01 08:03:12 --> Security Class Initialized
DEBUG - 2017-05-01 08:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 08:03:12 --> Input Class Initialized
INFO - 2017-05-01 08:03:12 --> Language Class Initialized
INFO - 2017-05-01 08:03:12 --> Loader Class Initialized
INFO - 2017-05-01 08:03:12 --> Helper loaded: url_helper
INFO - 2017-05-01 08:03:12 --> Helper loaded: form_helper
INFO - 2017-05-01 08:03:12 --> Helper loaded: html_helper
INFO - 2017-05-01 08:03:12 --> Helper loaded: custom_helper
INFO - 2017-05-01 08:03:12 --> Helper loaded: cache_helper
INFO - 2017-05-01 08:03:12 --> Database Driver Class Initialized
INFO - 2017-05-01 08:03:12 --> Parser Class Initialized
DEBUG - 2017-05-01 08:03:12 --> Session Class Initialized
INFO - 2017-05-01 08:03:12 --> Helper loaded: string_helper
DEBUG - 2017-05-01 08:03:12 --> Session routines successfully run
INFO - 2017-05-01 08:03:12 --> Form Validation Class Initialized
INFO - 2017-05-01 08:03:12 --> Controller Class Initialized
DEBUG - 2017-05-01 08:03:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 08:03:12 --> Model Class Initialized
DEBUG - 2017-05-01 08:03:12 --> Pagination Class Initialized
INFO - 2017-05-01 08:03:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-01 08:03:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-01 08:03:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-01 08:03:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-01 08:03:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 08:03:12 --> Final output sent to browser
DEBUG - 2017-05-01 08:03:12 --> Total execution time: 0.2501
INFO - 2017-05-01 08:59:10 --> Config Class Initialized
INFO - 2017-05-01 08:59:10 --> Hooks Class Initialized
DEBUG - 2017-05-01 08:59:10 --> UTF-8 Support Enabled
INFO - 2017-05-01 08:59:10 --> Utf8 Class Initialized
INFO - 2017-05-01 08:59:10 --> URI Class Initialized
INFO - 2017-05-01 08:59:10 --> Router Class Initialized
INFO - 2017-05-01 08:59:10 --> Output Class Initialized
INFO - 2017-05-01 08:59:10 --> Security Class Initialized
DEBUG - 2017-05-01 08:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 08:59:10 --> Input Class Initialized
INFO - 2017-05-01 08:59:10 --> Language Class Initialized
INFO - 2017-05-01 08:59:10 --> Loader Class Initialized
INFO - 2017-05-01 08:59:10 --> Helper loaded: url_helper
INFO - 2017-05-01 08:59:10 --> Helper loaded: form_helper
INFO - 2017-05-01 08:59:10 --> Helper loaded: html_helper
INFO - 2017-05-01 08:59:10 --> Helper loaded: custom_helper
INFO - 2017-05-01 08:59:10 --> Helper loaded: cache_helper
INFO - 2017-05-01 08:59:10 --> Database Driver Class Initialized
INFO - 2017-05-01 08:59:10 --> Parser Class Initialized
DEBUG - 2017-05-01 08:59:10 --> Session Class Initialized
INFO - 2017-05-01 08:59:10 --> Helper loaded: string_helper
DEBUG - 2017-05-01 08:59:10 --> Session routines successfully run
INFO - 2017-05-01 08:59:10 --> Form Validation Class Initialized
INFO - 2017-05-01 08:59:10 --> Controller Class Initialized
DEBUG - 2017-05-01 08:59:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-01 08:59:10 --> Model Class Initialized
DEBUG - 2017-05-01 08:59:10 --> Pagination Class Initialized
INFO - 2017-05-01 08:59:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-01 08:59:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-01 08:59:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/ajax_api_company.php
INFO - 2017-05-01 08:59:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-01 08:59:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 08:59:11 --> Final output sent to browser
DEBUG - 2017-05-01 08:59:11 --> Total execution time: 0.6726
INFO - 2017-05-01 09:18:35 --> Config Class Initialized
INFO - 2017-05-01 09:18:35 --> Hooks Class Initialized
DEBUG - 2017-05-01 09:18:35 --> UTF-8 Support Enabled
INFO - 2017-05-01 09:18:35 --> Utf8 Class Initialized
INFO - 2017-05-01 09:18:35 --> URI Class Initialized
INFO - 2017-05-01 09:18:35 --> Router Class Initialized
INFO - 2017-05-01 09:18:35 --> Output Class Initialized
INFO - 2017-05-01 09:18:35 --> Security Class Initialized
DEBUG - 2017-05-01 09:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 09:18:35 --> Input Class Initialized
INFO - 2017-05-01 09:18:35 --> Language Class Initialized
INFO - 2017-05-01 09:18:35 --> Loader Class Initialized
INFO - 2017-05-01 09:18:35 --> Helper loaded: url_helper
INFO - 2017-05-01 09:18:35 --> Helper loaded: form_helper
INFO - 2017-05-01 09:18:35 --> Helper loaded: html_helper
INFO - 2017-05-01 09:18:35 --> Helper loaded: custom_helper
INFO - 2017-05-01 09:18:35 --> Helper loaded: cache_helper
INFO - 2017-05-01 09:18:35 --> Database Driver Class Initialized
INFO - 2017-05-01 09:18:35 --> Parser Class Initialized
DEBUG - 2017-05-01 09:18:35 --> Session Class Initialized
INFO - 2017-05-01 09:18:35 --> Helper loaded: string_helper
DEBUG - 2017-05-01 09:18:35 --> Session routines successfully run
INFO - 2017-05-01 09:18:35 --> Form Validation Class Initialized
INFO - 2017-05-01 09:18:35 --> Controller Class Initialized
INFO - 2017-05-01 09:18:35 --> Model Class Initialized
INFO - 2017-05-01 09:18:35 --> Config Class Initialized
INFO - 2017-05-01 09:18:35 --> Hooks Class Initialized
DEBUG - 2017-05-01 09:18:35 --> UTF-8 Support Enabled
INFO - 2017-05-01 09:18:35 --> Utf8 Class Initialized
INFO - 2017-05-01 09:18:35 --> URI Class Initialized
INFO - 2017-05-01 09:18:35 --> Router Class Initialized
INFO - 2017-05-01 09:18:35 --> Output Class Initialized
INFO - 2017-05-01 09:18:35 --> Security Class Initialized
DEBUG - 2017-05-01 09:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-01 09:18:35 --> Input Class Initialized
INFO - 2017-05-01 09:18:35 --> Language Class Initialized
INFO - 2017-05-01 09:18:35 --> Loader Class Initialized
INFO - 2017-05-01 09:18:35 --> Helper loaded: url_helper
INFO - 2017-05-01 09:18:35 --> Helper loaded: form_helper
INFO - 2017-05-01 09:18:35 --> Helper loaded: html_helper
INFO - 2017-05-01 09:18:35 --> Helper loaded: custom_helper
INFO - 2017-05-01 09:18:35 --> Helper loaded: cache_helper
INFO - 2017-05-01 09:18:35 --> Database Driver Class Initialized
INFO - 2017-05-01 09:18:35 --> Parser Class Initialized
DEBUG - 2017-05-01 09:18:35 --> Session Class Initialized
INFO - 2017-05-01 09:18:35 --> Helper loaded: string_helper
ERROR - 2017-05-01 09:18:35 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-01 09:18:35 --> Session routines successfully run
INFO - 2017-05-01 09:18:36 --> Form Validation Class Initialized
INFO - 2017-05-01 09:18:36 --> Controller Class Initialized
INFO - 2017-05-01 09:18:36 --> Model Class Initialized
INFO - 2017-05-01 09:18:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-01 09:18:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-01 09:18:36 --> Final output sent to browser
DEBUG - 2017-05-01 09:18:36 --> Total execution time: 0.2160
