<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-05-12 08:54:58 --> Config Class Initialized
INFO - 2017-05-12 08:54:58 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:54:58 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:54:58 --> Utf8 Class Initialized
INFO - 2017-05-12 08:54:58 --> URI Class Initialized
DEBUG - 2017-05-12 08:54:58 --> No URI present. Default controller set.
INFO - 2017-05-12 08:54:58 --> Router Class Initialized
INFO - 2017-05-12 08:54:58 --> Output Class Initialized
INFO - 2017-05-12 08:54:58 --> Security Class Initialized
DEBUG - 2017-05-12 08:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:54:58 --> Input Class Initialized
INFO - 2017-05-12 08:54:58 --> Language Class Initialized
INFO - 2017-05-12 08:54:58 --> Loader Class Initialized
INFO - 2017-05-12 08:54:58 --> Helper loaded: url_helper
INFO - 2017-05-12 08:54:58 --> Helper loaded: form_helper
INFO - 2017-05-12 08:54:58 --> Helper loaded: html_helper
INFO - 2017-05-12 08:54:58 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:54:58 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:54:58 --> Database Driver Class Initialized
INFO - 2017-05-12 08:54:58 --> Parser Class Initialized
DEBUG - 2017-05-12 08:54:58 --> Session Class Initialized
INFO - 2017-05-12 08:54:58 --> Helper loaded: string_helper
ERROR - 2017-05-12 08:54:58 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-12 08:54:58 --> Session routines successfully run
INFO - 2017-05-12 08:54:58 --> Form Validation Class Initialized
INFO - 2017-05-12 08:54:58 --> Controller Class Initialized
INFO - 2017-05-12 08:54:58 --> Model Class Initialized
INFO - 2017-05-12 08:54:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-12 08:54:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 08:54:59 --> Final output sent to browser
DEBUG - 2017-05-12 08:54:59 --> Total execution time: 1.0014
INFO - 2017-05-12 08:55:03 --> Config Class Initialized
INFO - 2017-05-12 08:55:03 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:55:03 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:55:03 --> Utf8 Class Initialized
INFO - 2017-05-12 08:55:03 --> URI Class Initialized
DEBUG - 2017-05-12 08:55:03 --> No URI present. Default controller set.
INFO - 2017-05-12 08:55:03 --> Router Class Initialized
INFO - 2017-05-12 08:55:03 --> Output Class Initialized
INFO - 2017-05-12 08:55:03 --> Security Class Initialized
DEBUG - 2017-05-12 08:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:55:03 --> Input Class Initialized
INFO - 2017-05-12 08:55:03 --> Language Class Initialized
INFO - 2017-05-12 08:55:03 --> Loader Class Initialized
INFO - 2017-05-12 08:55:03 --> Helper loaded: url_helper
INFO - 2017-05-12 08:55:03 --> Helper loaded: form_helper
INFO - 2017-05-12 08:55:03 --> Helper loaded: html_helper
INFO - 2017-05-12 08:55:03 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:55:03 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:55:03 --> Database Driver Class Initialized
INFO - 2017-05-12 08:55:03 --> Parser Class Initialized
DEBUG - 2017-05-12 08:55:03 --> Session Class Initialized
INFO - 2017-05-12 08:55:03 --> Helper loaded: string_helper
ERROR - 2017-05-12 08:55:03 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-12 08:55:03 --> Session routines successfully run
INFO - 2017-05-12 08:55:03 --> Form Validation Class Initialized
INFO - 2017-05-12 08:55:03 --> Controller Class Initialized
INFO - 2017-05-12 08:55:03 --> Model Class Initialized
INFO - 2017-05-12 08:55:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-12 08:55:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 08:55:03 --> Final output sent to browser
DEBUG - 2017-05-12 08:55:03 --> Total execution time: 0.1656
INFO - 2017-05-12 08:56:53 --> Config Class Initialized
INFO - 2017-05-12 08:56:53 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:56:53 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:56:53 --> Utf8 Class Initialized
INFO - 2017-05-12 08:56:53 --> URI Class Initialized
INFO - 2017-05-12 08:56:53 --> Router Class Initialized
INFO - 2017-05-12 08:56:53 --> Output Class Initialized
INFO - 2017-05-12 08:56:53 --> Security Class Initialized
DEBUG - 2017-05-12 08:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:56:53 --> Input Class Initialized
INFO - 2017-05-12 08:56:53 --> Language Class Initialized
INFO - 2017-05-12 08:56:53 --> Loader Class Initialized
INFO - 2017-05-12 08:56:53 --> Helper loaded: url_helper
INFO - 2017-05-12 08:56:53 --> Helper loaded: form_helper
INFO - 2017-05-12 08:56:53 --> Helper loaded: html_helper
INFO - 2017-05-12 08:56:53 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:56:53 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:56:53 --> Database Driver Class Initialized
INFO - 2017-05-12 08:56:53 --> Parser Class Initialized
DEBUG - 2017-05-12 08:56:53 --> Session Class Initialized
INFO - 2017-05-12 08:56:53 --> Helper loaded: string_helper
ERROR - 2017-05-12 08:56:53 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-12 08:56:53 --> Session routines successfully run
INFO - 2017-05-12 08:56:53 --> Form Validation Class Initialized
INFO - 2017-05-12 08:56:53 --> Controller Class Initialized
INFO - 2017-05-12 08:56:53 --> Model Class Initialized
INFO - 2017-05-12 08:56:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 08:56:59 --> Config Class Initialized
INFO - 2017-05-12 08:56:59 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:56:59 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:56:59 --> Utf8 Class Initialized
INFO - 2017-05-12 08:56:59 --> URI Class Initialized
INFO - 2017-05-12 08:56:59 --> Router Class Initialized
INFO - 2017-05-12 08:56:59 --> Output Class Initialized
INFO - 2017-05-12 08:56:59 --> Security Class Initialized
DEBUG - 2017-05-12 08:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:56:59 --> Input Class Initialized
INFO - 2017-05-12 08:56:59 --> Language Class Initialized
INFO - 2017-05-12 08:56:59 --> Loader Class Initialized
INFO - 2017-05-12 08:56:59 --> Helper loaded: url_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: form_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: html_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:56:59 --> Database Driver Class Initialized
INFO - 2017-05-12 08:56:59 --> Parser Class Initialized
DEBUG - 2017-05-12 08:56:59 --> Session Class Initialized
INFO - 2017-05-12 08:56:59 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:56:59 --> Session routines successfully run
INFO - 2017-05-12 08:56:59 --> Form Validation Class Initialized
INFO - 2017-05-12 08:56:59 --> Controller Class Initialized
INFO - 2017-05-12 08:56:59 --> Model Class Initialized
INFO - 2017-05-12 08:56:59 --> Config Class Initialized
INFO - 2017-05-12 08:56:59 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:56:59 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:56:59 --> Utf8 Class Initialized
INFO - 2017-05-12 08:56:59 --> URI Class Initialized
INFO - 2017-05-12 08:56:59 --> Router Class Initialized
INFO - 2017-05-12 08:56:59 --> Output Class Initialized
INFO - 2017-05-12 08:56:59 --> Security Class Initialized
DEBUG - 2017-05-12 08:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:56:59 --> Input Class Initialized
INFO - 2017-05-12 08:56:59 --> Language Class Initialized
INFO - 2017-05-12 08:56:59 --> Loader Class Initialized
INFO - 2017-05-12 08:56:59 --> Helper loaded: url_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: form_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: html_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:56:59 --> Database Driver Class Initialized
INFO - 2017-05-12 08:56:59 --> Parser Class Initialized
DEBUG - 2017-05-12 08:56:59 --> Session Class Initialized
INFO - 2017-05-12 08:56:59 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:56:59 --> Session routines successfully run
INFO - 2017-05-12 08:56:59 --> Form Validation Class Initialized
INFO - 2017-05-12 08:56:59 --> Controller Class Initialized
INFO - 2017-05-12 08:56:59 --> Model Class Initialized
INFO - 2017-05-12 08:56:59 --> Config Class Initialized
INFO - 2017-05-12 08:56:59 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:56:59 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:56:59 --> Utf8 Class Initialized
INFO - 2017-05-12 08:56:59 --> URI Class Initialized
INFO - 2017-05-12 08:56:59 --> Router Class Initialized
INFO - 2017-05-12 08:56:59 --> Output Class Initialized
INFO - 2017-05-12 08:56:59 --> Security Class Initialized
DEBUG - 2017-05-12 08:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:56:59 --> Input Class Initialized
INFO - 2017-05-12 08:56:59 --> Language Class Initialized
INFO - 2017-05-12 08:56:59 --> Loader Class Initialized
INFO - 2017-05-12 08:56:59 --> Helper loaded: url_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: form_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: html_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:56:59 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:56:59 --> Database Driver Class Initialized
INFO - 2017-05-12 08:56:59 --> Parser Class Initialized
DEBUG - 2017-05-12 08:56:59 --> Session Class Initialized
INFO - 2017-05-12 08:56:59 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:56:59 --> Session routines successfully run
INFO - 2017-05-12 08:56:59 --> Form Validation Class Initialized
INFO - 2017-05-12 08:56:59 --> Controller Class Initialized
DEBUG - 2017-05-12 08:56:59 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:56:59 --> Model Class Initialized
DEBUG - 2017-05-12 08:57:00 --> Pagination Class Initialized
INFO - 2017-05-12 08:57:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 08:57:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 08:57:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-05-12 08:57:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 08:57:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 08:57:00 --> Final output sent to browser
DEBUG - 2017-05-12 08:57:00 --> Total execution time: 0.4758
INFO - 2017-05-12 08:57:45 --> Config Class Initialized
INFO - 2017-05-12 08:57:45 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:57:45 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:57:45 --> Utf8 Class Initialized
INFO - 2017-05-12 08:57:45 --> URI Class Initialized
INFO - 2017-05-12 08:57:45 --> Router Class Initialized
INFO - 2017-05-12 08:57:45 --> Output Class Initialized
INFO - 2017-05-12 08:57:45 --> Security Class Initialized
DEBUG - 2017-05-12 08:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:57:45 --> Input Class Initialized
INFO - 2017-05-12 08:57:45 --> Language Class Initialized
INFO - 2017-05-12 08:57:45 --> Loader Class Initialized
INFO - 2017-05-12 08:57:45 --> Helper loaded: url_helper
INFO - 2017-05-12 08:57:45 --> Helper loaded: form_helper
INFO - 2017-05-12 08:57:45 --> Helper loaded: html_helper
INFO - 2017-05-12 08:57:45 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:57:45 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:57:45 --> Database Driver Class Initialized
INFO - 2017-05-12 08:57:45 --> Parser Class Initialized
DEBUG - 2017-05-12 08:57:45 --> Session Class Initialized
INFO - 2017-05-12 08:57:45 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:57:45 --> Session routines successfully run
INFO - 2017-05-12 08:57:45 --> Form Validation Class Initialized
INFO - 2017-05-12 08:57:45 --> Controller Class Initialized
INFO - 2017-05-12 08:57:45 --> Model Class Initialized
INFO - 2017-05-12 08:57:45 --> Config Class Initialized
INFO - 2017-05-12 08:57:45 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:57:45 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:57:45 --> Utf8 Class Initialized
INFO - 2017-05-12 08:57:45 --> URI Class Initialized
INFO - 2017-05-12 08:57:46 --> Router Class Initialized
INFO - 2017-05-12 08:57:46 --> Output Class Initialized
INFO - 2017-05-12 08:57:46 --> Security Class Initialized
DEBUG - 2017-05-12 08:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:57:46 --> Input Class Initialized
INFO - 2017-05-12 08:57:46 --> Language Class Initialized
INFO - 2017-05-12 08:57:46 --> Loader Class Initialized
INFO - 2017-05-12 08:57:46 --> Helper loaded: url_helper
INFO - 2017-05-12 08:57:46 --> Helper loaded: form_helper
INFO - 2017-05-12 08:57:46 --> Helper loaded: html_helper
INFO - 2017-05-12 08:57:46 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:57:46 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:57:46 --> Database Driver Class Initialized
INFO - 2017-05-12 08:57:46 --> Parser Class Initialized
DEBUG - 2017-05-12 08:57:46 --> Session Class Initialized
INFO - 2017-05-12 08:57:46 --> Helper loaded: string_helper
ERROR - 2017-05-12 08:57:46 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-12 08:57:46 --> Session routines successfully run
INFO - 2017-05-12 08:57:46 --> Form Validation Class Initialized
INFO - 2017-05-12 08:57:46 --> Controller Class Initialized
INFO - 2017-05-12 08:57:46 --> Model Class Initialized
INFO - 2017-05-12 08:57:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-12 08:57:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 08:57:46 --> Final output sent to browser
DEBUG - 2017-05-12 08:57:46 --> Total execution time: 0.2227
INFO - 2017-05-12 08:58:02 --> Config Class Initialized
INFO - 2017-05-12 08:58:02 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:58:02 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:58:02 --> Utf8 Class Initialized
INFO - 2017-05-12 08:58:02 --> URI Class Initialized
INFO - 2017-05-12 08:58:02 --> Router Class Initialized
INFO - 2017-05-12 08:58:02 --> Output Class Initialized
INFO - 2017-05-12 08:58:02 --> Security Class Initialized
DEBUG - 2017-05-12 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:58:02 --> Input Class Initialized
INFO - 2017-05-12 08:58:02 --> Language Class Initialized
INFO - 2017-05-12 08:58:02 --> Loader Class Initialized
INFO - 2017-05-12 08:58:02 --> Helper loaded: url_helper
INFO - 2017-05-12 08:58:02 --> Helper loaded: form_helper
INFO - 2017-05-12 08:58:02 --> Helper loaded: html_helper
INFO - 2017-05-12 08:58:02 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:58:02 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:58:02 --> Database Driver Class Initialized
INFO - 2017-05-12 08:58:02 --> Parser Class Initialized
DEBUG - 2017-05-12 08:58:02 --> Session Class Initialized
INFO - 2017-05-12 08:58:02 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:58:02 --> Session routines successfully run
INFO - 2017-05-12 08:58:02 --> Form Validation Class Initialized
INFO - 2017-05-12 08:58:02 --> Controller Class Initialized
INFO - 2017-05-12 08:58:02 --> Model Class Initialized
INFO - 2017-05-12 08:58:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 08:58:02 --> Config Class Initialized
INFO - 2017-05-12 08:58:02 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:58:02 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:58:02 --> Utf8 Class Initialized
INFO - 2017-05-12 08:58:02 --> URI Class Initialized
INFO - 2017-05-12 08:58:02 --> Router Class Initialized
INFO - 2017-05-12 08:58:02 --> Output Class Initialized
INFO - 2017-05-12 08:58:02 --> Security Class Initialized
DEBUG - 2017-05-12 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:58:02 --> Input Class Initialized
INFO - 2017-05-12 08:58:02 --> Language Class Initialized
INFO - 2017-05-12 08:58:02 --> Loader Class Initialized
INFO - 2017-05-12 08:58:02 --> Helper loaded: url_helper
INFO - 2017-05-12 08:58:02 --> Helper loaded: form_helper
INFO - 2017-05-12 08:58:02 --> Helper loaded: html_helper
INFO - 2017-05-12 08:58:02 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:58:02 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:58:02 --> Database Driver Class Initialized
INFO - 2017-05-12 08:58:02 --> Parser Class Initialized
DEBUG - 2017-05-12 08:58:02 --> Session Class Initialized
INFO - 2017-05-12 08:58:02 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:58:02 --> Session routines successfully run
INFO - 2017-05-12 08:58:02 --> Form Validation Class Initialized
INFO - 2017-05-12 08:58:02 --> Controller Class Initialized
DEBUG - 2017-05-12 08:58:02 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:58:02 --> Model Class Initialized
DEBUG - 2017-05-12 08:58:02 --> Pagination Class Initialized
INFO - 2017-05-12 08:58:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 08:58:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 08:58:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-05-12 08:58:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 08:58:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 08:58:02 --> Final output sent to browser
DEBUG - 2017-05-12 08:58:02 --> Total execution time: 0.2562
INFO - 2017-05-12 08:58:15 --> Config Class Initialized
INFO - 2017-05-12 08:58:15 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:58:15 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:58:15 --> Utf8 Class Initialized
INFO - 2017-05-12 08:58:15 --> URI Class Initialized
INFO - 2017-05-12 08:58:15 --> Router Class Initialized
INFO - 2017-05-12 08:58:15 --> Output Class Initialized
INFO - 2017-05-12 08:58:15 --> Security Class Initialized
DEBUG - 2017-05-12 08:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:58:15 --> Input Class Initialized
INFO - 2017-05-12 08:58:15 --> Language Class Initialized
INFO - 2017-05-12 08:58:15 --> Loader Class Initialized
INFO - 2017-05-12 08:58:15 --> Helper loaded: url_helper
INFO - 2017-05-12 08:58:15 --> Helper loaded: form_helper
INFO - 2017-05-12 08:58:15 --> Helper loaded: html_helper
INFO - 2017-05-12 08:58:15 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:58:15 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:58:15 --> Database Driver Class Initialized
INFO - 2017-05-12 08:58:15 --> Parser Class Initialized
DEBUG - 2017-05-12 08:58:15 --> Session Class Initialized
INFO - 2017-05-12 08:58:15 --> Helper loaded: string_helper
ERROR - 2017-05-12 08:58:16 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-12 08:58:16 --> Session routines successfully run
INFO - 2017-05-12 08:58:16 --> Form Validation Class Initialized
INFO - 2017-05-12 08:58:16 --> Controller Class Initialized
INFO - 2017-05-12 08:58:16 --> Model Class Initialized
INFO - 2017-05-12 08:58:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 08:58:16 --> Config Class Initialized
INFO - 2017-05-12 08:58:16 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:58:16 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:58:16 --> Utf8 Class Initialized
INFO - 2017-05-12 08:58:16 --> URI Class Initialized
INFO - 2017-05-12 08:58:16 --> Router Class Initialized
INFO - 2017-05-12 08:58:16 --> Output Class Initialized
INFO - 2017-05-12 08:58:16 --> Security Class Initialized
DEBUG - 2017-05-12 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:58:16 --> Input Class Initialized
INFO - 2017-05-12 08:58:16 --> Language Class Initialized
INFO - 2017-05-12 08:58:16 --> Loader Class Initialized
INFO - 2017-05-12 08:58:16 --> Helper loaded: url_helper
INFO - 2017-05-12 08:58:16 --> Helper loaded: form_helper
INFO - 2017-05-12 08:58:16 --> Helper loaded: html_helper
INFO - 2017-05-12 08:58:16 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:58:16 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:58:16 --> Database Driver Class Initialized
INFO - 2017-05-12 08:58:16 --> Parser Class Initialized
DEBUG - 2017-05-12 08:58:16 --> Session Class Initialized
INFO - 2017-05-12 08:58:16 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:58:16 --> Session routines successfully run
INFO - 2017-05-12 08:58:16 --> Form Validation Class Initialized
INFO - 2017-05-12 08:58:16 --> Controller Class Initialized
DEBUG - 2017-05-12 08:58:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:58:16 --> Model Class Initialized
DEBUG - 2017-05-12 08:58:16 --> Pagination Class Initialized
INFO - 2017-05-12 08:58:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 08:58:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 08:58:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-05-12 08:58:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 08:58:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 08:58:16 --> Final output sent to browser
DEBUG - 2017-05-12 08:58:16 --> Total execution time: 0.2117
INFO - 2017-05-12 08:58:40 --> Config Class Initialized
INFO - 2017-05-12 08:58:40 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:58:40 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:58:40 --> Utf8 Class Initialized
INFO - 2017-05-12 08:58:40 --> URI Class Initialized
INFO - 2017-05-12 08:58:40 --> Router Class Initialized
INFO - 2017-05-12 08:58:40 --> Output Class Initialized
INFO - 2017-05-12 08:58:40 --> Security Class Initialized
DEBUG - 2017-05-12 08:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:58:40 --> Input Class Initialized
INFO - 2017-05-12 08:58:40 --> Language Class Initialized
INFO - 2017-05-12 08:58:40 --> Loader Class Initialized
INFO - 2017-05-12 08:58:40 --> Helper loaded: url_helper
INFO - 2017-05-12 08:58:40 --> Helper loaded: form_helper
INFO - 2017-05-12 08:58:40 --> Helper loaded: html_helper
INFO - 2017-05-12 08:58:40 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:58:40 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:58:40 --> Database Driver Class Initialized
INFO - 2017-05-12 08:58:40 --> Parser Class Initialized
DEBUG - 2017-05-12 08:58:40 --> Session Class Initialized
INFO - 2017-05-12 08:58:40 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:58:40 --> Session routines successfully run
INFO - 2017-05-12 08:58:40 --> Form Validation Class Initialized
INFO - 2017-05-12 08:58:40 --> Controller Class Initialized
DEBUG - 2017-05-12 08:58:40 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:58:40 --> Model Class Initialized
DEBUG - 2017-05-12 08:58:40 --> Pagination Class Initialized
INFO - 2017-05-12 08:58:40 --> Config Class Initialized
INFO - 2017-05-12 08:58:40 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:58:40 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:58:40 --> Utf8 Class Initialized
INFO - 2017-05-12 08:58:40 --> URI Class Initialized
INFO - 2017-05-12 08:58:40 --> Router Class Initialized
INFO - 2017-05-12 08:58:40 --> Output Class Initialized
INFO - 2017-05-12 08:58:40 --> Security Class Initialized
DEBUG - 2017-05-12 08:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:58:40 --> Input Class Initialized
INFO - 2017-05-12 08:58:40 --> Language Class Initialized
INFO - 2017-05-12 08:58:40 --> Loader Class Initialized
INFO - 2017-05-12 08:58:40 --> Helper loaded: url_helper
INFO - 2017-05-12 08:58:40 --> Helper loaded: form_helper
INFO - 2017-05-12 08:58:40 --> Helper loaded: html_helper
INFO - 2017-05-12 08:58:40 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:58:40 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:58:40 --> Database Driver Class Initialized
INFO - 2017-05-12 08:58:41 --> Parser Class Initialized
DEBUG - 2017-05-12 08:58:41 --> Session Class Initialized
INFO - 2017-05-12 08:58:41 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:58:41 --> Session routines successfully run
INFO - 2017-05-12 08:58:41 --> Form Validation Class Initialized
INFO - 2017-05-12 08:58:41 --> Controller Class Initialized
DEBUG - 2017-05-12 08:58:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:58:41 --> Model Class Initialized
DEBUG - 2017-05-12 08:58:41 --> Pagination Class Initialized
INFO - 2017-05-12 08:58:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 08:58:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 08:58:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 08:58:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 08:58:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 08:58:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 08:58:49 --> Final output sent to browser
DEBUG - 2017-05-12 08:58:49 --> Total execution time: 8.1262
INFO - 2017-05-12 08:58:55 --> Config Class Initialized
INFO - 2017-05-12 08:58:56 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:58:56 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:58:56 --> Utf8 Class Initialized
INFO - 2017-05-12 08:58:56 --> URI Class Initialized
INFO - 2017-05-12 08:58:56 --> Router Class Initialized
INFO - 2017-05-12 08:58:56 --> Output Class Initialized
INFO - 2017-05-12 08:58:56 --> Security Class Initialized
DEBUG - 2017-05-12 08:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:58:56 --> Input Class Initialized
INFO - 2017-05-12 08:58:56 --> Language Class Initialized
INFO - 2017-05-12 08:58:56 --> Loader Class Initialized
INFO - 2017-05-12 08:58:56 --> Helper loaded: url_helper
INFO - 2017-05-12 08:58:56 --> Helper loaded: form_helper
INFO - 2017-05-12 08:58:56 --> Helper loaded: html_helper
INFO - 2017-05-12 08:58:56 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:58:56 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:58:56 --> Database Driver Class Initialized
INFO - 2017-05-12 08:58:56 --> Parser Class Initialized
DEBUG - 2017-05-12 08:58:56 --> Session Class Initialized
INFO - 2017-05-12 08:58:56 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:58:56 --> Session routines successfully run
INFO - 2017-05-12 08:58:56 --> Form Validation Class Initialized
INFO - 2017-05-12 08:58:56 --> Controller Class Initialized
DEBUG - 2017-05-12 08:58:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:58:56 --> Model Class Initialized
DEBUG - 2017-05-12 08:58:56 --> Pagination Class Initialized
INFO - 2017-05-12 08:58:56 --> Config Class Initialized
INFO - 2017-05-12 08:58:56 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:58:56 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:58:56 --> Utf8 Class Initialized
INFO - 2017-05-12 08:58:56 --> URI Class Initialized
INFO - 2017-05-12 08:58:56 --> Router Class Initialized
INFO - 2017-05-12 08:58:56 --> Output Class Initialized
INFO - 2017-05-12 08:58:56 --> Security Class Initialized
DEBUG - 2017-05-12 08:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:58:56 --> Input Class Initialized
INFO - 2017-05-12 08:58:56 --> Language Class Initialized
INFO - 2017-05-12 08:58:56 --> Loader Class Initialized
INFO - 2017-05-12 08:58:56 --> Helper loaded: url_helper
INFO - 2017-05-12 08:58:56 --> Helper loaded: form_helper
INFO - 2017-05-12 08:58:56 --> Helper loaded: html_helper
INFO - 2017-05-12 08:58:56 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:58:56 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:58:56 --> Database Driver Class Initialized
INFO - 2017-05-12 08:58:56 --> Parser Class Initialized
DEBUG - 2017-05-12 08:58:56 --> Session Class Initialized
INFO - 2017-05-12 08:58:56 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:58:56 --> Session routines successfully run
INFO - 2017-05-12 08:58:56 --> Form Validation Class Initialized
INFO - 2017-05-12 08:58:56 --> Controller Class Initialized
DEBUG - 2017-05-12 08:58:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:58:56 --> Model Class Initialized
DEBUG - 2017-05-12 08:58:56 --> Pagination Class Initialized
INFO - 2017-05-12 08:58:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 08:58:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 08:58:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 08:58:58 --> Config Class Initialized
INFO - 2017-05-12 08:58:58 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:58:58 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:58:58 --> Utf8 Class Initialized
INFO - 2017-05-12 08:58:58 --> URI Class Initialized
INFO - 2017-05-12 08:58:58 --> Router Class Initialized
INFO - 2017-05-12 08:58:58 --> Output Class Initialized
INFO - 2017-05-12 08:58:58 --> Security Class Initialized
DEBUG - 2017-05-12 08:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:58:59 --> Input Class Initialized
INFO - 2017-05-12 08:58:59 --> Language Class Initialized
INFO - 2017-05-12 08:58:59 --> Loader Class Initialized
INFO - 2017-05-12 08:58:59 --> Helper loaded: url_helper
INFO - 2017-05-12 08:58:59 --> Helper loaded: form_helper
INFO - 2017-05-12 08:58:59 --> Helper loaded: html_helper
INFO - 2017-05-12 08:58:59 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:58:59 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:58:59 --> Database Driver Class Initialized
INFO - 2017-05-12 08:58:59 --> Parser Class Initialized
DEBUG - 2017-05-12 08:58:59 --> Session Class Initialized
INFO - 2017-05-12 08:58:59 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:58:59 --> Session routines successfully run
INFO - 2017-05-12 08:58:59 --> Form Validation Class Initialized
INFO - 2017-05-12 08:58:59 --> Controller Class Initialized
DEBUG - 2017-05-12 08:58:59 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:58:59 --> Model Class Initialized
DEBUG - 2017-05-12 08:58:59 --> Pagination Class Initialized
DEBUG - 2017-05-12 08:58:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 08:58:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 08:58:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 08:58:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 08:58:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 08:58:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 08:58:59 --> Final output sent to browser
DEBUG - 2017-05-12 08:58:59 --> Total execution time: 0.5016
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
INFO - 2017-05-12 08:58:59 --> Config Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 08:58:59 --> Hooks Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
DEBUG - 2017-05-12 08:58:59 --> UTF-8 Support Enabled
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
INFO - 2017-05-12 08:58:59 --> Utf8 Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
INFO - 2017-05-12 08:58:59 --> URI Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
INFO - 2017-05-12 08:58:59 --> Router Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 08:58:59 --> Output Class Initialized
INFO - 2017-05-12 08:58:59 --> Config Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
INFO - 2017-05-12 08:58:59 --> Hooks Class Initialized
INFO - 2017-05-12 08:58:59 --> Security Class Initialized
DEBUG - 2017-05-12 08:58:59 --> UTF-8 Support Enabled
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
DEBUG - 2017-05-12 08:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:58:59 --> Utf8 Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
INFO - 2017-05-12 08:58:59 --> Input Class Initialized
INFO - 2017-05-12 08:58:59 --> URI Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
INFO - 2017-05-12 08:58:59 --> Language Class Initialized
INFO - 2017-05-12 08:58:59 --> Router Class Initialized
ERROR - 2017-05-12 08:58:59 --> 404 Page Not Found: Default/assets
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 08:58:59 --> Output Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
INFO - 2017-05-12 08:58:59 --> Security Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
DEBUG - 2017-05-12 08:58:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
INFO - 2017-05-12 08:58:59 --> Input Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
INFO - 2017-05-12 08:58:59 --> Language Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:59 --> 404 Page Not Found: Default/assets
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
INFO - 2017-05-12 08:58:59 --> Config Class Initialized
INFO - 2017-05-12 08:58:59 --> Hooks Class Initialized
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
DEBUG - 2017-05-12 08:58:59 --> UTF-8 Support Enabled
ERROR - 2017-05-12 08:58:59 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 08:58:59 --> Utf8 Class Initialized
INFO - 2017-05-12 08:58:59 --> URI Class Initialized
INFO - 2017-05-12 08:58:59 --> Router Class Initialized
INFO - 2017-05-12 08:58:59 --> Output Class Initialized
INFO - 2017-05-12 08:58:59 --> Security Class Initialized
DEBUG - 2017-05-12 08:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:58:59 --> Input Class Initialized
INFO - 2017-05-12 08:58:59 --> Language Class Initialized
INFO - 2017-05-12 08:58:59 --> Loader Class Initialized
INFO - 2017-05-12 08:58:59 --> Helper loaded: url_helper
INFO - 2017-05-12 08:58:59 --> Helper loaded: form_helper
INFO - 2017-05-12 08:59:00 --> Helper loaded: html_helper
INFO - 2017-05-12 08:59:00 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:59:00 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:59:00 --> Database Driver Class Initialized
INFO - 2017-05-12 08:59:00 --> Parser Class Initialized
DEBUG - 2017-05-12 08:59:00 --> Session Class Initialized
INFO - 2017-05-12 08:59:00 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:59:00 --> Session routines successfully run
INFO - 2017-05-12 08:59:00 --> Form Validation Class Initialized
INFO - 2017-05-12 08:59:00 --> Controller Class Initialized
DEBUG - 2017-05-12 08:59:00 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:59:00 --> Model Class Initialized
DEBUG - 2017-05-12 08:59:00 --> Pagination Class Initialized
ERROR - 2017-05-12 08:59:00 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2017-05-12 08:59:00 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2017-05-12 08:59:00 --> Final output sent to browser
DEBUG - 2017-05-12 08:59:00 --> Total execution time: 0.2169
ERROR - 2017-05-12 08:59:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:59:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:59:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:59:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:59:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 08:59:01 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 08:59:01 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 08:59:01 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 08:59:01 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 08:59:01 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 08:59:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 08:59:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 08:59:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 08:59:01 --> Final output sent to browser
DEBUG - 2017-05-12 08:59:01 --> Total execution time: 5.3500
INFO - 2017-05-12 08:59:11 --> Config Class Initialized
INFO - 2017-05-12 08:59:11 --> Config Class Initialized
INFO - 2017-05-12 08:59:11 --> Hooks Class Initialized
INFO - 2017-05-12 08:59:11 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:59:11 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:59:11 --> Utf8 Class Initialized
DEBUG - 2017-05-12 08:59:11 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:59:11 --> Utf8 Class Initialized
INFO - 2017-05-12 08:59:11 --> URI Class Initialized
INFO - 2017-05-12 08:59:11 --> URI Class Initialized
INFO - 2017-05-12 08:59:11 --> Router Class Initialized
INFO - 2017-05-12 08:59:11 --> Router Class Initialized
INFO - 2017-05-12 08:59:11 --> Output Class Initialized
INFO - 2017-05-12 08:59:11 --> Output Class Initialized
INFO - 2017-05-12 08:59:11 --> Security Class Initialized
INFO - 2017-05-12 08:59:11 --> Security Class Initialized
DEBUG - 2017-05-12 08:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 08:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:59:11 --> Input Class Initialized
INFO - 2017-05-12 08:59:11 --> Input Class Initialized
INFO - 2017-05-12 08:59:11 --> Language Class Initialized
INFO - 2017-05-12 08:59:11 --> Language Class Initialized
INFO - 2017-05-12 08:59:11 --> Loader Class Initialized
INFO - 2017-05-12 08:59:11 --> Loader Class Initialized
INFO - 2017-05-12 08:59:11 --> Helper loaded: url_helper
INFO - 2017-05-12 08:59:11 --> Helper loaded: url_helper
INFO - 2017-05-12 08:59:11 --> Helper loaded: form_helper
INFO - 2017-05-12 08:59:11 --> Helper loaded: form_helper
INFO - 2017-05-12 08:59:11 --> Helper loaded: html_helper
INFO - 2017-05-12 08:59:11 --> Helper loaded: html_helper
INFO - 2017-05-12 08:59:11 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:59:11 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:59:11 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:59:11 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:59:11 --> Database Driver Class Initialized
INFO - 2017-05-12 08:59:12 --> Database Driver Class Initialized
INFO - 2017-05-12 08:59:12 --> Parser Class Initialized
INFO - 2017-05-12 08:59:12 --> Parser Class Initialized
DEBUG - 2017-05-12 08:59:12 --> Session Class Initialized
DEBUG - 2017-05-12 08:59:12 --> Session Class Initialized
INFO - 2017-05-12 08:59:12 --> Helper loaded: string_helper
INFO - 2017-05-12 08:59:12 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:59:12 --> Session routines successfully run
DEBUG - 2017-05-12 08:59:12 --> Session routines successfully run
INFO - 2017-05-12 08:59:12 --> Form Validation Class Initialized
INFO - 2017-05-12 08:59:12 --> Form Validation Class Initialized
INFO - 2017-05-12 08:59:12 --> Controller Class Initialized
INFO - 2017-05-12 08:59:12 --> Controller Class Initialized
DEBUG - 2017-05-12 08:59:12 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2017-05-12 08:59:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:59:12 --> Model Class Initialized
INFO - 2017-05-12 08:59:12 --> Model Class Initialized
DEBUG - 2017-05-12 08:59:12 --> Pagination Class Initialized
DEBUG - 2017-05-12 08:59:12 --> Pagination Class Initialized
INFO - 2017-05-12 08:59:12 --> Final output sent to browser
DEBUG - 2017-05-12 08:59:12 --> Total execution time: 0.2946
INFO - 2017-05-12 08:59:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2017-05-12 08:59:12 --> Final output sent to browser
DEBUG - 2017-05-12 08:59:12 --> Total execution time: 0.3330
INFO - 2017-05-12 08:59:24 --> Config Class Initialized
INFO - 2017-05-12 08:59:24 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:59:24 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:59:24 --> Utf8 Class Initialized
INFO - 2017-05-12 08:59:24 --> URI Class Initialized
INFO - 2017-05-12 08:59:24 --> Router Class Initialized
INFO - 2017-05-12 08:59:24 --> Output Class Initialized
INFO - 2017-05-12 08:59:24 --> Security Class Initialized
DEBUG - 2017-05-12 08:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:59:24 --> Input Class Initialized
INFO - 2017-05-12 08:59:24 --> Language Class Initialized
INFO - 2017-05-12 08:59:24 --> Loader Class Initialized
INFO - 2017-05-12 08:59:24 --> Helper loaded: url_helper
INFO - 2017-05-12 08:59:24 --> Helper loaded: form_helper
INFO - 2017-05-12 08:59:24 --> Helper loaded: html_helper
INFO - 2017-05-12 08:59:24 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:59:24 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:59:24 --> Database Driver Class Initialized
INFO - 2017-05-12 08:59:24 --> Parser Class Initialized
DEBUG - 2017-05-12 08:59:24 --> Session Class Initialized
INFO - 2017-05-12 08:59:24 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:59:24 --> Session routines successfully run
INFO - 2017-05-12 08:59:24 --> Form Validation Class Initialized
INFO - 2017-05-12 08:59:24 --> Controller Class Initialized
DEBUG - 2017-05-12 08:59:24 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:59:24 --> Model Class Initialized
DEBUG - 2017-05-12 08:59:24 --> Pagination Class Initialized
INFO - 2017-05-12 08:59:24 --> Final output sent to browser
DEBUG - 2017-05-12 08:59:24 --> Total execution time: 0.1834
INFO - 2017-05-12 08:59:33 --> Config Class Initialized
INFO - 2017-05-12 08:59:33 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:59:33 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:59:33 --> Utf8 Class Initialized
INFO - 2017-05-12 08:59:33 --> URI Class Initialized
INFO - 2017-05-12 08:59:33 --> Router Class Initialized
INFO - 2017-05-12 08:59:33 --> Output Class Initialized
INFO - 2017-05-12 08:59:33 --> Security Class Initialized
DEBUG - 2017-05-12 08:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:59:33 --> Input Class Initialized
INFO - 2017-05-12 08:59:33 --> Language Class Initialized
INFO - 2017-05-12 08:59:33 --> Loader Class Initialized
INFO - 2017-05-12 08:59:33 --> Helper loaded: url_helper
INFO - 2017-05-12 08:59:33 --> Helper loaded: form_helper
INFO - 2017-05-12 08:59:33 --> Helper loaded: html_helper
INFO - 2017-05-12 08:59:33 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:59:33 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:59:33 --> Database Driver Class Initialized
INFO - 2017-05-12 08:59:33 --> Parser Class Initialized
DEBUG - 2017-05-12 08:59:33 --> Session Class Initialized
INFO - 2017-05-12 08:59:33 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:59:33 --> Session routines successfully run
INFO - 2017-05-12 08:59:33 --> Form Validation Class Initialized
INFO - 2017-05-12 08:59:33 --> Controller Class Initialized
DEBUG - 2017-05-12 08:59:33 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:59:33 --> Model Class Initialized
DEBUG - 2017-05-12 08:59:33 --> Pagination Class Initialized
DEBUG - 2017-05-12 08:59:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 08:59:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 08:59:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 08:59:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 08:59:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 08:59:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 08:59:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 08:59:33 --> Final output sent to browser
DEBUG - 2017-05-12 08:59:33 --> Total execution time: 0.3544
INFO - 2017-05-12 08:59:33 --> Config Class Initialized
INFO - 2017-05-12 08:59:33 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:59:33 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:59:33 --> Utf8 Class Initialized
INFO - 2017-05-12 08:59:33 --> URI Class Initialized
INFO - 2017-05-12 08:59:33 --> Router Class Initialized
INFO - 2017-05-12 08:59:33 --> Output Class Initialized
INFO - 2017-05-12 08:59:33 --> Security Class Initialized
DEBUG - 2017-05-12 08:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:59:33 --> Input Class Initialized
INFO - 2017-05-12 08:59:33 --> Language Class Initialized
ERROR - 2017-05-12 08:59:33 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 08:59:33 --> Config Class Initialized
INFO - 2017-05-12 08:59:33 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:59:33 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:59:33 --> Utf8 Class Initialized
INFO - 2017-05-12 08:59:33 --> URI Class Initialized
INFO - 2017-05-12 08:59:33 --> Router Class Initialized
INFO - 2017-05-12 08:59:33 --> Output Class Initialized
INFO - 2017-05-12 08:59:33 --> Security Class Initialized
DEBUG - 2017-05-12 08:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:59:33 --> Input Class Initialized
INFO - 2017-05-12 08:59:33 --> Language Class Initialized
ERROR - 2017-05-12 08:59:33 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 08:59:33 --> Config Class Initialized
INFO - 2017-05-12 08:59:33 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:59:33 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:59:33 --> Utf8 Class Initialized
INFO - 2017-05-12 08:59:33 --> URI Class Initialized
INFO - 2017-05-12 08:59:33 --> Router Class Initialized
INFO - 2017-05-12 08:59:33 --> Output Class Initialized
INFO - 2017-05-12 08:59:33 --> Security Class Initialized
DEBUG - 2017-05-12 08:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:59:33 --> Input Class Initialized
INFO - 2017-05-12 08:59:33 --> Language Class Initialized
ERROR - 2017-05-12 08:59:33 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 08:59:33 --> Config Class Initialized
INFO - 2017-05-12 08:59:33 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:59:33 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:59:33 --> Utf8 Class Initialized
INFO - 2017-05-12 08:59:33 --> URI Class Initialized
INFO - 2017-05-12 08:59:33 --> Router Class Initialized
INFO - 2017-05-12 08:59:33 --> Output Class Initialized
INFO - 2017-05-12 08:59:33 --> Security Class Initialized
DEBUG - 2017-05-12 08:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:59:33 --> Input Class Initialized
INFO - 2017-05-12 08:59:33 --> Language Class Initialized
ERROR - 2017-05-12 08:59:33 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 08:59:33 --> Config Class Initialized
INFO - 2017-05-12 08:59:33 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:59:33 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:59:33 --> Utf8 Class Initialized
INFO - 2017-05-12 08:59:33 --> URI Class Initialized
INFO - 2017-05-12 08:59:33 --> Router Class Initialized
INFO - 2017-05-12 08:59:33 --> Output Class Initialized
INFO - 2017-05-12 08:59:33 --> Security Class Initialized
DEBUG - 2017-05-12 08:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:59:33 --> Input Class Initialized
INFO - 2017-05-12 08:59:34 --> Language Class Initialized
INFO - 2017-05-12 08:59:34 --> Loader Class Initialized
INFO - 2017-05-12 08:59:34 --> Helper loaded: url_helper
INFO - 2017-05-12 08:59:34 --> Helper loaded: form_helper
INFO - 2017-05-12 08:59:34 --> Helper loaded: html_helper
INFO - 2017-05-12 08:59:34 --> Helper loaded: custom_helper
INFO - 2017-05-12 08:59:34 --> Helper loaded: cache_helper
INFO - 2017-05-12 08:59:34 --> Database Driver Class Initialized
INFO - 2017-05-12 08:59:34 --> Parser Class Initialized
DEBUG - 2017-05-12 08:59:34 --> Session Class Initialized
INFO - 2017-05-12 08:59:34 --> Helper loaded: string_helper
DEBUG - 2017-05-12 08:59:34 --> Session routines successfully run
INFO - 2017-05-12 08:59:34 --> Form Validation Class Initialized
INFO - 2017-05-12 08:59:34 --> Controller Class Initialized
DEBUG - 2017-05-12 08:59:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 08:59:34 --> Model Class Initialized
DEBUG - 2017-05-12 08:59:34 --> Pagination Class Initialized
INFO - 2017-05-12 08:59:34 --> Final output sent to browser
DEBUG - 2017-05-12 08:59:34 --> Total execution time: 0.1920
INFO - 2017-05-12 09:00:37 --> Config Class Initialized
INFO - 2017-05-12 09:00:37 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:00:37 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:00:37 --> Utf8 Class Initialized
INFO - 2017-05-12 09:00:37 --> URI Class Initialized
INFO - 2017-05-12 09:00:37 --> Router Class Initialized
INFO - 2017-05-12 09:00:37 --> Output Class Initialized
INFO - 2017-05-12 09:00:37 --> Security Class Initialized
DEBUG - 2017-05-12 09:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:00:37 --> Input Class Initialized
INFO - 2017-05-12 09:00:37 --> Language Class Initialized
INFO - 2017-05-12 09:00:37 --> Loader Class Initialized
INFO - 2017-05-12 09:00:37 --> Helper loaded: url_helper
INFO - 2017-05-12 09:00:37 --> Helper loaded: form_helper
INFO - 2017-05-12 09:00:37 --> Helper loaded: html_helper
INFO - 2017-05-12 09:00:37 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:00:37 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:00:37 --> Database Driver Class Initialized
INFO - 2017-05-12 09:00:37 --> Parser Class Initialized
DEBUG - 2017-05-12 09:00:37 --> Session Class Initialized
INFO - 2017-05-12 09:00:37 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:00:37 --> Session routines successfully run
INFO - 2017-05-12 09:00:37 --> Form Validation Class Initialized
INFO - 2017-05-12 09:00:37 --> Controller Class Initialized
DEBUG - 2017-05-12 09:00:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:00:37 --> Model Class Initialized
DEBUG - 2017-05-12 09:00:37 --> Pagination Class Initialized
DEBUG - 2017-05-12 09:00:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 09:00:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 09:00:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 09:00:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 09:00:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 09:00:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 09:00:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 09:00:38 --> Final output sent to browser
DEBUG - 2017-05-12 09:00:38 --> Total execution time: 0.2598
INFO - 2017-05-12 09:00:38 --> Config Class Initialized
INFO - 2017-05-12 09:00:38 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:00:38 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:00:38 --> Utf8 Class Initialized
INFO - 2017-05-12 09:00:38 --> URI Class Initialized
INFO - 2017-05-12 09:00:38 --> Router Class Initialized
INFO - 2017-05-12 09:00:38 --> Output Class Initialized
INFO - 2017-05-12 09:00:38 --> Security Class Initialized
DEBUG - 2017-05-12 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:00:38 --> Input Class Initialized
INFO - 2017-05-12 09:00:38 --> Language Class Initialized
ERROR - 2017-05-12 09:00:38 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:00:38 --> Config Class Initialized
INFO - 2017-05-12 09:00:38 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:00:38 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:00:38 --> Utf8 Class Initialized
INFO - 2017-05-12 09:00:38 --> URI Class Initialized
INFO - 2017-05-12 09:00:38 --> Router Class Initialized
INFO - 2017-05-12 09:00:38 --> Config Class Initialized
INFO - 2017-05-12 09:00:38 --> Output Class Initialized
INFO - 2017-05-12 09:00:38 --> Hooks Class Initialized
INFO - 2017-05-12 09:00:38 --> Security Class Initialized
DEBUG - 2017-05-12 09:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:00:38 --> Utf8 Class Initialized
INFO - 2017-05-12 09:00:38 --> Input Class Initialized
INFO - 2017-05-12 09:00:38 --> URI Class Initialized
INFO - 2017-05-12 09:00:38 --> Language Class Initialized
INFO - 2017-05-12 09:00:38 --> Router Class Initialized
ERROR - 2017-05-12 09:00:38 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:00:38 --> Output Class Initialized
INFO - 2017-05-12 09:00:38 --> Security Class Initialized
DEBUG - 2017-05-12 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:00:38 --> Input Class Initialized
INFO - 2017-05-12 09:00:38 --> Language Class Initialized
ERROR - 2017-05-12 09:00:38 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:00:38 --> Config Class Initialized
INFO - 2017-05-12 09:00:38 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:00:38 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:00:38 --> Utf8 Class Initialized
INFO - 2017-05-12 09:00:38 --> URI Class Initialized
INFO - 2017-05-12 09:00:38 --> Router Class Initialized
INFO - 2017-05-12 09:00:38 --> Output Class Initialized
INFO - 2017-05-12 09:00:38 --> Security Class Initialized
DEBUG - 2017-05-12 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:00:38 --> Input Class Initialized
INFO - 2017-05-12 09:00:38 --> Language Class Initialized
ERROR - 2017-05-12 09:00:38 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:00:38 --> Config Class Initialized
INFO - 2017-05-12 09:00:38 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:00:38 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:00:38 --> Utf8 Class Initialized
INFO - 2017-05-12 09:00:38 --> URI Class Initialized
INFO - 2017-05-12 09:00:38 --> Router Class Initialized
INFO - 2017-05-12 09:00:38 --> Output Class Initialized
INFO - 2017-05-12 09:00:38 --> Security Class Initialized
DEBUG - 2017-05-12 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:00:38 --> Input Class Initialized
INFO - 2017-05-12 09:00:38 --> Language Class Initialized
INFO - 2017-05-12 09:00:38 --> Loader Class Initialized
INFO - 2017-05-12 09:00:38 --> Helper loaded: url_helper
INFO - 2017-05-12 09:00:38 --> Helper loaded: form_helper
INFO - 2017-05-12 09:00:38 --> Helper loaded: html_helper
INFO - 2017-05-12 09:00:38 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:00:38 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:00:38 --> Database Driver Class Initialized
INFO - 2017-05-12 09:00:38 --> Parser Class Initialized
DEBUG - 2017-05-12 09:00:38 --> Session Class Initialized
INFO - 2017-05-12 09:00:38 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:00:38 --> Session routines successfully run
INFO - 2017-05-12 09:00:38 --> Form Validation Class Initialized
INFO - 2017-05-12 09:00:38 --> Controller Class Initialized
DEBUG - 2017-05-12 09:00:38 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:00:38 --> Model Class Initialized
DEBUG - 2017-05-12 09:00:38 --> Pagination Class Initialized
ERROR - 2017-05-12 09:00:38 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2017-05-12 09:00:38 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2017-05-12 09:00:38 --> Final output sent to browser
DEBUG - 2017-05-12 09:00:38 --> Total execution time: 0.2067
INFO - 2017-05-12 09:01:01 --> Config Class Initialized
INFO - 2017-05-12 09:01:01 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:01:01 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:01:01 --> Utf8 Class Initialized
INFO - 2017-05-12 09:01:01 --> URI Class Initialized
INFO - 2017-05-12 09:01:01 --> Router Class Initialized
INFO - 2017-05-12 09:01:01 --> Output Class Initialized
INFO - 2017-05-12 09:01:01 --> Security Class Initialized
DEBUG - 2017-05-12 09:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:01:01 --> Input Class Initialized
INFO - 2017-05-12 09:01:01 --> Language Class Initialized
INFO - 2017-05-12 09:01:01 --> Loader Class Initialized
INFO - 2017-05-12 09:01:01 --> Helper loaded: url_helper
INFO - 2017-05-12 09:01:01 --> Helper loaded: form_helper
INFO - 2017-05-12 09:01:01 --> Helper loaded: html_helper
INFO - 2017-05-12 09:01:01 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:01:01 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:01:01 --> Database Driver Class Initialized
INFO - 2017-05-12 09:01:01 --> Parser Class Initialized
DEBUG - 2017-05-12 09:01:01 --> Session Class Initialized
INFO - 2017-05-12 09:01:01 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:01:01 --> Session routines successfully run
INFO - 2017-05-12 09:01:01 --> Form Validation Class Initialized
INFO - 2017-05-12 09:01:01 --> Controller Class Initialized
DEBUG - 2017-05-12 09:01:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:01:01 --> Model Class Initialized
DEBUG - 2017-05-12 09:01:01 --> Pagination Class Initialized
DEBUG - 2017-05-12 09:01:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 09:01:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 09:01:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 09:01:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 09:01:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 09:01:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 09:01:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 09:01:01 --> Final output sent to browser
DEBUG - 2017-05-12 09:01:01 --> Total execution time: 0.2528
INFO - 2017-05-12 09:01:01 --> Config Class Initialized
INFO - 2017-05-12 09:01:01 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:01:01 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:01:01 --> Utf8 Class Initialized
INFO - 2017-05-12 09:01:01 --> URI Class Initialized
INFO - 2017-05-12 09:01:01 --> Router Class Initialized
INFO - 2017-05-12 09:01:01 --> Output Class Initialized
INFO - 2017-05-12 09:01:01 --> Security Class Initialized
DEBUG - 2017-05-12 09:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:01:01 --> Input Class Initialized
INFO - 2017-05-12 09:01:01 --> Language Class Initialized
ERROR - 2017-05-12 09:01:01 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:01:01 --> Config Class Initialized
INFO - 2017-05-12 09:01:01 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:01:01 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:01:01 --> Utf8 Class Initialized
INFO - 2017-05-12 09:01:01 --> URI Class Initialized
INFO - 2017-05-12 09:01:01 --> Router Class Initialized
INFO - 2017-05-12 09:01:01 --> Config Class Initialized
INFO - 2017-05-12 09:01:01 --> Output Class Initialized
INFO - 2017-05-12 09:01:01 --> Hooks Class Initialized
INFO - 2017-05-12 09:01:01 --> Security Class Initialized
DEBUG - 2017-05-12 09:01:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 09:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:01:01 --> Utf8 Class Initialized
INFO - 2017-05-12 09:01:01 --> Input Class Initialized
INFO - 2017-05-12 09:01:01 --> URI Class Initialized
INFO - 2017-05-12 09:01:01 --> Language Class Initialized
INFO - 2017-05-12 09:01:01 --> Router Class Initialized
ERROR - 2017-05-12 09:01:01 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:01:01 --> Output Class Initialized
INFO - 2017-05-12 09:01:01 --> Security Class Initialized
DEBUG - 2017-05-12 09:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:01:01 --> Input Class Initialized
INFO - 2017-05-12 09:01:01 --> Language Class Initialized
ERROR - 2017-05-12 09:01:02 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:01:02 --> Config Class Initialized
INFO - 2017-05-12 09:01:02 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:01:02 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:01:02 --> Utf8 Class Initialized
INFO - 2017-05-12 09:01:02 --> URI Class Initialized
INFO - 2017-05-12 09:01:02 --> Router Class Initialized
INFO - 2017-05-12 09:01:02 --> Output Class Initialized
INFO - 2017-05-12 09:01:02 --> Security Class Initialized
DEBUG - 2017-05-12 09:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:01:02 --> Input Class Initialized
INFO - 2017-05-12 09:01:02 --> Language Class Initialized
ERROR - 2017-05-12 09:01:02 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:01:02 --> Config Class Initialized
INFO - 2017-05-12 09:01:02 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:01:02 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:01:02 --> Utf8 Class Initialized
INFO - 2017-05-12 09:01:02 --> URI Class Initialized
INFO - 2017-05-12 09:01:02 --> Router Class Initialized
INFO - 2017-05-12 09:01:02 --> Output Class Initialized
INFO - 2017-05-12 09:01:02 --> Security Class Initialized
DEBUG - 2017-05-12 09:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:01:02 --> Input Class Initialized
INFO - 2017-05-12 09:01:02 --> Language Class Initialized
INFO - 2017-05-12 09:01:02 --> Loader Class Initialized
INFO - 2017-05-12 09:01:02 --> Helper loaded: url_helper
INFO - 2017-05-12 09:01:02 --> Helper loaded: form_helper
INFO - 2017-05-12 09:01:02 --> Helper loaded: html_helper
INFO - 2017-05-12 09:01:02 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:01:02 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:01:02 --> Database Driver Class Initialized
INFO - 2017-05-12 09:01:02 --> Parser Class Initialized
DEBUG - 2017-05-12 09:01:02 --> Session Class Initialized
INFO - 2017-05-12 09:01:02 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:01:02 --> Session routines successfully run
INFO - 2017-05-12 09:01:02 --> Form Validation Class Initialized
INFO - 2017-05-12 09:01:02 --> Controller Class Initialized
DEBUG - 2017-05-12 09:01:02 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:01:02 --> Model Class Initialized
DEBUG - 2017-05-12 09:01:02 --> Pagination Class Initialized
ERROR - 2017-05-12 09:01:02 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2017-05-12 09:01:02 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2017-05-12 09:01:02 --> Final output sent to browser
DEBUG - 2017-05-12 09:01:02 --> Total execution time: 0.2119
INFO - 2017-05-12 09:02:35 --> Config Class Initialized
INFO - 2017-05-12 09:02:35 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:02:35 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:02:35 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:35 --> URI Class Initialized
INFO - 2017-05-12 09:02:35 --> Router Class Initialized
INFO - 2017-05-12 09:02:35 --> Output Class Initialized
INFO - 2017-05-12 09:02:35 --> Security Class Initialized
DEBUG - 2017-05-12 09:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:35 --> Input Class Initialized
INFO - 2017-05-12 09:02:35 --> Language Class Initialized
INFO - 2017-05-12 09:02:35 --> Loader Class Initialized
INFO - 2017-05-12 09:02:35 --> Helper loaded: url_helper
INFO - 2017-05-12 09:02:35 --> Helper loaded: form_helper
INFO - 2017-05-12 09:02:35 --> Helper loaded: html_helper
INFO - 2017-05-12 09:02:35 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:02:35 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:02:35 --> Database Driver Class Initialized
INFO - 2017-05-12 09:02:35 --> Parser Class Initialized
DEBUG - 2017-05-12 09:02:35 --> Session Class Initialized
INFO - 2017-05-12 09:02:35 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:02:35 --> Session routines successfully run
INFO - 2017-05-12 09:02:35 --> Form Validation Class Initialized
INFO - 2017-05-12 09:02:35 --> Controller Class Initialized
DEBUG - 2017-05-12 09:02:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:02:35 --> Model Class Initialized
DEBUG - 2017-05-12 09:02:35 --> Pagination Class Initialized
INFO - 2017-05-12 09:02:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 09:02:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 09:02:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 09:02:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 09:02:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 09:02:35 --> Final output sent to browser
DEBUG - 2017-05-12 09:02:35 --> Total execution time: 0.2420
INFO - 2017-05-12 09:02:35 --> Config Class Initialized
INFO - 2017-05-12 09:02:35 --> Config Class Initialized
INFO - 2017-05-12 09:02:35 --> Hooks Class Initialized
INFO - 2017-05-12 09:02:35 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 09:02:35 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:02:35 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:35 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:35 --> URI Class Initialized
INFO - 2017-05-12 09:02:35 --> URI Class Initialized
INFO - 2017-05-12 09:02:35 --> Router Class Initialized
INFO - 2017-05-12 09:02:35 --> Router Class Initialized
INFO - 2017-05-12 09:02:35 --> Output Class Initialized
INFO - 2017-05-12 09:02:35 --> Output Class Initialized
INFO - 2017-05-12 09:02:35 --> Security Class Initialized
INFO - 2017-05-12 09:02:35 --> Security Class Initialized
DEBUG - 2017-05-12 09:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:35 --> Input Class Initialized
DEBUG - 2017-05-12 09:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:35 --> Input Class Initialized
INFO - 2017-05-12 09:02:35 --> Language Class Initialized
INFO - 2017-05-12 09:02:35 --> Language Class Initialized
ERROR - 2017-05-12 09:02:35 --> 404 Page Not Found: Default/assets
ERROR - 2017-05-12 09:02:35 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:02:35 --> Config Class Initialized
INFO - 2017-05-12 09:02:35 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:02:35 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:02:35 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:35 --> URI Class Initialized
INFO - 2017-05-12 09:02:35 --> Router Class Initialized
INFO - 2017-05-12 09:02:35 --> Output Class Initialized
INFO - 2017-05-12 09:02:35 --> Security Class Initialized
DEBUG - 2017-05-12 09:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:35 --> Input Class Initialized
INFO - 2017-05-12 09:02:35 --> Language Class Initialized
ERROR - 2017-05-12 09:02:35 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:02:35 --> Config Class Initialized
INFO - 2017-05-12 09:02:36 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:02:36 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:02:36 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:36 --> URI Class Initialized
INFO - 2017-05-12 09:02:36 --> Router Class Initialized
INFO - 2017-05-12 09:02:36 --> Output Class Initialized
INFO - 2017-05-12 09:02:36 --> Security Class Initialized
DEBUG - 2017-05-12 09:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:36 --> Input Class Initialized
INFO - 2017-05-12 09:02:36 --> Language Class Initialized
ERROR - 2017-05-12 09:02:36 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:02:36 --> Config Class Initialized
INFO - 2017-05-12 09:02:36 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:02:36 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:02:36 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:36 --> URI Class Initialized
INFO - 2017-05-12 09:02:36 --> Router Class Initialized
INFO - 2017-05-12 09:02:36 --> Output Class Initialized
INFO - 2017-05-12 09:02:36 --> Security Class Initialized
DEBUG - 2017-05-12 09:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:36 --> Input Class Initialized
INFO - 2017-05-12 09:02:36 --> Language Class Initialized
INFO - 2017-05-12 09:02:36 --> Loader Class Initialized
INFO - 2017-05-12 09:02:36 --> Helper loaded: url_helper
INFO - 2017-05-12 09:02:36 --> Helper loaded: form_helper
INFO - 2017-05-12 09:02:36 --> Helper loaded: html_helper
INFO - 2017-05-12 09:02:36 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:02:36 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:02:36 --> Database Driver Class Initialized
INFO - 2017-05-12 09:02:36 --> Parser Class Initialized
DEBUG - 2017-05-12 09:02:36 --> Session Class Initialized
INFO - 2017-05-12 09:02:36 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:02:36 --> Session routines successfully run
INFO - 2017-05-12 09:02:36 --> Form Validation Class Initialized
INFO - 2017-05-12 09:02:36 --> Controller Class Initialized
DEBUG - 2017-05-12 09:02:36 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:02:36 --> Model Class Initialized
DEBUG - 2017-05-12 09:02:36 --> Pagination Class Initialized
INFO - 2017-05-12 09:02:36 --> Final output sent to browser
DEBUG - 2017-05-12 09:02:36 --> Total execution time: 0.1955
INFO - 2017-05-12 09:02:42 --> Config Class Initialized
INFO - 2017-05-12 09:02:42 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:02:42 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:02:42 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:42 --> URI Class Initialized
INFO - 2017-05-12 09:02:42 --> Router Class Initialized
INFO - 2017-05-12 09:02:42 --> Output Class Initialized
INFO - 2017-05-12 09:02:42 --> Security Class Initialized
DEBUG - 2017-05-12 09:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:42 --> Input Class Initialized
INFO - 2017-05-12 09:02:42 --> Language Class Initialized
INFO - 2017-05-12 09:02:42 --> Loader Class Initialized
INFO - 2017-05-12 09:02:42 --> Helper loaded: url_helper
INFO - 2017-05-12 09:02:42 --> Helper loaded: form_helper
INFO - 2017-05-12 09:02:42 --> Helper loaded: html_helper
INFO - 2017-05-12 09:02:42 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:02:42 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:02:42 --> Database Driver Class Initialized
INFO - 2017-05-12 09:02:42 --> Parser Class Initialized
DEBUG - 2017-05-12 09:02:42 --> Session Class Initialized
INFO - 2017-05-12 09:02:42 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:02:42 --> Session routines successfully run
INFO - 2017-05-12 09:02:42 --> Form Validation Class Initialized
INFO - 2017-05-12 09:02:42 --> Controller Class Initialized
DEBUG - 2017-05-12 09:02:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:02:43 --> Model Class Initialized
DEBUG - 2017-05-12 09:02:43 --> Pagination Class Initialized
DEBUG - 2017-05-12 09:02:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 09:02:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-05-12 09:02:43 --> Severity: Notice --> Undefined index: is_manager C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 209
INFO - 2017-05-12 09:02:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 09:02:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 09:02:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 09:02:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 09:02:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 09:02:43 --> Final output sent to browser
DEBUG - 2017-05-12 09:02:43 --> Total execution time: 0.2644
INFO - 2017-05-12 09:02:43 --> Config Class Initialized
INFO - 2017-05-12 09:02:43 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:02:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:02:43 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:43 --> Config Class Initialized
INFO - 2017-05-12 09:02:43 --> URI Class Initialized
INFO - 2017-05-12 09:02:43 --> Hooks Class Initialized
INFO - 2017-05-12 09:02:43 --> Router Class Initialized
DEBUG - 2017-05-12 09:02:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:02:43 --> Output Class Initialized
INFO - 2017-05-12 09:02:43 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:43 --> URI Class Initialized
INFO - 2017-05-12 09:02:43 --> Security Class Initialized
INFO - 2017-05-12 09:02:43 --> Router Class Initialized
DEBUG - 2017-05-12 09:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:43 --> Output Class Initialized
INFO - 2017-05-12 09:02:43 --> Input Class Initialized
INFO - 2017-05-12 09:02:43 --> Language Class Initialized
INFO - 2017-05-12 09:02:43 --> Security Class Initialized
ERROR - 2017-05-12 09:02:43 --> 404 Page Not Found: Default/assets
DEBUG - 2017-05-12 09:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:43 --> Input Class Initialized
INFO - 2017-05-12 09:02:43 --> Language Class Initialized
ERROR - 2017-05-12 09:02:43 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:02:43 --> Config Class Initialized
INFO - 2017-05-12 09:02:43 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:02:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:02:43 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:43 --> URI Class Initialized
INFO - 2017-05-12 09:02:43 --> Router Class Initialized
INFO - 2017-05-12 09:02:43 --> Output Class Initialized
INFO - 2017-05-12 09:02:43 --> Security Class Initialized
DEBUG - 2017-05-12 09:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:43 --> Input Class Initialized
INFO - 2017-05-12 09:02:43 --> Language Class Initialized
ERROR - 2017-05-12 09:02:43 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:02:43 --> Config Class Initialized
INFO - 2017-05-12 09:02:43 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:02:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:02:43 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:43 --> URI Class Initialized
INFO - 2017-05-12 09:02:43 --> Router Class Initialized
INFO - 2017-05-12 09:02:43 --> Output Class Initialized
INFO - 2017-05-12 09:02:43 --> Security Class Initialized
DEBUG - 2017-05-12 09:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:43 --> Input Class Initialized
INFO - 2017-05-12 09:02:43 --> Language Class Initialized
ERROR - 2017-05-12 09:02:43 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:02:43 --> Config Class Initialized
INFO - 2017-05-12 09:02:43 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:02:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:02:43 --> Utf8 Class Initialized
INFO - 2017-05-12 09:02:43 --> URI Class Initialized
INFO - 2017-05-12 09:02:43 --> Router Class Initialized
INFO - 2017-05-12 09:02:43 --> Output Class Initialized
INFO - 2017-05-12 09:02:43 --> Security Class Initialized
DEBUG - 2017-05-12 09:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:02:43 --> Input Class Initialized
INFO - 2017-05-12 09:02:43 --> Language Class Initialized
INFO - 2017-05-12 09:02:43 --> Loader Class Initialized
INFO - 2017-05-12 09:02:43 --> Helper loaded: url_helper
INFO - 2017-05-12 09:02:43 --> Helper loaded: form_helper
INFO - 2017-05-12 09:02:43 --> Helper loaded: html_helper
INFO - 2017-05-12 09:02:43 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:02:43 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:02:43 --> Database Driver Class Initialized
INFO - 2017-05-12 09:02:43 --> Parser Class Initialized
DEBUG - 2017-05-12 09:02:43 --> Session Class Initialized
INFO - 2017-05-12 09:02:43 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:02:43 --> Session routines successfully run
INFO - 2017-05-12 09:02:43 --> Form Validation Class Initialized
INFO - 2017-05-12 09:02:43 --> Controller Class Initialized
DEBUG - 2017-05-12 09:02:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:02:43 --> Model Class Initialized
DEBUG - 2017-05-12 09:02:43 --> Pagination Class Initialized
ERROR - 2017-05-12 09:02:43 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2017-05-12 09:02:43 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2017-05-12 09:02:43 --> Final output sent to browser
DEBUG - 2017-05-12 09:02:43 --> Total execution time: 0.2135
INFO - 2017-05-12 09:07:08 --> Config Class Initialized
INFO - 2017-05-12 09:07:08 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:07:08 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:07:08 --> Utf8 Class Initialized
INFO - 2017-05-12 09:07:08 --> URI Class Initialized
INFO - 2017-05-12 09:07:08 --> Router Class Initialized
INFO - 2017-05-12 09:07:08 --> Output Class Initialized
INFO - 2017-05-12 09:07:08 --> Security Class Initialized
DEBUG - 2017-05-12 09:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:07:08 --> Input Class Initialized
INFO - 2017-05-12 09:07:08 --> Language Class Initialized
INFO - 2017-05-12 09:07:08 --> Loader Class Initialized
INFO - 2017-05-12 09:07:08 --> Helper loaded: url_helper
INFO - 2017-05-12 09:07:08 --> Helper loaded: form_helper
INFO - 2017-05-12 09:07:08 --> Helper loaded: html_helper
INFO - 2017-05-12 09:07:08 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:07:08 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:07:08 --> Database Driver Class Initialized
INFO - 2017-05-12 09:07:08 --> Parser Class Initialized
DEBUG - 2017-05-12 09:07:08 --> Session Class Initialized
INFO - 2017-05-12 09:07:08 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:07:08 --> Session routines successfully run
INFO - 2017-05-12 09:07:08 --> Form Validation Class Initialized
INFO - 2017-05-12 09:07:08 --> Controller Class Initialized
DEBUG - 2017-05-12 09:07:08 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:07:08 --> Model Class Initialized
DEBUG - 2017-05-12 09:07:08 --> Pagination Class Initialized
DEBUG - 2017-05-12 09:07:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 09:07:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 09:07:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 09:07:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 09:07:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 09:07:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 09:07:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 09:07:08 --> Final output sent to browser
DEBUG - 2017-05-12 09:07:08 --> Total execution time: 0.2632
INFO - 2017-05-12 09:07:08 --> Config Class Initialized
INFO - 2017-05-12 09:07:08 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:07:08 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:07:08 --> Utf8 Class Initialized
INFO - 2017-05-12 09:07:08 --> URI Class Initialized
INFO - 2017-05-12 09:07:08 --> Router Class Initialized
INFO - 2017-05-12 09:07:08 --> Output Class Initialized
INFO - 2017-05-12 09:07:08 --> Security Class Initialized
DEBUG - 2017-05-12 09:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:07:08 --> Input Class Initialized
INFO - 2017-05-12 09:07:08 --> Language Class Initialized
ERROR - 2017-05-12 09:07:08 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:07:08 --> Config Class Initialized
INFO - 2017-05-12 09:07:08 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:07:08 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:07:08 --> Utf8 Class Initialized
INFO - 2017-05-12 09:07:08 --> URI Class Initialized
INFO - 2017-05-12 09:07:08 --> Router Class Initialized
INFO - 2017-05-12 09:07:08 --> Output Class Initialized
INFO - 2017-05-12 09:07:08 --> Config Class Initialized
INFO - 2017-05-12 09:07:08 --> Security Class Initialized
INFO - 2017-05-12 09:07:08 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 09:07:08 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:07:08 --> Input Class Initialized
INFO - 2017-05-12 09:07:08 --> Utf8 Class Initialized
INFO - 2017-05-12 09:07:09 --> Language Class Initialized
INFO - 2017-05-12 09:07:09 --> URI Class Initialized
ERROR - 2017-05-12 09:07:09 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:07:09 --> Router Class Initialized
INFO - 2017-05-12 09:07:09 --> Output Class Initialized
INFO - 2017-05-12 09:07:09 --> Security Class Initialized
DEBUG - 2017-05-12 09:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:07:09 --> Input Class Initialized
INFO - 2017-05-12 09:07:09 --> Language Class Initialized
ERROR - 2017-05-12 09:07:09 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:07:09 --> Config Class Initialized
INFO - 2017-05-12 09:07:09 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:07:09 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:07:09 --> Utf8 Class Initialized
INFO - 2017-05-12 09:07:09 --> URI Class Initialized
INFO - 2017-05-12 09:07:09 --> Router Class Initialized
INFO - 2017-05-12 09:07:09 --> Output Class Initialized
INFO - 2017-05-12 09:07:09 --> Security Class Initialized
DEBUG - 2017-05-12 09:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:07:09 --> Input Class Initialized
INFO - 2017-05-12 09:07:09 --> Language Class Initialized
ERROR - 2017-05-12 09:07:09 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:07:09 --> Config Class Initialized
INFO - 2017-05-12 09:07:09 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:07:09 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:07:09 --> Utf8 Class Initialized
INFO - 2017-05-12 09:07:09 --> URI Class Initialized
INFO - 2017-05-12 09:07:09 --> Router Class Initialized
INFO - 2017-05-12 09:07:09 --> Output Class Initialized
INFO - 2017-05-12 09:07:09 --> Security Class Initialized
DEBUG - 2017-05-12 09:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:07:09 --> Input Class Initialized
INFO - 2017-05-12 09:07:09 --> Language Class Initialized
INFO - 2017-05-12 09:07:09 --> Loader Class Initialized
INFO - 2017-05-12 09:07:09 --> Helper loaded: url_helper
INFO - 2017-05-12 09:07:09 --> Helper loaded: form_helper
INFO - 2017-05-12 09:07:09 --> Helper loaded: html_helper
INFO - 2017-05-12 09:07:09 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:07:09 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:07:09 --> Database Driver Class Initialized
INFO - 2017-05-12 09:07:09 --> Parser Class Initialized
DEBUG - 2017-05-12 09:07:09 --> Session Class Initialized
INFO - 2017-05-12 09:07:09 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:07:09 --> Session routines successfully run
INFO - 2017-05-12 09:07:09 --> Form Validation Class Initialized
INFO - 2017-05-12 09:07:09 --> Controller Class Initialized
DEBUG - 2017-05-12 09:07:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:07:09 --> Model Class Initialized
DEBUG - 2017-05-12 09:07:09 --> Pagination Class Initialized
ERROR - 2017-05-12 09:07:09 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2017-05-12 09:07:09 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2017-05-12 09:07:09 --> Final output sent to browser
DEBUG - 2017-05-12 09:07:09 --> Total execution time: 0.2289
INFO - 2017-05-12 09:20:45 --> Config Class Initialized
INFO - 2017-05-12 09:20:45 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:20:45 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:20:45 --> Utf8 Class Initialized
INFO - 2017-05-12 09:20:45 --> URI Class Initialized
INFO - 2017-05-12 09:20:45 --> Router Class Initialized
INFO - 2017-05-12 09:20:45 --> Output Class Initialized
INFO - 2017-05-12 09:20:45 --> Security Class Initialized
DEBUG - 2017-05-12 09:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:20:45 --> Input Class Initialized
INFO - 2017-05-12 09:20:45 --> Language Class Initialized
INFO - 2017-05-12 09:20:45 --> Loader Class Initialized
INFO - 2017-05-12 09:20:45 --> Helper loaded: url_helper
INFO - 2017-05-12 09:20:45 --> Helper loaded: form_helper
INFO - 2017-05-12 09:20:45 --> Helper loaded: html_helper
INFO - 2017-05-12 09:20:45 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:20:45 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:20:45 --> Database Driver Class Initialized
INFO - 2017-05-12 09:20:45 --> Parser Class Initialized
DEBUG - 2017-05-12 09:20:45 --> Session Class Initialized
INFO - 2017-05-12 09:20:45 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:20:45 --> Session routines successfully run
INFO - 2017-05-12 09:20:45 --> Form Validation Class Initialized
INFO - 2017-05-12 09:20:45 --> Controller Class Initialized
DEBUG - 2017-05-12 09:20:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:20:45 --> Model Class Initialized
DEBUG - 2017-05-12 09:20:45 --> Pagination Class Initialized
DEBUG - 2017-05-12 09:20:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 09:20:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 09:20:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 09:20:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 09:20:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 09:20:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 09:20:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 09:20:45 --> Final output sent to browser
DEBUG - 2017-05-12 09:20:45 --> Total execution time: 0.3039
INFO - 2017-05-12 09:20:45 --> Config Class Initialized
INFO - 2017-05-12 09:20:45 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:20:45 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:20:45 --> Utf8 Class Initialized
INFO - 2017-05-12 09:20:45 --> URI Class Initialized
INFO - 2017-05-12 09:20:45 --> Router Class Initialized
INFO - 2017-05-12 09:20:45 --> Output Class Initialized
INFO - 2017-05-12 09:20:45 --> Security Class Initialized
DEBUG - 2017-05-12 09:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:20:45 --> Input Class Initialized
INFO - 2017-05-12 09:20:45 --> Config Class Initialized
INFO - 2017-05-12 09:20:45 --> Language Class Initialized
INFO - 2017-05-12 09:20:45 --> Hooks Class Initialized
ERROR - 2017-05-12 09:20:45 --> 404 Page Not Found: Default/assets
DEBUG - 2017-05-12 09:20:45 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:20:45 --> Utf8 Class Initialized
INFO - 2017-05-12 09:20:45 --> URI Class Initialized
INFO - 2017-05-12 09:20:45 --> Router Class Initialized
INFO - 2017-05-12 09:20:45 --> Output Class Initialized
INFO - 2017-05-12 09:20:45 --> Security Class Initialized
DEBUG - 2017-05-12 09:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:20:45 --> Input Class Initialized
INFO - 2017-05-12 09:20:45 --> Language Class Initialized
ERROR - 2017-05-12 09:20:45 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:20:45 --> Config Class Initialized
INFO - 2017-05-12 09:20:45 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:20:45 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:20:45 --> Utf8 Class Initialized
INFO - 2017-05-12 09:20:45 --> URI Class Initialized
INFO - 2017-05-12 09:20:45 --> Router Class Initialized
INFO - 2017-05-12 09:20:45 --> Output Class Initialized
INFO - 2017-05-12 09:20:45 --> Security Class Initialized
DEBUG - 2017-05-12 09:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:20:45 --> Input Class Initialized
INFO - 2017-05-12 09:20:45 --> Language Class Initialized
INFO - 2017-05-12 09:20:45 --> Loader Class Initialized
INFO - 2017-05-12 09:20:45 --> Helper loaded: url_helper
INFO - 2017-05-12 09:20:45 --> Helper loaded: form_helper
INFO - 2017-05-12 09:20:45 --> Helper loaded: html_helper
INFO - 2017-05-12 09:20:45 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:20:45 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:20:45 --> Database Driver Class Initialized
INFO - 2017-05-12 09:20:45 --> Parser Class Initialized
DEBUG - 2017-05-12 09:20:45 --> Session Class Initialized
INFO - 2017-05-12 09:20:45 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:20:45 --> Session routines successfully run
INFO - 2017-05-12 09:20:45 --> Form Validation Class Initialized
INFO - 2017-05-12 09:20:45 --> Controller Class Initialized
DEBUG - 2017-05-12 09:20:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:20:45 --> Model Class Initialized
DEBUG - 2017-05-12 09:20:45 --> Pagination Class Initialized
ERROR - 2017-05-12 09:20:45 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 906
ERROR - 2017-05-12 09:20:45 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 909
INFO - 2017-05-12 09:20:45 --> Final output sent to browser
DEBUG - 2017-05-12 09:20:45 --> Total execution time: 0.2476
INFO - 2017-05-12 09:20:52 --> Config Class Initialized
INFO - 2017-05-12 09:20:52 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:20:52 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:20:52 --> Utf8 Class Initialized
INFO - 2017-05-12 09:20:52 --> URI Class Initialized
INFO - 2017-05-12 09:20:52 --> Router Class Initialized
INFO - 2017-05-12 09:20:52 --> Output Class Initialized
INFO - 2017-05-12 09:20:52 --> Security Class Initialized
DEBUG - 2017-05-12 09:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:20:52 --> Input Class Initialized
INFO - 2017-05-12 09:20:52 --> Language Class Initialized
INFO - 2017-05-12 09:20:52 --> Loader Class Initialized
INFO - 2017-05-12 09:20:52 --> Helper loaded: url_helper
INFO - 2017-05-12 09:20:52 --> Helper loaded: form_helper
INFO - 2017-05-12 09:20:52 --> Helper loaded: html_helper
INFO - 2017-05-12 09:20:53 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:20:53 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:20:53 --> Database Driver Class Initialized
INFO - 2017-05-12 09:20:53 --> Parser Class Initialized
DEBUG - 2017-05-12 09:20:53 --> Session Class Initialized
INFO - 2017-05-12 09:20:53 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:20:53 --> Session routines successfully run
INFO - 2017-05-12 09:20:53 --> Form Validation Class Initialized
INFO - 2017-05-12 09:20:53 --> Controller Class Initialized
DEBUG - 2017-05-12 09:20:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:20:53 --> Model Class Initialized
DEBUG - 2017-05-12 09:20:53 --> Pagination Class Initialized
DEBUG - 2017-05-12 09:20:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 09:20:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 09:20:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 09:20:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 09:20:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 09:20:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 09:20:53 --> Final output sent to browser
DEBUG - 2017-05-12 09:20:53 --> Total execution time: 0.2731
INFO - 2017-05-12 09:20:53 --> Config Class Initialized
INFO - 2017-05-12 09:20:53 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:20:53 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:20:53 --> Utf8 Class Initialized
INFO - 2017-05-12 09:20:53 --> URI Class Initialized
INFO - 2017-05-12 09:20:53 --> Router Class Initialized
INFO - 2017-05-12 09:20:53 --> Output Class Initialized
INFO - 2017-05-12 09:20:53 --> Security Class Initialized
INFO - 2017-05-12 09:20:53 --> Config Class Initialized
DEBUG - 2017-05-12 09:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:20:53 --> Hooks Class Initialized
INFO - 2017-05-12 09:20:53 --> Input Class Initialized
INFO - 2017-05-12 09:20:53 --> Language Class Initialized
DEBUG - 2017-05-12 09:20:53 --> UTF-8 Support Enabled
ERROR - 2017-05-12 09:20:53 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:20:53 --> Utf8 Class Initialized
INFO - 2017-05-12 09:20:53 --> URI Class Initialized
INFO - 2017-05-12 09:20:53 --> Router Class Initialized
INFO - 2017-05-12 09:20:53 --> Output Class Initialized
INFO - 2017-05-12 09:20:53 --> Security Class Initialized
DEBUG - 2017-05-12 09:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:20:53 --> Input Class Initialized
INFO - 2017-05-12 09:20:53 --> Language Class Initialized
ERROR - 2017-05-12 09:20:53 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:20:53 --> Config Class Initialized
INFO - 2017-05-12 09:20:53 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:20:53 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:20:53 --> Utf8 Class Initialized
INFO - 2017-05-12 09:20:53 --> URI Class Initialized
INFO - 2017-05-12 09:20:53 --> Router Class Initialized
INFO - 2017-05-12 09:20:53 --> Output Class Initialized
INFO - 2017-05-12 09:20:53 --> Security Class Initialized
DEBUG - 2017-05-12 09:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:20:53 --> Input Class Initialized
INFO - 2017-05-12 09:20:53 --> Language Class Initialized
ERROR - 2017-05-12 09:20:53 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:20:53 --> Config Class Initialized
INFO - 2017-05-12 09:20:53 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:20:53 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:20:53 --> Utf8 Class Initialized
INFO - 2017-05-12 09:20:53 --> URI Class Initialized
INFO - 2017-05-12 09:20:53 --> Router Class Initialized
INFO - 2017-05-12 09:20:53 --> Output Class Initialized
INFO - 2017-05-12 09:20:53 --> Security Class Initialized
DEBUG - 2017-05-12 09:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:20:53 --> Input Class Initialized
INFO - 2017-05-12 09:20:53 --> Language Class Initialized
ERROR - 2017-05-12 09:20:53 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:20:53 --> Config Class Initialized
INFO - 2017-05-12 09:20:53 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:20:54 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:20:54 --> Utf8 Class Initialized
INFO - 2017-05-12 09:20:54 --> URI Class Initialized
INFO - 2017-05-12 09:20:54 --> Router Class Initialized
INFO - 2017-05-12 09:20:54 --> Output Class Initialized
INFO - 2017-05-12 09:20:54 --> Security Class Initialized
DEBUG - 2017-05-12 09:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:20:54 --> Input Class Initialized
INFO - 2017-05-12 09:20:54 --> Language Class Initialized
INFO - 2017-05-12 09:20:54 --> Loader Class Initialized
INFO - 2017-05-12 09:20:54 --> Helper loaded: url_helper
INFO - 2017-05-12 09:20:54 --> Helper loaded: form_helper
INFO - 2017-05-12 09:20:54 --> Helper loaded: html_helper
INFO - 2017-05-12 09:20:54 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:20:54 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:20:54 --> Database Driver Class Initialized
INFO - 2017-05-12 09:20:54 --> Parser Class Initialized
DEBUG - 2017-05-12 09:20:54 --> Session Class Initialized
INFO - 2017-05-12 09:20:54 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:20:54 --> Session routines successfully run
INFO - 2017-05-12 09:20:54 --> Form Validation Class Initialized
INFO - 2017-05-12 09:20:54 --> Controller Class Initialized
DEBUG - 2017-05-12 09:20:54 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:20:54 --> Model Class Initialized
DEBUG - 2017-05-12 09:20:54 --> Pagination Class Initialized
ERROR - 2017-05-12 09:20:54 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 906
ERROR - 2017-05-12 09:20:54 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 909
INFO - 2017-05-12 09:20:54 --> Final output sent to browser
DEBUG - 2017-05-12 09:20:54 --> Total execution time: 0.2325
INFO - 2017-05-12 09:27:52 --> Config Class Initialized
INFO - 2017-05-12 09:27:52 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:27:52 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:27:52 --> Utf8 Class Initialized
INFO - 2017-05-12 09:27:52 --> URI Class Initialized
INFO - 2017-05-12 09:27:52 --> Router Class Initialized
INFO - 2017-05-12 09:27:52 --> Output Class Initialized
INFO - 2017-05-12 09:27:52 --> Security Class Initialized
DEBUG - 2017-05-12 09:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:27:52 --> Input Class Initialized
INFO - 2017-05-12 09:27:52 --> Language Class Initialized
INFO - 2017-05-12 09:27:52 --> Loader Class Initialized
INFO - 2017-05-12 09:27:52 --> Helper loaded: url_helper
INFO - 2017-05-12 09:27:52 --> Helper loaded: form_helper
INFO - 2017-05-12 09:27:52 --> Helper loaded: html_helper
INFO - 2017-05-12 09:27:52 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:27:52 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:27:52 --> Database Driver Class Initialized
INFO - 2017-05-12 09:27:52 --> Parser Class Initialized
DEBUG - 2017-05-12 09:27:52 --> Session Class Initialized
INFO - 2017-05-12 09:27:52 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:27:52 --> Session routines successfully run
INFO - 2017-05-12 09:27:52 --> Form Validation Class Initialized
INFO - 2017-05-12 09:27:52 --> Controller Class Initialized
DEBUG - 2017-05-12 09:27:52 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:27:52 --> Model Class Initialized
DEBUG - 2017-05-12 09:27:52 --> Pagination Class Initialized
INFO - 2017-05-12 09:27:52 --> Config Class Initialized
INFO - 2017-05-12 09:27:52 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:27:52 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:27:52 --> Utf8 Class Initialized
INFO - 2017-05-12 09:27:52 --> URI Class Initialized
INFO - 2017-05-12 09:27:52 --> Router Class Initialized
INFO - 2017-05-12 09:27:52 --> Output Class Initialized
INFO - 2017-05-12 09:27:52 --> Security Class Initialized
DEBUG - 2017-05-12 09:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:27:52 --> Input Class Initialized
INFO - 2017-05-12 09:27:52 --> Language Class Initialized
INFO - 2017-05-12 09:27:52 --> Loader Class Initialized
INFO - 2017-05-12 09:27:52 --> Helper loaded: url_helper
INFO - 2017-05-12 09:27:52 --> Helper loaded: form_helper
INFO - 2017-05-12 09:27:52 --> Helper loaded: html_helper
INFO - 2017-05-12 09:27:52 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:27:52 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:27:52 --> Database Driver Class Initialized
INFO - 2017-05-12 09:27:52 --> Parser Class Initialized
DEBUG - 2017-05-12 09:27:52 --> Session Class Initialized
INFO - 2017-05-12 09:27:52 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:27:52 --> Session routines successfully run
INFO - 2017-05-12 09:27:52 --> Form Validation Class Initialized
INFO - 2017-05-12 09:27:52 --> Controller Class Initialized
DEBUG - 2017-05-12 09:27:52 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:27:52 --> Model Class Initialized
DEBUG - 2017-05-12 09:27:52 --> Pagination Class Initialized
INFO - 2017-05-12 09:27:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 09:27:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 09:27:52 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:52 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:52 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:52 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:52 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:52 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:52 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:52 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:52 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:52 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:53 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:54 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:55 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:27:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:27:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:27:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:27:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:27:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 09:27:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 09:27:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 09:27:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 09:27:58 --> Final output sent to browser
DEBUG - 2017-05-12 09:27:58 --> Total execution time: 5.4712
INFO - 2017-05-12 09:28:00 --> Config Class Initialized
INFO - 2017-05-12 09:28:00 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:28:00 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:28:00 --> Utf8 Class Initialized
INFO - 2017-05-12 09:28:00 --> URI Class Initialized
INFO - 2017-05-12 09:28:00 --> Router Class Initialized
INFO - 2017-05-12 09:28:00 --> Output Class Initialized
INFO - 2017-05-12 09:28:00 --> Security Class Initialized
DEBUG - 2017-05-12 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:28:00 --> Input Class Initialized
INFO - 2017-05-12 09:28:00 --> Language Class Initialized
INFO - 2017-05-12 09:28:00 --> Loader Class Initialized
INFO - 2017-05-12 09:28:00 --> Helper loaded: url_helper
INFO - 2017-05-12 09:28:00 --> Helper loaded: form_helper
INFO - 2017-05-12 09:28:01 --> Helper loaded: html_helper
INFO - 2017-05-12 09:28:01 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:28:01 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:28:01 --> Database Driver Class Initialized
INFO - 2017-05-12 09:28:01 --> Parser Class Initialized
DEBUG - 2017-05-12 09:28:01 --> Session Class Initialized
INFO - 2017-05-12 09:28:01 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:28:01 --> Session routines successfully run
INFO - 2017-05-12 09:28:01 --> Form Validation Class Initialized
INFO - 2017-05-12 09:28:01 --> Controller Class Initialized
DEBUG - 2017-05-12 09:28:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:28:01 --> Model Class Initialized
DEBUG - 2017-05-12 09:28:01 --> Pagination Class Initialized
DEBUG - 2017-05-12 09:28:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 09:28:15 --> Config Class Initialized
INFO - 2017-05-12 09:28:15 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:28:15 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:28:15 --> Utf8 Class Initialized
INFO - 2017-05-12 09:28:15 --> URI Class Initialized
INFO - 2017-05-12 09:28:15 --> Router Class Initialized
INFO - 2017-05-12 09:28:15 --> Output Class Initialized
INFO - 2017-05-12 09:28:15 --> Security Class Initialized
DEBUG - 2017-05-12 09:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:28:15 --> Input Class Initialized
INFO - 2017-05-12 09:28:15 --> Language Class Initialized
INFO - 2017-05-12 09:28:15 --> Loader Class Initialized
INFO - 2017-05-12 09:28:15 --> Helper loaded: url_helper
INFO - 2017-05-12 09:28:15 --> Helper loaded: form_helper
INFO - 2017-05-12 09:28:15 --> Helper loaded: html_helper
INFO - 2017-05-12 09:28:15 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:28:15 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:28:15 --> Database Driver Class Initialized
INFO - 2017-05-12 09:28:15 --> Parser Class Initialized
DEBUG - 2017-05-12 09:28:15 --> Session Class Initialized
INFO - 2017-05-12 09:28:15 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:28:15 --> Session routines successfully run
INFO - 2017-05-12 09:28:15 --> Form Validation Class Initialized
INFO - 2017-05-12 09:28:15 --> Controller Class Initialized
DEBUG - 2017-05-12 09:28:15 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:28:15 --> Model Class Initialized
DEBUG - 2017-05-12 09:28:15 --> Pagination Class Initialized
INFO - 2017-05-12 09:28:15 --> Config Class Initialized
INFO - 2017-05-12 09:28:15 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:28:15 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:28:15 --> Utf8 Class Initialized
INFO - 2017-05-12 09:28:15 --> URI Class Initialized
INFO - 2017-05-12 09:28:15 --> Router Class Initialized
INFO - 2017-05-12 09:28:15 --> Output Class Initialized
INFO - 2017-05-12 09:28:15 --> Security Class Initialized
DEBUG - 2017-05-12 09:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:28:15 --> Input Class Initialized
INFO - 2017-05-12 09:28:15 --> Language Class Initialized
INFO - 2017-05-12 09:28:15 --> Loader Class Initialized
INFO - 2017-05-12 09:28:15 --> Helper loaded: url_helper
INFO - 2017-05-12 09:28:15 --> Helper loaded: form_helper
INFO - 2017-05-12 09:28:15 --> Helper loaded: html_helper
INFO - 2017-05-12 09:28:15 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:28:15 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:28:15 --> Database Driver Class Initialized
INFO - 2017-05-12 09:28:15 --> Parser Class Initialized
DEBUG - 2017-05-12 09:28:15 --> Session Class Initialized
INFO - 2017-05-12 09:28:15 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:28:15 --> Session routines successfully run
INFO - 2017-05-12 09:28:15 --> Form Validation Class Initialized
INFO - 2017-05-12 09:28:15 --> Controller Class Initialized
DEBUG - 2017-05-12 09:28:15 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:28:15 --> Model Class Initialized
DEBUG - 2017-05-12 09:28:15 --> Pagination Class Initialized
INFO - 2017-05-12 09:28:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 09:28:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 09:28:15 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:15 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:15 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:15 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:15 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:15 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:15 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:15 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:15 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:15 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:17 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:19 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:20 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:20 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:20 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:20 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:20 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 09:28:20 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 09:28:20 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 09:28:20 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 09:28:20 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 09:28:20 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 09:28:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 09:28:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 09:28:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 09:28:20 --> Final output sent to browser
DEBUG - 2017-05-12 09:28:21 --> Total execution time: 5.2957
INFO - 2017-05-12 09:28:25 --> Config Class Initialized
INFO - 2017-05-12 09:28:25 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:28:25 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:28:25 --> Utf8 Class Initialized
INFO - 2017-05-12 09:28:25 --> URI Class Initialized
INFO - 2017-05-12 09:28:25 --> Router Class Initialized
INFO - 2017-05-12 09:28:25 --> Output Class Initialized
INFO - 2017-05-12 09:28:25 --> Security Class Initialized
DEBUG - 2017-05-12 09:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:28:25 --> Input Class Initialized
INFO - 2017-05-12 09:28:25 --> Language Class Initialized
INFO - 2017-05-12 09:28:25 --> Loader Class Initialized
INFO - 2017-05-12 09:28:25 --> Helper loaded: url_helper
INFO - 2017-05-12 09:28:25 --> Helper loaded: form_helper
INFO - 2017-05-12 09:28:25 --> Helper loaded: html_helper
INFO - 2017-05-12 09:28:25 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:28:25 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:28:25 --> Database Driver Class Initialized
INFO - 2017-05-12 09:28:25 --> Parser Class Initialized
DEBUG - 2017-05-12 09:28:25 --> Session Class Initialized
INFO - 2017-05-12 09:28:25 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:28:25 --> Session routines successfully run
INFO - 2017-05-12 09:28:25 --> Form Validation Class Initialized
INFO - 2017-05-12 09:28:25 --> Controller Class Initialized
DEBUG - 2017-05-12 09:28:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:28:25 --> Model Class Initialized
DEBUG - 2017-05-12 09:28:25 --> Pagination Class Initialized
INFO - 2017-05-12 09:28:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 09:28:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 09:28:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 09:28:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 09:28:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 09:28:25 --> Final output sent to browser
DEBUG - 2017-05-12 09:28:25 --> Total execution time: 0.3278
INFO - 2017-05-12 09:28:25 --> Config Class Initialized
INFO - 2017-05-12 09:28:25 --> Config Class Initialized
INFO - 2017-05-12 09:28:25 --> Hooks Class Initialized
INFO - 2017-05-12 09:28:25 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:28:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 09:28:25 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:28:25 --> Utf8 Class Initialized
INFO - 2017-05-12 09:28:25 --> Utf8 Class Initialized
INFO - 2017-05-12 09:28:25 --> URI Class Initialized
INFO - 2017-05-12 09:28:25 --> URI Class Initialized
INFO - 2017-05-12 09:28:25 --> Router Class Initialized
INFO - 2017-05-12 09:28:25 --> Router Class Initialized
INFO - 2017-05-12 09:28:25 --> Output Class Initialized
INFO - 2017-05-12 09:28:25 --> Output Class Initialized
INFO - 2017-05-12 09:28:25 --> Security Class Initialized
INFO - 2017-05-12 09:28:25 --> Security Class Initialized
DEBUG - 2017-05-12 09:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 09:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:28:26 --> Input Class Initialized
INFO - 2017-05-12 09:28:26 --> Input Class Initialized
INFO - 2017-05-12 09:28:26 --> Language Class Initialized
INFO - 2017-05-12 09:28:26 --> Language Class Initialized
ERROR - 2017-05-12 09:28:26 --> 404 Page Not Found: Default/assets
ERROR - 2017-05-12 09:28:26 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:28:26 --> Config Class Initialized
INFO - 2017-05-12 09:28:26 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:28:26 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:28:26 --> Utf8 Class Initialized
INFO - 2017-05-12 09:28:26 --> URI Class Initialized
INFO - 2017-05-12 09:28:26 --> Router Class Initialized
INFO - 2017-05-12 09:28:26 --> Output Class Initialized
INFO - 2017-05-12 09:28:26 --> Security Class Initialized
DEBUG - 2017-05-12 09:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:28:26 --> Input Class Initialized
INFO - 2017-05-12 09:28:26 --> Language Class Initialized
ERROR - 2017-05-12 09:28:26 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:28:26 --> Config Class Initialized
INFO - 2017-05-12 09:28:26 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:28:26 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:28:26 --> Utf8 Class Initialized
INFO - 2017-05-12 09:28:26 --> URI Class Initialized
INFO - 2017-05-12 09:28:26 --> Router Class Initialized
INFO - 2017-05-12 09:28:26 --> Output Class Initialized
INFO - 2017-05-12 09:28:26 --> Security Class Initialized
DEBUG - 2017-05-12 09:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:28:26 --> Input Class Initialized
INFO - 2017-05-12 09:28:26 --> Language Class Initialized
ERROR - 2017-05-12 09:28:26 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 09:28:26 --> Config Class Initialized
INFO - 2017-05-12 09:28:26 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:28:26 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:28:26 --> Utf8 Class Initialized
INFO - 2017-05-12 09:28:26 --> URI Class Initialized
INFO - 2017-05-12 09:28:26 --> Router Class Initialized
INFO - 2017-05-12 09:28:26 --> Output Class Initialized
INFO - 2017-05-12 09:28:26 --> Security Class Initialized
DEBUG - 2017-05-12 09:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:28:26 --> Input Class Initialized
INFO - 2017-05-12 09:28:26 --> Language Class Initialized
INFO - 2017-05-12 09:28:26 --> Loader Class Initialized
INFO - 2017-05-12 09:28:26 --> Helper loaded: url_helper
INFO - 2017-05-12 09:28:26 --> Helper loaded: form_helper
INFO - 2017-05-12 09:28:26 --> Helper loaded: html_helper
INFO - 2017-05-12 09:28:26 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:28:26 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:28:26 --> Database Driver Class Initialized
INFO - 2017-05-12 09:28:26 --> Parser Class Initialized
DEBUG - 2017-05-12 09:28:26 --> Session Class Initialized
INFO - 2017-05-12 09:28:26 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:28:26 --> Session routines successfully run
INFO - 2017-05-12 09:28:26 --> Form Validation Class Initialized
INFO - 2017-05-12 09:28:26 --> Controller Class Initialized
DEBUG - 2017-05-12 09:28:26 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:28:26 --> Model Class Initialized
DEBUG - 2017-05-12 09:28:26 --> Pagination Class Initialized
INFO - 2017-05-12 09:28:26 --> Final output sent to browser
DEBUG - 2017-05-12 09:28:26 --> Total execution time: 0.2306
INFO - 2017-05-12 09:28:28 --> Config Class Initialized
INFO - 2017-05-12 09:28:28 --> Hooks Class Initialized
DEBUG - 2017-05-12 09:28:28 --> UTF-8 Support Enabled
INFO - 2017-05-12 09:28:28 --> Utf8 Class Initialized
INFO - 2017-05-12 09:28:28 --> URI Class Initialized
INFO - 2017-05-12 09:28:28 --> Router Class Initialized
INFO - 2017-05-12 09:28:28 --> Output Class Initialized
INFO - 2017-05-12 09:28:28 --> Security Class Initialized
DEBUG - 2017-05-12 09:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 09:28:28 --> Input Class Initialized
INFO - 2017-05-12 09:28:28 --> Language Class Initialized
INFO - 2017-05-12 09:28:28 --> Loader Class Initialized
INFO - 2017-05-12 09:28:28 --> Helper loaded: url_helper
INFO - 2017-05-12 09:28:28 --> Helper loaded: form_helper
INFO - 2017-05-12 09:28:28 --> Helper loaded: html_helper
INFO - 2017-05-12 09:28:28 --> Helper loaded: custom_helper
INFO - 2017-05-12 09:28:28 --> Helper loaded: cache_helper
INFO - 2017-05-12 09:28:28 --> Database Driver Class Initialized
INFO - 2017-05-12 09:28:28 --> Parser Class Initialized
DEBUG - 2017-05-12 09:28:28 --> Session Class Initialized
INFO - 2017-05-12 09:28:28 --> Helper loaded: string_helper
DEBUG - 2017-05-12 09:28:28 --> Session routines successfully run
INFO - 2017-05-12 09:28:28 --> Form Validation Class Initialized
INFO - 2017-05-12 09:28:28 --> Controller Class Initialized
DEBUG - 2017-05-12 09:28:28 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 09:28:28 --> Model Class Initialized
DEBUG - 2017-05-12 09:28:28 --> Pagination Class Initialized
DEBUG - 2017-05-12 09:28:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 09:28:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 10:44:39 --> Config Class Initialized
INFO - 2017-05-12 10:44:39 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:44:39 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:44:39 --> Utf8 Class Initialized
INFO - 2017-05-12 10:44:39 --> URI Class Initialized
INFO - 2017-05-12 10:44:39 --> Router Class Initialized
INFO - 2017-05-12 10:44:39 --> Output Class Initialized
INFO - 2017-05-12 10:44:39 --> Security Class Initialized
DEBUG - 2017-05-12 10:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:44:39 --> Input Class Initialized
INFO - 2017-05-12 10:44:39 --> Language Class Initialized
INFO - 2017-05-12 10:44:39 --> Loader Class Initialized
INFO - 2017-05-12 10:44:39 --> Helper loaded: url_helper
INFO - 2017-05-12 10:44:39 --> Helper loaded: form_helper
INFO - 2017-05-12 10:44:39 --> Helper loaded: html_helper
INFO - 2017-05-12 10:44:39 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:44:39 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:44:39 --> Database Driver Class Initialized
INFO - 2017-05-12 10:44:39 --> Parser Class Initialized
DEBUG - 2017-05-12 10:44:39 --> Session Class Initialized
INFO - 2017-05-12 10:44:39 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:44:39 --> Session routines successfully run
INFO - 2017-05-12 10:44:39 --> Form Validation Class Initialized
INFO - 2017-05-12 10:44:39 --> Controller Class Initialized
DEBUG - 2017-05-12 10:44:39 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:44:40 --> Model Class Initialized
DEBUG - 2017-05-12 10:44:40 --> Pagination Class Initialized
DEBUG - 2017-05-12 10:44:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 10:44:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 10:44:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 10:44:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 10:44:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 10:44:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 10:44:40 --> Final output sent to browser
DEBUG - 2017-05-12 10:44:40 --> Total execution time: 0.3599
INFO - 2017-05-12 10:44:40 --> Config Class Initialized
INFO - 2017-05-12 10:44:40 --> Config Class Initialized
INFO - 2017-05-12 10:44:40 --> Hooks Class Initialized
INFO - 2017-05-12 10:44:40 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:44:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 10:44:40 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:44:40 --> Utf8 Class Initialized
INFO - 2017-05-12 10:44:41 --> Utf8 Class Initialized
INFO - 2017-05-12 10:44:41 --> URI Class Initialized
INFO - 2017-05-12 10:44:41 --> URI Class Initialized
INFO - 2017-05-12 10:44:41 --> Router Class Initialized
INFO - 2017-05-12 10:44:41 --> Router Class Initialized
INFO - 2017-05-12 10:44:41 --> Output Class Initialized
INFO - 2017-05-12 10:44:41 --> Output Class Initialized
INFO - 2017-05-12 10:44:41 --> Security Class Initialized
INFO - 2017-05-12 10:44:41 --> Security Class Initialized
DEBUG - 2017-05-12 10:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:44:41 --> Input Class Initialized
DEBUG - 2017-05-12 10:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:44:41 --> Input Class Initialized
INFO - 2017-05-12 10:44:41 --> Language Class Initialized
INFO - 2017-05-12 10:44:41 --> Language Class Initialized
ERROR - 2017-05-12 10:44:41 --> 404 Page Not Found: Default/assets
ERROR - 2017-05-12 10:44:41 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 10:44:41 --> Config Class Initialized
INFO - 2017-05-12 10:44:41 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:44:41 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:44:41 --> Utf8 Class Initialized
INFO - 2017-05-12 10:44:41 --> URI Class Initialized
INFO - 2017-05-12 10:44:41 --> Router Class Initialized
INFO - 2017-05-12 10:44:41 --> Output Class Initialized
INFO - 2017-05-12 10:44:41 --> Security Class Initialized
DEBUG - 2017-05-12 10:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:44:41 --> Input Class Initialized
INFO - 2017-05-12 10:44:41 --> Language Class Initialized
INFO - 2017-05-12 10:44:41 --> Loader Class Initialized
INFO - 2017-05-12 10:44:41 --> Helper loaded: url_helper
INFO - 2017-05-12 10:44:41 --> Helper loaded: form_helper
INFO - 2017-05-12 10:44:41 --> Helper loaded: html_helper
INFO - 2017-05-12 10:44:41 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:44:41 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:44:41 --> Database Driver Class Initialized
INFO - 2017-05-12 10:44:41 --> Parser Class Initialized
DEBUG - 2017-05-12 10:44:41 --> Session Class Initialized
INFO - 2017-05-12 10:44:41 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:44:41 --> Session routines successfully run
INFO - 2017-05-12 10:44:41 --> Form Validation Class Initialized
INFO - 2017-05-12 10:44:41 --> Controller Class Initialized
DEBUG - 2017-05-12 10:44:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:44:41 --> Model Class Initialized
DEBUG - 2017-05-12 10:44:41 --> Pagination Class Initialized
ERROR - 2017-05-12 10:44:41 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 884
ERROR - 2017-05-12 10:44:41 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 887
INFO - 2017-05-12 10:44:41 --> Final output sent to browser
DEBUG - 2017-05-12 10:44:41 --> Total execution time: 0.4374
INFO - 2017-05-12 10:45:01 --> Config Class Initialized
INFO - 2017-05-12 10:45:01 --> Config Class Initialized
INFO - 2017-05-12 10:45:01 --> Hooks Class Initialized
INFO - 2017-05-12 10:45:01 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:45:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 10:45:01 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:45:01 --> Utf8 Class Initialized
INFO - 2017-05-12 10:45:01 --> Utf8 Class Initialized
INFO - 2017-05-12 10:45:01 --> URI Class Initialized
INFO - 2017-05-12 10:45:01 --> URI Class Initialized
INFO - 2017-05-12 10:45:01 --> Router Class Initialized
INFO - 2017-05-12 10:45:01 --> Router Class Initialized
INFO - 2017-05-12 10:45:01 --> Output Class Initialized
INFO - 2017-05-12 10:45:01 --> Output Class Initialized
INFO - 2017-05-12 10:45:01 --> Security Class Initialized
INFO - 2017-05-12 10:45:01 --> Security Class Initialized
DEBUG - 2017-05-12 10:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 10:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:45:01 --> Input Class Initialized
INFO - 2017-05-12 10:45:01 --> Input Class Initialized
INFO - 2017-05-12 10:45:01 --> Language Class Initialized
INFO - 2017-05-12 10:45:01 --> Language Class Initialized
INFO - 2017-05-12 10:45:01 --> Loader Class Initialized
INFO - 2017-05-12 10:45:01 --> Loader Class Initialized
INFO - 2017-05-12 10:45:01 --> Helper loaded: url_helper
INFO - 2017-05-12 10:45:01 --> Helper loaded: url_helper
INFO - 2017-05-12 10:45:01 --> Helper loaded: form_helper
INFO - 2017-05-12 10:45:01 --> Helper loaded: form_helper
INFO - 2017-05-12 10:45:01 --> Helper loaded: html_helper
INFO - 2017-05-12 10:45:01 --> Helper loaded: html_helper
INFO - 2017-05-12 10:45:01 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:45:01 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:45:01 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:45:01 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:45:01 --> Database Driver Class Initialized
INFO - 2017-05-12 10:45:01 --> Database Driver Class Initialized
INFO - 2017-05-12 10:45:01 --> Parser Class Initialized
INFO - 2017-05-12 10:45:01 --> Parser Class Initialized
DEBUG - 2017-05-12 10:45:01 --> Session Class Initialized
DEBUG - 2017-05-12 10:45:01 --> Session Class Initialized
INFO - 2017-05-12 10:45:01 --> Helper loaded: string_helper
INFO - 2017-05-12 10:45:01 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:45:01 --> Session routines successfully run
DEBUG - 2017-05-12 10:45:01 --> Session routines successfully run
INFO - 2017-05-12 10:45:01 --> Form Validation Class Initialized
INFO - 2017-05-12 10:45:01 --> Form Validation Class Initialized
INFO - 2017-05-12 10:45:01 --> Controller Class Initialized
INFO - 2017-05-12 10:45:01 --> Controller Class Initialized
DEBUG - 2017-05-12 10:45:01 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2017-05-12 10:45:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:45:01 --> Model Class Initialized
INFO - 2017-05-12 10:45:01 --> Model Class Initialized
DEBUG - 2017-05-12 10:45:01 --> Pagination Class Initialized
DEBUG - 2017-05-12 10:45:01 --> Pagination Class Initialized
INFO - 2017-05-12 10:45:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2017-05-12 10:45:01 --> Final output sent to browser
INFO - 2017-05-12 10:45:01 --> Final output sent to browser
DEBUG - 2017-05-12 10:45:01 --> Total execution time: 0.3869
DEBUG - 2017-05-12 10:45:01 --> Total execution time: 0.3938
INFO - 2017-05-12 10:45:05 --> Config Class Initialized
INFO - 2017-05-12 10:45:05 --> Config Class Initialized
INFO - 2017-05-12 10:45:05 --> Hooks Class Initialized
INFO - 2017-05-12 10:45:05 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 10:45:05 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:45:05 --> Utf8 Class Initialized
INFO - 2017-05-12 10:45:05 --> Utf8 Class Initialized
INFO - 2017-05-12 10:45:05 --> URI Class Initialized
INFO - 2017-05-12 10:45:05 --> URI Class Initialized
INFO - 2017-05-12 10:45:05 --> Router Class Initialized
INFO - 2017-05-12 10:45:05 --> Router Class Initialized
INFO - 2017-05-12 10:45:05 --> Output Class Initialized
INFO - 2017-05-12 10:45:05 --> Output Class Initialized
INFO - 2017-05-12 10:45:05 --> Security Class Initialized
INFO - 2017-05-12 10:45:05 --> Security Class Initialized
DEBUG - 2017-05-12 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 10:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:45:05 --> Input Class Initialized
INFO - 2017-05-12 10:45:05 --> Input Class Initialized
INFO - 2017-05-12 10:45:05 --> Language Class Initialized
INFO - 2017-05-12 10:45:05 --> Language Class Initialized
INFO - 2017-05-12 10:45:05 --> Loader Class Initialized
INFO - 2017-05-12 10:45:05 --> Loader Class Initialized
INFO - 2017-05-12 10:45:05 --> Helper loaded: url_helper
INFO - 2017-05-12 10:45:05 --> Helper loaded: url_helper
INFO - 2017-05-12 10:45:05 --> Helper loaded: form_helper
INFO - 2017-05-12 10:45:05 --> Helper loaded: form_helper
INFO - 2017-05-12 10:45:05 --> Helper loaded: html_helper
INFO - 2017-05-12 10:45:05 --> Helper loaded: html_helper
INFO - 2017-05-12 10:45:05 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:45:05 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:45:05 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:45:05 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:45:05 --> Database Driver Class Initialized
INFO - 2017-05-12 10:45:05 --> Database Driver Class Initialized
INFO - 2017-05-12 10:45:05 --> Parser Class Initialized
INFO - 2017-05-12 10:45:05 --> Parser Class Initialized
DEBUG - 2017-05-12 10:45:05 --> Session Class Initialized
DEBUG - 2017-05-12 10:45:05 --> Session Class Initialized
INFO - 2017-05-12 10:45:05 --> Helper loaded: string_helper
INFO - 2017-05-12 10:45:05 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:45:05 --> Session routines successfully run
DEBUG - 2017-05-12 10:45:05 --> Session routines successfully run
INFO - 2017-05-12 10:45:05 --> Form Validation Class Initialized
INFO - 2017-05-12 10:45:05 --> Form Validation Class Initialized
INFO - 2017-05-12 10:45:05 --> Controller Class Initialized
INFO - 2017-05-12 10:45:05 --> Controller Class Initialized
DEBUG - 2017-05-12 10:45:05 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2017-05-12 10:45:05 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:45:05 --> Model Class Initialized
INFO - 2017-05-12 10:45:05 --> Model Class Initialized
DEBUG - 2017-05-12 10:45:05 --> Pagination Class Initialized
DEBUG - 2017-05-12 10:45:05 --> Pagination Class Initialized
INFO - 2017-05-12 10:45:05 --> Final output sent to browser
INFO - 2017-05-12 10:45:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
DEBUG - 2017-05-12 10:45:05 --> Total execution time: 0.2656
INFO - 2017-05-12 10:45:05 --> Final output sent to browser
DEBUG - 2017-05-12 10:45:06 --> Total execution time: 0.2877
INFO - 2017-05-12 10:45:19 --> Config Class Initialized
INFO - 2017-05-12 10:45:19 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:45:19 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:45:19 --> Utf8 Class Initialized
INFO - 2017-05-12 10:45:19 --> URI Class Initialized
INFO - 2017-05-12 10:45:19 --> Router Class Initialized
INFO - 2017-05-12 10:45:19 --> Output Class Initialized
INFO - 2017-05-12 10:45:19 --> Security Class Initialized
DEBUG - 2017-05-12 10:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:45:19 --> Input Class Initialized
INFO - 2017-05-12 10:45:19 --> Language Class Initialized
INFO - 2017-05-12 10:45:19 --> Loader Class Initialized
INFO - 2017-05-12 10:45:19 --> Helper loaded: url_helper
INFO - 2017-05-12 10:45:19 --> Helper loaded: form_helper
INFO - 2017-05-12 10:45:19 --> Helper loaded: html_helper
INFO - 2017-05-12 10:45:19 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:45:19 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:45:19 --> Database Driver Class Initialized
INFO - 2017-05-12 10:45:19 --> Parser Class Initialized
DEBUG - 2017-05-12 10:45:19 --> Session Class Initialized
INFO - 2017-05-12 10:45:19 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:45:19 --> Session routines successfully run
INFO - 2017-05-12 10:45:19 --> Form Validation Class Initialized
INFO - 2017-05-12 10:45:19 --> Controller Class Initialized
DEBUG - 2017-05-12 10:45:19 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:45:19 --> Model Class Initialized
DEBUG - 2017-05-12 10:45:19 --> Pagination Class Initialized
INFO - 2017-05-12 10:45:19 --> Final output sent to browser
DEBUG - 2017-05-12 10:45:19 --> Total execution time: 0.2423
INFO - 2017-05-12 10:45:32 --> Config Class Initialized
INFO - 2017-05-12 10:45:32 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:45:32 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:45:32 --> Utf8 Class Initialized
INFO - 2017-05-12 10:45:32 --> URI Class Initialized
INFO - 2017-05-12 10:45:32 --> Router Class Initialized
INFO - 2017-05-12 10:45:32 --> Output Class Initialized
INFO - 2017-05-12 10:45:32 --> Security Class Initialized
DEBUG - 2017-05-12 10:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:45:32 --> Input Class Initialized
INFO - 2017-05-12 10:45:32 --> Language Class Initialized
INFO - 2017-05-12 10:45:32 --> Loader Class Initialized
INFO - 2017-05-12 10:45:32 --> Helper loaded: url_helper
INFO - 2017-05-12 10:45:32 --> Helper loaded: form_helper
INFO - 2017-05-12 10:45:32 --> Helper loaded: html_helper
INFO - 2017-05-12 10:45:32 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:45:32 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:45:32 --> Database Driver Class Initialized
INFO - 2017-05-12 10:45:32 --> Parser Class Initialized
DEBUG - 2017-05-12 10:45:32 --> Session Class Initialized
INFO - 2017-05-12 10:45:32 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:45:32 --> Session routines successfully run
INFO - 2017-05-12 10:45:32 --> Form Validation Class Initialized
INFO - 2017-05-12 10:45:33 --> Controller Class Initialized
DEBUG - 2017-05-12 10:45:33 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:45:33 --> Model Class Initialized
DEBUG - 2017-05-12 10:45:33 --> Pagination Class Initialized
INFO - 2017-05-12 10:45:33 --> Final output sent to browser
DEBUG - 2017-05-12 10:45:33 --> Total execution time: 0.2310
INFO - 2017-05-12 10:45:43 --> Config Class Initialized
INFO - 2017-05-12 10:45:43 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:45:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:45:43 --> Utf8 Class Initialized
INFO - 2017-05-12 10:45:43 --> URI Class Initialized
INFO - 2017-05-12 10:45:43 --> Router Class Initialized
INFO - 2017-05-12 10:45:43 --> Output Class Initialized
INFO - 2017-05-12 10:45:43 --> Security Class Initialized
DEBUG - 2017-05-12 10:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:45:43 --> Input Class Initialized
INFO - 2017-05-12 10:45:43 --> Language Class Initialized
INFO - 2017-05-12 10:45:43 --> Loader Class Initialized
INFO - 2017-05-12 10:45:44 --> Helper loaded: url_helper
INFO - 2017-05-12 10:45:44 --> Helper loaded: form_helper
INFO - 2017-05-12 10:45:44 --> Helper loaded: html_helper
INFO - 2017-05-12 10:45:44 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:45:44 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:45:44 --> Database Driver Class Initialized
INFO - 2017-05-12 10:45:44 --> Parser Class Initialized
DEBUG - 2017-05-12 10:45:44 --> Session Class Initialized
INFO - 2017-05-12 10:45:44 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:45:44 --> Session routines successfully run
INFO - 2017-05-12 10:45:44 --> Form Validation Class Initialized
INFO - 2017-05-12 10:45:44 --> Controller Class Initialized
DEBUG - 2017-05-12 10:45:44 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:45:44 --> Model Class Initialized
DEBUG - 2017-05-12 10:45:44 --> Pagination Class Initialized
DEBUG - 2017-05-12 10:45:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 10:45:44 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-05-12 10:45:44 --> Query error: Column 'staff_level' cannot be null - Invalid query: INSERT INTO `users` (`first_name`, `last_name`, `email`, `password`, `staff_level`, `user_time_zone`, `is_manager`, `is_administrator`, `company_id`, `country_id`, `user_status`, `email_verification_code`, `signup_date`, `signup_IP`) VALUES ('www', 'www', 'www@gmail.com', 'aa57c3db69086f13f9b60b4b3de58f38', NULL, 'America/Argentina/Buenos_Aires', '0', '', '97', '17', 'active', '76EPxRPAGC6u', '2017-05-12 10:45:44', '127.0.0.1')
INFO - 2017-05-12 10:45:44 --> Language file loaded: language/english/db_lang.php
INFO - 2017-05-12 10:47:13 --> Config Class Initialized
INFO - 2017-05-12 10:47:13 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:47:13 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:47:13 --> Utf8 Class Initialized
INFO - 2017-05-12 10:47:13 --> URI Class Initialized
INFO - 2017-05-12 10:47:13 --> Router Class Initialized
INFO - 2017-05-12 10:47:13 --> Output Class Initialized
INFO - 2017-05-12 10:47:13 --> Security Class Initialized
DEBUG - 2017-05-12 10:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:47:13 --> Input Class Initialized
INFO - 2017-05-12 10:47:13 --> Language Class Initialized
INFO - 2017-05-12 10:47:13 --> Loader Class Initialized
INFO - 2017-05-12 10:47:14 --> Helper loaded: url_helper
INFO - 2017-05-12 10:47:14 --> Helper loaded: form_helper
INFO - 2017-05-12 10:47:14 --> Helper loaded: html_helper
INFO - 2017-05-12 10:47:14 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:47:14 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:47:14 --> Database Driver Class Initialized
INFO - 2017-05-12 10:47:14 --> Parser Class Initialized
DEBUG - 2017-05-12 10:47:14 --> Session Class Initialized
INFO - 2017-05-12 10:47:14 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:47:14 --> Session routines successfully run
INFO - 2017-05-12 10:47:14 --> Form Validation Class Initialized
INFO - 2017-05-12 10:47:14 --> Controller Class Initialized
DEBUG - 2017-05-12 10:47:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:49:03 --> Config Class Initialized
INFO - 2017-05-12 10:49:03 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:49:03 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:49:03 --> Utf8 Class Initialized
INFO - 2017-05-12 10:49:03 --> URI Class Initialized
INFO - 2017-05-12 10:49:03 --> Router Class Initialized
INFO - 2017-05-12 10:49:03 --> Output Class Initialized
INFO - 2017-05-12 10:49:03 --> Security Class Initialized
DEBUG - 2017-05-12 10:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:49:03 --> Input Class Initialized
INFO - 2017-05-12 10:49:03 --> Language Class Initialized
INFO - 2017-05-12 10:49:03 --> Loader Class Initialized
INFO - 2017-05-12 10:49:03 --> Helper loaded: url_helper
INFO - 2017-05-12 10:49:03 --> Helper loaded: form_helper
INFO - 2017-05-12 10:49:03 --> Helper loaded: html_helper
INFO - 2017-05-12 10:49:03 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:49:03 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:49:03 --> Database Driver Class Initialized
INFO - 2017-05-12 10:49:03 --> Parser Class Initialized
DEBUG - 2017-05-12 10:49:03 --> Session Class Initialized
INFO - 2017-05-12 10:49:03 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:49:03 --> Session routines successfully run
INFO - 2017-05-12 10:49:03 --> Form Validation Class Initialized
INFO - 2017-05-12 10:49:03 --> Controller Class Initialized
DEBUG - 2017-05-12 10:49:03 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:49:21 --> Config Class Initialized
INFO - 2017-05-12 10:49:21 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:49:21 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:49:21 --> Utf8 Class Initialized
INFO - 2017-05-12 10:49:21 --> URI Class Initialized
INFO - 2017-05-12 10:49:21 --> Router Class Initialized
INFO - 2017-05-12 10:49:21 --> Output Class Initialized
INFO - 2017-05-12 10:49:21 --> Security Class Initialized
DEBUG - 2017-05-12 10:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:49:21 --> Input Class Initialized
INFO - 2017-05-12 10:49:21 --> Language Class Initialized
INFO - 2017-05-12 10:49:21 --> Loader Class Initialized
INFO - 2017-05-12 10:49:21 --> Helper loaded: url_helper
INFO - 2017-05-12 10:49:21 --> Helper loaded: form_helper
INFO - 2017-05-12 10:49:21 --> Helper loaded: html_helper
INFO - 2017-05-12 10:49:21 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:49:21 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:49:21 --> Database Driver Class Initialized
INFO - 2017-05-12 10:49:21 --> Parser Class Initialized
DEBUG - 2017-05-12 10:49:21 --> Session Class Initialized
INFO - 2017-05-12 10:49:21 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:49:21 --> Session routines successfully run
INFO - 2017-05-12 10:49:21 --> Form Validation Class Initialized
INFO - 2017-05-12 10:49:21 --> Controller Class Initialized
DEBUG - 2017-05-12 10:49:21 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:51:36 --> Config Class Initialized
INFO - 2017-05-12 10:51:36 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:51:36 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:51:36 --> Utf8 Class Initialized
INFO - 2017-05-12 10:51:36 --> URI Class Initialized
INFO - 2017-05-12 10:51:36 --> Router Class Initialized
INFO - 2017-05-12 10:51:36 --> Output Class Initialized
INFO - 2017-05-12 10:51:36 --> Security Class Initialized
DEBUG - 2017-05-12 10:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:51:36 --> Input Class Initialized
INFO - 2017-05-12 10:51:36 --> Language Class Initialized
INFO - 2017-05-12 10:51:36 --> Loader Class Initialized
INFO - 2017-05-12 10:51:36 --> Helper loaded: url_helper
INFO - 2017-05-12 10:51:36 --> Helper loaded: form_helper
INFO - 2017-05-12 10:51:36 --> Helper loaded: html_helper
INFO - 2017-05-12 10:51:36 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:51:36 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:51:36 --> Database Driver Class Initialized
INFO - 2017-05-12 10:51:36 --> Parser Class Initialized
DEBUG - 2017-05-12 10:51:36 --> Session Class Initialized
INFO - 2017-05-12 10:51:36 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:51:36 --> Session routines successfully run
INFO - 2017-05-12 10:51:36 --> Form Validation Class Initialized
INFO - 2017-05-12 10:51:36 --> Controller Class Initialized
DEBUG - 2017-05-12 10:51:36 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:51:36 --> Model Class Initialized
DEBUG - 2017-05-12 10:51:36 --> Pagination Class Initialized
DEBUG - 2017-05-12 10:51:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 10:51:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 10:51:37 --> Config Class Initialized
INFO - 2017-05-12 10:51:37 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:51:37 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:51:37 --> Utf8 Class Initialized
INFO - 2017-05-12 10:51:37 --> URI Class Initialized
INFO - 2017-05-12 10:51:37 --> Router Class Initialized
INFO - 2017-05-12 10:51:37 --> Output Class Initialized
INFO - 2017-05-12 10:51:37 --> Security Class Initialized
DEBUG - 2017-05-12 10:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:51:37 --> Input Class Initialized
INFO - 2017-05-12 10:51:37 --> Language Class Initialized
INFO - 2017-05-12 10:51:37 --> Loader Class Initialized
INFO - 2017-05-12 10:51:37 --> Helper loaded: url_helper
INFO - 2017-05-12 10:51:37 --> Helper loaded: form_helper
INFO - 2017-05-12 10:51:37 --> Helper loaded: html_helper
INFO - 2017-05-12 10:51:37 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:51:37 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:51:37 --> Database Driver Class Initialized
INFO - 2017-05-12 10:51:37 --> Parser Class Initialized
DEBUG - 2017-05-12 10:51:37 --> Session Class Initialized
INFO - 2017-05-12 10:51:37 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:51:37 --> Session routines successfully run
INFO - 2017-05-12 10:51:37 --> Form Validation Class Initialized
INFO - 2017-05-12 10:51:37 --> Controller Class Initialized
DEBUG - 2017-05-12 10:51:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:51:37 --> Model Class Initialized
DEBUG - 2017-05-12 10:51:37 --> Pagination Class Initialized
INFO - 2017-05-12 10:51:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 10:51:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 10:51:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:38 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:39 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:40 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:51:42 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:51:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:51:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:51:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:51:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 10:51:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 10:51:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 10:51:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 10:51:42 --> Final output sent to browser
DEBUG - 2017-05-12 10:51:42 --> Total execution time: 4.9325
INFO - 2017-05-12 10:51:48 --> Config Class Initialized
INFO - 2017-05-12 10:51:48 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:51:48 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:51:48 --> Utf8 Class Initialized
INFO - 2017-05-12 10:51:48 --> URI Class Initialized
INFO - 2017-05-12 10:51:48 --> Router Class Initialized
INFO - 2017-05-12 10:51:48 --> Output Class Initialized
INFO - 2017-05-12 10:51:48 --> Security Class Initialized
DEBUG - 2017-05-12 10:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:51:48 --> Input Class Initialized
INFO - 2017-05-12 10:51:48 --> Language Class Initialized
INFO - 2017-05-12 10:51:48 --> Loader Class Initialized
INFO - 2017-05-12 10:51:48 --> Helper loaded: url_helper
INFO - 2017-05-12 10:51:48 --> Helper loaded: form_helper
INFO - 2017-05-12 10:51:48 --> Helper loaded: html_helper
INFO - 2017-05-12 10:51:48 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:51:48 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:51:48 --> Database Driver Class Initialized
INFO - 2017-05-12 10:51:48 --> Parser Class Initialized
DEBUG - 2017-05-12 10:51:48 --> Session Class Initialized
INFO - 2017-05-12 10:51:48 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:51:48 --> Session routines successfully run
INFO - 2017-05-12 10:51:48 --> Form Validation Class Initialized
INFO - 2017-05-12 10:51:48 --> Controller Class Initialized
DEBUG - 2017-05-12 10:51:48 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:51:48 --> Model Class Initialized
DEBUG - 2017-05-12 10:51:48 --> Pagination Class Initialized
INFO - 2017-05-12 10:51:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 10:51:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 10:51:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 10:51:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 10:51:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 10:51:48 --> Final output sent to browser
DEBUG - 2017-05-12 10:51:48 --> Total execution time: 0.3361
INFO - 2017-05-12 10:51:48 --> Config Class Initialized
INFO - 2017-05-12 10:51:48 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:51:48 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:51:48 --> Utf8 Class Initialized
INFO - 2017-05-12 10:51:48 --> Config Class Initialized
INFO - 2017-05-12 10:51:48 --> Hooks Class Initialized
INFO - 2017-05-12 10:51:48 --> URI Class Initialized
DEBUG - 2017-05-12 10:51:48 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:51:48 --> Router Class Initialized
INFO - 2017-05-12 10:51:48 --> Utf8 Class Initialized
INFO - 2017-05-12 10:51:48 --> URI Class Initialized
INFO - 2017-05-12 10:51:48 --> Output Class Initialized
INFO - 2017-05-12 10:51:48 --> Router Class Initialized
INFO - 2017-05-12 10:51:48 --> Security Class Initialized
INFO - 2017-05-12 10:51:48 --> Output Class Initialized
DEBUG - 2017-05-12 10:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:51:48 --> Security Class Initialized
INFO - 2017-05-12 10:51:48 --> Input Class Initialized
INFO - 2017-05-12 10:51:48 --> Language Class Initialized
DEBUG - 2017-05-12 10:51:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-05-12 10:51:48 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 10:51:48 --> Input Class Initialized
INFO - 2017-05-12 10:51:48 --> Language Class Initialized
ERROR - 2017-05-12 10:51:48 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 10:51:48 --> Config Class Initialized
INFO - 2017-05-12 10:51:48 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:51:48 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:51:48 --> Utf8 Class Initialized
INFO - 2017-05-12 10:51:48 --> URI Class Initialized
INFO - 2017-05-12 10:51:48 --> Router Class Initialized
INFO - 2017-05-12 10:51:48 --> Output Class Initialized
INFO - 2017-05-12 10:51:48 --> Security Class Initialized
DEBUG - 2017-05-12 10:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:51:48 --> Input Class Initialized
INFO - 2017-05-12 10:51:48 --> Language Class Initialized
ERROR - 2017-05-12 10:51:48 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 10:51:48 --> Config Class Initialized
INFO - 2017-05-12 10:51:48 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:51:48 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:51:48 --> Utf8 Class Initialized
INFO - 2017-05-12 10:51:48 --> URI Class Initialized
INFO - 2017-05-12 10:51:48 --> Router Class Initialized
INFO - 2017-05-12 10:51:48 --> Output Class Initialized
INFO - 2017-05-12 10:51:48 --> Security Class Initialized
DEBUG - 2017-05-12 10:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:51:48 --> Input Class Initialized
INFO - 2017-05-12 10:51:48 --> Language Class Initialized
INFO - 2017-05-12 10:51:48 --> Loader Class Initialized
INFO - 2017-05-12 10:51:48 --> Helper loaded: url_helper
INFO - 2017-05-12 10:51:48 --> Helper loaded: form_helper
INFO - 2017-05-12 10:51:48 --> Helper loaded: html_helper
INFO - 2017-05-12 10:51:49 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:51:49 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:51:49 --> Database Driver Class Initialized
INFO - 2017-05-12 10:51:49 --> Parser Class Initialized
DEBUG - 2017-05-12 10:51:49 --> Session Class Initialized
INFO - 2017-05-12 10:51:49 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:51:49 --> Session routines successfully run
INFO - 2017-05-12 10:51:49 --> Form Validation Class Initialized
INFO - 2017-05-12 10:51:49 --> Controller Class Initialized
DEBUG - 2017-05-12 10:51:49 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:51:49 --> Model Class Initialized
DEBUG - 2017-05-12 10:51:49 --> Pagination Class Initialized
INFO - 2017-05-12 10:51:49 --> Final output sent to browser
DEBUG - 2017-05-12 10:51:49 --> Total execution time: 0.3808
INFO - 2017-05-12 10:52:43 --> Config Class Initialized
INFO - 2017-05-12 10:52:43 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:52:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:52:43 --> Utf8 Class Initialized
INFO - 2017-05-12 10:52:43 --> URI Class Initialized
INFO - 2017-05-12 10:52:43 --> Router Class Initialized
INFO - 2017-05-12 10:52:43 --> Output Class Initialized
INFO - 2017-05-12 10:52:43 --> Security Class Initialized
DEBUG - 2017-05-12 10:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:52:43 --> Input Class Initialized
INFO - 2017-05-12 10:52:43 --> Language Class Initialized
INFO - 2017-05-12 10:52:43 --> Loader Class Initialized
INFO - 2017-05-12 10:52:43 --> Helper loaded: url_helper
INFO - 2017-05-12 10:52:43 --> Helper loaded: form_helper
INFO - 2017-05-12 10:52:43 --> Helper loaded: html_helper
INFO - 2017-05-12 10:52:43 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:52:43 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:52:43 --> Database Driver Class Initialized
INFO - 2017-05-12 10:52:43 --> Parser Class Initialized
DEBUG - 2017-05-12 10:52:43 --> Session Class Initialized
INFO - 2017-05-12 10:52:43 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:52:43 --> Session routines successfully run
INFO - 2017-05-12 10:52:43 --> Form Validation Class Initialized
INFO - 2017-05-12 10:52:43 --> Controller Class Initialized
DEBUG - 2017-05-12 10:52:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:52:43 --> Model Class Initialized
DEBUG - 2017-05-12 10:52:43 --> Pagination Class Initialized
DEBUG - 2017-05-12 10:52:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 10:52:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 10:52:43 --> Config Class Initialized
INFO - 2017-05-12 10:52:43 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:52:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:52:43 --> Utf8 Class Initialized
INFO - 2017-05-12 10:52:43 --> URI Class Initialized
INFO - 2017-05-12 10:52:43 --> Router Class Initialized
INFO - 2017-05-12 10:52:43 --> Output Class Initialized
INFO - 2017-05-12 10:52:43 --> Security Class Initialized
DEBUG - 2017-05-12 10:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:52:43 --> Input Class Initialized
INFO - 2017-05-12 10:52:43 --> Language Class Initialized
INFO - 2017-05-12 10:52:43 --> Loader Class Initialized
INFO - 2017-05-12 10:52:43 --> Helper loaded: url_helper
INFO - 2017-05-12 10:52:44 --> Helper loaded: form_helper
INFO - 2017-05-12 10:52:44 --> Helper loaded: html_helper
INFO - 2017-05-12 10:52:44 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:52:44 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:52:44 --> Database Driver Class Initialized
INFO - 2017-05-12 10:52:44 --> Parser Class Initialized
DEBUG - 2017-05-12 10:52:44 --> Session Class Initialized
INFO - 2017-05-12 10:52:44 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:52:44 --> Session routines successfully run
INFO - 2017-05-12 10:52:44 --> Form Validation Class Initialized
INFO - 2017-05-12 10:52:44 --> Controller Class Initialized
DEBUG - 2017-05-12 10:52:44 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:52:44 --> Model Class Initialized
DEBUG - 2017-05-12 10:52:44 --> Pagination Class Initialized
INFO - 2017-05-12 10:52:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 10:52:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:52:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:52:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:52:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:52:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:52:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 10:52:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 10:52:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 10:52:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 10:52:48 --> Final output sent to browser
DEBUG - 2017-05-12 10:52:48 --> Total execution time: 4.9121
INFO - 2017-05-12 10:52:57 --> Config Class Initialized
INFO - 2017-05-12 10:52:57 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:52:57 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:52:57 --> Utf8 Class Initialized
INFO - 2017-05-12 10:52:57 --> URI Class Initialized
INFO - 2017-05-12 10:52:57 --> Router Class Initialized
INFO - 2017-05-12 10:52:57 --> Output Class Initialized
INFO - 2017-05-12 10:52:57 --> Security Class Initialized
DEBUG - 2017-05-12 10:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:52:57 --> Input Class Initialized
INFO - 2017-05-12 10:52:57 --> Language Class Initialized
INFO - 2017-05-12 10:52:57 --> Loader Class Initialized
INFO - 2017-05-12 10:52:57 --> Helper loaded: url_helper
INFO - 2017-05-12 10:52:57 --> Helper loaded: form_helper
INFO - 2017-05-12 10:52:57 --> Helper loaded: html_helper
INFO - 2017-05-12 10:52:57 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:52:57 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:52:57 --> Database Driver Class Initialized
INFO - 2017-05-12 10:52:57 --> Parser Class Initialized
DEBUG - 2017-05-12 10:52:57 --> Session Class Initialized
INFO - 2017-05-12 10:52:57 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:52:57 --> Session routines successfully run
INFO - 2017-05-12 10:52:57 --> Form Validation Class Initialized
INFO - 2017-05-12 10:52:57 --> Controller Class Initialized
DEBUG - 2017-05-12 10:52:57 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:52:58 --> Model Class Initialized
DEBUG - 2017-05-12 10:52:58 --> Pagination Class Initialized
INFO - 2017-05-12 10:52:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 10:52:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 10:52:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 10:52:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 10:52:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 10:52:58 --> Final output sent to browser
DEBUG - 2017-05-12 10:52:58 --> Total execution time: 1.0547
INFO - 2017-05-12 10:52:58 --> Config Class Initialized
INFO - 2017-05-12 10:52:58 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:52:58 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:52:58 --> Utf8 Class Initialized
INFO - 2017-05-12 10:52:58 --> Config Class Initialized
INFO - 2017-05-12 10:52:58 --> URI Class Initialized
INFO - 2017-05-12 10:52:58 --> Hooks Class Initialized
INFO - 2017-05-12 10:52:58 --> Router Class Initialized
DEBUG - 2017-05-12 10:52:58 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:52:58 --> Output Class Initialized
INFO - 2017-05-12 10:52:58 --> Utf8 Class Initialized
INFO - 2017-05-12 10:52:58 --> URI Class Initialized
INFO - 2017-05-12 10:52:58 --> Security Class Initialized
DEBUG - 2017-05-12 10:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:52:58 --> Router Class Initialized
INFO - 2017-05-12 10:52:59 --> Input Class Initialized
INFO - 2017-05-12 10:52:59 --> Output Class Initialized
INFO - 2017-05-12 10:52:59 --> Language Class Initialized
INFO - 2017-05-12 10:52:59 --> Security Class Initialized
ERROR - 2017-05-12 10:52:59 --> 404 Page Not Found: Default/assets
DEBUG - 2017-05-12 10:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:52:59 --> Input Class Initialized
INFO - 2017-05-12 10:52:59 --> Language Class Initialized
ERROR - 2017-05-12 10:52:59 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 10:52:59 --> Config Class Initialized
INFO - 2017-05-12 10:52:59 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:52:59 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:52:59 --> Utf8 Class Initialized
INFO - 2017-05-12 10:52:59 --> URI Class Initialized
INFO - 2017-05-12 10:52:59 --> Router Class Initialized
INFO - 2017-05-12 10:52:59 --> Output Class Initialized
INFO - 2017-05-12 10:52:59 --> Security Class Initialized
DEBUG - 2017-05-12 10:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:52:59 --> Input Class Initialized
INFO - 2017-05-12 10:52:59 --> Language Class Initialized
INFO - 2017-05-12 10:52:59 --> Loader Class Initialized
INFO - 2017-05-12 10:52:59 --> Helper loaded: url_helper
INFO - 2017-05-12 10:52:59 --> Helper loaded: form_helper
INFO - 2017-05-12 10:52:59 --> Helper loaded: html_helper
INFO - 2017-05-12 10:52:59 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:52:59 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:52:59 --> Database Driver Class Initialized
INFO - 2017-05-12 10:52:59 --> Parser Class Initialized
DEBUG - 2017-05-12 10:52:59 --> Session Class Initialized
INFO - 2017-05-12 10:52:59 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:52:59 --> Session routines successfully run
INFO - 2017-05-12 10:52:59 --> Form Validation Class Initialized
INFO - 2017-05-12 10:52:59 --> Controller Class Initialized
DEBUG - 2017-05-12 10:52:59 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:52:59 --> Model Class Initialized
DEBUG - 2017-05-12 10:52:59 --> Pagination Class Initialized
INFO - 2017-05-12 10:52:59 --> Final output sent to browser
DEBUG - 2017-05-12 10:52:59 --> Total execution time: 0.3058
INFO - 2017-05-12 10:54:56 --> Config Class Initialized
INFO - 2017-05-12 10:54:56 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:54:56 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:54:56 --> Utf8 Class Initialized
INFO - 2017-05-12 10:54:56 --> URI Class Initialized
INFO - 2017-05-12 10:54:56 --> Router Class Initialized
INFO - 2017-05-12 10:54:56 --> Output Class Initialized
INFO - 2017-05-12 10:54:56 --> Security Class Initialized
DEBUG - 2017-05-12 10:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:54:56 --> Input Class Initialized
INFO - 2017-05-12 10:54:56 --> Language Class Initialized
INFO - 2017-05-12 10:54:56 --> Loader Class Initialized
INFO - 2017-05-12 10:54:56 --> Helper loaded: url_helper
INFO - 2017-05-12 10:54:56 --> Helper loaded: form_helper
INFO - 2017-05-12 10:54:56 --> Helper loaded: html_helper
INFO - 2017-05-12 10:54:56 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:54:56 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:54:56 --> Database Driver Class Initialized
INFO - 2017-05-12 10:54:56 --> Parser Class Initialized
DEBUG - 2017-05-12 10:54:56 --> Session Class Initialized
INFO - 2017-05-12 10:54:56 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:54:56 --> Session routines successfully run
INFO - 2017-05-12 10:54:56 --> Form Validation Class Initialized
INFO - 2017-05-12 10:54:56 --> Controller Class Initialized
DEBUG - 2017-05-12 10:54:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:54:56 --> Model Class Initialized
DEBUG - 2017-05-12 10:54:56 --> Pagination Class Initialized
INFO - 2017-05-12 10:54:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 10:54:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:55:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 10:55:01 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 10:55:01 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 10:55:01 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 10:55:01 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 10:55:01 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 10:55:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 10:55:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 10:55:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 10:55:01 --> Final output sent to browser
DEBUG - 2017-05-12 10:55:01 --> Total execution time: 4.9453
INFO - 2017-05-12 10:55:03 --> Config Class Initialized
INFO - 2017-05-12 10:55:03 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:55:03 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:55:03 --> Utf8 Class Initialized
INFO - 2017-05-12 10:55:03 --> URI Class Initialized
INFO - 2017-05-12 10:55:03 --> Router Class Initialized
INFO - 2017-05-12 10:55:03 --> Output Class Initialized
INFO - 2017-05-12 10:55:03 --> Security Class Initialized
DEBUG - 2017-05-12 10:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:55:03 --> Input Class Initialized
INFO - 2017-05-12 10:55:03 --> Language Class Initialized
INFO - 2017-05-12 10:55:03 --> Loader Class Initialized
INFO - 2017-05-12 10:55:03 --> Helper loaded: url_helper
INFO - 2017-05-12 10:55:03 --> Helper loaded: form_helper
INFO - 2017-05-12 10:55:03 --> Helper loaded: html_helper
INFO - 2017-05-12 10:55:03 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:55:03 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:55:03 --> Database Driver Class Initialized
INFO - 2017-05-12 10:55:03 --> Parser Class Initialized
DEBUG - 2017-05-12 10:55:03 --> Session Class Initialized
INFO - 2017-05-12 10:55:04 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:55:04 --> Session routines successfully run
INFO - 2017-05-12 10:55:04 --> Form Validation Class Initialized
INFO - 2017-05-12 10:55:04 --> Controller Class Initialized
DEBUG - 2017-05-12 10:55:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-12 10:55:04 --> Pagination Class Initialized
INFO - 2017-05-12 10:55:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 10:55:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 10:55:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 10:55:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 10:55:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 10:55:04 --> Final output sent to browser
DEBUG - 2017-05-12 10:55:04 --> Total execution time: 0.3437
INFO - 2017-05-12 10:55:04 --> Config Class Initialized
INFO - 2017-05-12 10:55:04 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:55:04 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:55:04 --> Utf8 Class Initialized
INFO - 2017-05-12 10:55:04 --> URI Class Initialized
INFO - 2017-05-12 10:55:04 --> Router Class Initialized
INFO - 2017-05-12 10:55:04 --> Output Class Initialized
INFO - 2017-05-12 10:55:04 --> Security Class Initialized
DEBUG - 2017-05-12 10:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:55:04 --> Config Class Initialized
INFO - 2017-05-12 10:55:04 --> Input Class Initialized
INFO - 2017-05-12 10:55:04 --> Hooks Class Initialized
INFO - 2017-05-12 10:55:04 --> Language Class Initialized
DEBUG - 2017-05-12 10:55:04 --> UTF-8 Support Enabled
ERROR - 2017-05-12 10:55:04 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 10:55:04 --> Utf8 Class Initialized
INFO - 2017-05-12 10:55:04 --> URI Class Initialized
INFO - 2017-05-12 10:55:04 --> Router Class Initialized
INFO - 2017-05-12 10:55:04 --> Output Class Initialized
INFO - 2017-05-12 10:55:04 --> Security Class Initialized
DEBUG - 2017-05-12 10:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:55:04 --> Input Class Initialized
INFO - 2017-05-12 10:55:04 --> Language Class Initialized
ERROR - 2017-05-12 10:55:04 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 10:55:04 --> Config Class Initialized
INFO - 2017-05-12 10:55:04 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:55:04 --> UTF-8 Support Enabled
INFO - 2017-05-12 10:55:04 --> Utf8 Class Initialized
INFO - 2017-05-12 10:55:04 --> URI Class Initialized
INFO - 2017-05-12 10:55:04 --> Router Class Initialized
INFO - 2017-05-12 10:55:04 --> Output Class Initialized
INFO - 2017-05-12 10:55:04 --> Security Class Initialized
DEBUG - 2017-05-12 10:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 10:55:04 --> Input Class Initialized
INFO - 2017-05-12 10:55:04 --> Language Class Initialized
INFO - 2017-05-12 10:55:04 --> Loader Class Initialized
INFO - 2017-05-12 10:55:04 --> Helper loaded: url_helper
INFO - 2017-05-12 10:55:04 --> Helper loaded: form_helper
INFO - 2017-05-12 10:55:04 --> Helper loaded: html_helper
INFO - 2017-05-12 10:55:04 --> Helper loaded: custom_helper
INFO - 2017-05-12 10:55:04 --> Helper loaded: cache_helper
INFO - 2017-05-12 10:55:04 --> Database Driver Class Initialized
INFO - 2017-05-12 10:55:04 --> Parser Class Initialized
DEBUG - 2017-05-12 10:55:04 --> Session Class Initialized
INFO - 2017-05-12 10:55:04 --> Helper loaded: string_helper
DEBUG - 2017-05-12 10:55:04 --> Session routines successfully run
INFO - 2017-05-12 10:55:04 --> Form Validation Class Initialized
INFO - 2017-05-12 10:55:04 --> Controller Class Initialized
DEBUG - 2017-05-12 10:55:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-12 10:55:04 --> Pagination Class Initialized
INFO - 2017-05-12 10:55:04 --> Final output sent to browser
DEBUG - 2017-05-12 10:55:04 --> Total execution time: 0.2754
INFO - 2017-05-12 11:03:20 --> Config Class Initialized
INFO - 2017-05-12 11:03:20 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:03:20 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:03:20 --> Utf8 Class Initialized
INFO - 2017-05-12 11:03:20 --> URI Class Initialized
INFO - 2017-05-12 11:03:20 --> Router Class Initialized
INFO - 2017-05-12 11:03:20 --> Output Class Initialized
INFO - 2017-05-12 11:03:20 --> Security Class Initialized
DEBUG - 2017-05-12 11:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:03:20 --> Input Class Initialized
INFO - 2017-05-12 11:03:20 --> Language Class Initialized
INFO - 2017-05-12 11:03:20 --> Loader Class Initialized
INFO - 2017-05-12 11:03:20 --> Helper loaded: url_helper
INFO - 2017-05-12 11:03:20 --> Helper loaded: form_helper
INFO - 2017-05-12 11:03:20 --> Helper loaded: html_helper
INFO - 2017-05-12 11:03:20 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:03:20 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:03:20 --> Database Driver Class Initialized
INFO - 2017-05-12 11:03:20 --> Parser Class Initialized
DEBUG - 2017-05-12 11:03:20 --> Session Class Initialized
INFO - 2017-05-12 11:03:20 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:03:20 --> Session routines successfully run
INFO - 2017-05-12 11:03:20 --> Form Validation Class Initialized
INFO - 2017-05-12 11:03:20 --> Controller Class Initialized
DEBUG - 2017-05-12 11:03:20 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:03:20 --> Model Class Initialized
DEBUG - 2017-05-12 11:03:20 --> Pagination Class Initialized
INFO - 2017-05-12 11:03:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:03:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:03:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:03:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:03:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:03:21 --> Final output sent to browser
DEBUG - 2017-05-12 11:03:21 --> Total execution time: 0.6936
INFO - 2017-05-12 11:03:21 --> Config Class Initialized
INFO - 2017-05-12 11:03:21 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:03:21 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:03:21 --> Utf8 Class Initialized
INFO - 2017-05-12 11:03:21 --> URI Class Initialized
INFO - 2017-05-12 11:03:21 --> Router Class Initialized
INFO - 2017-05-12 11:03:21 --> Output Class Initialized
INFO - 2017-05-12 11:03:21 --> Security Class Initialized
INFO - 2017-05-12 11:03:21 --> Config Class Initialized
DEBUG - 2017-05-12 11:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:03:21 --> Hooks Class Initialized
INFO - 2017-05-12 11:03:21 --> Input Class Initialized
DEBUG - 2017-05-12 11:03:21 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:03:21 --> Language Class Initialized
INFO - 2017-05-12 11:03:21 --> Utf8 Class Initialized
INFO - 2017-05-12 11:03:21 --> URI Class Initialized
ERROR - 2017-05-12 11:03:21 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:03:21 --> Router Class Initialized
INFO - 2017-05-12 11:03:21 --> Output Class Initialized
INFO - 2017-05-12 11:03:21 --> Security Class Initialized
DEBUG - 2017-05-12 11:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:03:21 --> Input Class Initialized
INFO - 2017-05-12 11:03:21 --> Language Class Initialized
ERROR - 2017-05-12 11:03:21 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:03:21 --> Config Class Initialized
INFO - 2017-05-12 11:03:21 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:03:21 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:03:21 --> Utf8 Class Initialized
INFO - 2017-05-12 11:03:21 --> URI Class Initialized
INFO - 2017-05-12 11:03:21 --> Router Class Initialized
INFO - 2017-05-12 11:03:21 --> Output Class Initialized
INFO - 2017-05-12 11:03:21 --> Security Class Initialized
DEBUG - 2017-05-12 11:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:03:21 --> Input Class Initialized
INFO - 2017-05-12 11:03:21 --> Language Class Initialized
INFO - 2017-05-12 11:03:21 --> Loader Class Initialized
INFO - 2017-05-12 11:03:21 --> Helper loaded: url_helper
INFO - 2017-05-12 11:03:21 --> Helper loaded: form_helper
INFO - 2017-05-12 11:03:21 --> Helper loaded: html_helper
INFO - 2017-05-12 11:03:21 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:03:21 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:03:21 --> Database Driver Class Initialized
INFO - 2017-05-12 11:03:21 --> Parser Class Initialized
DEBUG - 2017-05-12 11:03:21 --> Session Class Initialized
INFO - 2017-05-12 11:03:21 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:03:21 --> Session routines successfully run
INFO - 2017-05-12 11:03:21 --> Form Validation Class Initialized
INFO - 2017-05-12 11:03:21 --> Controller Class Initialized
DEBUG - 2017-05-12 11:03:21 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:03:21 --> Model Class Initialized
DEBUG - 2017-05-12 11:03:21 --> Pagination Class Initialized
INFO - 2017-05-12 11:03:21 --> Final output sent to browser
DEBUG - 2017-05-12 11:03:21 --> Total execution time: 0.2773
INFO - 2017-05-12 11:04:32 --> Config Class Initialized
INFO - 2017-05-12 11:04:32 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:04:32 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:04:32 --> Utf8 Class Initialized
INFO - 2017-05-12 11:04:32 --> URI Class Initialized
INFO - 2017-05-12 11:04:32 --> Router Class Initialized
INFO - 2017-05-12 11:04:32 --> Output Class Initialized
INFO - 2017-05-12 11:04:32 --> Security Class Initialized
DEBUG - 2017-05-12 11:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:04:32 --> Input Class Initialized
INFO - 2017-05-12 11:04:32 --> Language Class Initialized
INFO - 2017-05-12 11:04:32 --> Loader Class Initialized
INFO - 2017-05-12 11:04:32 --> Helper loaded: url_helper
INFO - 2017-05-12 11:04:32 --> Helper loaded: form_helper
INFO - 2017-05-12 11:04:32 --> Helper loaded: html_helper
INFO - 2017-05-12 11:04:32 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:04:32 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:04:32 --> Database Driver Class Initialized
INFO - 2017-05-12 11:04:32 --> Parser Class Initialized
DEBUG - 2017-05-12 11:04:32 --> Session Class Initialized
INFO - 2017-05-12 11:04:32 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:04:32 --> Session routines successfully run
INFO - 2017-05-12 11:04:32 --> Form Validation Class Initialized
INFO - 2017-05-12 11:04:32 --> Controller Class Initialized
DEBUG - 2017-05-12 11:04:32 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:04:32 --> Model Class Initialized
DEBUG - 2017-05-12 11:04:32 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:04:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:04:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:04:32 --> Config Class Initialized
INFO - 2017-05-12 11:04:32 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:04:32 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:04:32 --> Utf8 Class Initialized
INFO - 2017-05-12 11:04:32 --> URI Class Initialized
INFO - 2017-05-12 11:04:32 --> Router Class Initialized
INFO - 2017-05-12 11:04:32 --> Output Class Initialized
INFO - 2017-05-12 11:04:32 --> Security Class Initialized
DEBUG - 2017-05-12 11:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:04:32 --> Input Class Initialized
INFO - 2017-05-12 11:04:32 --> Language Class Initialized
INFO - 2017-05-12 11:04:32 --> Loader Class Initialized
INFO - 2017-05-12 11:04:32 --> Helper loaded: url_helper
INFO - 2017-05-12 11:04:32 --> Helper loaded: form_helper
INFO - 2017-05-12 11:04:32 --> Helper loaded: html_helper
INFO - 2017-05-12 11:04:32 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:04:32 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:04:32 --> Database Driver Class Initialized
INFO - 2017-05-12 11:04:32 --> Parser Class Initialized
DEBUG - 2017-05-12 11:04:32 --> Session Class Initialized
INFO - 2017-05-12 11:04:32 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:04:32 --> Session routines successfully run
INFO - 2017-05-12 11:04:32 --> Form Validation Class Initialized
INFO - 2017-05-12 11:04:33 --> Controller Class Initialized
DEBUG - 2017-05-12 11:04:33 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:04:33 --> Model Class Initialized
DEBUG - 2017-05-12 11:04:33 --> Pagination Class Initialized
INFO - 2017-05-12 11:04:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:04:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:33 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:36 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:04:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:04:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:04:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:04:37 --> Final output sent to browser
DEBUG - 2017-05-12 11:04:37 --> Total execution time: 5.2392
INFO - 2017-05-12 11:04:42 --> Config Class Initialized
INFO - 2017-05-12 11:04:42 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:04:42 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:04:42 --> Utf8 Class Initialized
INFO - 2017-05-12 11:04:42 --> URI Class Initialized
INFO - 2017-05-12 11:04:42 --> Router Class Initialized
INFO - 2017-05-12 11:04:42 --> Output Class Initialized
INFO - 2017-05-12 11:04:42 --> Security Class Initialized
DEBUG - 2017-05-12 11:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:04:42 --> Input Class Initialized
INFO - 2017-05-12 11:04:42 --> Language Class Initialized
INFO - 2017-05-12 11:04:42 --> Loader Class Initialized
INFO - 2017-05-12 11:04:42 --> Helper loaded: url_helper
INFO - 2017-05-12 11:04:42 --> Helper loaded: form_helper
INFO - 2017-05-12 11:04:42 --> Helper loaded: html_helper
INFO - 2017-05-12 11:04:42 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:04:42 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:04:42 --> Database Driver Class Initialized
INFO - 2017-05-12 11:04:42 --> Parser Class Initialized
DEBUG - 2017-05-12 11:04:42 --> Session Class Initialized
INFO - 2017-05-12 11:04:42 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:04:42 --> Session routines successfully run
INFO - 2017-05-12 11:04:42 --> Form Validation Class Initialized
INFO - 2017-05-12 11:04:42 --> Controller Class Initialized
DEBUG - 2017-05-12 11:04:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:04:42 --> Model Class Initialized
DEBUG - 2017-05-12 11:04:42 --> Pagination Class Initialized
INFO - 2017-05-12 11:04:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:04:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:04:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:04:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:04:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:04:43 --> Final output sent to browser
DEBUG - 2017-05-12 11:04:43 --> Total execution time: 0.4830
INFO - 2017-05-12 11:04:43 --> Config Class Initialized
INFO - 2017-05-12 11:04:43 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:04:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:04:43 --> Utf8 Class Initialized
INFO - 2017-05-12 11:04:43 --> URI Class Initialized
INFO - 2017-05-12 11:04:43 --> Router Class Initialized
INFO - 2017-05-12 11:04:43 --> Output Class Initialized
INFO - 2017-05-12 11:04:43 --> Security Class Initialized
INFO - 2017-05-12 11:04:43 --> Config Class Initialized
DEBUG - 2017-05-12 11:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:04:43 --> Hooks Class Initialized
INFO - 2017-05-12 11:04:43 --> Input Class Initialized
DEBUG - 2017-05-12 11:04:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:04:43 --> Language Class Initialized
INFO - 2017-05-12 11:04:43 --> Utf8 Class Initialized
INFO - 2017-05-12 11:04:43 --> URI Class Initialized
ERROR - 2017-05-12 11:04:43 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:04:43 --> Router Class Initialized
INFO - 2017-05-12 11:04:43 --> Output Class Initialized
INFO - 2017-05-12 11:04:43 --> Security Class Initialized
DEBUG - 2017-05-12 11:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:04:43 --> Input Class Initialized
INFO - 2017-05-12 11:04:43 --> Language Class Initialized
ERROR - 2017-05-12 11:04:43 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:04:43 --> Config Class Initialized
INFO - 2017-05-12 11:04:43 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:04:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:04:43 --> Utf8 Class Initialized
INFO - 2017-05-12 11:04:43 --> URI Class Initialized
INFO - 2017-05-12 11:04:43 --> Router Class Initialized
INFO - 2017-05-12 11:04:43 --> Output Class Initialized
INFO - 2017-05-12 11:04:43 --> Security Class Initialized
DEBUG - 2017-05-12 11:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:04:43 --> Input Class Initialized
INFO - 2017-05-12 11:04:43 --> Language Class Initialized
INFO - 2017-05-12 11:04:43 --> Loader Class Initialized
INFO - 2017-05-12 11:04:43 --> Helper loaded: url_helper
INFO - 2017-05-12 11:04:43 --> Helper loaded: form_helper
INFO - 2017-05-12 11:04:43 --> Helper loaded: html_helper
INFO - 2017-05-12 11:04:43 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:04:43 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:04:43 --> Database Driver Class Initialized
INFO - 2017-05-12 11:04:43 --> Parser Class Initialized
DEBUG - 2017-05-12 11:04:43 --> Session Class Initialized
INFO - 2017-05-12 11:04:43 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:04:43 --> Session routines successfully run
INFO - 2017-05-12 11:04:43 --> Form Validation Class Initialized
INFO - 2017-05-12 11:04:43 --> Controller Class Initialized
DEBUG - 2017-05-12 11:04:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:04:43 --> Model Class Initialized
DEBUG - 2017-05-12 11:04:43 --> Pagination Class Initialized
INFO - 2017-05-12 11:04:43 --> Final output sent to browser
DEBUG - 2017-05-12 11:04:43 --> Total execution time: 0.2984
INFO - 2017-05-12 11:04:47 --> Config Class Initialized
INFO - 2017-05-12 11:04:47 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:04:47 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:04:47 --> Utf8 Class Initialized
INFO - 2017-05-12 11:04:47 --> URI Class Initialized
INFO - 2017-05-12 11:04:47 --> Router Class Initialized
INFO - 2017-05-12 11:04:47 --> Output Class Initialized
INFO - 2017-05-12 11:04:47 --> Security Class Initialized
DEBUG - 2017-05-12 11:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:04:47 --> Input Class Initialized
INFO - 2017-05-12 11:04:47 --> Language Class Initialized
INFO - 2017-05-12 11:04:47 --> Loader Class Initialized
INFO - 2017-05-12 11:04:47 --> Helper loaded: url_helper
INFO - 2017-05-12 11:04:47 --> Helper loaded: form_helper
INFO - 2017-05-12 11:04:47 --> Helper loaded: html_helper
INFO - 2017-05-12 11:04:47 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:04:47 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:04:47 --> Database Driver Class Initialized
INFO - 2017-05-12 11:04:47 --> Parser Class Initialized
DEBUG - 2017-05-12 11:04:47 --> Session Class Initialized
INFO - 2017-05-12 11:04:47 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:04:47 --> Session routines successfully run
INFO - 2017-05-12 11:04:47 --> Form Validation Class Initialized
INFO - 2017-05-12 11:04:47 --> Controller Class Initialized
DEBUG - 2017-05-12 11:04:47 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:04:47 --> Model Class Initialized
DEBUG - 2017-05-12 11:04:47 --> Pagination Class Initialized
INFO - 2017-05-12 11:04:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:04:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:04:52 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:04:52 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:04:52 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:04:52 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:04:52 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:04:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:04:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:04:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:04:52 --> Final output sent to browser
DEBUG - 2017-05-12 11:04:52 --> Total execution time: 5.0115
INFO - 2017-05-12 11:04:56 --> Config Class Initialized
INFO - 2017-05-12 11:04:56 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:04:56 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:04:56 --> Utf8 Class Initialized
INFO - 2017-05-12 11:04:56 --> URI Class Initialized
INFO - 2017-05-12 11:04:56 --> Router Class Initialized
INFO - 2017-05-12 11:04:56 --> Output Class Initialized
INFO - 2017-05-12 11:04:56 --> Security Class Initialized
DEBUG - 2017-05-12 11:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:04:56 --> Input Class Initialized
INFO - 2017-05-12 11:04:56 --> Language Class Initialized
INFO - 2017-05-12 11:04:56 --> Loader Class Initialized
INFO - 2017-05-12 11:04:56 --> Helper loaded: url_helper
INFO - 2017-05-12 11:04:56 --> Helper loaded: form_helper
INFO - 2017-05-12 11:04:56 --> Helper loaded: html_helper
INFO - 2017-05-12 11:04:56 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:04:56 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:04:56 --> Database Driver Class Initialized
INFO - 2017-05-12 11:04:56 --> Parser Class Initialized
DEBUG - 2017-05-12 11:04:56 --> Session Class Initialized
INFO - 2017-05-12 11:04:56 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:04:56 --> Session routines successfully run
INFO - 2017-05-12 11:04:56 --> Form Validation Class Initialized
INFO - 2017-05-12 11:04:56 --> Controller Class Initialized
DEBUG - 2017-05-12 11:04:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:04:56 --> Model Class Initialized
DEBUG - 2017-05-12 11:04:56 --> Pagination Class Initialized
INFO - 2017-05-12 11:04:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:04:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:04:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:04:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:04:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:04:57 --> Final output sent to browser
DEBUG - 2017-05-12 11:04:57 --> Total execution time: 1.1316
INFO - 2017-05-12 11:04:57 --> Config Class Initialized
INFO - 2017-05-12 11:04:57 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:04:57 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:04:57 --> Utf8 Class Initialized
INFO - 2017-05-12 11:04:57 --> URI Class Initialized
INFO - 2017-05-12 11:04:57 --> Router Class Initialized
INFO - 2017-05-12 11:04:57 --> Output Class Initialized
INFO - 2017-05-12 11:04:57 --> Security Class Initialized
DEBUG - 2017-05-12 11:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:04:57 --> Input Class Initialized
INFO - 2017-05-12 11:04:57 --> Config Class Initialized
INFO - 2017-05-12 11:04:57 --> Hooks Class Initialized
INFO - 2017-05-12 11:04:57 --> Language Class Initialized
ERROR - 2017-05-12 11:04:57 --> 404 Page Not Found: Default/assets
DEBUG - 2017-05-12 11:04:57 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:04:57 --> Utf8 Class Initialized
INFO - 2017-05-12 11:04:57 --> URI Class Initialized
INFO - 2017-05-12 11:04:57 --> Router Class Initialized
INFO - 2017-05-12 11:04:57 --> Output Class Initialized
INFO - 2017-05-12 11:04:57 --> Security Class Initialized
DEBUG - 2017-05-12 11:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:04:57 --> Input Class Initialized
INFO - 2017-05-12 11:04:57 --> Language Class Initialized
ERROR - 2017-05-12 11:04:57 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:04:57 --> Config Class Initialized
INFO - 2017-05-12 11:04:57 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:04:57 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:04:57 --> Utf8 Class Initialized
INFO - 2017-05-12 11:04:57 --> URI Class Initialized
INFO - 2017-05-12 11:04:57 --> Router Class Initialized
INFO - 2017-05-12 11:04:57 --> Output Class Initialized
INFO - 2017-05-12 11:04:57 --> Security Class Initialized
DEBUG - 2017-05-12 11:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:04:57 --> Input Class Initialized
INFO - 2017-05-12 11:04:57 --> Language Class Initialized
INFO - 2017-05-12 11:04:57 --> Loader Class Initialized
INFO - 2017-05-12 11:04:57 --> Helper loaded: url_helper
INFO - 2017-05-12 11:04:57 --> Helper loaded: form_helper
INFO - 2017-05-12 11:04:57 --> Helper loaded: html_helper
INFO - 2017-05-12 11:04:57 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:04:57 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:04:57 --> Database Driver Class Initialized
INFO - 2017-05-12 11:04:57 --> Parser Class Initialized
DEBUG - 2017-05-12 11:04:57 --> Session Class Initialized
INFO - 2017-05-12 11:04:58 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:04:58 --> Session routines successfully run
INFO - 2017-05-12 11:04:58 --> Form Validation Class Initialized
INFO - 2017-05-12 11:04:58 --> Controller Class Initialized
DEBUG - 2017-05-12 11:04:58 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:04:58 --> Model Class Initialized
DEBUG - 2017-05-12 11:04:58 --> Pagination Class Initialized
INFO - 2017-05-12 11:04:58 --> Final output sent to browser
DEBUG - 2017-05-12 11:04:58 --> Total execution time: 0.3699
INFO - 2017-05-12 11:05:04 --> Config Class Initialized
INFO - 2017-05-12 11:05:04 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:05:04 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:05:04 --> Utf8 Class Initialized
INFO - 2017-05-12 11:05:04 --> URI Class Initialized
INFO - 2017-05-12 11:05:04 --> Router Class Initialized
INFO - 2017-05-12 11:05:04 --> Output Class Initialized
INFO - 2017-05-12 11:05:04 --> Security Class Initialized
DEBUG - 2017-05-12 11:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:05:04 --> Input Class Initialized
INFO - 2017-05-12 11:05:04 --> Language Class Initialized
INFO - 2017-05-12 11:05:04 --> Loader Class Initialized
INFO - 2017-05-12 11:05:04 --> Helper loaded: url_helper
INFO - 2017-05-12 11:05:04 --> Helper loaded: form_helper
INFO - 2017-05-12 11:05:04 --> Helper loaded: html_helper
INFO - 2017-05-12 11:05:04 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:05:04 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:05:04 --> Database Driver Class Initialized
INFO - 2017-05-12 11:05:04 --> Parser Class Initialized
DEBUG - 2017-05-12 11:05:04 --> Session Class Initialized
INFO - 2017-05-12 11:05:04 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:05:04 --> Session routines successfully run
INFO - 2017-05-12 11:05:04 --> Form Validation Class Initialized
INFO - 2017-05-12 11:05:04 --> Controller Class Initialized
DEBUG - 2017-05-12 11:05:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:05:04 --> Model Class Initialized
DEBUG - 2017-05-12 11:05:04 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:05:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:05:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:05:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:05:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:05:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:05:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:05:05 --> Final output sent to browser
DEBUG - 2017-05-12 11:05:05 --> Total execution time: 1.4073
INFO - 2017-05-12 11:05:05 --> Config Class Initialized
INFO - 2017-05-12 11:05:05 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:05:05 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:05:05 --> Utf8 Class Initialized
INFO - 2017-05-12 11:05:05 --> URI Class Initialized
INFO - 2017-05-12 11:05:05 --> Router Class Initialized
INFO - 2017-05-12 11:05:05 --> Output Class Initialized
INFO - 2017-05-12 11:05:05 --> Security Class Initialized
DEBUG - 2017-05-12 11:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:05:05 --> Input Class Initialized
INFO - 2017-05-12 11:05:05 --> Config Class Initialized
INFO - 2017-05-12 11:05:05 --> Hooks Class Initialized
INFO - 2017-05-12 11:05:05 --> Language Class Initialized
ERROR - 2017-05-12 11:05:05 --> 404 Page Not Found: Default/assets
DEBUG - 2017-05-12 11:05:05 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:05:05 --> Utf8 Class Initialized
INFO - 2017-05-12 11:05:05 --> URI Class Initialized
INFO - 2017-05-12 11:05:05 --> Router Class Initialized
INFO - 2017-05-12 11:05:05 --> Output Class Initialized
INFO - 2017-05-12 11:05:05 --> Security Class Initialized
DEBUG - 2017-05-12 11:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:05:05 --> Input Class Initialized
INFO - 2017-05-12 11:05:05 --> Language Class Initialized
ERROR - 2017-05-12 11:05:05 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:05:05 --> Config Class Initialized
INFO - 2017-05-12 11:05:05 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:05:05 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:05:06 --> Utf8 Class Initialized
INFO - 2017-05-12 11:05:06 --> URI Class Initialized
INFO - 2017-05-12 11:05:06 --> Router Class Initialized
INFO - 2017-05-12 11:05:06 --> Output Class Initialized
INFO - 2017-05-12 11:05:06 --> Security Class Initialized
DEBUG - 2017-05-12 11:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:05:06 --> Input Class Initialized
INFO - 2017-05-12 11:05:06 --> Language Class Initialized
INFO - 2017-05-12 11:05:06 --> Loader Class Initialized
INFO - 2017-05-12 11:05:06 --> Helper loaded: url_helper
INFO - 2017-05-12 11:05:06 --> Helper loaded: form_helper
INFO - 2017-05-12 11:05:06 --> Helper loaded: html_helper
INFO - 2017-05-12 11:05:06 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:05:06 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:05:06 --> Database Driver Class Initialized
INFO - 2017-05-12 11:05:06 --> Parser Class Initialized
DEBUG - 2017-05-12 11:05:06 --> Session Class Initialized
INFO - 2017-05-12 11:05:06 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:05:06 --> Session routines successfully run
INFO - 2017-05-12 11:05:06 --> Form Validation Class Initialized
INFO - 2017-05-12 11:05:06 --> Controller Class Initialized
DEBUG - 2017-05-12 11:05:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:05:06 --> Model Class Initialized
DEBUG - 2017-05-12 11:05:06 --> Pagination Class Initialized
ERROR - 2017-05-12 11:05:06 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 885
ERROR - 2017-05-12 11:05:06 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 888
INFO - 2017-05-12 11:05:06 --> Final output sent to browser
DEBUG - 2017-05-12 11:05:06 --> Total execution time: 0.3486
INFO - 2017-05-12 11:05:44 --> Config Class Initialized
INFO - 2017-05-12 11:05:44 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:05:44 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:05:44 --> Utf8 Class Initialized
INFO - 2017-05-12 11:05:44 --> URI Class Initialized
INFO - 2017-05-12 11:05:44 --> Router Class Initialized
INFO - 2017-05-12 11:05:44 --> Output Class Initialized
INFO - 2017-05-12 11:05:44 --> Security Class Initialized
DEBUG - 2017-05-12 11:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:05:44 --> Input Class Initialized
INFO - 2017-05-12 11:05:44 --> Language Class Initialized
INFO - 2017-05-12 11:05:44 --> Loader Class Initialized
INFO - 2017-05-12 11:05:44 --> Helper loaded: url_helper
INFO - 2017-05-12 11:05:44 --> Helper loaded: form_helper
INFO - 2017-05-12 11:05:44 --> Helper loaded: html_helper
INFO - 2017-05-12 11:05:44 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:05:44 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:05:44 --> Database Driver Class Initialized
INFO - 2017-05-12 11:05:44 --> Parser Class Initialized
DEBUG - 2017-05-12 11:05:44 --> Session Class Initialized
INFO - 2017-05-12 11:05:44 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:05:44 --> Session routines successfully run
INFO - 2017-05-12 11:05:45 --> Form Validation Class Initialized
INFO - 2017-05-12 11:05:45 --> Controller Class Initialized
DEBUG - 2017-05-12 11:05:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:05:45 --> Model Class Initialized
DEBUG - 2017-05-12 11:05:45 --> Pagination Class Initialized
INFO - 2017-05-12 11:05:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:05:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:05:49 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:05:49 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:05:49 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:05:49 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:05:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:05:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:05:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:05:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:05:49 --> Final output sent to browser
DEBUG - 2017-05-12 11:05:49 --> Total execution time: 4.9125
INFO - 2017-05-12 11:06:04 --> Config Class Initialized
INFO - 2017-05-12 11:06:04 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:06:04 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:06:04 --> Utf8 Class Initialized
INFO - 2017-05-12 11:06:05 --> URI Class Initialized
INFO - 2017-05-12 11:06:05 --> Router Class Initialized
INFO - 2017-05-12 11:06:05 --> Output Class Initialized
INFO - 2017-05-12 11:06:05 --> Security Class Initialized
DEBUG - 2017-05-12 11:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:06:05 --> Input Class Initialized
INFO - 2017-05-12 11:06:05 --> Language Class Initialized
INFO - 2017-05-12 11:06:05 --> Loader Class Initialized
INFO - 2017-05-12 11:06:05 --> Helper loaded: url_helper
INFO - 2017-05-12 11:06:05 --> Helper loaded: form_helper
INFO - 2017-05-12 11:06:05 --> Helper loaded: html_helper
INFO - 2017-05-12 11:06:05 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:06:05 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:06:05 --> Database Driver Class Initialized
INFO - 2017-05-12 11:06:05 --> Parser Class Initialized
DEBUG - 2017-05-12 11:06:05 --> Session Class Initialized
INFO - 2017-05-12 11:06:05 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:06:05 --> Session routines successfully run
INFO - 2017-05-12 11:06:05 --> Form Validation Class Initialized
INFO - 2017-05-12 11:06:05 --> Controller Class Initialized
DEBUG - 2017-05-12 11:06:05 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:06:05 --> Model Class Initialized
DEBUG - 2017-05-12 11:06:05 --> Pagination Class Initialized
INFO - 2017-05-12 11:06:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:06:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:06:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:06:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:06:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:06:06 --> Final output sent to browser
DEBUG - 2017-05-12 11:06:06 --> Total execution time: 1.1182
INFO - 2017-05-12 11:06:06 --> Config Class Initialized
INFO - 2017-05-12 11:06:06 --> Hooks Class Initialized
INFO - 2017-05-12 11:06:06 --> Config Class Initialized
DEBUG - 2017-05-12 11:06:06 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:06:06 --> Hooks Class Initialized
INFO - 2017-05-12 11:06:06 --> Utf8 Class Initialized
DEBUG - 2017-05-12 11:06:06 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:06:06 --> URI Class Initialized
INFO - 2017-05-12 11:06:06 --> Utf8 Class Initialized
INFO - 2017-05-12 11:06:06 --> URI Class Initialized
INFO - 2017-05-12 11:06:06 --> Router Class Initialized
INFO - 2017-05-12 11:06:06 --> Router Class Initialized
INFO - 2017-05-12 11:06:06 --> Output Class Initialized
INFO - 2017-05-12 11:06:06 --> Output Class Initialized
INFO - 2017-05-12 11:06:06 --> Security Class Initialized
INFO - 2017-05-12 11:06:06 --> Security Class Initialized
DEBUG - 2017-05-12 11:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 11:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:06:06 --> Input Class Initialized
INFO - 2017-05-12 11:06:06 --> Input Class Initialized
INFO - 2017-05-12 11:06:06 --> Language Class Initialized
INFO - 2017-05-12 11:06:06 --> Language Class Initialized
ERROR - 2017-05-12 11:06:06 --> 404 Page Not Found: Default/assets
ERROR - 2017-05-12 11:06:06 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:06:06 --> Config Class Initialized
INFO - 2017-05-12 11:06:06 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:06:06 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:06:06 --> Utf8 Class Initialized
INFO - 2017-05-12 11:06:06 --> URI Class Initialized
INFO - 2017-05-12 11:06:06 --> Router Class Initialized
INFO - 2017-05-12 11:06:06 --> Output Class Initialized
INFO - 2017-05-12 11:06:06 --> Security Class Initialized
DEBUG - 2017-05-12 11:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:06:06 --> Input Class Initialized
INFO - 2017-05-12 11:06:06 --> Language Class Initialized
INFO - 2017-05-12 11:06:06 --> Loader Class Initialized
INFO - 2017-05-12 11:06:06 --> Helper loaded: url_helper
INFO - 2017-05-12 11:06:06 --> Helper loaded: form_helper
INFO - 2017-05-12 11:06:06 --> Helper loaded: html_helper
INFO - 2017-05-12 11:06:06 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:06:06 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:06:06 --> Database Driver Class Initialized
INFO - 2017-05-12 11:06:06 --> Parser Class Initialized
DEBUG - 2017-05-12 11:06:06 --> Session Class Initialized
INFO - 2017-05-12 11:06:06 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:06:06 --> Session routines successfully run
INFO - 2017-05-12 11:06:06 --> Form Validation Class Initialized
INFO - 2017-05-12 11:06:06 --> Controller Class Initialized
DEBUG - 2017-05-12 11:06:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:06:06 --> Model Class Initialized
DEBUG - 2017-05-12 11:06:06 --> Pagination Class Initialized
INFO - 2017-05-12 11:06:06 --> Final output sent to browser
DEBUG - 2017-05-12 11:06:06 --> Total execution time: 0.3677
INFO - 2017-05-12 11:10:13 --> Config Class Initialized
INFO - 2017-05-12 11:10:14 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:10:14 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:10:14 --> Utf8 Class Initialized
INFO - 2017-05-12 11:10:14 --> URI Class Initialized
INFO - 2017-05-12 11:10:14 --> Router Class Initialized
INFO - 2017-05-12 11:10:14 --> Output Class Initialized
INFO - 2017-05-12 11:10:14 --> Security Class Initialized
DEBUG - 2017-05-12 11:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:10:14 --> Input Class Initialized
INFO - 2017-05-12 11:10:14 --> Language Class Initialized
INFO - 2017-05-12 11:10:14 --> Loader Class Initialized
INFO - 2017-05-12 11:10:14 --> Helper loaded: url_helper
INFO - 2017-05-12 11:10:14 --> Helper loaded: form_helper
INFO - 2017-05-12 11:10:14 --> Helper loaded: html_helper
INFO - 2017-05-12 11:10:14 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:10:14 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:10:14 --> Database Driver Class Initialized
INFO - 2017-05-12 11:10:14 --> Parser Class Initialized
DEBUG - 2017-05-12 11:10:14 --> Session Class Initialized
INFO - 2017-05-12 11:10:14 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:10:14 --> Session routines successfully run
INFO - 2017-05-12 11:10:14 --> Form Validation Class Initialized
INFO - 2017-05-12 11:10:14 --> Controller Class Initialized
DEBUG - 2017-05-12 11:10:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:10:14 --> Model Class Initialized
DEBUG - 2017-05-12 11:10:14 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:10:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:10:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:10:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:10:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:10:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:10:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:10:14 --> Final output sent to browser
DEBUG - 2017-05-12 11:10:14 --> Total execution time: 0.3982
INFO - 2017-05-12 11:10:14 --> Config Class Initialized
INFO - 2017-05-12 11:10:14 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:10:14 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:10:14 --> Utf8 Class Initialized
INFO - 2017-05-12 11:10:14 --> Config Class Initialized
INFO - 2017-05-12 11:10:14 --> URI Class Initialized
INFO - 2017-05-12 11:10:14 --> Hooks Class Initialized
INFO - 2017-05-12 11:10:14 --> Router Class Initialized
DEBUG - 2017-05-12 11:10:14 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:10:14 --> Output Class Initialized
INFO - 2017-05-12 11:10:14 --> Utf8 Class Initialized
INFO - 2017-05-12 11:10:14 --> URI Class Initialized
INFO - 2017-05-12 11:10:14 --> Security Class Initialized
DEBUG - 2017-05-12 11:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:10:14 --> Router Class Initialized
INFO - 2017-05-12 11:10:14 --> Input Class Initialized
INFO - 2017-05-12 11:10:14 --> Output Class Initialized
INFO - 2017-05-12 11:10:14 --> Language Class Initialized
INFO - 2017-05-12 11:10:14 --> Security Class Initialized
ERROR - 2017-05-12 11:10:14 --> 404 Page Not Found: Default/assets
DEBUG - 2017-05-12 11:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:10:14 --> Input Class Initialized
INFO - 2017-05-12 11:10:14 --> Language Class Initialized
ERROR - 2017-05-12 11:10:14 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:10:16 --> Config Class Initialized
INFO - 2017-05-12 11:10:16 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:10:16 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:10:16 --> Utf8 Class Initialized
INFO - 2017-05-12 11:10:16 --> URI Class Initialized
INFO - 2017-05-12 11:10:16 --> Router Class Initialized
INFO - 2017-05-12 11:10:16 --> Output Class Initialized
INFO - 2017-05-12 11:10:16 --> Security Class Initialized
DEBUG - 2017-05-12 11:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:10:16 --> Input Class Initialized
INFO - 2017-05-12 11:10:16 --> Language Class Initialized
ERROR - 2017-05-12 11:10:16 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:10:16 --> Config Class Initialized
INFO - 2017-05-12 11:10:16 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:10:16 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:10:16 --> Utf8 Class Initialized
INFO - 2017-05-12 11:10:16 --> URI Class Initialized
INFO - 2017-05-12 11:10:16 --> Router Class Initialized
INFO - 2017-05-12 11:10:16 --> Output Class Initialized
INFO - 2017-05-12 11:10:16 --> Security Class Initialized
DEBUG - 2017-05-12 11:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:10:16 --> Input Class Initialized
INFO - 2017-05-12 11:10:16 --> Language Class Initialized
ERROR - 2017-05-12 11:10:16 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:10:16 --> Config Class Initialized
INFO - 2017-05-12 11:10:16 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:10:16 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:10:16 --> Utf8 Class Initialized
INFO - 2017-05-12 11:10:16 --> URI Class Initialized
INFO - 2017-05-12 11:10:16 --> Router Class Initialized
INFO - 2017-05-12 11:10:16 --> Output Class Initialized
INFO - 2017-05-12 11:10:16 --> Security Class Initialized
DEBUG - 2017-05-12 11:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:10:16 --> Input Class Initialized
INFO - 2017-05-12 11:10:16 --> Language Class Initialized
INFO - 2017-05-12 11:10:16 --> Loader Class Initialized
INFO - 2017-05-12 11:10:16 --> Helper loaded: url_helper
INFO - 2017-05-12 11:10:16 --> Helper loaded: form_helper
INFO - 2017-05-12 11:10:16 --> Helper loaded: html_helper
INFO - 2017-05-12 11:10:16 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:10:16 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:10:16 --> Database Driver Class Initialized
INFO - 2017-05-12 11:10:16 --> Parser Class Initialized
DEBUG - 2017-05-12 11:10:16 --> Session Class Initialized
INFO - 2017-05-12 11:10:16 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:10:16 --> Session routines successfully run
INFO - 2017-05-12 11:10:16 --> Form Validation Class Initialized
INFO - 2017-05-12 11:10:16 --> Controller Class Initialized
DEBUG - 2017-05-12 11:10:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:10:17 --> Model Class Initialized
DEBUG - 2017-05-12 11:10:17 --> Pagination Class Initialized
ERROR - 2017-05-12 11:10:17 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 885
ERROR - 2017-05-12 11:10:17 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 888
INFO - 2017-05-12 11:10:17 --> Final output sent to browser
DEBUG - 2017-05-12 11:10:17 --> Total execution time: 0.3509
INFO - 2017-05-12 11:10:18 --> Config Class Initialized
INFO - 2017-05-12 11:10:18 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:10:18 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:10:18 --> Utf8 Class Initialized
INFO - 2017-05-12 11:10:18 --> URI Class Initialized
INFO - 2017-05-12 11:10:18 --> Router Class Initialized
INFO - 2017-05-12 11:10:18 --> Output Class Initialized
INFO - 2017-05-12 11:10:18 --> Security Class Initialized
DEBUG - 2017-05-12 11:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:10:18 --> Input Class Initialized
INFO - 2017-05-12 11:10:18 --> Language Class Initialized
INFO - 2017-05-12 11:10:18 --> Loader Class Initialized
INFO - 2017-05-12 11:10:18 --> Helper loaded: url_helper
INFO - 2017-05-12 11:10:18 --> Helper loaded: form_helper
INFO - 2017-05-12 11:10:18 --> Helper loaded: html_helper
INFO - 2017-05-12 11:10:18 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:10:18 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:10:18 --> Database Driver Class Initialized
INFO - 2017-05-12 11:10:18 --> Parser Class Initialized
DEBUG - 2017-05-12 11:10:18 --> Session Class Initialized
INFO - 2017-05-12 11:10:18 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:10:18 --> Session routines successfully run
INFO - 2017-05-12 11:10:18 --> Form Validation Class Initialized
INFO - 2017-05-12 11:10:18 --> Controller Class Initialized
INFO - 2017-05-12 11:10:18 --> Model Class Initialized
INFO - 2017-05-12 11:10:18 --> Config Class Initialized
INFO - 2017-05-12 11:10:18 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:10:18 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:10:18 --> Utf8 Class Initialized
INFO - 2017-05-12 11:10:18 --> URI Class Initialized
INFO - 2017-05-12 11:10:18 --> Router Class Initialized
INFO - 2017-05-12 11:10:18 --> Output Class Initialized
INFO - 2017-05-12 11:10:18 --> Security Class Initialized
DEBUG - 2017-05-12 11:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:10:18 --> Input Class Initialized
INFO - 2017-05-12 11:10:18 --> Language Class Initialized
INFO - 2017-05-12 11:10:18 --> Loader Class Initialized
INFO - 2017-05-12 11:10:18 --> Helper loaded: url_helper
INFO - 2017-05-12 11:10:18 --> Helper loaded: form_helper
INFO - 2017-05-12 11:10:18 --> Helper loaded: html_helper
INFO - 2017-05-12 11:10:18 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:10:18 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:10:18 --> Database Driver Class Initialized
INFO - 2017-05-12 11:10:18 --> Parser Class Initialized
DEBUG - 2017-05-12 11:10:18 --> Session Class Initialized
INFO - 2017-05-12 11:10:18 --> Helper loaded: string_helper
ERROR - 2017-05-12 11:10:18 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-12 11:10:18 --> Session routines successfully run
INFO - 2017-05-12 11:10:18 --> Form Validation Class Initialized
INFO - 2017-05-12 11:10:18 --> Controller Class Initialized
INFO - 2017-05-12 11:10:18 --> Model Class Initialized
INFO - 2017-05-12 11:10:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-12 11:10:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:10:19 --> Final output sent to browser
DEBUG - 2017-05-12 11:10:19 --> Total execution time: 0.3653
INFO - 2017-05-12 11:13:28 --> Config Class Initialized
INFO - 2017-05-12 11:13:28 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:13:28 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:13:28 --> Utf8 Class Initialized
INFO - 2017-05-12 11:13:28 --> URI Class Initialized
INFO - 2017-05-12 11:13:28 --> Router Class Initialized
INFO - 2017-05-12 11:13:28 --> Output Class Initialized
INFO - 2017-05-12 11:13:28 --> Security Class Initialized
DEBUG - 2017-05-12 11:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:13:28 --> Input Class Initialized
INFO - 2017-05-12 11:13:28 --> Language Class Initialized
INFO - 2017-05-12 11:13:28 --> Loader Class Initialized
INFO - 2017-05-12 11:13:28 --> Helper loaded: url_helper
INFO - 2017-05-12 11:13:28 --> Helper loaded: form_helper
INFO - 2017-05-12 11:13:28 --> Helper loaded: html_helper
INFO - 2017-05-12 11:13:28 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:13:28 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:13:28 --> Database Driver Class Initialized
INFO - 2017-05-12 11:13:28 --> Parser Class Initialized
DEBUG - 2017-05-12 11:13:28 --> Session Class Initialized
INFO - 2017-05-12 11:13:28 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:13:28 --> Session routines successfully run
INFO - 2017-05-12 11:13:28 --> Form Validation Class Initialized
INFO - 2017-05-12 11:13:28 --> Controller Class Initialized
DEBUG - 2017-05-12 11:13:28 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:13:28 --> Model Class Initialized
DEBUG - 2017-05-12 11:13:28 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:13:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:13:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-05-12 11:13:28 --> Config file loaded: ../application/admin/config/chargify.php
INFO - 2017-05-12 11:13:30 --> Config Class Initialized
INFO - 2017-05-12 11:13:30 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:13:30 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:13:30 --> Utf8 Class Initialized
INFO - 2017-05-12 11:13:30 --> URI Class Initialized
INFO - 2017-05-12 11:13:30 --> Router Class Initialized
INFO - 2017-05-12 11:13:30 --> Output Class Initialized
INFO - 2017-05-12 11:13:30 --> Security Class Initialized
DEBUG - 2017-05-12 11:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:13:30 --> Input Class Initialized
INFO - 2017-05-12 11:13:30 --> Language Class Initialized
INFO - 2017-05-12 11:13:30 --> Loader Class Initialized
INFO - 2017-05-12 11:13:30 --> Helper loaded: url_helper
INFO - 2017-05-12 11:13:30 --> Helper loaded: form_helper
INFO - 2017-05-12 11:13:30 --> Helper loaded: html_helper
INFO - 2017-05-12 11:13:30 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:13:30 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:13:30 --> Database Driver Class Initialized
INFO - 2017-05-12 11:13:30 --> Parser Class Initialized
DEBUG - 2017-05-12 11:13:30 --> Session Class Initialized
INFO - 2017-05-12 11:13:30 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:13:30 --> Session routines successfully run
INFO - 2017-05-12 11:13:30 --> Form Validation Class Initialized
INFO - 2017-05-12 11:13:30 --> Controller Class Initialized
DEBUG - 2017-05-12 11:13:30 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:13:30 --> Model Class Initialized
DEBUG - 2017-05-12 11:13:30 --> Pagination Class Initialized
INFO - 2017-05-12 11:13:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:13:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:32 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:13:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:13:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:13:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:13:35 --> Final output sent to browser
DEBUG - 2017-05-12 11:13:35 --> Total execution time: 5.2745
INFO - 2017-05-12 11:13:38 --> Config Class Initialized
INFO - 2017-05-12 11:13:38 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:13:38 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:13:38 --> Utf8 Class Initialized
INFO - 2017-05-12 11:13:38 --> URI Class Initialized
INFO - 2017-05-12 11:13:38 --> Router Class Initialized
INFO - 2017-05-12 11:13:38 --> Output Class Initialized
INFO - 2017-05-12 11:13:38 --> Security Class Initialized
DEBUG - 2017-05-12 11:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:13:38 --> Input Class Initialized
INFO - 2017-05-12 11:13:38 --> Language Class Initialized
INFO - 2017-05-12 11:13:38 --> Loader Class Initialized
INFO - 2017-05-12 11:13:38 --> Helper loaded: url_helper
INFO - 2017-05-12 11:13:38 --> Helper loaded: form_helper
INFO - 2017-05-12 11:13:38 --> Helper loaded: html_helper
INFO - 2017-05-12 11:13:38 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:13:38 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:13:38 --> Database Driver Class Initialized
INFO - 2017-05-12 11:13:38 --> Parser Class Initialized
DEBUG - 2017-05-12 11:13:38 --> Session Class Initialized
INFO - 2017-05-12 11:13:38 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:13:38 --> Session routines successfully run
INFO - 2017-05-12 11:13:38 --> Form Validation Class Initialized
INFO - 2017-05-12 11:13:39 --> Controller Class Initialized
DEBUG - 2017-05-12 11:13:39 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:13:39 --> Model Class Initialized
DEBUG - 2017-05-12 11:13:39 --> Pagination Class Initialized
INFO - 2017-05-12 11:13:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:13:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:13:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:13:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:13:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:13:39 --> Final output sent to browser
DEBUG - 2017-05-12 11:13:39 --> Total execution time: 1.1294
INFO - 2017-05-12 11:13:39 --> Config Class Initialized
INFO - 2017-05-12 11:13:39 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:13:39 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:13:39 --> Utf8 Class Initialized
INFO - 2017-05-12 11:13:39 --> URI Class Initialized
INFO - 2017-05-12 11:13:39 --> Router Class Initialized
INFO - 2017-05-12 11:13:39 --> Config Class Initialized
INFO - 2017-05-12 11:13:40 --> Output Class Initialized
INFO - 2017-05-12 11:13:40 --> Hooks Class Initialized
INFO - 2017-05-12 11:13:40 --> Security Class Initialized
DEBUG - 2017-05-12 11:13:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 11:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:13:40 --> Utf8 Class Initialized
INFO - 2017-05-12 11:13:40 --> Input Class Initialized
INFO - 2017-05-12 11:13:40 --> URI Class Initialized
INFO - 2017-05-12 11:13:40 --> Language Class Initialized
INFO - 2017-05-12 11:13:40 --> Router Class Initialized
ERROR - 2017-05-12 11:13:40 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:13:40 --> Output Class Initialized
INFO - 2017-05-12 11:13:40 --> Security Class Initialized
DEBUG - 2017-05-12 11:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:13:40 --> Input Class Initialized
INFO - 2017-05-12 11:13:40 --> Language Class Initialized
ERROR - 2017-05-12 11:13:40 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:13:40 --> Config Class Initialized
INFO - 2017-05-12 11:13:40 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:13:40 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:13:40 --> Utf8 Class Initialized
INFO - 2017-05-12 11:13:40 --> URI Class Initialized
INFO - 2017-05-12 11:13:40 --> Router Class Initialized
INFO - 2017-05-12 11:13:40 --> Output Class Initialized
INFO - 2017-05-12 11:13:40 --> Security Class Initialized
DEBUG - 2017-05-12 11:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:13:40 --> Input Class Initialized
INFO - 2017-05-12 11:13:40 --> Language Class Initialized
INFO - 2017-05-12 11:13:40 --> Loader Class Initialized
INFO - 2017-05-12 11:13:40 --> Helper loaded: url_helper
INFO - 2017-05-12 11:13:40 --> Helper loaded: form_helper
INFO - 2017-05-12 11:13:40 --> Helper loaded: html_helper
INFO - 2017-05-12 11:13:40 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:13:40 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:13:40 --> Database Driver Class Initialized
INFO - 2017-05-12 11:13:40 --> Parser Class Initialized
DEBUG - 2017-05-12 11:13:40 --> Session Class Initialized
INFO - 2017-05-12 11:13:40 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:13:40 --> Session routines successfully run
INFO - 2017-05-12 11:13:40 --> Form Validation Class Initialized
INFO - 2017-05-12 11:13:40 --> Controller Class Initialized
DEBUG - 2017-05-12 11:13:40 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:13:40 --> Model Class Initialized
DEBUG - 2017-05-12 11:13:40 --> Pagination Class Initialized
INFO - 2017-05-12 11:13:40 --> Final output sent to browser
DEBUG - 2017-05-12 11:13:40 --> Total execution time: 0.3778
INFO - 2017-05-12 11:13:42 --> Config Class Initialized
INFO - 2017-05-12 11:13:42 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:13:42 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:13:42 --> Utf8 Class Initialized
INFO - 2017-05-12 11:13:42 --> URI Class Initialized
INFO - 2017-05-12 11:13:42 --> Router Class Initialized
INFO - 2017-05-12 11:13:42 --> Output Class Initialized
INFO - 2017-05-12 11:13:42 --> Security Class Initialized
DEBUG - 2017-05-12 11:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:13:42 --> Input Class Initialized
INFO - 2017-05-12 11:13:42 --> Language Class Initialized
INFO - 2017-05-12 11:13:42 --> Loader Class Initialized
INFO - 2017-05-12 11:13:42 --> Helper loaded: url_helper
INFO - 2017-05-12 11:13:42 --> Helper loaded: form_helper
INFO - 2017-05-12 11:13:43 --> Helper loaded: html_helper
INFO - 2017-05-12 11:13:43 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:13:43 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:13:43 --> Database Driver Class Initialized
INFO - 2017-05-12 11:13:43 --> Parser Class Initialized
DEBUG - 2017-05-12 11:13:43 --> Session Class Initialized
INFO - 2017-05-12 11:13:43 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:13:43 --> Session routines successfully run
INFO - 2017-05-12 11:13:43 --> Form Validation Class Initialized
INFO - 2017-05-12 11:13:43 --> Controller Class Initialized
DEBUG - 2017-05-12 11:13:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:13:43 --> Model Class Initialized
DEBUG - 2017-05-12 11:13:43 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:13:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:13:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-05-12 11:13:43 --> Config file loaded: ../application/admin/config/chargify.php
INFO - 2017-05-12 11:13:44 --> Config Class Initialized
INFO - 2017-05-12 11:13:44 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:13:44 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:13:44 --> Utf8 Class Initialized
INFO - 2017-05-12 11:13:44 --> URI Class Initialized
INFO - 2017-05-12 11:13:44 --> Router Class Initialized
INFO - 2017-05-12 11:13:44 --> Output Class Initialized
INFO - 2017-05-12 11:13:44 --> Security Class Initialized
DEBUG - 2017-05-12 11:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:13:44 --> Input Class Initialized
INFO - 2017-05-12 11:13:44 --> Language Class Initialized
INFO - 2017-05-12 11:13:44 --> Loader Class Initialized
INFO - 2017-05-12 11:13:44 --> Helper loaded: url_helper
INFO - 2017-05-12 11:13:44 --> Helper loaded: form_helper
INFO - 2017-05-12 11:13:44 --> Helper loaded: html_helper
INFO - 2017-05-12 11:13:44 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:13:44 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:13:44 --> Database Driver Class Initialized
INFO - 2017-05-12 11:13:44 --> Parser Class Initialized
DEBUG - 2017-05-12 11:13:44 --> Session Class Initialized
INFO - 2017-05-12 11:13:44 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:13:44 --> Session routines successfully run
INFO - 2017-05-12 11:13:44 --> Form Validation Class Initialized
INFO - 2017-05-12 11:13:44 --> Controller Class Initialized
DEBUG - 2017-05-12 11:13:44 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:13:44 --> Model Class Initialized
DEBUG - 2017-05-12 11:13:44 --> Pagination Class Initialized
INFO - 2017-05-12 11:13:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:13:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:13:49 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:13:49 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:13:49 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:13:49 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:13:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:13:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:13:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:13:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:13:49 --> Final output sent to browser
DEBUG - 2017-05-12 11:13:49 --> Total execution time: 5.1184
INFO - 2017-05-12 11:14:47 --> Config Class Initialized
INFO - 2017-05-12 11:14:47 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:14:47 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:14:47 --> Utf8 Class Initialized
INFO - 2017-05-12 11:14:47 --> URI Class Initialized
INFO - 2017-05-12 11:14:47 --> Router Class Initialized
INFO - 2017-05-12 11:14:48 --> Output Class Initialized
INFO - 2017-05-12 11:14:48 --> Security Class Initialized
DEBUG - 2017-05-12 11:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:14:48 --> Input Class Initialized
INFO - 2017-05-12 11:14:48 --> Language Class Initialized
INFO - 2017-05-12 11:14:48 --> Loader Class Initialized
INFO - 2017-05-12 11:14:48 --> Helper loaded: url_helper
INFO - 2017-05-12 11:14:48 --> Helper loaded: form_helper
INFO - 2017-05-12 11:14:48 --> Helper loaded: html_helper
INFO - 2017-05-12 11:14:48 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:14:48 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:14:48 --> Database Driver Class Initialized
INFO - 2017-05-12 11:14:48 --> Parser Class Initialized
DEBUG - 2017-05-12 11:14:48 --> Session Class Initialized
INFO - 2017-05-12 11:14:48 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:14:48 --> Session routines successfully run
INFO - 2017-05-12 11:14:48 --> Form Validation Class Initialized
INFO - 2017-05-12 11:14:48 --> Controller Class Initialized
DEBUG - 2017-05-12 11:14:48 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:14:48 --> Model Class Initialized
DEBUG - 2017-05-12 11:14:48 --> Pagination Class Initialized
INFO - 2017-05-12 11:14:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:14:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:14:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:14:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:14:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:14:49 --> Final output sent to browser
DEBUG - 2017-05-12 11:14:49 --> Total execution time: 1.1625
INFO - 2017-05-12 11:14:49 --> Config Class Initialized
INFO - 2017-05-12 11:14:49 --> Hooks Class Initialized
INFO - 2017-05-12 11:14:49 --> Config Class Initialized
INFO - 2017-05-12 11:14:49 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:14:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 11:14:49 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:14:49 --> Utf8 Class Initialized
INFO - 2017-05-12 11:14:49 --> Utf8 Class Initialized
INFO - 2017-05-12 11:14:49 --> URI Class Initialized
INFO - 2017-05-12 11:14:49 --> URI Class Initialized
INFO - 2017-05-12 11:14:49 --> Router Class Initialized
INFO - 2017-05-12 11:14:49 --> Router Class Initialized
INFO - 2017-05-12 11:14:49 --> Output Class Initialized
INFO - 2017-05-12 11:14:49 --> Output Class Initialized
INFO - 2017-05-12 11:14:49 --> Security Class Initialized
INFO - 2017-05-12 11:14:49 --> Security Class Initialized
DEBUG - 2017-05-12 11:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 11:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:14:49 --> Input Class Initialized
INFO - 2017-05-12 11:14:49 --> Input Class Initialized
INFO - 2017-05-12 11:14:49 --> Language Class Initialized
INFO - 2017-05-12 11:14:49 --> Language Class Initialized
ERROR - 2017-05-12 11:14:49 --> 404 Page Not Found: Default/assets
ERROR - 2017-05-12 11:14:49 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:14:49 --> Config Class Initialized
INFO - 2017-05-12 11:14:49 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:14:49 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:14:49 --> Utf8 Class Initialized
INFO - 2017-05-12 11:14:49 --> URI Class Initialized
INFO - 2017-05-12 11:14:49 --> Router Class Initialized
INFO - 2017-05-12 11:14:49 --> Output Class Initialized
INFO - 2017-05-12 11:14:49 --> Security Class Initialized
DEBUG - 2017-05-12 11:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:14:49 --> Input Class Initialized
INFO - 2017-05-12 11:14:49 --> Language Class Initialized
INFO - 2017-05-12 11:14:49 --> Loader Class Initialized
INFO - 2017-05-12 11:14:49 --> Helper loaded: url_helper
INFO - 2017-05-12 11:14:49 --> Helper loaded: form_helper
INFO - 2017-05-12 11:14:49 --> Helper loaded: html_helper
INFO - 2017-05-12 11:14:49 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:14:49 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:14:49 --> Database Driver Class Initialized
INFO - 2017-05-12 11:14:49 --> Parser Class Initialized
DEBUG - 2017-05-12 11:14:49 --> Session Class Initialized
INFO - 2017-05-12 11:14:49 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:14:49 --> Session routines successfully run
INFO - 2017-05-12 11:14:49 --> Form Validation Class Initialized
INFO - 2017-05-12 11:14:49 --> Controller Class Initialized
DEBUG - 2017-05-12 11:14:49 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:14:49 --> Model Class Initialized
DEBUG - 2017-05-12 11:14:49 --> Pagination Class Initialized
INFO - 2017-05-12 11:14:49 --> Final output sent to browser
DEBUG - 2017-05-12 11:14:49 --> Total execution time: 0.3894
INFO - 2017-05-12 11:15:06 --> Config Class Initialized
INFO - 2017-05-12 11:15:06 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:15:06 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:15:06 --> Utf8 Class Initialized
INFO - 2017-05-12 11:15:06 --> URI Class Initialized
INFO - 2017-05-12 11:15:06 --> Router Class Initialized
INFO - 2017-05-12 11:15:06 --> Output Class Initialized
INFO - 2017-05-12 11:15:06 --> Security Class Initialized
DEBUG - 2017-05-12 11:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:15:06 --> Input Class Initialized
INFO - 2017-05-12 11:15:06 --> Language Class Initialized
INFO - 2017-05-12 11:15:06 --> Loader Class Initialized
INFO - 2017-05-12 11:15:06 --> Helper loaded: url_helper
INFO - 2017-05-12 11:15:06 --> Helper loaded: form_helper
INFO - 2017-05-12 11:15:06 --> Helper loaded: html_helper
INFO - 2017-05-12 11:15:06 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:15:06 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:15:06 --> Database Driver Class Initialized
INFO - 2017-05-12 11:15:06 --> Parser Class Initialized
DEBUG - 2017-05-12 11:15:06 --> Session Class Initialized
INFO - 2017-05-12 11:15:06 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:15:06 --> Session routines successfully run
INFO - 2017-05-12 11:15:06 --> Form Validation Class Initialized
INFO - 2017-05-12 11:15:06 --> Controller Class Initialized
DEBUG - 2017-05-12 11:15:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:15:06 --> Model Class Initialized
DEBUG - 2017-05-12 11:15:06 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:15:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:15:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-05-12 11:15:06 --> Config file loaded: ../application/admin/config/chargify.php
INFO - 2017-05-12 11:15:07 --> Config Class Initialized
INFO - 2017-05-12 11:15:07 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:15:07 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:15:07 --> Utf8 Class Initialized
INFO - 2017-05-12 11:15:07 --> URI Class Initialized
INFO - 2017-05-12 11:15:07 --> Router Class Initialized
INFO - 2017-05-12 11:15:07 --> Output Class Initialized
INFO - 2017-05-12 11:15:08 --> Security Class Initialized
DEBUG - 2017-05-12 11:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:15:08 --> Input Class Initialized
INFO - 2017-05-12 11:15:08 --> Language Class Initialized
INFO - 2017-05-12 11:15:08 --> Loader Class Initialized
INFO - 2017-05-12 11:15:08 --> Helper loaded: url_helper
INFO - 2017-05-12 11:15:08 --> Helper loaded: form_helper
INFO - 2017-05-12 11:15:08 --> Helper loaded: html_helper
INFO - 2017-05-12 11:15:08 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:15:08 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:15:08 --> Database Driver Class Initialized
INFO - 2017-05-12 11:15:08 --> Parser Class Initialized
DEBUG - 2017-05-12 11:15:08 --> Session Class Initialized
INFO - 2017-05-12 11:15:08 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:15:08 --> Session routines successfully run
INFO - 2017-05-12 11:15:08 --> Form Validation Class Initialized
INFO - 2017-05-12 11:15:08 --> Controller Class Initialized
DEBUG - 2017-05-12 11:15:08 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:15:08 --> Model Class Initialized
DEBUG - 2017-05-12 11:15:08 --> Pagination Class Initialized
INFO - 2017-05-12 11:15:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:15:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:08 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:10 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:11 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:12 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:13 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:13 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:13 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:13 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:15:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:15:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:15:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:15:13 --> Final output sent to browser
DEBUG - 2017-05-12 11:15:13 --> Total execution time: 5.2266
INFO - 2017-05-12 11:15:20 --> Config Class Initialized
INFO - 2017-05-12 11:15:20 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:15:20 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:15:20 --> Utf8 Class Initialized
INFO - 2017-05-12 11:15:20 --> URI Class Initialized
INFO - 2017-05-12 11:15:20 --> Router Class Initialized
INFO - 2017-05-12 11:15:20 --> Output Class Initialized
INFO - 2017-05-12 11:15:20 --> Security Class Initialized
DEBUG - 2017-05-12 11:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:15:20 --> Input Class Initialized
INFO - 2017-05-12 11:15:20 --> Language Class Initialized
INFO - 2017-05-12 11:15:20 --> Loader Class Initialized
INFO - 2017-05-12 11:15:20 --> Helper loaded: url_helper
INFO - 2017-05-12 11:15:20 --> Helper loaded: form_helper
INFO - 2017-05-12 11:15:21 --> Helper loaded: html_helper
INFO - 2017-05-12 11:15:21 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:15:21 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:15:21 --> Database Driver Class Initialized
INFO - 2017-05-12 11:15:21 --> Parser Class Initialized
DEBUG - 2017-05-12 11:15:21 --> Session Class Initialized
INFO - 2017-05-12 11:15:21 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:15:21 --> Session routines successfully run
INFO - 2017-05-12 11:15:21 --> Form Validation Class Initialized
INFO - 2017-05-12 11:15:21 --> Controller Class Initialized
DEBUG - 2017-05-12 11:15:21 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:15:21 --> Model Class Initialized
DEBUG - 2017-05-12 11:15:21 --> Pagination Class Initialized
INFO - 2017-05-12 11:15:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:15:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:15:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:15:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:15:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:15:22 --> Final output sent to browser
DEBUG - 2017-05-12 11:15:22 --> Total execution time: 1.1682
INFO - 2017-05-12 11:15:22 --> Config Class Initialized
INFO - 2017-05-12 11:15:22 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:15:22 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:15:22 --> Utf8 Class Initialized
INFO - 2017-05-12 11:15:22 --> URI Class Initialized
INFO - 2017-05-12 11:15:22 --> Router Class Initialized
INFO - 2017-05-12 11:15:22 --> Config Class Initialized
INFO - 2017-05-12 11:15:22 --> Output Class Initialized
INFO - 2017-05-12 11:15:22 --> Hooks Class Initialized
INFO - 2017-05-12 11:15:22 --> Security Class Initialized
DEBUG - 2017-05-12 11:15:22 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 11:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:15:22 --> Utf8 Class Initialized
INFO - 2017-05-12 11:15:22 --> Input Class Initialized
INFO - 2017-05-12 11:15:22 --> URI Class Initialized
INFO - 2017-05-12 11:15:22 --> Language Class Initialized
INFO - 2017-05-12 11:15:22 --> Router Class Initialized
ERROR - 2017-05-12 11:15:22 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:15:22 --> Output Class Initialized
INFO - 2017-05-12 11:15:22 --> Security Class Initialized
DEBUG - 2017-05-12 11:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:15:22 --> Input Class Initialized
INFO - 2017-05-12 11:15:22 --> Language Class Initialized
ERROR - 2017-05-12 11:15:22 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:15:22 --> Config Class Initialized
INFO - 2017-05-12 11:15:22 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:15:22 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:15:22 --> Utf8 Class Initialized
INFO - 2017-05-12 11:15:22 --> URI Class Initialized
INFO - 2017-05-12 11:15:22 --> Router Class Initialized
INFO - 2017-05-12 11:15:22 --> Output Class Initialized
INFO - 2017-05-12 11:15:22 --> Security Class Initialized
DEBUG - 2017-05-12 11:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:15:22 --> Input Class Initialized
INFO - 2017-05-12 11:15:22 --> Language Class Initialized
INFO - 2017-05-12 11:15:22 --> Loader Class Initialized
INFO - 2017-05-12 11:15:22 --> Helper loaded: url_helper
INFO - 2017-05-12 11:15:22 --> Helper loaded: form_helper
INFO - 2017-05-12 11:15:22 --> Helper loaded: html_helper
INFO - 2017-05-12 11:15:22 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:15:22 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:15:22 --> Database Driver Class Initialized
INFO - 2017-05-12 11:15:22 --> Parser Class Initialized
DEBUG - 2017-05-12 11:15:22 --> Session Class Initialized
INFO - 2017-05-12 11:15:22 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:15:22 --> Session routines successfully run
INFO - 2017-05-12 11:15:22 --> Form Validation Class Initialized
INFO - 2017-05-12 11:15:22 --> Controller Class Initialized
DEBUG - 2017-05-12 11:15:22 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:15:22 --> Model Class Initialized
DEBUG - 2017-05-12 11:15:22 --> Pagination Class Initialized
INFO - 2017-05-12 11:15:22 --> Final output sent to browser
DEBUG - 2017-05-12 11:15:22 --> Total execution time: 0.3732
INFO - 2017-05-12 11:15:31 --> Config Class Initialized
INFO - 2017-05-12 11:15:31 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:15:31 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:15:31 --> Utf8 Class Initialized
INFO - 2017-05-12 11:15:31 --> URI Class Initialized
INFO - 2017-05-12 11:15:31 --> Router Class Initialized
INFO - 2017-05-12 11:15:31 --> Output Class Initialized
INFO - 2017-05-12 11:15:31 --> Security Class Initialized
DEBUG - 2017-05-12 11:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:15:31 --> Input Class Initialized
INFO - 2017-05-12 11:15:31 --> Language Class Initialized
INFO - 2017-05-12 11:15:31 --> Loader Class Initialized
INFO - 2017-05-12 11:15:31 --> Helper loaded: url_helper
INFO - 2017-05-12 11:15:31 --> Helper loaded: form_helper
INFO - 2017-05-12 11:15:31 --> Helper loaded: html_helper
INFO - 2017-05-12 11:15:31 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:15:31 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:15:31 --> Database Driver Class Initialized
INFO - 2017-05-12 11:15:31 --> Parser Class Initialized
DEBUG - 2017-05-12 11:15:31 --> Session Class Initialized
INFO - 2017-05-12 11:15:31 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:15:31 --> Session routines successfully run
INFO - 2017-05-12 11:15:31 --> Form Validation Class Initialized
INFO - 2017-05-12 11:15:31 --> Controller Class Initialized
DEBUG - 2017-05-12 11:15:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:15:31 --> Model Class Initialized
DEBUG - 2017-05-12 11:15:31 --> Pagination Class Initialized
INFO - 2017-05-12 11:15:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:15:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:32 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:32 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:32 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:32 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:32 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:32 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:32 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:32 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:32 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:32 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:35 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:15:36 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:15:36 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:15:36 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:15:36 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:15:36 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:15:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:15:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:15:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:15:36 --> Final output sent to browser
DEBUG - 2017-05-12 11:15:36 --> Total execution time: 5.2765
INFO - 2017-05-12 11:15:43 --> Config Class Initialized
INFO - 2017-05-12 11:15:43 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:15:43 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:15:43 --> Utf8 Class Initialized
INFO - 2017-05-12 11:15:43 --> URI Class Initialized
INFO - 2017-05-12 11:15:43 --> Router Class Initialized
INFO - 2017-05-12 11:15:43 --> Output Class Initialized
INFO - 2017-05-12 11:15:44 --> Security Class Initialized
DEBUG - 2017-05-12 11:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:15:44 --> Input Class Initialized
INFO - 2017-05-12 11:15:44 --> Language Class Initialized
INFO - 2017-05-12 11:15:44 --> Loader Class Initialized
INFO - 2017-05-12 11:15:44 --> Helper loaded: url_helper
INFO - 2017-05-12 11:15:44 --> Helper loaded: form_helper
INFO - 2017-05-12 11:15:44 --> Helper loaded: html_helper
INFO - 2017-05-12 11:15:44 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:15:44 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:15:44 --> Database Driver Class Initialized
INFO - 2017-05-12 11:15:44 --> Parser Class Initialized
DEBUG - 2017-05-12 11:15:44 --> Session Class Initialized
INFO - 2017-05-12 11:15:44 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:15:44 --> Session routines successfully run
INFO - 2017-05-12 11:15:44 --> Form Validation Class Initialized
INFO - 2017-05-12 11:15:44 --> Controller Class Initialized
DEBUG - 2017-05-12 11:15:44 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:15:44 --> Model Class Initialized
DEBUG - 2017-05-12 11:15:44 --> Pagination Class Initialized
INFO - 2017-05-12 11:15:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:15:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:15:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:15:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:15:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:15:44 --> Final output sent to browser
DEBUG - 2017-05-12 11:15:44 --> Total execution time: 0.4423
INFO - 2017-05-12 11:15:44 --> Config Class Initialized
INFO - 2017-05-12 11:15:44 --> Config Class Initialized
INFO - 2017-05-12 11:15:44 --> Hooks Class Initialized
INFO - 2017-05-12 11:15:44 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:15:44 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:15:44 --> Utf8 Class Initialized
DEBUG - 2017-05-12 11:15:44 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:15:44 --> Utf8 Class Initialized
INFO - 2017-05-12 11:15:44 --> URI Class Initialized
INFO - 2017-05-12 11:15:44 --> URI Class Initialized
INFO - 2017-05-12 11:15:44 --> Router Class Initialized
INFO - 2017-05-12 11:15:44 --> Router Class Initialized
INFO - 2017-05-12 11:15:44 --> Output Class Initialized
INFO - 2017-05-12 11:15:44 --> Output Class Initialized
INFO - 2017-05-12 11:15:44 --> Security Class Initialized
INFO - 2017-05-12 11:15:44 --> Security Class Initialized
DEBUG - 2017-05-12 11:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 11:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:15:44 --> Input Class Initialized
INFO - 2017-05-12 11:15:44 --> Input Class Initialized
INFO - 2017-05-12 11:15:44 --> Language Class Initialized
INFO - 2017-05-12 11:15:44 --> Language Class Initialized
ERROR - 2017-05-12 11:15:44 --> 404 Page Not Found: Default/assets
ERROR - 2017-05-12 11:15:44 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:15:44 --> Config Class Initialized
INFO - 2017-05-12 11:15:44 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:15:44 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:15:44 --> Utf8 Class Initialized
INFO - 2017-05-12 11:15:44 --> URI Class Initialized
INFO - 2017-05-12 11:15:44 --> Router Class Initialized
INFO - 2017-05-12 11:15:44 --> Output Class Initialized
INFO - 2017-05-12 11:15:44 --> Security Class Initialized
DEBUG - 2017-05-12 11:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:15:44 --> Input Class Initialized
INFO - 2017-05-12 11:15:44 --> Language Class Initialized
INFO - 2017-05-12 11:15:44 --> Loader Class Initialized
INFO - 2017-05-12 11:15:44 --> Helper loaded: url_helper
INFO - 2017-05-12 11:15:44 --> Helper loaded: form_helper
INFO - 2017-05-12 11:15:44 --> Helper loaded: html_helper
INFO - 2017-05-12 11:15:44 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:15:44 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:15:44 --> Database Driver Class Initialized
INFO - 2017-05-12 11:15:44 --> Parser Class Initialized
DEBUG - 2017-05-12 11:15:44 --> Session Class Initialized
INFO - 2017-05-12 11:15:45 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:15:45 --> Session routines successfully run
INFO - 2017-05-12 11:15:45 --> Form Validation Class Initialized
INFO - 2017-05-12 11:15:45 --> Controller Class Initialized
DEBUG - 2017-05-12 11:15:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:15:45 --> Model Class Initialized
DEBUG - 2017-05-12 11:15:45 --> Pagination Class Initialized
INFO - 2017-05-12 11:15:45 --> Final output sent to browser
DEBUG - 2017-05-12 11:15:45 --> Total execution time: 0.3756
INFO - 2017-05-12 11:16:10 --> Config Class Initialized
INFO - 2017-05-12 11:16:10 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:16:10 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:16:10 --> Utf8 Class Initialized
INFO - 2017-05-12 11:16:10 --> URI Class Initialized
INFO - 2017-05-12 11:16:10 --> Router Class Initialized
INFO - 2017-05-12 11:16:10 --> Output Class Initialized
INFO - 2017-05-12 11:16:10 --> Security Class Initialized
DEBUG - 2017-05-12 11:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:16:10 --> Input Class Initialized
INFO - 2017-05-12 11:16:10 --> Language Class Initialized
INFO - 2017-05-12 11:16:10 --> Loader Class Initialized
INFO - 2017-05-12 11:16:10 --> Helper loaded: url_helper
INFO - 2017-05-12 11:16:10 --> Helper loaded: form_helper
INFO - 2017-05-12 11:16:10 --> Helper loaded: html_helper
INFO - 2017-05-12 11:16:10 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:16:10 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:16:10 --> Database Driver Class Initialized
INFO - 2017-05-12 11:16:10 --> Parser Class Initialized
DEBUG - 2017-05-12 11:16:10 --> Session Class Initialized
INFO - 2017-05-12 11:16:10 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:16:10 --> Session routines successfully run
INFO - 2017-05-12 11:16:10 --> Form Validation Class Initialized
INFO - 2017-05-12 11:16:10 --> Controller Class Initialized
DEBUG - 2017-05-12 11:16:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:16:10 --> Model Class Initialized
DEBUG - 2017-05-12 11:16:10 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:16:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:16:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:16:10 --> Upload Class Initialized
INFO - 2017-05-12 11:16:10 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-05-12 11:16:11 --> The upload path does not appear to be valid.
INFO - 2017-05-12 11:16:11 --> Image Lib Class Initialized
INFO - 2017-05-12 11:16:11 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-05-12 11:16:11 --> The path to the image is not correct.
ERROR - 2017-05-12 11:16:11 --> Your server does not support the GD function required to process this type of image.
INFO - 2017-05-12 11:17:19 --> Config Class Initialized
INFO - 2017-05-12 11:17:19 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:17:19 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:17:19 --> Utf8 Class Initialized
INFO - 2017-05-12 11:17:19 --> URI Class Initialized
INFO - 2017-05-12 11:17:19 --> Router Class Initialized
INFO - 2017-05-12 11:17:19 --> Output Class Initialized
INFO - 2017-05-12 11:17:19 --> Security Class Initialized
DEBUG - 2017-05-12 11:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:17:19 --> Input Class Initialized
INFO - 2017-05-12 11:17:19 --> Language Class Initialized
INFO - 2017-05-12 11:17:19 --> Loader Class Initialized
INFO - 2017-05-12 11:17:19 --> Helper loaded: url_helper
INFO - 2017-05-12 11:17:19 --> Helper loaded: form_helper
INFO - 2017-05-12 11:17:20 --> Helper loaded: html_helper
INFO - 2017-05-12 11:17:20 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:17:20 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:17:20 --> Database Driver Class Initialized
INFO - 2017-05-12 11:17:20 --> Parser Class Initialized
DEBUG - 2017-05-12 11:17:20 --> Session Class Initialized
INFO - 2017-05-12 11:17:20 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:17:20 --> Session routines successfully run
INFO - 2017-05-12 11:17:20 --> Form Validation Class Initialized
INFO - 2017-05-12 11:17:20 --> Controller Class Initialized
DEBUG - 2017-05-12 11:17:20 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:17:20 --> Model Class Initialized
DEBUG - 2017-05-12 11:17:20 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:17:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:17:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:17:20 --> Upload Class Initialized
INFO - 2017-05-12 11:17:20 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-05-12 11:17:20 --> The upload path does not appear to be valid.
INFO - 2017-05-12 11:17:20 --> Image Lib Class Initialized
INFO - 2017-05-12 11:17:20 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-05-12 11:17:20 --> The path to the image is not correct.
ERROR - 2017-05-12 11:17:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2017-05-12 11:17:22 --> Severity: User Warning --> S3::inputFile(): Unable to open input file:  C:\xampp\htdocs\schedullo\system\libraries\S3.php 449
INFO - 2017-05-12 11:17:22 --> Config Class Initialized
INFO - 2017-05-12 11:17:22 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:17:22 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:17:22 --> Utf8 Class Initialized
INFO - 2017-05-12 11:17:22 --> URI Class Initialized
INFO - 2017-05-12 11:17:22 --> Router Class Initialized
INFO - 2017-05-12 11:17:22 --> Output Class Initialized
INFO - 2017-05-12 11:17:22 --> Security Class Initialized
DEBUG - 2017-05-12 11:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:17:22 --> Input Class Initialized
INFO - 2017-05-12 11:17:22 --> Language Class Initialized
INFO - 2017-05-12 11:17:22 --> Loader Class Initialized
INFO - 2017-05-12 11:17:22 --> Helper loaded: url_helper
INFO - 2017-05-12 11:17:22 --> Helper loaded: form_helper
INFO - 2017-05-12 11:17:22 --> Helper loaded: html_helper
INFO - 2017-05-12 11:17:22 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:17:22 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:17:22 --> Database Driver Class Initialized
INFO - 2017-05-12 11:17:22 --> Parser Class Initialized
DEBUG - 2017-05-12 11:17:22 --> Session Class Initialized
INFO - 2017-05-12 11:17:22 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:17:22 --> Session routines successfully run
INFO - 2017-05-12 11:17:22 --> Form Validation Class Initialized
INFO - 2017-05-12 11:17:22 --> Controller Class Initialized
DEBUG - 2017-05-12 11:17:22 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:17:22 --> Model Class Initialized
DEBUG - 2017-05-12 11:17:22 --> Pagination Class Initialized
INFO - 2017-05-12 11:17:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:17:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:23 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:24 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:25 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:26 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:28 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:28 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:28 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:28 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:28 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:17:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:17:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:17:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:17:28 --> Final output sent to browser
DEBUG - 2017-05-12 11:17:28 --> Total execution time: 6.1188
INFO - 2017-05-12 11:17:34 --> Config Class Initialized
INFO - 2017-05-12 11:17:34 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:17:34 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:17:34 --> Utf8 Class Initialized
INFO - 2017-05-12 11:17:34 --> URI Class Initialized
INFO - 2017-05-12 11:17:34 --> Router Class Initialized
INFO - 2017-05-12 11:17:34 --> Output Class Initialized
INFO - 2017-05-12 11:17:34 --> Security Class Initialized
DEBUG - 2017-05-12 11:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:17:34 --> Input Class Initialized
INFO - 2017-05-12 11:17:34 --> Language Class Initialized
INFO - 2017-05-12 11:17:34 --> Loader Class Initialized
INFO - 2017-05-12 11:17:34 --> Helper loaded: url_helper
INFO - 2017-05-12 11:17:34 --> Helper loaded: form_helper
INFO - 2017-05-12 11:17:34 --> Helper loaded: html_helper
INFO - 2017-05-12 11:17:34 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:17:34 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:17:34 --> Database Driver Class Initialized
INFO - 2017-05-12 11:17:34 --> Parser Class Initialized
DEBUG - 2017-05-12 11:17:34 --> Session Class Initialized
INFO - 2017-05-12 11:17:34 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:17:34 --> Session routines successfully run
INFO - 2017-05-12 11:17:34 --> Form Validation Class Initialized
INFO - 2017-05-12 11:17:34 --> Controller Class Initialized
DEBUG - 2017-05-12 11:17:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:17:34 --> Model Class Initialized
DEBUG - 2017-05-12 11:17:34 --> Pagination Class Initialized
INFO - 2017-05-12 11:17:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:17:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:17:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:17:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:17:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:17:35 --> Final output sent to browser
DEBUG - 2017-05-12 11:17:35 --> Total execution time: 1.3677
INFO - 2017-05-12 11:17:35 --> Config Class Initialized
INFO - 2017-05-12 11:17:35 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:17:35 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:17:35 --> Utf8 Class Initialized
INFO - 2017-05-12 11:17:36 --> URI Class Initialized
INFO - 2017-05-12 11:17:36 --> Router Class Initialized
INFO - 2017-05-12 11:17:36 --> Output Class Initialized
INFO - 2017-05-12 11:17:36 --> Config Class Initialized
INFO - 2017-05-12 11:17:36 --> Security Class Initialized
INFO - 2017-05-12 11:17:36 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 11:17:36 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:17:36 --> Input Class Initialized
INFO - 2017-05-12 11:17:36 --> Utf8 Class Initialized
INFO - 2017-05-12 11:17:36 --> Language Class Initialized
INFO - 2017-05-12 11:17:36 --> URI Class Initialized
ERROR - 2017-05-12 11:17:36 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:17:36 --> Router Class Initialized
INFO - 2017-05-12 11:17:36 --> Output Class Initialized
INFO - 2017-05-12 11:17:36 --> Security Class Initialized
DEBUG - 2017-05-12 11:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:17:36 --> Input Class Initialized
INFO - 2017-05-12 11:17:36 --> Language Class Initialized
ERROR - 2017-05-12 11:17:36 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:17:36 --> Config Class Initialized
INFO - 2017-05-12 11:17:36 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:17:36 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:17:36 --> Utf8 Class Initialized
INFO - 2017-05-12 11:17:36 --> URI Class Initialized
INFO - 2017-05-12 11:17:36 --> Router Class Initialized
INFO - 2017-05-12 11:17:36 --> Output Class Initialized
INFO - 2017-05-12 11:17:36 --> Security Class Initialized
DEBUG - 2017-05-12 11:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:17:36 --> Input Class Initialized
INFO - 2017-05-12 11:17:36 --> Language Class Initialized
INFO - 2017-05-12 11:17:36 --> Loader Class Initialized
INFO - 2017-05-12 11:17:36 --> Helper loaded: url_helper
INFO - 2017-05-12 11:17:36 --> Helper loaded: form_helper
INFO - 2017-05-12 11:17:36 --> Helper loaded: html_helper
INFO - 2017-05-12 11:17:36 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:17:36 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:17:36 --> Database Driver Class Initialized
INFO - 2017-05-12 11:17:36 --> Parser Class Initialized
DEBUG - 2017-05-12 11:17:36 --> Session Class Initialized
INFO - 2017-05-12 11:17:36 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:17:36 --> Session routines successfully run
INFO - 2017-05-12 11:17:36 --> Form Validation Class Initialized
INFO - 2017-05-12 11:17:36 --> Controller Class Initialized
DEBUG - 2017-05-12 11:17:36 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:17:36 --> Model Class Initialized
DEBUG - 2017-05-12 11:17:36 --> Pagination Class Initialized
INFO - 2017-05-12 11:17:36 --> Final output sent to browser
DEBUG - 2017-05-12 11:17:36 --> Total execution time: 0.3964
INFO - 2017-05-12 11:17:40 --> Config Class Initialized
INFO - 2017-05-12 11:17:40 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:17:40 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:17:40 --> Utf8 Class Initialized
INFO - 2017-05-12 11:17:40 --> URI Class Initialized
INFO - 2017-05-12 11:17:40 --> Router Class Initialized
INFO - 2017-05-12 11:17:40 --> Output Class Initialized
INFO - 2017-05-12 11:17:40 --> Security Class Initialized
DEBUG - 2017-05-12 11:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:17:40 --> Input Class Initialized
INFO - 2017-05-12 11:17:40 --> Language Class Initialized
INFO - 2017-05-12 11:17:40 --> Loader Class Initialized
INFO - 2017-05-12 11:17:40 --> Helper loaded: url_helper
INFO - 2017-05-12 11:17:40 --> Helper loaded: form_helper
INFO - 2017-05-12 11:17:40 --> Helper loaded: html_helper
INFO - 2017-05-12 11:17:40 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:17:40 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:17:40 --> Database Driver Class Initialized
INFO - 2017-05-12 11:17:40 --> Parser Class Initialized
DEBUG - 2017-05-12 11:17:40 --> Session Class Initialized
INFO - 2017-05-12 11:17:40 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:17:40 --> Session routines successfully run
INFO - 2017-05-12 11:17:40 --> Form Validation Class Initialized
INFO - 2017-05-12 11:17:40 --> Controller Class Initialized
DEBUG - 2017-05-12 11:17:40 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:17:40 --> Model Class Initialized
DEBUG - 2017-05-12 11:17:40 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:17:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:17:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:17:40 --> Upload Class Initialized
INFO - 2017-05-12 11:17:40 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-05-12 11:17:40 --> The upload path does not appear to be valid.
INFO - 2017-05-12 11:17:40 --> Image Lib Class Initialized
INFO - 2017-05-12 11:17:40 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-05-12 11:17:40 --> The path to the image is not correct.
ERROR - 2017-05-12 11:17:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2017-05-12 11:17:42 --> Severity: User Warning --> S3::inputFile(): Unable to open input file:  C:\xampp\htdocs\schedullo\system\libraries\S3.php 449
INFO - 2017-05-12 11:17:44 --> Config Class Initialized
INFO - 2017-05-12 11:17:45 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:17:45 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:17:45 --> Utf8 Class Initialized
INFO - 2017-05-12 11:17:45 --> URI Class Initialized
INFO - 2017-05-12 11:17:45 --> Router Class Initialized
INFO - 2017-05-12 11:17:45 --> Output Class Initialized
INFO - 2017-05-12 11:17:45 --> Security Class Initialized
DEBUG - 2017-05-12 11:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:17:45 --> Input Class Initialized
INFO - 2017-05-12 11:17:45 --> Language Class Initialized
INFO - 2017-05-12 11:17:45 --> Loader Class Initialized
INFO - 2017-05-12 11:17:45 --> Helper loaded: url_helper
INFO - 2017-05-12 11:17:45 --> Helper loaded: form_helper
INFO - 2017-05-12 11:17:45 --> Helper loaded: html_helper
INFO - 2017-05-12 11:17:45 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:17:45 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:17:45 --> Database Driver Class Initialized
INFO - 2017-05-12 11:17:45 --> Parser Class Initialized
DEBUG - 2017-05-12 11:17:45 --> Session Class Initialized
INFO - 2017-05-12 11:17:45 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:17:45 --> Session routines successfully run
INFO - 2017-05-12 11:17:45 --> Form Validation Class Initialized
INFO - 2017-05-12 11:17:45 --> Controller Class Initialized
DEBUG - 2017-05-12 11:17:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:17:45 --> Model Class Initialized
DEBUG - 2017-05-12 11:17:45 --> Pagination Class Initialized
INFO - 2017-05-12 11:17:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:17:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:46 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:47 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:48 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:49 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:17:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:17:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:17:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:17:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:17:51 --> Final output sent to browser
DEBUG - 2017-05-12 11:17:51 --> Total execution time: 6.0482
INFO - 2017-05-12 11:17:55 --> Config Class Initialized
INFO - 2017-05-12 11:17:55 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:17:55 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:17:55 --> Utf8 Class Initialized
INFO - 2017-05-12 11:17:55 --> URI Class Initialized
INFO - 2017-05-12 11:17:55 --> Router Class Initialized
INFO - 2017-05-12 11:17:55 --> Output Class Initialized
INFO - 2017-05-12 11:17:55 --> Security Class Initialized
DEBUG - 2017-05-12 11:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:17:56 --> Input Class Initialized
INFO - 2017-05-12 11:17:56 --> Language Class Initialized
INFO - 2017-05-12 11:17:56 --> Loader Class Initialized
INFO - 2017-05-12 11:17:56 --> Helper loaded: url_helper
INFO - 2017-05-12 11:17:56 --> Helper loaded: form_helper
INFO - 2017-05-12 11:17:56 --> Helper loaded: html_helper
INFO - 2017-05-12 11:17:56 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:17:56 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:17:56 --> Database Driver Class Initialized
INFO - 2017-05-12 11:17:56 --> Parser Class Initialized
DEBUG - 2017-05-12 11:17:56 --> Session Class Initialized
INFO - 2017-05-12 11:17:56 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:17:56 --> Session routines successfully run
INFO - 2017-05-12 11:17:56 --> Form Validation Class Initialized
INFO - 2017-05-12 11:17:56 --> Controller Class Initialized
DEBUG - 2017-05-12 11:17:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:17:56 --> Model Class Initialized
DEBUG - 2017-05-12 11:17:56 --> Pagination Class Initialized
INFO - 2017-05-12 11:17:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:17:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:01 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:02 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:03 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:03 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:03 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:03 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:03 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:04 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:18:06 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:18:06 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:18:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:18:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:18:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:18:06 --> Final output sent to browser
DEBUG - 2017-05-12 11:18:06 --> Total execution time: 10.2043
INFO - 2017-05-12 11:18:09 --> Config Class Initialized
INFO - 2017-05-12 11:18:09 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:09 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:09 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:09 --> URI Class Initialized
INFO - 2017-05-12 11:18:09 --> Router Class Initialized
INFO - 2017-05-12 11:18:09 --> Output Class Initialized
INFO - 2017-05-12 11:18:10 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:10 --> Input Class Initialized
INFO - 2017-05-12 11:18:10 --> Language Class Initialized
INFO - 2017-05-12 11:18:10 --> Loader Class Initialized
INFO - 2017-05-12 11:18:10 --> Helper loaded: url_helper
INFO - 2017-05-12 11:18:10 --> Helper loaded: form_helper
INFO - 2017-05-12 11:18:10 --> Helper loaded: html_helper
INFO - 2017-05-12 11:18:10 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:18:10 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:18:10 --> Database Driver Class Initialized
INFO - 2017-05-12 11:18:10 --> Parser Class Initialized
DEBUG - 2017-05-12 11:18:10 --> Session Class Initialized
INFO - 2017-05-12 11:18:10 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:18:10 --> Session routines successfully run
INFO - 2017-05-12 11:18:10 --> Form Validation Class Initialized
INFO - 2017-05-12 11:18:10 --> Controller Class Initialized
DEBUG - 2017-05-12 11:18:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:18:10 --> Model Class Initialized
DEBUG - 2017-05-12 11:18:10 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:18:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:18:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:18:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:18:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:18:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:18:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:18:10 --> Final output sent to browser
DEBUG - 2017-05-12 11:18:10 --> Total execution time: 0.4858
INFO - 2017-05-12 11:18:10 --> Config Class Initialized
INFO - 2017-05-12 11:18:10 --> Config Class Initialized
INFO - 2017-05-12 11:18:10 --> Hooks Class Initialized
INFO - 2017-05-12 11:18:10 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:10 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 11:18:10 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:10 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:10 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:10 --> URI Class Initialized
INFO - 2017-05-12 11:18:10 --> URI Class Initialized
INFO - 2017-05-12 11:18:10 --> Router Class Initialized
INFO - 2017-05-12 11:18:10 --> Router Class Initialized
INFO - 2017-05-12 11:18:10 --> Output Class Initialized
INFO - 2017-05-12 11:18:10 --> Output Class Initialized
INFO - 2017-05-12 11:18:10 --> Security Class Initialized
INFO - 2017-05-12 11:18:10 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 11:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:10 --> Input Class Initialized
INFO - 2017-05-12 11:18:10 --> Input Class Initialized
INFO - 2017-05-12 11:18:10 --> Language Class Initialized
INFO - 2017-05-12 11:18:10 --> Language Class Initialized
ERROR - 2017-05-12 11:18:10 --> 404 Page Not Found: Default/assets
ERROR - 2017-05-12 11:18:10 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:18:11 --> Config Class Initialized
INFO - 2017-05-12 11:18:11 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:11 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:11 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:11 --> URI Class Initialized
INFO - 2017-05-12 11:18:11 --> Router Class Initialized
INFO - 2017-05-12 11:18:11 --> Output Class Initialized
INFO - 2017-05-12 11:18:11 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:11 --> Input Class Initialized
INFO - 2017-05-12 11:18:11 --> Language Class Initialized
INFO - 2017-05-12 11:18:11 --> Loader Class Initialized
INFO - 2017-05-12 11:18:11 --> Helper loaded: url_helper
INFO - 2017-05-12 11:18:11 --> Helper loaded: form_helper
INFO - 2017-05-12 11:18:11 --> Helper loaded: html_helper
INFO - 2017-05-12 11:18:11 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:18:11 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:18:11 --> Database Driver Class Initialized
INFO - 2017-05-12 11:18:11 --> Parser Class Initialized
DEBUG - 2017-05-12 11:18:11 --> Session Class Initialized
INFO - 2017-05-12 11:18:11 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:18:11 --> Session routines successfully run
INFO - 2017-05-12 11:18:11 --> Form Validation Class Initialized
INFO - 2017-05-12 11:18:11 --> Controller Class Initialized
DEBUG - 2017-05-12 11:18:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:18:11 --> Model Class Initialized
DEBUG - 2017-05-12 11:18:11 --> Pagination Class Initialized
ERROR - 2017-05-12 11:18:11 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 883
ERROR - 2017-05-12 11:18:11 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 886
INFO - 2017-05-12 11:18:11 --> Final output sent to browser
DEBUG - 2017-05-12 11:18:11 --> Total execution time: 0.4139
INFO - 2017-05-12 11:18:21 --> Config Class Initialized
INFO - 2017-05-12 11:18:21 --> Config Class Initialized
INFO - 2017-05-12 11:18:21 --> Hooks Class Initialized
INFO - 2017-05-12 11:18:21 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:21 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 11:18:21 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:21 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:21 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:21 --> URI Class Initialized
INFO - 2017-05-12 11:18:21 --> URI Class Initialized
INFO - 2017-05-12 11:18:21 --> Router Class Initialized
INFO - 2017-05-12 11:18:21 --> Router Class Initialized
INFO - 2017-05-12 11:18:21 --> Output Class Initialized
INFO - 2017-05-12 11:18:21 --> Output Class Initialized
INFO - 2017-05-12 11:18:21 --> Security Class Initialized
INFO - 2017-05-12 11:18:21 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 11:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:21 --> Input Class Initialized
INFO - 2017-05-12 11:18:21 --> Input Class Initialized
INFO - 2017-05-12 11:18:21 --> Language Class Initialized
INFO - 2017-05-12 11:18:21 --> Language Class Initialized
INFO - 2017-05-12 11:18:21 --> Loader Class Initialized
INFO - 2017-05-12 11:18:21 --> Loader Class Initialized
INFO - 2017-05-12 11:18:21 --> Helper loaded: url_helper
INFO - 2017-05-12 11:18:21 --> Helper loaded: url_helper
INFO - 2017-05-12 11:18:21 --> Helper loaded: form_helper
INFO - 2017-05-12 11:18:21 --> Helper loaded: form_helper
INFO - 2017-05-12 11:18:21 --> Helper loaded: html_helper
INFO - 2017-05-12 11:18:21 --> Helper loaded: html_helper
INFO - 2017-05-12 11:18:21 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:18:21 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:18:21 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:18:21 --> Database Driver Class Initialized
INFO - 2017-05-12 11:18:21 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:18:21 --> Parser Class Initialized
INFO - 2017-05-12 11:18:21 --> Database Driver Class Initialized
DEBUG - 2017-05-12 11:18:21 --> Session Class Initialized
INFO - 2017-05-12 11:18:21 --> Parser Class Initialized
INFO - 2017-05-12 11:18:21 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:18:21 --> Session Class Initialized
DEBUG - 2017-05-12 11:18:21 --> Session routines successfully run
INFO - 2017-05-12 11:18:21 --> Helper loaded: string_helper
INFO - 2017-05-12 11:18:21 --> Form Validation Class Initialized
DEBUG - 2017-05-12 11:18:21 --> Session routines successfully run
INFO - 2017-05-12 11:18:21 --> Controller Class Initialized
INFO - 2017-05-12 11:18:21 --> Form Validation Class Initialized
DEBUG - 2017-05-12 11:18:21 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:18:21 --> Controller Class Initialized
INFO - 2017-05-12 11:18:21 --> Model Class Initialized
DEBUG - 2017-05-12 11:18:21 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2017-05-12 11:18:21 --> Pagination Class Initialized
INFO - 2017-05-12 11:18:22 --> Model Class Initialized
INFO - 2017-05-12 11:18:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
DEBUG - 2017-05-12 11:18:22 --> Pagination Class Initialized
INFO - 2017-05-12 11:18:22 --> Final output sent to browser
INFO - 2017-05-12 11:18:22 --> Final output sent to browser
DEBUG - 2017-05-12 11:18:22 --> Total execution time: 0.6334
DEBUG - 2017-05-12 11:18:22 --> Total execution time: 0.6467
INFO - 2017-05-12 11:18:25 --> Config Class Initialized
INFO - 2017-05-12 11:18:25 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:25 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:25 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:25 --> URI Class Initialized
INFO - 2017-05-12 11:18:25 --> Router Class Initialized
INFO - 2017-05-12 11:18:25 --> Output Class Initialized
INFO - 2017-05-12 11:18:25 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:25 --> Input Class Initialized
INFO - 2017-05-12 11:18:25 --> Language Class Initialized
INFO - 2017-05-12 11:18:25 --> Loader Class Initialized
INFO - 2017-05-12 11:18:25 --> Helper loaded: url_helper
INFO - 2017-05-12 11:18:25 --> Helper loaded: form_helper
INFO - 2017-05-12 11:18:25 --> Helper loaded: html_helper
INFO - 2017-05-12 11:18:25 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:18:25 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:18:25 --> Database Driver Class Initialized
INFO - 2017-05-12 11:18:25 --> Parser Class Initialized
DEBUG - 2017-05-12 11:18:25 --> Session Class Initialized
INFO - 2017-05-12 11:18:25 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:18:25 --> Session routines successfully run
INFO - 2017-05-12 11:18:25 --> Form Validation Class Initialized
INFO - 2017-05-12 11:18:25 --> Controller Class Initialized
DEBUG - 2017-05-12 11:18:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:18:25 --> Model Class Initialized
DEBUG - 2017-05-12 11:18:25 --> Pagination Class Initialized
INFO - 2017-05-12 11:18:25 --> Final output sent to browser
DEBUG - 2017-05-12 11:18:25 --> Total execution time: 0.3780
INFO - 2017-05-12 11:18:31 --> Config Class Initialized
INFO - 2017-05-12 11:18:31 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:31 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:31 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:31 --> URI Class Initialized
INFO - 2017-05-12 11:18:31 --> Router Class Initialized
INFO - 2017-05-12 11:18:31 --> Output Class Initialized
INFO - 2017-05-12 11:18:31 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:31 --> Input Class Initialized
INFO - 2017-05-12 11:18:31 --> Language Class Initialized
INFO - 2017-05-12 11:18:31 --> Loader Class Initialized
INFO - 2017-05-12 11:18:31 --> Helper loaded: url_helper
INFO - 2017-05-12 11:18:31 --> Helper loaded: form_helper
INFO - 2017-05-12 11:18:31 --> Helper loaded: html_helper
INFO - 2017-05-12 11:18:31 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:18:31 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:18:31 --> Database Driver Class Initialized
INFO - 2017-05-12 11:18:31 --> Parser Class Initialized
DEBUG - 2017-05-12 11:18:31 --> Session Class Initialized
INFO - 2017-05-12 11:18:31 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:18:31 --> Session routines successfully run
INFO - 2017-05-12 11:18:31 --> Form Validation Class Initialized
INFO - 2017-05-12 11:18:31 --> Controller Class Initialized
DEBUG - 2017-05-12 11:18:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:18:31 --> Model Class Initialized
DEBUG - 2017-05-12 11:18:31 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:18:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:18:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:18:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:18:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:18:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:18:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:18:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:18:32 --> Final output sent to browser
DEBUG - 2017-05-12 11:18:32 --> Total execution time: 0.5092
INFO - 2017-05-12 11:18:32 --> Config Class Initialized
INFO - 2017-05-12 11:18:32 --> Config Class Initialized
INFO - 2017-05-12 11:18:32 --> Hooks Class Initialized
INFO - 2017-05-12 11:18:32 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 11:18:32 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:32 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:32 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:32 --> URI Class Initialized
INFO - 2017-05-12 11:18:32 --> URI Class Initialized
INFO - 2017-05-12 11:18:32 --> Router Class Initialized
INFO - 2017-05-12 11:18:32 --> Router Class Initialized
INFO - 2017-05-12 11:18:32 --> Output Class Initialized
INFO - 2017-05-12 11:18:32 --> Output Class Initialized
INFO - 2017-05-12 11:18:32 --> Security Class Initialized
INFO - 2017-05-12 11:18:32 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 11:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:32 --> Input Class Initialized
INFO - 2017-05-12 11:18:32 --> Input Class Initialized
INFO - 2017-05-12 11:18:32 --> Language Class Initialized
INFO - 2017-05-12 11:18:32 --> Language Class Initialized
ERROR - 2017-05-12 11:18:32 --> 404 Page Not Found: Default/assets
ERROR - 2017-05-12 11:18:32 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:18:32 --> Config Class Initialized
INFO - 2017-05-12 11:18:32 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:32 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:32 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:32 --> URI Class Initialized
INFO - 2017-05-12 11:18:32 --> Router Class Initialized
INFO - 2017-05-12 11:18:32 --> Output Class Initialized
INFO - 2017-05-12 11:18:32 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:32 --> Input Class Initialized
INFO - 2017-05-12 11:18:32 --> Language Class Initialized
INFO - 2017-05-12 11:18:32 --> Loader Class Initialized
INFO - 2017-05-12 11:18:32 --> Helper loaded: url_helper
INFO - 2017-05-12 11:18:32 --> Helper loaded: form_helper
INFO - 2017-05-12 11:18:32 --> Helper loaded: html_helper
INFO - 2017-05-12 11:18:32 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:18:32 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:18:32 --> Database Driver Class Initialized
INFO - 2017-05-12 11:18:32 --> Parser Class Initialized
DEBUG - 2017-05-12 11:18:32 --> Session Class Initialized
INFO - 2017-05-12 11:18:32 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:18:32 --> Session routines successfully run
INFO - 2017-05-12 11:18:32 --> Form Validation Class Initialized
INFO - 2017-05-12 11:18:32 --> Controller Class Initialized
DEBUG - 2017-05-12 11:18:32 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:18:32 --> Model Class Initialized
DEBUG - 2017-05-12 11:18:32 --> Pagination Class Initialized
INFO - 2017-05-12 11:18:32 --> Final output sent to browser
DEBUG - 2017-05-12 11:18:32 --> Total execution time: 0.3776
INFO - 2017-05-12 11:18:46 --> Config Class Initialized
INFO - 2017-05-12 11:18:46 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:46 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:46 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:46 --> URI Class Initialized
INFO - 2017-05-12 11:18:46 --> Router Class Initialized
INFO - 2017-05-12 11:18:46 --> Output Class Initialized
INFO - 2017-05-12 11:18:47 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:47 --> Input Class Initialized
INFO - 2017-05-12 11:18:47 --> Language Class Initialized
INFO - 2017-05-12 11:18:47 --> Loader Class Initialized
INFO - 2017-05-12 11:18:47 --> Helper loaded: url_helper
INFO - 2017-05-12 11:18:47 --> Helper loaded: form_helper
INFO - 2017-05-12 11:18:47 --> Helper loaded: html_helper
INFO - 2017-05-12 11:18:47 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:18:47 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:18:47 --> Database Driver Class Initialized
INFO - 2017-05-12 11:18:47 --> Parser Class Initialized
DEBUG - 2017-05-12 11:18:47 --> Session Class Initialized
INFO - 2017-05-12 11:18:47 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:18:47 --> Session routines successfully run
INFO - 2017-05-12 11:18:47 --> Form Validation Class Initialized
INFO - 2017-05-12 11:18:47 --> Controller Class Initialized
DEBUG - 2017-05-12 11:18:47 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:18:47 --> Model Class Initialized
DEBUG - 2017-05-12 11:18:47 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:18:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:18:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:18:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:18:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:18:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:18:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:18:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:18:47 --> Final output sent to browser
DEBUG - 2017-05-12 11:18:47 --> Total execution time: 0.5096
INFO - 2017-05-12 11:18:47 --> Config Class Initialized
INFO - 2017-05-12 11:18:47 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:47 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:47 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:47 --> URI Class Initialized
INFO - 2017-05-12 11:18:47 --> Router Class Initialized
INFO - 2017-05-12 11:18:47 --> Output Class Initialized
INFO - 2017-05-12 11:18:47 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:47 --> Input Class Initialized
INFO - 2017-05-12 11:18:47 --> Config Class Initialized
INFO - 2017-05-12 11:18:47 --> Language Class Initialized
INFO - 2017-05-12 11:18:47 --> Hooks Class Initialized
ERROR - 2017-05-12 11:18:47 --> 404 Page Not Found: Default/assets
DEBUG - 2017-05-12 11:18:47 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:47 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:47 --> URI Class Initialized
INFO - 2017-05-12 11:18:47 --> Config Class Initialized
INFO - 2017-05-12 11:18:47 --> Router Class Initialized
INFO - 2017-05-12 11:18:47 --> Hooks Class Initialized
INFO - 2017-05-12 11:18:47 --> Output Class Initialized
DEBUG - 2017-05-12 11:18:47 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:47 --> Security Class Initialized
INFO - 2017-05-12 11:18:47 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:47 --> URI Class Initialized
DEBUG - 2017-05-12 11:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:47 --> Input Class Initialized
INFO - 2017-05-12 11:18:47 --> Router Class Initialized
INFO - 2017-05-12 11:18:47 --> Language Class Initialized
INFO - 2017-05-12 11:18:47 --> Output Class Initialized
ERROR - 2017-05-12 11:18:47 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:18:47 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:47 --> Input Class Initialized
INFO - 2017-05-12 11:18:47 --> Language Class Initialized
ERROR - 2017-05-12 11:18:47 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:18:47 --> Config Class Initialized
INFO - 2017-05-12 11:18:47 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:47 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:47 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:47 --> URI Class Initialized
INFO - 2017-05-12 11:18:47 --> Router Class Initialized
INFO - 2017-05-12 11:18:48 --> Output Class Initialized
INFO - 2017-05-12 11:18:48 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:48 --> Input Class Initialized
INFO - 2017-05-12 11:18:48 --> Language Class Initialized
ERROR - 2017-05-12 11:18:48 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:18:48 --> Config Class Initialized
INFO - 2017-05-12 11:18:48 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:18:48 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:18:48 --> Utf8 Class Initialized
INFO - 2017-05-12 11:18:48 --> URI Class Initialized
INFO - 2017-05-12 11:18:48 --> Router Class Initialized
INFO - 2017-05-12 11:18:48 --> Output Class Initialized
INFO - 2017-05-12 11:18:48 --> Security Class Initialized
DEBUG - 2017-05-12 11:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:18:48 --> Input Class Initialized
INFO - 2017-05-12 11:18:48 --> Language Class Initialized
INFO - 2017-05-12 11:18:48 --> Loader Class Initialized
INFO - 2017-05-12 11:18:48 --> Helper loaded: url_helper
INFO - 2017-05-12 11:18:48 --> Helper loaded: form_helper
INFO - 2017-05-12 11:18:48 --> Helper loaded: html_helper
INFO - 2017-05-12 11:18:48 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:18:48 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:18:48 --> Database Driver Class Initialized
INFO - 2017-05-12 11:18:48 --> Parser Class Initialized
DEBUG - 2017-05-12 11:18:48 --> Session Class Initialized
INFO - 2017-05-12 11:18:48 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:18:48 --> Session routines successfully run
INFO - 2017-05-12 11:18:48 --> Form Validation Class Initialized
INFO - 2017-05-12 11:18:48 --> Controller Class Initialized
DEBUG - 2017-05-12 11:18:48 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:18:48 --> Model Class Initialized
DEBUG - 2017-05-12 11:18:48 --> Pagination Class Initialized
ERROR - 2017-05-12 11:18:48 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 883
ERROR - 2017-05-12 11:18:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 886
INFO - 2017-05-12 11:18:48 --> Final output sent to browser
DEBUG - 2017-05-12 11:18:48 --> Total execution time: 0.4208
INFO - 2017-05-12 11:19:18 --> Config Class Initialized
INFO - 2017-05-12 11:19:18 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:19:18 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:19:18 --> Utf8 Class Initialized
INFO - 2017-05-12 11:19:18 --> URI Class Initialized
INFO - 2017-05-12 11:19:18 --> Router Class Initialized
INFO - 2017-05-12 11:19:18 --> Output Class Initialized
INFO - 2017-05-12 11:19:18 --> Security Class Initialized
DEBUG - 2017-05-12 11:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:19:18 --> Input Class Initialized
INFO - 2017-05-12 11:19:18 --> Language Class Initialized
INFO - 2017-05-12 11:19:18 --> Loader Class Initialized
INFO - 2017-05-12 11:19:18 --> Helper loaded: url_helper
INFO - 2017-05-12 11:19:18 --> Helper loaded: form_helper
INFO - 2017-05-12 11:19:18 --> Helper loaded: html_helper
INFO - 2017-05-12 11:19:18 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:19:18 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:19:18 --> Database Driver Class Initialized
INFO - 2017-05-12 11:19:18 --> Parser Class Initialized
DEBUG - 2017-05-12 11:19:18 --> Session Class Initialized
INFO - 2017-05-12 11:19:18 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:19:18 --> Session routines successfully run
INFO - 2017-05-12 11:19:18 --> Form Validation Class Initialized
INFO - 2017-05-12 11:19:18 --> Controller Class Initialized
DEBUG - 2017-05-12 11:19:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:19:18 --> Model Class Initialized
DEBUG - 2017-05-12 11:19:19 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:19:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:19:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:19:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:19:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:19:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:19:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:19:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:19:19 --> Final output sent to browser
DEBUG - 2017-05-12 11:19:19 --> Total execution time: 0.5143
INFO - 2017-05-12 11:19:19 --> Config Class Initialized
INFO - 2017-05-12 11:19:19 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:19:19 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:19:19 --> Utf8 Class Initialized
INFO - 2017-05-12 11:19:19 --> URI Class Initialized
INFO - 2017-05-12 11:19:19 --> Router Class Initialized
INFO - 2017-05-12 11:19:19 --> Output Class Initialized
INFO - 2017-05-12 11:19:19 --> Security Class Initialized
DEBUG - 2017-05-12 11:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:19:19 --> Config Class Initialized
INFO - 2017-05-12 11:19:19 --> Input Class Initialized
INFO - 2017-05-12 11:19:19 --> Hooks Class Initialized
INFO - 2017-05-12 11:19:19 --> Language Class Initialized
DEBUG - 2017-05-12 11:19:19 --> UTF-8 Support Enabled
ERROR - 2017-05-12 11:19:19 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:19:19 --> Utf8 Class Initialized
INFO - 2017-05-12 11:19:19 --> URI Class Initialized
INFO - 2017-05-12 11:19:19 --> Router Class Initialized
INFO - 2017-05-12 11:19:19 --> Output Class Initialized
INFO - 2017-05-12 11:19:19 --> Security Class Initialized
DEBUG - 2017-05-12 11:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:19:19 --> Input Class Initialized
INFO - 2017-05-12 11:19:19 --> Language Class Initialized
ERROR - 2017-05-12 11:19:19 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:19:19 --> Config Class Initialized
INFO - 2017-05-12 11:19:19 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:19:19 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:19:19 --> Utf8 Class Initialized
INFO - 2017-05-12 11:19:19 --> URI Class Initialized
INFO - 2017-05-12 11:19:19 --> Router Class Initialized
INFO - 2017-05-12 11:19:19 --> Output Class Initialized
INFO - 2017-05-12 11:19:19 --> Security Class Initialized
DEBUG - 2017-05-12 11:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:19:19 --> Input Class Initialized
INFO - 2017-05-12 11:19:19 --> Language Class Initialized
INFO - 2017-05-12 11:19:19 --> Loader Class Initialized
INFO - 2017-05-12 11:19:19 --> Helper loaded: url_helper
INFO - 2017-05-12 11:19:19 --> Helper loaded: form_helper
INFO - 2017-05-12 11:19:19 --> Helper loaded: html_helper
INFO - 2017-05-12 11:19:19 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:19:19 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:19:19 --> Database Driver Class Initialized
INFO - 2017-05-12 11:19:19 --> Parser Class Initialized
DEBUG - 2017-05-12 11:19:19 --> Session Class Initialized
INFO - 2017-05-12 11:19:19 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:19:19 --> Session routines successfully run
INFO - 2017-05-12 11:19:19 --> Form Validation Class Initialized
INFO - 2017-05-12 11:19:19 --> Controller Class Initialized
DEBUG - 2017-05-12 11:19:19 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:19:19 --> Model Class Initialized
DEBUG - 2017-05-12 11:19:19 --> Pagination Class Initialized
ERROR - 2017-05-12 11:19:19 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 883
ERROR - 2017-05-12 11:19:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 886
INFO - 2017-05-12 11:19:19 --> Final output sent to browser
DEBUG - 2017-05-12 11:19:19 --> Total execution time: 0.4109
INFO - 2017-05-12 11:20:10 --> Config Class Initialized
INFO - 2017-05-12 11:20:10 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:20:10 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:20:10 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:10 --> URI Class Initialized
INFO - 2017-05-12 11:20:10 --> Router Class Initialized
INFO - 2017-05-12 11:20:10 --> Output Class Initialized
INFO - 2017-05-12 11:20:10 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:10 --> Input Class Initialized
INFO - 2017-05-12 11:20:10 --> Language Class Initialized
INFO - 2017-05-12 11:20:10 --> Loader Class Initialized
INFO - 2017-05-12 11:20:10 --> Helper loaded: url_helper
INFO - 2017-05-12 11:20:10 --> Helper loaded: form_helper
INFO - 2017-05-12 11:20:10 --> Helper loaded: html_helper
INFO - 2017-05-12 11:20:10 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:20:10 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:20:10 --> Database Driver Class Initialized
INFO - 2017-05-12 11:20:10 --> Parser Class Initialized
DEBUG - 2017-05-12 11:20:10 --> Session Class Initialized
INFO - 2017-05-12 11:20:10 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:20:10 --> Session routines successfully run
INFO - 2017-05-12 11:20:10 --> Form Validation Class Initialized
INFO - 2017-05-12 11:20:10 --> Controller Class Initialized
DEBUG - 2017-05-12 11:20:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:20:10 --> Model Class Initialized
DEBUG - 2017-05-12 11:20:10 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:20:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:20:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:20:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:20:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:20:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:20:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:20:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:20:10 --> Final output sent to browser
DEBUG - 2017-05-12 11:20:10 --> Total execution time: 0.5162
INFO - 2017-05-12 11:20:11 --> Config Class Initialized
INFO - 2017-05-12 11:20:11 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:20:11 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:20:11 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:11 --> URI Class Initialized
INFO - 2017-05-12 11:20:11 --> Router Class Initialized
INFO - 2017-05-12 11:20:11 --> Output Class Initialized
INFO - 2017-05-12 11:20:11 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:11 --> Input Class Initialized
INFO - 2017-05-12 11:20:11 --> Config Class Initialized
INFO - 2017-05-12 11:20:11 --> Language Class Initialized
INFO - 2017-05-12 11:20:11 --> Hooks Class Initialized
ERROR - 2017-05-12 11:20:11 --> 404 Page Not Found: Default/assets
DEBUG - 2017-05-12 11:20:11 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:20:11 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:11 --> URI Class Initialized
INFO - 2017-05-12 11:20:11 --> Router Class Initialized
INFO - 2017-05-12 11:20:11 --> Output Class Initialized
INFO - 2017-05-12 11:20:11 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:11 --> Input Class Initialized
INFO - 2017-05-12 11:20:11 --> Language Class Initialized
ERROR - 2017-05-12 11:20:11 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:20:11 --> Config Class Initialized
INFO - 2017-05-12 11:20:11 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:20:11 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:20:11 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:11 --> URI Class Initialized
INFO - 2017-05-12 11:20:11 --> Router Class Initialized
INFO - 2017-05-12 11:20:11 --> Output Class Initialized
INFO - 2017-05-12 11:20:11 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:11 --> Input Class Initialized
INFO - 2017-05-12 11:20:11 --> Language Class Initialized
INFO - 2017-05-12 11:20:11 --> Loader Class Initialized
INFO - 2017-05-12 11:20:11 --> Helper loaded: url_helper
INFO - 2017-05-12 11:20:11 --> Helper loaded: form_helper
INFO - 2017-05-12 11:20:11 --> Helper loaded: html_helper
INFO - 2017-05-12 11:20:11 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:20:11 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:20:11 --> Database Driver Class Initialized
INFO - 2017-05-12 11:20:11 --> Parser Class Initialized
DEBUG - 2017-05-12 11:20:11 --> Session Class Initialized
INFO - 2017-05-12 11:20:11 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:20:11 --> Session routines successfully run
INFO - 2017-05-12 11:20:11 --> Form Validation Class Initialized
INFO - 2017-05-12 11:20:11 --> Controller Class Initialized
DEBUG - 2017-05-12 11:20:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:20:11 --> Model Class Initialized
DEBUG - 2017-05-12 11:20:11 --> Pagination Class Initialized
ERROR - 2017-05-12 11:20:11 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 883
ERROR - 2017-05-12 11:20:11 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 886
INFO - 2017-05-12 11:20:11 --> Final output sent to browser
DEBUG - 2017-05-12 11:20:11 --> Total execution time: 0.4133
INFO - 2017-05-12 11:20:15 --> Config Class Initialized
INFO - 2017-05-12 11:20:16 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:20:16 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:20:16 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:16 --> URI Class Initialized
INFO - 2017-05-12 11:20:16 --> Router Class Initialized
INFO - 2017-05-12 11:20:16 --> Output Class Initialized
INFO - 2017-05-12 11:20:16 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:16 --> Input Class Initialized
INFO - 2017-05-12 11:20:16 --> Language Class Initialized
INFO - 2017-05-12 11:20:16 --> Loader Class Initialized
INFO - 2017-05-12 11:20:16 --> Helper loaded: url_helper
INFO - 2017-05-12 11:20:16 --> Helper loaded: form_helper
INFO - 2017-05-12 11:20:16 --> Helper loaded: html_helper
INFO - 2017-05-12 11:20:16 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:20:16 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:20:16 --> Database Driver Class Initialized
INFO - 2017-05-12 11:20:16 --> Parser Class Initialized
DEBUG - 2017-05-12 11:20:16 --> Session Class Initialized
INFO - 2017-05-12 11:20:16 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:20:16 --> Session routines successfully run
INFO - 2017-05-12 11:20:16 --> Form Validation Class Initialized
INFO - 2017-05-12 11:20:16 --> Controller Class Initialized
DEBUG - 2017-05-12 11:20:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:20:16 --> Model Class Initialized
DEBUG - 2017-05-12 11:20:16 --> Pagination Class Initialized
INFO - 2017-05-12 11:20:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:20:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:20:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:20:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:20:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:20:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:20:16 --> Final output sent to browser
DEBUG - 2017-05-12 11:20:16 --> Total execution time: 0.5982
INFO - 2017-05-12 11:20:25 --> Config Class Initialized
INFO - 2017-05-12 11:20:25 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:20:25 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:20:25 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:25 --> URI Class Initialized
INFO - 2017-05-12 11:20:25 --> Router Class Initialized
INFO - 2017-05-12 11:20:25 --> Output Class Initialized
INFO - 2017-05-12 11:20:25 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:25 --> Input Class Initialized
INFO - 2017-05-12 11:20:25 --> Language Class Initialized
INFO - 2017-05-12 11:20:25 --> Loader Class Initialized
INFO - 2017-05-12 11:20:25 --> Helper loaded: url_helper
INFO - 2017-05-12 11:20:25 --> Helper loaded: form_helper
INFO - 2017-05-12 11:20:25 --> Helper loaded: html_helper
INFO - 2017-05-12 11:20:25 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:20:25 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:20:25 --> Database Driver Class Initialized
INFO - 2017-05-12 11:20:25 --> Parser Class Initialized
DEBUG - 2017-05-12 11:20:25 --> Session Class Initialized
INFO - 2017-05-12 11:20:25 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:20:25 --> Session routines successfully run
INFO - 2017-05-12 11:20:25 --> Form Validation Class Initialized
INFO - 2017-05-12 11:20:25 --> Controller Class Initialized
DEBUG - 2017-05-12 11:20:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:20:25 --> Model Class Initialized
DEBUG - 2017-05-12 11:20:25 --> Pagination Class Initialized
INFO - 2017-05-12 11:20:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:20:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:28 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:20:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:20:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:20:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:20:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:20:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:20:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:20:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:20:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:20:31 --> Final output sent to browser
DEBUG - 2017-05-12 11:20:31 --> Total execution time: 6.2293
INFO - 2017-05-12 11:20:33 --> Config Class Initialized
INFO - 2017-05-12 11:20:33 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:20:33 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:20:33 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:33 --> URI Class Initialized
INFO - 2017-05-12 11:20:33 --> Router Class Initialized
INFO - 2017-05-12 11:20:33 --> Output Class Initialized
INFO - 2017-05-12 11:20:33 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:33 --> Input Class Initialized
INFO - 2017-05-12 11:20:33 --> Language Class Initialized
INFO - 2017-05-12 11:20:33 --> Loader Class Initialized
INFO - 2017-05-12 11:20:33 --> Helper loaded: url_helper
INFO - 2017-05-12 11:20:33 --> Helper loaded: form_helper
INFO - 2017-05-12 11:20:33 --> Helper loaded: html_helper
INFO - 2017-05-12 11:20:33 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:20:33 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:20:33 --> Database Driver Class Initialized
INFO - 2017-05-12 11:20:33 --> Parser Class Initialized
DEBUG - 2017-05-12 11:20:33 --> Session Class Initialized
INFO - 2017-05-12 11:20:33 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:20:33 --> Session routines successfully run
INFO - 2017-05-12 11:20:34 --> Form Validation Class Initialized
INFO - 2017-05-12 11:20:34 --> Controller Class Initialized
DEBUG - 2017-05-12 11:20:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:20:34 --> Model Class Initialized
DEBUG - 2017-05-12 11:20:34 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:20:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:20:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:20:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:20:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:20:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:20:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:20:34 --> Final output sent to browser
DEBUG - 2017-05-12 11:20:34 --> Total execution time: 0.5058
INFO - 2017-05-12 11:20:34 --> Config Class Initialized
INFO - 2017-05-12 11:20:34 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:20:34 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:20:34 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:34 --> URI Class Initialized
INFO - 2017-05-12 11:20:34 --> Router Class Initialized
INFO - 2017-05-12 11:20:34 --> Config Class Initialized
INFO - 2017-05-12 11:20:34 --> Output Class Initialized
INFO - 2017-05-12 11:20:34 --> Hooks Class Initialized
INFO - 2017-05-12 11:20:34 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 11:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:34 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:34 --> Input Class Initialized
INFO - 2017-05-12 11:20:34 --> URI Class Initialized
INFO - 2017-05-12 11:20:34 --> Language Class Initialized
INFO - 2017-05-12 11:20:34 --> Router Class Initialized
ERROR - 2017-05-12 11:20:34 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:20:34 --> Output Class Initialized
INFO - 2017-05-12 11:20:34 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:34 --> Input Class Initialized
INFO - 2017-05-12 11:20:34 --> Language Class Initialized
ERROR - 2017-05-12 11:20:34 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:20:34 --> Config Class Initialized
INFO - 2017-05-12 11:20:34 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:20:34 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:20:34 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:34 --> URI Class Initialized
INFO - 2017-05-12 11:20:34 --> Router Class Initialized
INFO - 2017-05-12 11:20:34 --> Output Class Initialized
INFO - 2017-05-12 11:20:34 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:34 --> Input Class Initialized
INFO - 2017-05-12 11:20:34 --> Language Class Initialized
INFO - 2017-05-12 11:20:34 --> Loader Class Initialized
INFO - 2017-05-12 11:20:34 --> Helper loaded: url_helper
INFO - 2017-05-12 11:20:34 --> Helper loaded: form_helper
INFO - 2017-05-12 11:20:34 --> Helper loaded: html_helper
INFO - 2017-05-12 11:20:34 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:20:34 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:20:34 --> Database Driver Class Initialized
INFO - 2017-05-12 11:20:34 --> Parser Class Initialized
DEBUG - 2017-05-12 11:20:34 --> Session Class Initialized
INFO - 2017-05-12 11:20:34 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:20:34 --> Session routines successfully run
INFO - 2017-05-12 11:20:34 --> Form Validation Class Initialized
INFO - 2017-05-12 11:20:34 --> Controller Class Initialized
DEBUG - 2017-05-12 11:20:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:20:34 --> Model Class Initialized
DEBUG - 2017-05-12 11:20:34 --> Pagination Class Initialized
ERROR - 2017-05-12 11:20:34 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 883
ERROR - 2017-05-12 11:20:34 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 886
INFO - 2017-05-12 11:20:34 --> Final output sent to browser
DEBUG - 2017-05-12 11:20:35 --> Total execution time: 0.4319
INFO - 2017-05-12 11:20:44 --> Config Class Initialized
INFO - 2017-05-12 11:20:44 --> Config Class Initialized
INFO - 2017-05-12 11:20:44 --> Hooks Class Initialized
INFO - 2017-05-12 11:20:44 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:20:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 11:20:44 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:20:44 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:44 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:44 --> URI Class Initialized
INFO - 2017-05-12 11:20:44 --> URI Class Initialized
INFO - 2017-05-12 11:20:44 --> Router Class Initialized
INFO - 2017-05-12 11:20:44 --> Router Class Initialized
INFO - 2017-05-12 11:20:44 --> Output Class Initialized
INFO - 2017-05-12 11:20:44 --> Output Class Initialized
INFO - 2017-05-12 11:20:44 --> Security Class Initialized
INFO - 2017-05-12 11:20:44 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 11:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:44 --> Input Class Initialized
INFO - 2017-05-12 11:20:44 --> Input Class Initialized
INFO - 2017-05-12 11:20:44 --> Language Class Initialized
INFO - 2017-05-12 11:20:44 --> Language Class Initialized
INFO - 2017-05-12 11:20:44 --> Loader Class Initialized
INFO - 2017-05-12 11:20:44 --> Loader Class Initialized
INFO - 2017-05-12 11:20:44 --> Helper loaded: url_helper
INFO - 2017-05-12 11:20:44 --> Helper loaded: url_helper
INFO - 2017-05-12 11:20:44 --> Helper loaded: form_helper
INFO - 2017-05-12 11:20:44 --> Helper loaded: form_helper
INFO - 2017-05-12 11:20:44 --> Helper loaded: html_helper
INFO - 2017-05-12 11:20:44 --> Helper loaded: html_helper
INFO - 2017-05-12 11:20:45 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:20:45 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:20:45 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:20:45 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:20:45 --> Database Driver Class Initialized
INFO - 2017-05-12 11:20:45 --> Database Driver Class Initialized
INFO - 2017-05-12 11:20:45 --> Parser Class Initialized
INFO - 2017-05-12 11:20:45 --> Parser Class Initialized
DEBUG - 2017-05-12 11:20:45 --> Session Class Initialized
DEBUG - 2017-05-12 11:20:45 --> Session Class Initialized
INFO - 2017-05-12 11:20:45 --> Helper loaded: string_helper
INFO - 2017-05-12 11:20:45 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:20:45 --> Session routines successfully run
DEBUG - 2017-05-12 11:20:45 --> Session routines successfully run
INFO - 2017-05-12 11:20:45 --> Form Validation Class Initialized
INFO - 2017-05-12 11:20:45 --> Form Validation Class Initialized
INFO - 2017-05-12 11:20:45 --> Controller Class Initialized
INFO - 2017-05-12 11:20:45 --> Controller Class Initialized
DEBUG - 2017-05-12 11:20:45 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2017-05-12 11:20:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:20:45 --> Model Class Initialized
INFO - 2017-05-12 11:20:45 --> Model Class Initialized
DEBUG - 2017-05-12 11:20:45 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:20:45 --> Pagination Class Initialized
INFO - 2017-05-12 11:20:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2017-05-12 11:20:45 --> Final output sent to browser
INFO - 2017-05-12 11:20:45 --> Final output sent to browser
DEBUG - 2017-05-12 11:20:45 --> Total execution time: 0.6879
DEBUG - 2017-05-12 11:20:45 --> Total execution time: 0.7015
INFO - 2017-05-12 11:20:56 --> Config Class Initialized
INFO - 2017-05-12 11:20:56 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:20:56 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:20:56 --> Utf8 Class Initialized
INFO - 2017-05-12 11:20:56 --> URI Class Initialized
INFO - 2017-05-12 11:20:56 --> Router Class Initialized
INFO - 2017-05-12 11:20:56 --> Output Class Initialized
INFO - 2017-05-12 11:20:56 --> Security Class Initialized
DEBUG - 2017-05-12 11:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:20:56 --> Input Class Initialized
INFO - 2017-05-12 11:20:56 --> Language Class Initialized
INFO - 2017-05-12 11:20:56 --> Loader Class Initialized
INFO - 2017-05-12 11:20:56 --> Helper loaded: url_helper
INFO - 2017-05-12 11:20:56 --> Helper loaded: form_helper
INFO - 2017-05-12 11:20:56 --> Helper loaded: html_helper
INFO - 2017-05-12 11:20:56 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:20:56 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:20:56 --> Database Driver Class Initialized
INFO - 2017-05-12 11:20:56 --> Parser Class Initialized
DEBUG - 2017-05-12 11:20:56 --> Session Class Initialized
INFO - 2017-05-12 11:20:56 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:20:56 --> Session routines successfully run
INFO - 2017-05-12 11:20:56 --> Form Validation Class Initialized
INFO - 2017-05-12 11:20:56 --> Controller Class Initialized
DEBUG - 2017-05-12 11:20:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:20:56 --> Model Class Initialized
DEBUG - 2017-05-12 11:20:56 --> Pagination Class Initialized
INFO - 2017-05-12 11:20:56 --> Final output sent to browser
DEBUG - 2017-05-12 11:20:56 --> Total execution time: 0.4091
INFO - 2017-05-12 11:21:00 --> Config Class Initialized
INFO - 2017-05-12 11:21:00 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:21:00 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:21:00 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:00 --> URI Class Initialized
INFO - 2017-05-12 11:21:00 --> Router Class Initialized
INFO - 2017-05-12 11:21:00 --> Output Class Initialized
INFO - 2017-05-12 11:21:00 --> Security Class Initialized
DEBUG - 2017-05-12 11:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:21:00 --> Input Class Initialized
INFO - 2017-05-12 11:21:00 --> Language Class Initialized
INFO - 2017-05-12 11:21:00 --> Loader Class Initialized
INFO - 2017-05-12 11:21:00 --> Helper loaded: url_helper
INFO - 2017-05-12 11:21:00 --> Helper loaded: form_helper
INFO - 2017-05-12 11:21:00 --> Helper loaded: html_helper
INFO - 2017-05-12 11:21:00 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:21:00 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:21:00 --> Database Driver Class Initialized
INFO - 2017-05-12 11:21:00 --> Parser Class Initialized
DEBUG - 2017-05-12 11:21:00 --> Session Class Initialized
INFO - 2017-05-12 11:21:00 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:21:00 --> Session routines successfully run
INFO - 2017-05-12 11:21:00 --> Form Validation Class Initialized
INFO - 2017-05-12 11:21:01 --> Controller Class Initialized
DEBUG - 2017-05-12 11:21:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:21:01 --> Model Class Initialized
DEBUG - 2017-05-12 11:21:01 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:21:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:21:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:21:01 --> Config Class Initialized
INFO - 2017-05-12 11:21:01 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:21:01 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:21:01 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:01 --> URI Class Initialized
INFO - 2017-05-12 11:21:01 --> Router Class Initialized
INFO - 2017-05-12 11:21:01 --> Output Class Initialized
INFO - 2017-05-12 11:21:01 --> Security Class Initialized
DEBUG - 2017-05-12 11:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:21:01 --> Input Class Initialized
INFO - 2017-05-12 11:21:01 --> Language Class Initialized
INFO - 2017-05-12 11:21:01 --> Loader Class Initialized
INFO - 2017-05-12 11:21:01 --> Helper loaded: url_helper
INFO - 2017-05-12 11:21:01 --> Helper loaded: form_helper
INFO - 2017-05-12 11:21:01 --> Helper loaded: html_helper
INFO - 2017-05-12 11:21:01 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:21:01 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:21:01 --> Database Driver Class Initialized
INFO - 2017-05-12 11:21:01 --> Parser Class Initialized
DEBUG - 2017-05-12 11:21:01 --> Session Class Initialized
INFO - 2017-05-12 11:21:01 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:21:01 --> Session routines successfully run
INFO - 2017-05-12 11:21:01 --> Form Validation Class Initialized
INFO - 2017-05-12 11:21:01 --> Controller Class Initialized
DEBUG - 2017-05-12 11:21:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:21:01 --> Model Class Initialized
DEBUG - 2017-05-12 11:21:01 --> Pagination Class Initialized
INFO - 2017-05-12 11:21:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:21:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:02 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:03 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:04 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:05 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:21:06 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:21:07 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:21:07 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:21:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:21:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:21:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:21:07 --> Final output sent to browser
DEBUG - 2017-05-12 11:21:07 --> Total execution time: 5.5268
INFO - 2017-05-12 11:21:12 --> Config Class Initialized
INFO - 2017-05-12 11:21:12 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:21:12 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:21:12 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:12 --> URI Class Initialized
INFO - 2017-05-12 11:21:12 --> Router Class Initialized
INFO - 2017-05-12 11:21:12 --> Output Class Initialized
INFO - 2017-05-12 11:21:12 --> Security Class Initialized
DEBUG - 2017-05-12 11:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:21:12 --> Input Class Initialized
INFO - 2017-05-12 11:21:12 --> Language Class Initialized
INFO - 2017-05-12 11:21:12 --> Loader Class Initialized
INFO - 2017-05-12 11:21:12 --> Helper loaded: url_helper
INFO - 2017-05-12 11:21:12 --> Helper loaded: form_helper
INFO - 2017-05-12 11:21:12 --> Helper loaded: html_helper
INFO - 2017-05-12 11:21:12 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:21:12 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:21:12 --> Database Driver Class Initialized
INFO - 2017-05-12 11:21:12 --> Parser Class Initialized
DEBUG - 2017-05-12 11:21:12 --> Session Class Initialized
INFO - 2017-05-12 11:21:12 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:21:12 --> Session routines successfully run
INFO - 2017-05-12 11:21:12 --> Form Validation Class Initialized
INFO - 2017-05-12 11:21:13 --> Controller Class Initialized
DEBUG - 2017-05-12 11:21:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:21:13 --> Model Class Initialized
DEBUG - 2017-05-12 11:21:13 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:21:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:21:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:21:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:21:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:21:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:21:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:21:13 --> Final output sent to browser
DEBUG - 2017-05-12 11:21:13 --> Total execution time: 0.5193
INFO - 2017-05-12 11:21:13 --> Config Class Initialized
INFO - 2017-05-12 11:21:13 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:21:13 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:21:13 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:13 --> URI Class Initialized
INFO - 2017-05-12 11:21:13 --> Config Class Initialized
INFO - 2017-05-12 11:21:13 --> Hooks Class Initialized
INFO - 2017-05-12 11:21:13 --> Router Class Initialized
INFO - 2017-05-12 11:21:13 --> Output Class Initialized
DEBUG - 2017-05-12 11:21:13 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:21:13 --> Security Class Initialized
INFO - 2017-05-12 11:21:13 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:13 --> URI Class Initialized
DEBUG - 2017-05-12 11:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:21:13 --> Input Class Initialized
INFO - 2017-05-12 11:21:13 --> Router Class Initialized
INFO - 2017-05-12 11:21:13 --> Language Class Initialized
INFO - 2017-05-12 11:21:13 --> Output Class Initialized
ERROR - 2017-05-12 11:21:13 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:21:13 --> Security Class Initialized
DEBUG - 2017-05-12 11:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:21:13 --> Input Class Initialized
INFO - 2017-05-12 11:21:13 --> Language Class Initialized
ERROR - 2017-05-12 11:21:13 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:21:13 --> Config Class Initialized
INFO - 2017-05-12 11:21:13 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:21:13 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:21:13 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:13 --> URI Class Initialized
INFO - 2017-05-12 11:21:13 --> Router Class Initialized
INFO - 2017-05-12 11:21:13 --> Output Class Initialized
INFO - 2017-05-12 11:21:13 --> Security Class Initialized
DEBUG - 2017-05-12 11:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:21:13 --> Input Class Initialized
INFO - 2017-05-12 11:21:13 --> Language Class Initialized
INFO - 2017-05-12 11:21:13 --> Loader Class Initialized
INFO - 2017-05-12 11:21:13 --> Helper loaded: url_helper
INFO - 2017-05-12 11:21:13 --> Helper loaded: form_helper
INFO - 2017-05-12 11:21:13 --> Helper loaded: html_helper
INFO - 2017-05-12 11:21:13 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:21:13 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:21:13 --> Database Driver Class Initialized
INFO - 2017-05-12 11:21:13 --> Parser Class Initialized
DEBUG - 2017-05-12 11:21:13 --> Session Class Initialized
INFO - 2017-05-12 11:21:13 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:21:13 --> Session routines successfully run
INFO - 2017-05-12 11:21:13 --> Form Validation Class Initialized
INFO - 2017-05-12 11:21:13 --> Controller Class Initialized
DEBUG - 2017-05-12 11:21:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:21:13 --> Model Class Initialized
DEBUG - 2017-05-12 11:21:13 --> Pagination Class Initialized
ERROR - 2017-05-12 11:21:13 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 883
ERROR - 2017-05-12 11:21:13 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 886
INFO - 2017-05-12 11:21:14 --> Final output sent to browser
DEBUG - 2017-05-12 11:21:14 --> Total execution time: 0.4461
INFO - 2017-05-12 11:21:17 --> Config Class Initialized
INFO - 2017-05-12 11:21:18 --> Config Class Initialized
INFO - 2017-05-12 11:21:18 --> Hooks Class Initialized
INFO - 2017-05-12 11:21:18 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:21:18 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 11:21:18 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:21:18 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:18 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:18 --> URI Class Initialized
INFO - 2017-05-12 11:21:18 --> URI Class Initialized
INFO - 2017-05-12 11:21:18 --> Router Class Initialized
INFO - 2017-05-12 11:21:18 --> Router Class Initialized
INFO - 2017-05-12 11:21:18 --> Output Class Initialized
INFO - 2017-05-12 11:21:18 --> Output Class Initialized
INFO - 2017-05-12 11:21:18 --> Security Class Initialized
INFO - 2017-05-12 11:21:18 --> Security Class Initialized
DEBUG - 2017-05-12 11:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 11:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:21:18 --> Input Class Initialized
INFO - 2017-05-12 11:21:18 --> Input Class Initialized
INFO - 2017-05-12 11:21:18 --> Language Class Initialized
INFO - 2017-05-12 11:21:18 --> Language Class Initialized
INFO - 2017-05-12 11:21:18 --> Loader Class Initialized
INFO - 2017-05-12 11:21:18 --> Loader Class Initialized
INFO - 2017-05-12 11:21:18 --> Helper loaded: url_helper
INFO - 2017-05-12 11:21:18 --> Helper loaded: url_helper
INFO - 2017-05-12 11:21:18 --> Helper loaded: form_helper
INFO - 2017-05-12 11:21:18 --> Helper loaded: form_helper
INFO - 2017-05-12 11:21:18 --> Helper loaded: html_helper
INFO - 2017-05-12 11:21:18 --> Helper loaded: html_helper
INFO - 2017-05-12 11:21:18 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:21:18 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:21:18 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:21:18 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:21:18 --> Database Driver Class Initialized
INFO - 2017-05-12 11:21:18 --> Database Driver Class Initialized
INFO - 2017-05-12 11:21:18 --> Parser Class Initialized
INFO - 2017-05-12 11:21:18 --> Parser Class Initialized
DEBUG - 2017-05-12 11:21:18 --> Session Class Initialized
DEBUG - 2017-05-12 11:21:18 --> Session Class Initialized
INFO - 2017-05-12 11:21:18 --> Helper loaded: string_helper
INFO - 2017-05-12 11:21:18 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:21:18 --> Session routines successfully run
DEBUG - 2017-05-12 11:21:18 --> Session routines successfully run
INFO - 2017-05-12 11:21:18 --> Form Validation Class Initialized
INFO - 2017-05-12 11:21:18 --> Form Validation Class Initialized
INFO - 2017-05-12 11:21:18 --> Controller Class Initialized
INFO - 2017-05-12 11:21:18 --> Controller Class Initialized
DEBUG - 2017-05-12 11:21:18 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2017-05-12 11:21:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:21:18 --> Model Class Initialized
INFO - 2017-05-12 11:21:18 --> Model Class Initialized
DEBUG - 2017-05-12 11:21:18 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:21:18 --> Pagination Class Initialized
INFO - 2017-05-12 11:21:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2017-05-12 11:21:18 --> Final output sent to browser
INFO - 2017-05-12 11:21:18 --> Final output sent to browser
DEBUG - 2017-05-12 11:21:18 --> Total execution time: 0.7105
DEBUG - 2017-05-12 11:21:18 --> Total execution time: 0.7265
INFO - 2017-05-12 11:21:37 --> Config Class Initialized
INFO - 2017-05-12 11:21:37 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:21:37 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:21:37 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:37 --> URI Class Initialized
INFO - 2017-05-12 11:21:37 --> Router Class Initialized
INFO - 2017-05-12 11:21:37 --> Output Class Initialized
INFO - 2017-05-12 11:21:37 --> Security Class Initialized
DEBUG - 2017-05-12 11:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:21:37 --> Input Class Initialized
INFO - 2017-05-12 11:21:37 --> Language Class Initialized
INFO - 2017-05-12 11:21:37 --> Loader Class Initialized
INFO - 2017-05-12 11:21:37 --> Helper loaded: url_helper
INFO - 2017-05-12 11:21:37 --> Helper loaded: form_helper
INFO - 2017-05-12 11:21:37 --> Helper loaded: html_helper
INFO - 2017-05-12 11:21:37 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:21:37 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:21:37 --> Database Driver Class Initialized
INFO - 2017-05-12 11:21:37 --> Parser Class Initialized
DEBUG - 2017-05-12 11:21:37 --> Session Class Initialized
INFO - 2017-05-12 11:21:37 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:21:37 --> Session routines successfully run
INFO - 2017-05-12 11:21:37 --> Form Validation Class Initialized
INFO - 2017-05-12 11:21:37 --> Controller Class Initialized
DEBUG - 2017-05-12 11:21:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:21:37 --> Model Class Initialized
DEBUG - 2017-05-12 11:21:37 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:21:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:21:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:21:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:21:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:21:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:21:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:21:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:21:37 --> Final output sent to browser
DEBUG - 2017-05-12 11:21:37 --> Total execution time: 0.5486
INFO - 2017-05-12 11:21:37 --> Config Class Initialized
INFO - 2017-05-12 11:21:37 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:21:38 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:21:38 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:38 --> URI Class Initialized
INFO - 2017-05-12 11:21:38 --> Router Class Initialized
INFO - 2017-05-12 11:21:38 --> Output Class Initialized
INFO - 2017-05-12 11:21:38 --> Config Class Initialized
INFO - 2017-05-12 11:21:38 --> Security Class Initialized
INFO - 2017-05-12 11:21:38 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:21:38 --> Input Class Initialized
DEBUG - 2017-05-12 11:21:38 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:21:38 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:38 --> Language Class Initialized
INFO - 2017-05-12 11:21:38 --> URI Class Initialized
ERROR - 2017-05-12 11:21:38 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:21:38 --> Router Class Initialized
INFO - 2017-05-12 11:21:38 --> Output Class Initialized
INFO - 2017-05-12 11:21:38 --> Security Class Initialized
DEBUG - 2017-05-12 11:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:21:38 --> Input Class Initialized
INFO - 2017-05-12 11:21:38 --> Language Class Initialized
ERROR - 2017-05-12 11:21:38 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:21:38 --> Config Class Initialized
INFO - 2017-05-12 11:21:38 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:21:38 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:21:38 --> Utf8 Class Initialized
INFO - 2017-05-12 11:21:38 --> URI Class Initialized
INFO - 2017-05-12 11:21:38 --> Router Class Initialized
INFO - 2017-05-12 11:21:38 --> Output Class Initialized
INFO - 2017-05-12 11:21:38 --> Security Class Initialized
DEBUG - 2017-05-12 11:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:21:38 --> Input Class Initialized
INFO - 2017-05-12 11:21:38 --> Language Class Initialized
INFO - 2017-05-12 11:21:38 --> Loader Class Initialized
INFO - 2017-05-12 11:21:38 --> Helper loaded: url_helper
INFO - 2017-05-12 11:21:38 --> Helper loaded: form_helper
INFO - 2017-05-12 11:21:38 --> Helper loaded: html_helper
INFO - 2017-05-12 11:21:38 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:21:38 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:21:38 --> Database Driver Class Initialized
INFO - 2017-05-12 11:21:38 --> Parser Class Initialized
DEBUG - 2017-05-12 11:21:38 --> Session Class Initialized
INFO - 2017-05-12 11:21:38 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:21:38 --> Session routines successfully run
INFO - 2017-05-12 11:21:38 --> Form Validation Class Initialized
INFO - 2017-05-12 11:21:38 --> Controller Class Initialized
DEBUG - 2017-05-12 11:21:38 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:21:38 --> Model Class Initialized
DEBUG - 2017-05-12 11:21:38 --> Pagination Class Initialized
ERROR - 2017-05-12 11:21:38 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 883
ERROR - 2017-05-12 11:21:38 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 886
INFO - 2017-05-12 11:21:38 --> Final output sent to browser
DEBUG - 2017-05-12 11:21:38 --> Total execution time: 0.4357
INFO - 2017-05-12 11:23:59 --> Config Class Initialized
INFO - 2017-05-12 11:23:59 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:23:59 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:23:59 --> Utf8 Class Initialized
INFO - 2017-05-12 11:23:59 --> URI Class Initialized
INFO - 2017-05-12 11:23:59 --> Router Class Initialized
INFO - 2017-05-12 11:23:59 --> Output Class Initialized
INFO - 2017-05-12 11:24:00 --> Security Class Initialized
DEBUG - 2017-05-12 11:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:24:00 --> Input Class Initialized
INFO - 2017-05-12 11:24:00 --> Language Class Initialized
INFO - 2017-05-12 11:24:00 --> Loader Class Initialized
INFO - 2017-05-12 11:24:00 --> Helper loaded: url_helper
INFO - 2017-05-12 11:24:00 --> Helper loaded: form_helper
INFO - 2017-05-12 11:24:00 --> Helper loaded: html_helper
INFO - 2017-05-12 11:24:00 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:24:00 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:24:00 --> Database Driver Class Initialized
INFO - 2017-05-12 11:24:00 --> Parser Class Initialized
DEBUG - 2017-05-12 11:24:00 --> Session Class Initialized
INFO - 2017-05-12 11:24:00 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:24:00 --> Session routines successfully run
INFO - 2017-05-12 11:24:00 --> Form Validation Class Initialized
INFO - 2017-05-12 11:24:00 --> Controller Class Initialized
DEBUG - 2017-05-12 11:24:00 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:24:00 --> Model Class Initialized
DEBUG - 2017-05-12 11:24:00 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:24:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:24:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:24:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:24:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:24:17 --> Config Class Initialized
INFO - 2017-05-12 11:24:17 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:24:17 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:24:17 --> Utf8 Class Initialized
INFO - 2017-05-12 11:24:17 --> URI Class Initialized
INFO - 2017-05-12 11:24:17 --> Router Class Initialized
INFO - 2017-05-12 11:24:17 --> Output Class Initialized
INFO - 2017-05-12 11:24:17 --> Security Class Initialized
DEBUG - 2017-05-12 11:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:24:17 --> Input Class Initialized
INFO - 2017-05-12 11:24:17 --> Language Class Initialized
INFO - 2017-05-12 11:24:17 --> Loader Class Initialized
INFO - 2017-05-12 11:24:17 --> Helper loaded: url_helper
INFO - 2017-05-12 11:24:17 --> Helper loaded: form_helper
INFO - 2017-05-12 11:24:17 --> Helper loaded: html_helper
INFO - 2017-05-12 11:24:17 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:24:17 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:24:17 --> Database Driver Class Initialized
INFO - 2017-05-12 11:24:17 --> Parser Class Initialized
DEBUG - 2017-05-12 11:24:17 --> Session Class Initialized
INFO - 2017-05-12 11:24:17 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:24:17 --> Session routines successfully run
INFO - 2017-05-12 11:24:17 --> Form Validation Class Initialized
INFO - 2017-05-12 11:24:17 --> Controller Class Initialized
DEBUG - 2017-05-12 11:24:17 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:24:17 --> Model Class Initialized
DEBUG - 2017-05-12 11:24:17 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:24:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:24:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:24:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:24:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:24:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:24:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:24:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:24:17 --> Final output sent to browser
DEBUG - 2017-05-12 11:24:17 --> Total execution time: 0.5354
INFO - 2017-05-12 11:24:17 --> Config Class Initialized
INFO - 2017-05-12 11:24:17 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:24:18 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:24:18 --> Config Class Initialized
INFO - 2017-05-12 11:24:18 --> Utf8 Class Initialized
INFO - 2017-05-12 11:24:18 --> Hooks Class Initialized
INFO - 2017-05-12 11:24:18 --> URI Class Initialized
DEBUG - 2017-05-12 11:24:18 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:24:18 --> Router Class Initialized
INFO - 2017-05-12 11:24:18 --> Utf8 Class Initialized
INFO - 2017-05-12 11:24:18 --> URI Class Initialized
INFO - 2017-05-12 11:24:18 --> Output Class Initialized
INFO - 2017-05-12 11:24:18 --> Router Class Initialized
INFO - 2017-05-12 11:24:18 --> Security Class Initialized
INFO - 2017-05-12 11:24:18 --> Output Class Initialized
DEBUG - 2017-05-12 11:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:24:18 --> Security Class Initialized
INFO - 2017-05-12 11:24:18 --> Input Class Initialized
INFO - 2017-05-12 11:24:18 --> Language Class Initialized
DEBUG - 2017-05-12 11:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-05-12 11:24:18 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:24:18 --> Input Class Initialized
INFO - 2017-05-12 11:24:18 --> Language Class Initialized
ERROR - 2017-05-12 11:24:18 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:24:18 --> Config Class Initialized
INFO - 2017-05-12 11:24:18 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:24:18 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:24:18 --> Utf8 Class Initialized
INFO - 2017-05-12 11:24:18 --> URI Class Initialized
INFO - 2017-05-12 11:24:18 --> Router Class Initialized
INFO - 2017-05-12 11:24:18 --> Output Class Initialized
INFO - 2017-05-12 11:24:18 --> Security Class Initialized
DEBUG - 2017-05-12 11:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:24:18 --> Input Class Initialized
INFO - 2017-05-12 11:24:18 --> Language Class Initialized
INFO - 2017-05-12 11:24:18 --> Loader Class Initialized
INFO - 2017-05-12 11:24:18 --> Helper loaded: url_helper
INFO - 2017-05-12 11:24:18 --> Helper loaded: form_helper
INFO - 2017-05-12 11:24:18 --> Helper loaded: html_helper
INFO - 2017-05-12 11:24:18 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:24:18 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:24:18 --> Database Driver Class Initialized
INFO - 2017-05-12 11:24:18 --> Parser Class Initialized
DEBUG - 2017-05-12 11:24:18 --> Session Class Initialized
INFO - 2017-05-12 11:24:18 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:24:18 --> Session routines successfully run
INFO - 2017-05-12 11:24:18 --> Form Validation Class Initialized
INFO - 2017-05-12 11:24:18 --> Controller Class Initialized
DEBUG - 2017-05-12 11:24:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:24:18 --> Model Class Initialized
DEBUG - 2017-05-12 11:24:18 --> Pagination Class Initialized
INFO - 2017-05-12 11:24:18 --> Final output sent to browser
DEBUG - 2017-05-12 11:24:18 --> Total execution time: 0.4120
INFO - 2017-05-12 11:25:13 --> Config Class Initialized
INFO - 2017-05-12 11:25:13 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:13 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:13 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:13 --> URI Class Initialized
INFO - 2017-05-12 11:25:13 --> Router Class Initialized
INFO - 2017-05-12 11:25:13 --> Output Class Initialized
INFO - 2017-05-12 11:25:13 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:13 --> Input Class Initialized
INFO - 2017-05-12 11:25:13 --> Language Class Initialized
INFO - 2017-05-12 11:25:13 --> Loader Class Initialized
INFO - 2017-05-12 11:25:13 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:13 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:13 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:13 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:13 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:13 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:13 --> Parser Class Initialized
DEBUG - 2017-05-12 11:25:13 --> Session Class Initialized
INFO - 2017-05-12 11:25:13 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:25:13 --> Session routines successfully run
INFO - 2017-05-12 11:25:13 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:13 --> Controller Class Initialized
DEBUG - 2017-05-12 11:25:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:25:13 --> Model Class Initialized
DEBUG - 2017-05-12 11:25:13 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:25:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:25:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:25:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:25:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:25:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:25:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:25:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:25:14 --> Final output sent to browser
DEBUG - 2017-05-12 11:25:14 --> Total execution time: 0.6647
INFO - 2017-05-12 11:25:14 --> Config Class Initialized
INFO - 2017-05-12 11:25:14 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:14 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:14 --> Config Class Initialized
INFO - 2017-05-12 11:25:14 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:14 --> Hooks Class Initialized
INFO - 2017-05-12 11:25:14 --> URI Class Initialized
DEBUG - 2017-05-12 11:25:14 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:14 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:14 --> Router Class Initialized
INFO - 2017-05-12 11:25:14 --> URI Class Initialized
INFO - 2017-05-12 11:25:14 --> Output Class Initialized
INFO - 2017-05-12 11:25:14 --> Router Class Initialized
INFO - 2017-05-12 11:25:14 --> Security Class Initialized
INFO - 2017-05-12 11:25:14 --> Output Class Initialized
DEBUG - 2017-05-12 11:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:14 --> Input Class Initialized
INFO - 2017-05-12 11:25:14 --> Security Class Initialized
INFO - 2017-05-12 11:25:14 --> Language Class Initialized
DEBUG - 2017-05-12 11:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-05-12 11:25:14 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:25:14 --> Input Class Initialized
INFO - 2017-05-12 11:25:14 --> Language Class Initialized
ERROR - 2017-05-12 11:25:14 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:25:14 --> Config Class Initialized
INFO - 2017-05-12 11:25:14 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:14 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:14 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:14 --> URI Class Initialized
INFO - 2017-05-12 11:25:14 --> Router Class Initialized
INFO - 2017-05-12 11:25:14 --> Output Class Initialized
INFO - 2017-05-12 11:25:14 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:14 --> Input Class Initialized
INFO - 2017-05-12 11:25:14 --> Language Class Initialized
INFO - 2017-05-12 11:25:14 --> Loader Class Initialized
INFO - 2017-05-12 11:25:14 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:14 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:14 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:14 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:14 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:14 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:14 --> Parser Class Initialized
DEBUG - 2017-05-12 11:25:14 --> Session Class Initialized
INFO - 2017-05-12 11:25:14 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:25:14 --> Session routines successfully run
INFO - 2017-05-12 11:25:14 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:14 --> Controller Class Initialized
DEBUG - 2017-05-12 11:25:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:25:14 --> Model Class Initialized
DEBUG - 2017-05-12 11:25:14 --> Pagination Class Initialized
INFO - 2017-05-12 11:25:14 --> Final output sent to browser
DEBUG - 2017-05-12 11:25:14 --> Total execution time: 0.4282
INFO - 2017-05-12 11:25:21 --> Config Class Initialized
INFO - 2017-05-12 11:25:21 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:21 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:21 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:21 --> URI Class Initialized
INFO - 2017-05-12 11:25:21 --> Router Class Initialized
INFO - 2017-05-12 11:25:21 --> Output Class Initialized
INFO - 2017-05-12 11:25:21 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:21 --> Input Class Initialized
INFO - 2017-05-12 11:25:21 --> Language Class Initialized
INFO - 2017-05-12 11:25:21 --> Loader Class Initialized
INFO - 2017-05-12 11:25:21 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:21 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:21 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:21 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:21 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:21 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:21 --> Parser Class Initialized
DEBUG - 2017-05-12 11:25:21 --> Session Class Initialized
INFO - 2017-05-12 11:25:21 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:25:21 --> Session routines successfully run
INFO - 2017-05-12 11:25:21 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:21 --> Controller Class Initialized
DEBUG - 2017-05-12 11:25:21 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:25:21 --> Model Class Initialized
DEBUG - 2017-05-12 11:25:22 --> Pagination Class Initialized
INFO - 2017-05-12 11:25:22 --> Final output sent to browser
DEBUG - 2017-05-12 11:25:22 --> Total execution time: 0.4495
INFO - 2017-05-12 11:25:24 --> Config Class Initialized
INFO - 2017-05-12 11:25:24 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:24 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:24 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:24 --> URI Class Initialized
INFO - 2017-05-12 11:25:25 --> Router Class Initialized
INFO - 2017-05-12 11:25:25 --> Output Class Initialized
INFO - 2017-05-12 11:25:25 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:25 --> Input Class Initialized
INFO - 2017-05-12 11:25:25 --> Language Class Initialized
INFO - 2017-05-12 11:25:25 --> Loader Class Initialized
INFO - 2017-05-12 11:25:25 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:25 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:25 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:25 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:25 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:25 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:25 --> Parser Class Initialized
DEBUG - 2017-05-12 11:25:25 --> Session Class Initialized
INFO - 2017-05-12 11:25:25 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:25:25 --> Session routines successfully run
INFO - 2017-05-12 11:25:25 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:25 --> Controller Class Initialized
DEBUG - 2017-05-12 11:25:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:25:25 --> Model Class Initialized
DEBUG - 2017-05-12 11:25:25 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:25:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:25:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:25:25 --> Config Class Initialized
INFO - 2017-05-12 11:25:25 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:25 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:25 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:26 --> URI Class Initialized
INFO - 2017-05-12 11:25:26 --> Router Class Initialized
INFO - 2017-05-12 11:25:26 --> Output Class Initialized
INFO - 2017-05-12 11:25:26 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:26 --> Input Class Initialized
INFO - 2017-05-12 11:25:26 --> Language Class Initialized
INFO - 2017-05-12 11:25:26 --> Loader Class Initialized
INFO - 2017-05-12 11:25:26 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:26 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:26 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:26 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:26 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:26 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:26 --> Parser Class Initialized
DEBUG - 2017-05-12 11:25:26 --> Session Class Initialized
INFO - 2017-05-12 11:25:26 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:25:26 --> Session routines successfully run
INFO - 2017-05-12 11:25:26 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:26 --> Controller Class Initialized
DEBUG - 2017-05-12 11:25:26 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:25:26 --> Model Class Initialized
DEBUG - 2017-05-12 11:25:26 --> Pagination Class Initialized
INFO - 2017-05-12 11:25:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:25:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:25:26 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:26 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:26 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:26 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:26 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:26 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:26 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:26 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:26 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:26 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:27 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:28 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:25:31 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:25:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:25:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:25:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:25:31 --> Final output sent to browser
DEBUG - 2017-05-12 11:25:31 --> Total execution time: 6.0074
INFO - 2017-05-12 11:25:36 --> Config Class Initialized
INFO - 2017-05-12 11:25:36 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:36 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:36 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:36 --> URI Class Initialized
INFO - 2017-05-12 11:25:36 --> Router Class Initialized
INFO - 2017-05-12 11:25:36 --> Output Class Initialized
INFO - 2017-05-12 11:25:36 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:36 --> Input Class Initialized
INFO - 2017-05-12 11:25:36 --> Language Class Initialized
INFO - 2017-05-12 11:25:36 --> Loader Class Initialized
INFO - 2017-05-12 11:25:36 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:36 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:36 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:36 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:36 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:36 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:36 --> Parser Class Initialized
DEBUG - 2017-05-12 11:25:36 --> Session Class Initialized
INFO - 2017-05-12 11:25:36 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:25:36 --> Session routines successfully run
INFO - 2017-05-12 11:25:36 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:36 --> Controller Class Initialized
DEBUG - 2017-05-12 11:25:36 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:25:37 --> Model Class Initialized
DEBUG - 2017-05-12 11:25:37 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:25:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:25:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:25:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:25:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:25:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:25:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:25:37 --> Final output sent to browser
DEBUG - 2017-05-12 11:25:37 --> Total execution time: 0.6287
INFO - 2017-05-12 11:25:37 --> Config Class Initialized
INFO - 2017-05-12 11:25:37 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:37 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:37 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:37 --> URI Class Initialized
INFO - 2017-05-12 11:25:37 --> Router Class Initialized
INFO - 2017-05-12 11:25:37 --> Output Class Initialized
INFO - 2017-05-12 11:25:37 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:37 --> Input Class Initialized
INFO - 2017-05-12 11:25:37 --> Language Class Initialized
ERROR - 2017-05-12 11:25:37 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:25:39 --> Config Class Initialized
INFO - 2017-05-12 11:25:39 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:39 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:39 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:39 --> URI Class Initialized
INFO - 2017-05-12 11:25:39 --> Router Class Initialized
INFO - 2017-05-12 11:25:39 --> Output Class Initialized
INFO - 2017-05-12 11:25:39 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:39 --> Input Class Initialized
INFO - 2017-05-12 11:25:39 --> Language Class Initialized
ERROR - 2017-05-12 11:25:39 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:25:41 --> Config Class Initialized
INFO - 2017-05-12 11:25:41 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:41 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:41 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:41 --> URI Class Initialized
INFO - 2017-05-12 11:25:41 --> Router Class Initialized
INFO - 2017-05-12 11:25:41 --> Output Class Initialized
INFO - 2017-05-12 11:25:41 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:41 --> Input Class Initialized
INFO - 2017-05-12 11:25:41 --> Language Class Initialized
INFO - 2017-05-12 11:25:41 --> Loader Class Initialized
INFO - 2017-05-12 11:25:41 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:41 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:41 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:41 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:41 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:41 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:41 --> Parser Class Initialized
DEBUG - 2017-05-12 11:25:41 --> Session Class Initialized
INFO - 2017-05-12 11:25:41 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:25:41 --> Session routines successfully run
INFO - 2017-05-12 11:25:41 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:41 --> Controller Class Initialized
DEBUG - 2017-05-12 11:25:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:25:41 --> Model Class Initialized
DEBUG - 2017-05-12 11:25:41 --> Pagination Class Initialized
INFO - 2017-05-12 11:25:41 --> Final output sent to browser
DEBUG - 2017-05-12 11:25:41 --> Total execution time: 0.4836
INFO - 2017-05-12 11:25:42 --> Config Class Initialized
INFO - 2017-05-12 11:25:42 --> Config Class Initialized
INFO - 2017-05-12 11:25:42 --> Hooks Class Initialized
INFO - 2017-05-12 11:25:42 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 11:25:42 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:42 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:42 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:42 --> URI Class Initialized
INFO - 2017-05-12 11:25:42 --> URI Class Initialized
INFO - 2017-05-12 11:25:42 --> Router Class Initialized
INFO - 2017-05-12 11:25:42 --> Router Class Initialized
INFO - 2017-05-12 11:25:42 --> Output Class Initialized
INFO - 2017-05-12 11:25:42 --> Output Class Initialized
INFO - 2017-05-12 11:25:42 --> Security Class Initialized
INFO - 2017-05-12 11:25:42 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-12 11:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:42 --> Input Class Initialized
INFO - 2017-05-12 11:25:42 --> Input Class Initialized
INFO - 2017-05-12 11:25:42 --> Language Class Initialized
INFO - 2017-05-12 11:25:42 --> Language Class Initialized
INFO - 2017-05-12 11:25:42 --> Loader Class Initialized
INFO - 2017-05-12 11:25:42 --> Loader Class Initialized
INFO - 2017-05-12 11:25:42 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:42 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:42 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:42 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:42 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:42 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:42 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:42 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:42 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:42 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:42 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:42 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:42 --> Parser Class Initialized
INFO - 2017-05-12 11:25:42 --> Parser Class Initialized
DEBUG - 2017-05-12 11:25:42 --> Session Class Initialized
DEBUG - 2017-05-12 11:25:42 --> Session Class Initialized
INFO - 2017-05-12 11:25:42 --> Helper loaded: string_helper
INFO - 2017-05-12 11:25:42 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:25:42 --> Session routines successfully run
DEBUG - 2017-05-12 11:25:42 --> Session routines successfully run
INFO - 2017-05-12 11:25:42 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:42 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:42 --> Controller Class Initialized
INFO - 2017-05-12 11:25:42 --> Controller Class Initialized
DEBUG - 2017-05-12 11:25:42 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2017-05-12 11:25:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:25:42 --> Model Class Initialized
INFO - 2017-05-12 11:25:42 --> Model Class Initialized
DEBUG - 2017-05-12 11:25:42 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:25:42 --> Pagination Class Initialized
INFO - 2017-05-12 11:25:42 --> Final output sent to browser
INFO - 2017-05-12 11:25:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
DEBUG - 2017-05-12 11:25:42 --> Total execution time: 0.6945
INFO - 2017-05-12 11:25:42 --> Final output sent to browser
DEBUG - 2017-05-12 11:25:42 --> Total execution time: 0.7244
INFO - 2017-05-12 11:25:48 --> Config Class Initialized
INFO - 2017-05-12 11:25:48 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:48 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:48 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:48 --> URI Class Initialized
INFO - 2017-05-12 11:25:48 --> Router Class Initialized
INFO - 2017-05-12 11:25:48 --> Output Class Initialized
INFO - 2017-05-12 11:25:48 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:48 --> Input Class Initialized
INFO - 2017-05-12 11:25:48 --> Language Class Initialized
INFO - 2017-05-12 11:25:48 --> Loader Class Initialized
INFO - 2017-05-12 11:25:48 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:48 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:48 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:48 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:48 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:48 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:48 --> Parser Class Initialized
DEBUG - 2017-05-12 11:25:48 --> Session Class Initialized
INFO - 2017-05-12 11:25:48 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:25:48 --> Session routines successfully run
INFO - 2017-05-12 11:25:48 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:48 --> Controller Class Initialized
DEBUG - 2017-05-12 11:25:48 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:25:48 --> Model Class Initialized
DEBUG - 2017-05-12 11:25:49 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:25:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:25:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:25:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:25:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:25:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:25:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:25:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:25:49 --> Final output sent to browser
DEBUG - 2017-05-12 11:25:49 --> Total execution time: 0.5768
INFO - 2017-05-12 11:25:49 --> Config Class Initialized
INFO - 2017-05-12 11:25:49 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:49 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:49 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:49 --> URI Class Initialized
INFO - 2017-05-12 11:25:49 --> Router Class Initialized
INFO - 2017-05-12 11:25:49 --> Output Class Initialized
INFO - 2017-05-12 11:25:49 --> Security Class Initialized
INFO - 2017-05-12 11:25:49 --> Config Class Initialized
DEBUG - 2017-05-12 11:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:49 --> Hooks Class Initialized
INFO - 2017-05-12 11:25:49 --> Input Class Initialized
DEBUG - 2017-05-12 11:25:49 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:49 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:49 --> Language Class Initialized
INFO - 2017-05-12 11:25:49 --> URI Class Initialized
ERROR - 2017-05-12 11:25:49 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:25:49 --> Router Class Initialized
INFO - 2017-05-12 11:25:49 --> Output Class Initialized
INFO - 2017-05-12 11:25:49 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:49 --> Input Class Initialized
INFO - 2017-05-12 11:25:49 --> Language Class Initialized
ERROR - 2017-05-12 11:25:49 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:25:49 --> Config Class Initialized
INFO - 2017-05-12 11:25:49 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:49 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:49 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:49 --> URI Class Initialized
INFO - 2017-05-12 11:25:49 --> Router Class Initialized
INFO - 2017-05-12 11:25:49 --> Output Class Initialized
INFO - 2017-05-12 11:25:49 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:49 --> Input Class Initialized
INFO - 2017-05-12 11:25:49 --> Language Class Initialized
INFO - 2017-05-12 11:25:49 --> Loader Class Initialized
INFO - 2017-05-12 11:25:49 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:49 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:49 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:49 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:49 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:49 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:49 --> Parser Class Initialized
DEBUG - 2017-05-12 11:25:49 --> Session Class Initialized
INFO - 2017-05-12 11:25:49 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:25:49 --> Session routines successfully run
INFO - 2017-05-12 11:25:49 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:49 --> Controller Class Initialized
DEBUG - 2017-05-12 11:25:49 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:25:49 --> Model Class Initialized
DEBUG - 2017-05-12 11:25:49 --> Pagination Class Initialized
INFO - 2017-05-12 11:25:49 --> Final output sent to browser
DEBUG - 2017-05-12 11:25:50 --> Total execution time: 0.4378
INFO - 2017-05-12 11:25:57 --> Config Class Initialized
INFO - 2017-05-12 11:25:57 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:57 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:57 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:57 --> URI Class Initialized
INFO - 2017-05-12 11:25:57 --> Router Class Initialized
INFO - 2017-05-12 11:25:57 --> Output Class Initialized
INFO - 2017-05-12 11:25:57 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:57 --> Input Class Initialized
INFO - 2017-05-12 11:25:57 --> Language Class Initialized
INFO - 2017-05-12 11:25:57 --> Loader Class Initialized
INFO - 2017-05-12 11:25:57 --> Helper loaded: url_helper
INFO - 2017-05-12 11:25:57 --> Helper loaded: form_helper
INFO - 2017-05-12 11:25:57 --> Helper loaded: html_helper
INFO - 2017-05-12 11:25:57 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:25:57 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:25:57 --> Database Driver Class Initialized
INFO - 2017-05-12 11:25:57 --> Parser Class Initialized
DEBUG - 2017-05-12 11:25:57 --> Session Class Initialized
INFO - 2017-05-12 11:25:57 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:25:57 --> Session routines successfully run
INFO - 2017-05-12 11:25:57 --> Form Validation Class Initialized
INFO - 2017-05-12 11:25:57 --> Controller Class Initialized
DEBUG - 2017-05-12 11:25:57 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:25:57 --> Model Class Initialized
DEBUG - 2017-05-12 11:25:57 --> Pagination Class Initialized
INFO - 2017-05-12 11:25:57 --> Final output sent to browser
DEBUG - 2017-05-12 11:25:57 --> Total execution time: 0.4242
INFO - 2017-05-12 11:25:59 --> Config Class Initialized
INFO - 2017-05-12 11:25:59 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:25:59 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:25:59 --> Utf8 Class Initialized
INFO - 2017-05-12 11:25:59 --> URI Class Initialized
INFO - 2017-05-12 11:25:59 --> Router Class Initialized
INFO - 2017-05-12 11:25:59 --> Output Class Initialized
INFO - 2017-05-12 11:25:59 --> Security Class Initialized
DEBUG - 2017-05-12 11:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:25:59 --> Input Class Initialized
INFO - 2017-05-12 11:25:59 --> Language Class Initialized
INFO - 2017-05-12 11:26:00 --> Loader Class Initialized
INFO - 2017-05-12 11:26:00 --> Helper loaded: url_helper
INFO - 2017-05-12 11:26:00 --> Helper loaded: form_helper
INFO - 2017-05-12 11:26:00 --> Helper loaded: html_helper
INFO - 2017-05-12 11:26:00 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:26:00 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:26:00 --> Database Driver Class Initialized
INFO - 2017-05-12 11:26:00 --> Parser Class Initialized
DEBUG - 2017-05-12 11:26:00 --> Session Class Initialized
INFO - 2017-05-12 11:26:00 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:26:00 --> Session routines successfully run
INFO - 2017-05-12 11:26:00 --> Form Validation Class Initialized
INFO - 2017-05-12 11:26:00 --> Controller Class Initialized
DEBUG - 2017-05-12 11:26:00 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:26:00 --> Model Class Initialized
DEBUG - 2017-05-12 11:26:00 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:26:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:26:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:26:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:26:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:26:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-05-12 11:26:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:26:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:26:00 --> Final output sent to browser
DEBUG - 2017-05-12 11:26:00 --> Total execution time: 0.5774
INFO - 2017-05-12 11:26:00 --> Config Class Initialized
INFO - 2017-05-12 11:26:00 --> Hooks Class Initialized
INFO - 2017-05-12 11:26:00 --> Config Class Initialized
DEBUG - 2017-05-12 11:26:00 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:00 --> Hooks Class Initialized
INFO - 2017-05-12 11:26:00 --> Utf8 Class Initialized
DEBUG - 2017-05-12 11:26:00 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:00 --> URI Class Initialized
INFO - 2017-05-12 11:26:00 --> Utf8 Class Initialized
INFO - 2017-05-12 11:26:00 --> Router Class Initialized
INFO - 2017-05-12 11:26:00 --> URI Class Initialized
INFO - 2017-05-12 11:26:00 --> Output Class Initialized
INFO - 2017-05-12 11:26:00 --> Router Class Initialized
INFO - 2017-05-12 11:26:00 --> Security Class Initialized
INFO - 2017-05-12 11:26:00 --> Output Class Initialized
DEBUG - 2017-05-12 11:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:26:00 --> Security Class Initialized
INFO - 2017-05-12 11:26:00 --> Input Class Initialized
INFO - 2017-05-12 11:26:00 --> Language Class Initialized
DEBUG - 2017-05-12 11:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-05-12 11:26:00 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:26:00 --> Input Class Initialized
INFO - 2017-05-12 11:26:00 --> Language Class Initialized
ERROR - 2017-05-12 11:26:00 --> 404 Page Not Found: Default/assets
INFO - 2017-05-12 11:26:00 --> Config Class Initialized
INFO - 2017-05-12 11:26:00 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:26:00 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:00 --> Utf8 Class Initialized
INFO - 2017-05-12 11:26:00 --> URI Class Initialized
INFO - 2017-05-12 11:26:00 --> Router Class Initialized
INFO - 2017-05-12 11:26:00 --> Output Class Initialized
INFO - 2017-05-12 11:26:00 --> Security Class Initialized
DEBUG - 2017-05-12 11:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:26:00 --> Input Class Initialized
INFO - 2017-05-12 11:26:00 --> Language Class Initialized
INFO - 2017-05-12 11:26:00 --> Loader Class Initialized
INFO - 2017-05-12 11:26:01 --> Helper loaded: url_helper
INFO - 2017-05-12 11:26:01 --> Helper loaded: form_helper
INFO - 2017-05-12 11:26:01 --> Helper loaded: html_helper
INFO - 2017-05-12 11:26:01 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:26:01 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:26:01 --> Database Driver Class Initialized
INFO - 2017-05-12 11:26:01 --> Parser Class Initialized
DEBUG - 2017-05-12 11:26:01 --> Session Class Initialized
INFO - 2017-05-12 11:26:01 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:26:01 --> Session routines successfully run
INFO - 2017-05-12 11:26:01 --> Form Validation Class Initialized
INFO - 2017-05-12 11:26:01 --> Controller Class Initialized
DEBUG - 2017-05-12 11:26:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:26:01 --> Model Class Initialized
DEBUG - 2017-05-12 11:26:01 --> Pagination Class Initialized
INFO - 2017-05-12 11:26:01 --> Final output sent to browser
DEBUG - 2017-05-12 11:26:01 --> Total execution time: 0.4538
INFO - 2017-05-12 11:26:07 --> Config Class Initialized
INFO - 2017-05-12 11:26:07 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:26:07 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:07 --> Utf8 Class Initialized
INFO - 2017-05-12 11:26:07 --> URI Class Initialized
INFO - 2017-05-12 11:26:07 --> Router Class Initialized
INFO - 2017-05-12 11:26:07 --> Output Class Initialized
INFO - 2017-05-12 11:26:07 --> Security Class Initialized
DEBUG - 2017-05-12 11:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:26:07 --> Input Class Initialized
INFO - 2017-05-12 11:26:07 --> Language Class Initialized
INFO - 2017-05-12 11:26:07 --> Loader Class Initialized
INFO - 2017-05-12 11:26:07 --> Helper loaded: url_helper
INFO - 2017-05-12 11:26:07 --> Helper loaded: form_helper
INFO - 2017-05-12 11:26:08 --> Helper loaded: html_helper
INFO - 2017-05-12 11:26:08 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:26:08 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:26:08 --> Database Driver Class Initialized
INFO - 2017-05-12 11:26:08 --> Parser Class Initialized
DEBUG - 2017-05-12 11:26:08 --> Session Class Initialized
INFO - 2017-05-12 11:26:08 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:26:08 --> Session routines successfully run
INFO - 2017-05-12 11:26:08 --> Form Validation Class Initialized
INFO - 2017-05-12 11:26:08 --> Controller Class Initialized
DEBUG - 2017-05-12 11:26:08 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:26:08 --> Model Class Initialized
DEBUG - 2017-05-12 11:26:08 --> Pagination Class Initialized
INFO - 2017-05-12 11:26:08 --> Final output sent to browser
DEBUG - 2017-05-12 11:26:08 --> Total execution time: 0.4472
INFO - 2017-05-12 11:26:11 --> Config Class Initialized
INFO - 2017-05-12 11:26:11 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:26:11 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:11 --> Utf8 Class Initialized
INFO - 2017-05-12 11:26:11 --> URI Class Initialized
INFO - 2017-05-12 11:26:11 --> Router Class Initialized
INFO - 2017-05-12 11:26:11 --> Output Class Initialized
INFO - 2017-05-12 11:26:11 --> Security Class Initialized
DEBUG - 2017-05-12 11:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:26:11 --> Input Class Initialized
INFO - 2017-05-12 11:26:11 --> Language Class Initialized
INFO - 2017-05-12 11:26:11 --> Loader Class Initialized
INFO - 2017-05-12 11:26:11 --> Helper loaded: url_helper
INFO - 2017-05-12 11:26:11 --> Helper loaded: form_helper
INFO - 2017-05-12 11:26:11 --> Helper loaded: html_helper
INFO - 2017-05-12 11:26:11 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:26:11 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:26:12 --> Database Driver Class Initialized
INFO - 2017-05-12 11:26:12 --> Parser Class Initialized
DEBUG - 2017-05-12 11:26:12 --> Session Class Initialized
INFO - 2017-05-12 11:26:12 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:26:12 --> Session routines successfully run
INFO - 2017-05-12 11:26:12 --> Form Validation Class Initialized
INFO - 2017-05-12 11:26:12 --> Controller Class Initialized
DEBUG - 2017-05-12 11:26:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:26:12 --> Model Class Initialized
DEBUG - 2017-05-12 11:26:12 --> Pagination Class Initialized
DEBUG - 2017-05-12 11:26:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-05-12 11:26:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:26:12 --> Config Class Initialized
INFO - 2017-05-12 11:26:12 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:26:12 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:12 --> Utf8 Class Initialized
INFO - 2017-05-12 11:26:12 --> URI Class Initialized
INFO - 2017-05-12 11:26:12 --> Router Class Initialized
INFO - 2017-05-12 11:26:12 --> Output Class Initialized
INFO - 2017-05-12 11:26:12 --> Security Class Initialized
DEBUG - 2017-05-12 11:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:26:12 --> Input Class Initialized
INFO - 2017-05-12 11:26:12 --> Language Class Initialized
INFO - 2017-05-12 11:26:12 --> Loader Class Initialized
INFO - 2017-05-12 11:26:12 --> Helper loaded: url_helper
INFO - 2017-05-12 11:26:12 --> Helper loaded: form_helper
INFO - 2017-05-12 11:26:12 --> Helper loaded: html_helper
INFO - 2017-05-12 11:26:12 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:26:12 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:26:12 --> Database Driver Class Initialized
INFO - 2017-05-12 11:26:12 --> Parser Class Initialized
DEBUG - 2017-05-12 11:26:12 --> Session Class Initialized
INFO - 2017-05-12 11:26:12 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:26:12 --> Session routines successfully run
INFO - 2017-05-12 11:26:12 --> Form Validation Class Initialized
INFO - 2017-05-12 11:26:13 --> Controller Class Initialized
DEBUG - 2017-05-12 11:26:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:26:13 --> Model Class Initialized
DEBUG - 2017-05-12 11:26:13 --> Pagination Class Initialized
INFO - 2017-05-12 11:26:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:26:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:13 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:14 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-05-12 11:26:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-05-12 11:26:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-05-12 11:26:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-05-12 11:26:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-05-12 11:26:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-05-12 11:26:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:26:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:26:18 --> Final output sent to browser
DEBUG - 2017-05-12 11:26:18 --> Total execution time: 5.4963
INFO - 2017-05-12 11:26:20 --> Config Class Initialized
INFO - 2017-05-12 11:26:20 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:26:20 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:20 --> Utf8 Class Initialized
INFO - 2017-05-12 11:26:20 --> URI Class Initialized
INFO - 2017-05-12 11:26:20 --> Router Class Initialized
INFO - 2017-05-12 11:26:20 --> Output Class Initialized
INFO - 2017-05-12 11:26:20 --> Security Class Initialized
DEBUG - 2017-05-12 11:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:26:20 --> Input Class Initialized
INFO - 2017-05-12 11:26:20 --> Language Class Initialized
INFO - 2017-05-12 11:26:20 --> Loader Class Initialized
INFO - 2017-05-12 11:26:20 --> Helper loaded: url_helper
INFO - 2017-05-12 11:26:20 --> Helper loaded: form_helper
INFO - 2017-05-12 11:26:20 --> Helper loaded: html_helper
INFO - 2017-05-12 11:26:20 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:26:20 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:26:20 --> Database Driver Class Initialized
INFO - 2017-05-12 11:26:20 --> Parser Class Initialized
DEBUG - 2017-05-12 11:26:20 --> Session Class Initialized
INFO - 2017-05-12 11:26:20 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:26:20 --> Session routines successfully run
INFO - 2017-05-12 11:26:20 --> Form Validation Class Initialized
INFO - 2017-05-12 11:26:21 --> Controller Class Initialized
INFO - 2017-05-12 11:26:21 --> Model Class Initialized
INFO - 2017-05-12 11:26:21 --> Config Class Initialized
INFO - 2017-05-12 11:26:21 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:26:21 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:21 --> Utf8 Class Initialized
INFO - 2017-05-12 11:26:21 --> URI Class Initialized
INFO - 2017-05-12 11:26:21 --> Router Class Initialized
INFO - 2017-05-12 11:26:21 --> Output Class Initialized
INFO - 2017-05-12 11:26:21 --> Security Class Initialized
DEBUG - 2017-05-12 11:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:26:21 --> Input Class Initialized
INFO - 2017-05-12 11:26:21 --> Language Class Initialized
INFO - 2017-05-12 11:26:21 --> Loader Class Initialized
INFO - 2017-05-12 11:26:21 --> Helper loaded: url_helper
INFO - 2017-05-12 11:26:21 --> Helper loaded: form_helper
INFO - 2017-05-12 11:26:21 --> Helper loaded: html_helper
INFO - 2017-05-12 11:26:21 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:26:21 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:26:21 --> Database Driver Class Initialized
INFO - 2017-05-12 11:26:21 --> Parser Class Initialized
DEBUG - 2017-05-12 11:26:21 --> Session Class Initialized
INFO - 2017-05-12 11:26:21 --> Helper loaded: string_helper
ERROR - 2017-05-12 11:26:21 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-12 11:26:21 --> Session routines successfully run
INFO - 2017-05-12 11:26:21 --> Form Validation Class Initialized
INFO - 2017-05-12 11:26:21 --> Controller Class Initialized
INFO - 2017-05-12 11:26:21 --> Model Class Initialized
INFO - 2017-05-12 11:26:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-12 11:26:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:26:21 --> Final output sent to browser
DEBUG - 2017-05-12 11:26:21 --> Total execution time: 0.4999
INFO - 2017-05-12 11:26:34 --> Config Class Initialized
INFO - 2017-05-12 11:26:34 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:26:34 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:34 --> Utf8 Class Initialized
INFO - 2017-05-12 11:26:34 --> URI Class Initialized
INFO - 2017-05-12 11:26:34 --> Router Class Initialized
INFO - 2017-05-12 11:26:34 --> Output Class Initialized
INFO - 2017-05-12 11:26:34 --> Security Class Initialized
DEBUG - 2017-05-12 11:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:26:34 --> Input Class Initialized
INFO - 2017-05-12 11:26:34 --> Language Class Initialized
INFO - 2017-05-12 11:26:34 --> Loader Class Initialized
INFO - 2017-05-12 11:26:34 --> Helper loaded: url_helper
INFO - 2017-05-12 11:26:34 --> Helper loaded: form_helper
INFO - 2017-05-12 11:26:34 --> Helper loaded: html_helper
INFO - 2017-05-12 11:26:34 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:26:35 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:26:35 --> Database Driver Class Initialized
INFO - 2017-05-12 11:26:35 --> Parser Class Initialized
DEBUG - 2017-05-12 11:26:35 --> Session Class Initialized
INFO - 2017-05-12 11:26:35 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:26:35 --> Session routines successfully run
INFO - 2017-05-12 11:26:35 --> Form Validation Class Initialized
INFO - 2017-05-12 11:26:35 --> Controller Class Initialized
INFO - 2017-05-12 11:26:35 --> Model Class Initialized
INFO - 2017-05-12 11:26:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:26:35 --> Config Class Initialized
INFO - 2017-05-12 11:26:35 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:26:35 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:35 --> Utf8 Class Initialized
INFO - 2017-05-12 11:26:35 --> URI Class Initialized
INFO - 2017-05-12 11:26:35 --> Router Class Initialized
INFO - 2017-05-12 11:26:35 --> Output Class Initialized
INFO - 2017-05-12 11:26:35 --> Security Class Initialized
DEBUG - 2017-05-12 11:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:26:35 --> Input Class Initialized
INFO - 2017-05-12 11:26:35 --> Language Class Initialized
INFO - 2017-05-12 11:26:35 --> Loader Class Initialized
INFO - 2017-05-12 11:26:35 --> Helper loaded: url_helper
INFO - 2017-05-12 11:26:35 --> Helper loaded: form_helper
INFO - 2017-05-12 11:26:35 --> Helper loaded: html_helper
INFO - 2017-05-12 11:26:35 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:26:35 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:26:35 --> Database Driver Class Initialized
INFO - 2017-05-12 11:26:35 --> Parser Class Initialized
DEBUG - 2017-05-12 11:26:35 --> Session Class Initialized
INFO - 2017-05-12 11:26:35 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:26:35 --> Session routines successfully run
INFO - 2017-05-12 11:26:35 --> Form Validation Class Initialized
INFO - 2017-05-12 11:26:35 --> Controller Class Initialized
DEBUG - 2017-05-12 11:26:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:26:35 --> Model Class Initialized
DEBUG - 2017-05-12 11:26:35 --> Pagination Class Initialized
INFO - 2017-05-12 11:26:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:26:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:26:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-05-12 11:26:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:26:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:26:35 --> Final output sent to browser
DEBUG - 2017-05-12 11:26:35 --> Total execution time: 0.6329
INFO - 2017-05-12 11:26:39 --> Config Class Initialized
INFO - 2017-05-12 11:26:39 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:26:39 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:39 --> Utf8 Class Initialized
INFO - 2017-05-12 11:26:39 --> URI Class Initialized
INFO - 2017-05-12 11:26:39 --> Router Class Initialized
INFO - 2017-05-12 11:26:39 --> Output Class Initialized
INFO - 2017-05-12 11:26:39 --> Security Class Initialized
DEBUG - 2017-05-12 11:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:26:39 --> Input Class Initialized
INFO - 2017-05-12 11:26:39 --> Language Class Initialized
INFO - 2017-05-12 11:26:39 --> Loader Class Initialized
INFO - 2017-05-12 11:26:39 --> Helper loaded: url_helper
INFO - 2017-05-12 11:26:39 --> Helper loaded: form_helper
INFO - 2017-05-12 11:26:39 --> Helper loaded: html_helper
INFO - 2017-05-12 11:26:39 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:26:39 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:26:39 --> Database Driver Class Initialized
INFO - 2017-05-12 11:26:39 --> Parser Class Initialized
DEBUG - 2017-05-12 11:26:39 --> Session Class Initialized
INFO - 2017-05-12 11:26:39 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:26:39 --> Session routines successfully run
INFO - 2017-05-12 11:26:39 --> Form Validation Class Initialized
INFO - 2017-05-12 11:26:39 --> Controller Class Initialized
INFO - 2017-05-12 11:26:39 --> Model Class Initialized
INFO - 2017-05-12 11:26:39 --> Config Class Initialized
INFO - 2017-05-12 11:26:39 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:26:39 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:26:39 --> Utf8 Class Initialized
INFO - 2017-05-12 11:26:39 --> URI Class Initialized
INFO - 2017-05-12 11:26:39 --> Router Class Initialized
INFO - 2017-05-12 11:26:39 --> Output Class Initialized
INFO - 2017-05-12 11:26:39 --> Security Class Initialized
DEBUG - 2017-05-12 11:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:26:39 --> Input Class Initialized
INFO - 2017-05-12 11:26:39 --> Language Class Initialized
INFO - 2017-05-12 11:26:39 --> Loader Class Initialized
INFO - 2017-05-12 11:26:39 --> Helper loaded: url_helper
INFO - 2017-05-12 11:26:39 --> Helper loaded: form_helper
INFO - 2017-05-12 11:26:39 --> Helper loaded: html_helper
INFO - 2017-05-12 11:26:39 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:26:39 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:26:40 --> Database Driver Class Initialized
INFO - 2017-05-12 11:26:40 --> Parser Class Initialized
DEBUG - 2017-05-12 11:26:40 --> Session Class Initialized
INFO - 2017-05-12 11:26:40 --> Helper loaded: string_helper
ERROR - 2017-05-12 11:26:40 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-12 11:26:40 --> Session routines successfully run
INFO - 2017-05-12 11:26:40 --> Form Validation Class Initialized
INFO - 2017-05-12 11:26:40 --> Controller Class Initialized
INFO - 2017-05-12 11:26:40 --> Model Class Initialized
INFO - 2017-05-12 11:26:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-12 11:26:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:26:40 --> Final output sent to browser
DEBUG - 2017-05-12 11:26:40 --> Total execution time: 0.4935
INFO - 2017-05-12 11:28:11 --> Config Class Initialized
INFO - 2017-05-12 11:28:11 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:28:11 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:28:11 --> Utf8 Class Initialized
INFO - 2017-05-12 11:28:11 --> URI Class Initialized
INFO - 2017-05-12 11:28:11 --> Router Class Initialized
INFO - 2017-05-12 11:28:11 --> Output Class Initialized
INFO - 2017-05-12 11:28:11 --> Security Class Initialized
DEBUG - 2017-05-12 11:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:28:11 --> Input Class Initialized
INFO - 2017-05-12 11:28:11 --> Language Class Initialized
INFO - 2017-05-12 11:28:11 --> Loader Class Initialized
INFO - 2017-05-12 11:28:11 --> Helper loaded: url_helper
INFO - 2017-05-12 11:28:11 --> Helper loaded: form_helper
INFO - 2017-05-12 11:28:11 --> Helper loaded: html_helper
INFO - 2017-05-12 11:28:11 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:28:11 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:28:11 --> Database Driver Class Initialized
INFO - 2017-05-12 11:28:11 --> Parser Class Initialized
DEBUG - 2017-05-12 11:28:11 --> Session Class Initialized
INFO - 2017-05-12 11:28:11 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:28:11 --> Session routines successfully run
INFO - 2017-05-12 11:28:11 --> Form Validation Class Initialized
INFO - 2017-05-12 11:28:11 --> Controller Class Initialized
INFO - 2017-05-12 11:28:11 --> Model Class Initialized
INFO - 2017-05-12 11:28:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:29:24 --> Config Class Initialized
INFO - 2017-05-12 11:29:24 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:29:24 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:29:24 --> Utf8 Class Initialized
INFO - 2017-05-12 11:29:24 --> URI Class Initialized
INFO - 2017-05-12 11:29:24 --> Router Class Initialized
INFO - 2017-05-12 11:29:24 --> Output Class Initialized
INFO - 2017-05-12 11:29:24 --> Security Class Initialized
DEBUG - 2017-05-12 11:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:29:24 --> Input Class Initialized
INFO - 2017-05-12 11:29:24 --> Language Class Initialized
INFO - 2017-05-12 11:29:24 --> Loader Class Initialized
INFO - 2017-05-12 11:29:24 --> Helper loaded: url_helper
INFO - 2017-05-12 11:29:24 --> Helper loaded: form_helper
INFO - 2017-05-12 11:29:24 --> Helper loaded: html_helper
INFO - 2017-05-12 11:29:24 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:29:24 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:29:24 --> Database Driver Class Initialized
INFO - 2017-05-12 11:29:24 --> Parser Class Initialized
DEBUG - 2017-05-12 11:29:24 --> Session Class Initialized
INFO - 2017-05-12 11:29:24 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:29:24 --> Session routines successfully run
INFO - 2017-05-12 11:29:24 --> Form Validation Class Initialized
INFO - 2017-05-12 11:29:24 --> Controller Class Initialized
INFO - 2017-05-12 11:29:24 --> Model Class Initialized
INFO - 2017-05-12 11:29:24 --> Config Class Initialized
INFO - 2017-05-12 11:29:24 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:29:24 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:29:24 --> Utf8 Class Initialized
INFO - 2017-05-12 11:29:25 --> URI Class Initialized
INFO - 2017-05-12 11:29:25 --> Router Class Initialized
INFO - 2017-05-12 11:29:25 --> Output Class Initialized
INFO - 2017-05-12 11:29:25 --> Security Class Initialized
DEBUG - 2017-05-12 11:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:29:25 --> Input Class Initialized
INFO - 2017-05-12 11:29:25 --> Language Class Initialized
INFO - 2017-05-12 11:29:25 --> Loader Class Initialized
INFO - 2017-05-12 11:29:25 --> Helper loaded: url_helper
INFO - 2017-05-12 11:29:25 --> Helper loaded: form_helper
INFO - 2017-05-12 11:29:25 --> Helper loaded: html_helper
INFO - 2017-05-12 11:29:25 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:29:25 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:29:25 --> Database Driver Class Initialized
INFO - 2017-05-12 11:29:25 --> Parser Class Initialized
DEBUG - 2017-05-12 11:29:25 --> Session Class Initialized
INFO - 2017-05-12 11:29:25 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:29:25 --> Session routines successfully run
INFO - 2017-05-12 11:29:25 --> Form Validation Class Initialized
INFO - 2017-05-12 11:29:25 --> Controller Class Initialized
INFO - 2017-05-12 11:29:25 --> Model Class Initialized
INFO - 2017-05-12 11:29:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-12 11:29:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:29:25 --> Final output sent to browser
DEBUG - 2017-05-12 11:29:25 --> Total execution time: 0.4733
INFO - 2017-05-12 11:29:36 --> Config Class Initialized
INFO - 2017-05-12 11:29:36 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:29:36 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:29:36 --> Utf8 Class Initialized
INFO - 2017-05-12 11:29:36 --> URI Class Initialized
INFO - 2017-05-12 11:29:36 --> Router Class Initialized
INFO - 2017-05-12 11:29:36 --> Output Class Initialized
INFO - 2017-05-12 11:29:36 --> Security Class Initialized
DEBUG - 2017-05-12 11:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:29:36 --> Input Class Initialized
INFO - 2017-05-12 11:29:36 --> Language Class Initialized
INFO - 2017-05-12 11:29:36 --> Loader Class Initialized
INFO - 2017-05-12 11:29:36 --> Helper loaded: url_helper
INFO - 2017-05-12 11:29:36 --> Helper loaded: form_helper
INFO - 2017-05-12 11:29:36 --> Helper loaded: html_helper
INFO - 2017-05-12 11:29:36 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:29:36 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:29:36 --> Database Driver Class Initialized
INFO - 2017-05-12 11:29:36 --> Parser Class Initialized
DEBUG - 2017-05-12 11:29:36 --> Session Class Initialized
INFO - 2017-05-12 11:29:36 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:29:36 --> Session routines successfully run
INFO - 2017-05-12 11:29:36 --> Form Validation Class Initialized
INFO - 2017-05-12 11:29:36 --> Controller Class Initialized
INFO - 2017-05-12 11:29:36 --> Model Class Initialized
INFO - 2017-05-12 11:29:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:29:37 --> Config Class Initialized
INFO - 2017-05-12 11:29:37 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:29:37 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:29:37 --> Utf8 Class Initialized
INFO - 2017-05-12 11:29:37 --> URI Class Initialized
INFO - 2017-05-12 11:29:37 --> Router Class Initialized
INFO - 2017-05-12 11:29:37 --> Output Class Initialized
INFO - 2017-05-12 11:29:37 --> Security Class Initialized
DEBUG - 2017-05-12 11:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:29:37 --> Input Class Initialized
INFO - 2017-05-12 11:29:37 --> Language Class Initialized
INFO - 2017-05-12 11:29:37 --> Loader Class Initialized
INFO - 2017-05-12 11:29:37 --> Helper loaded: url_helper
INFO - 2017-05-12 11:29:37 --> Helper loaded: form_helper
INFO - 2017-05-12 11:29:37 --> Helper loaded: html_helper
INFO - 2017-05-12 11:29:37 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:29:37 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:29:37 --> Database Driver Class Initialized
INFO - 2017-05-12 11:29:37 --> Parser Class Initialized
DEBUG - 2017-05-12 11:29:37 --> Session Class Initialized
INFO - 2017-05-12 11:29:37 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:29:37 --> Session routines successfully run
INFO - 2017-05-12 11:29:37 --> Form Validation Class Initialized
INFO - 2017-05-12 11:29:37 --> Controller Class Initialized
DEBUG - 2017-05-12 11:29:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:29:37 --> Model Class Initialized
DEBUG - 2017-05-12 11:29:37 --> Pagination Class Initialized
INFO - 2017-05-12 11:29:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:29:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:29:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-05-12 11:29:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:29:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:29:37 --> Final output sent to browser
DEBUG - 2017-05-12 11:29:37 --> Total execution time: 0.5999
INFO - 2017-05-12 11:29:40 --> Config Class Initialized
INFO - 2017-05-12 11:29:40 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:29:40 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:29:40 --> Utf8 Class Initialized
INFO - 2017-05-12 11:29:40 --> URI Class Initialized
INFO - 2017-05-12 11:29:40 --> Router Class Initialized
INFO - 2017-05-12 11:29:40 --> Output Class Initialized
INFO - 2017-05-12 11:29:40 --> Security Class Initialized
DEBUG - 2017-05-12 11:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:29:40 --> Input Class Initialized
INFO - 2017-05-12 11:29:40 --> Language Class Initialized
INFO - 2017-05-12 11:29:40 --> Loader Class Initialized
INFO - 2017-05-12 11:29:40 --> Helper loaded: url_helper
INFO - 2017-05-12 11:29:40 --> Helper loaded: form_helper
INFO - 2017-05-12 11:29:40 --> Helper loaded: html_helper
INFO - 2017-05-12 11:29:40 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:29:40 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:29:40 --> Database Driver Class Initialized
INFO - 2017-05-12 11:29:40 --> Parser Class Initialized
DEBUG - 2017-05-12 11:29:40 --> Session Class Initialized
INFO - 2017-05-12 11:29:40 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:29:40 --> Session routines successfully run
INFO - 2017-05-12 11:29:40 --> Form Validation Class Initialized
INFO - 2017-05-12 11:29:40 --> Controller Class Initialized
INFO - 2017-05-12 11:29:40 --> Model Class Initialized
INFO - 2017-05-12 11:29:40 --> Config Class Initialized
INFO - 2017-05-12 11:29:40 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:29:40 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:29:40 --> Utf8 Class Initialized
INFO - 2017-05-12 11:29:40 --> URI Class Initialized
INFO - 2017-05-12 11:29:40 --> Router Class Initialized
INFO - 2017-05-12 11:29:40 --> Output Class Initialized
INFO - 2017-05-12 11:29:40 --> Security Class Initialized
DEBUG - 2017-05-12 11:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:29:40 --> Input Class Initialized
INFO - 2017-05-12 11:29:40 --> Language Class Initialized
INFO - 2017-05-12 11:29:40 --> Loader Class Initialized
INFO - 2017-05-12 11:29:40 --> Helper loaded: url_helper
INFO - 2017-05-12 11:29:40 --> Helper loaded: form_helper
INFO - 2017-05-12 11:29:40 --> Helper loaded: html_helper
INFO - 2017-05-12 11:29:40 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:29:40 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:29:40 --> Database Driver Class Initialized
INFO - 2017-05-12 11:29:40 --> Parser Class Initialized
DEBUG - 2017-05-12 11:29:40 --> Session Class Initialized
INFO - 2017-05-12 11:29:40 --> Helper loaded: string_helper
ERROR - 2017-05-12 11:29:40 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-12 11:29:40 --> Session routines successfully run
INFO - 2017-05-12 11:29:40 --> Form Validation Class Initialized
INFO - 2017-05-12 11:29:40 --> Controller Class Initialized
INFO - 2017-05-12 11:29:40 --> Model Class Initialized
INFO - 2017-05-12 11:29:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-12 11:29:40 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:29:40 --> Final output sent to browser
DEBUG - 2017-05-12 11:29:40 --> Total execution time: 0.5060
INFO - 2017-05-12 11:29:52 --> Config Class Initialized
INFO - 2017-05-12 11:29:52 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:29:52 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:29:52 --> Utf8 Class Initialized
INFO - 2017-05-12 11:29:52 --> URI Class Initialized
INFO - 2017-05-12 11:29:52 --> Router Class Initialized
INFO - 2017-05-12 11:29:52 --> Output Class Initialized
INFO - 2017-05-12 11:29:52 --> Security Class Initialized
DEBUG - 2017-05-12 11:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:29:52 --> Input Class Initialized
INFO - 2017-05-12 11:29:52 --> Language Class Initialized
INFO - 2017-05-12 11:29:52 --> Loader Class Initialized
INFO - 2017-05-12 11:29:52 --> Helper loaded: url_helper
INFO - 2017-05-12 11:29:52 --> Helper loaded: form_helper
INFO - 2017-05-12 11:29:52 --> Helper loaded: html_helper
INFO - 2017-05-12 11:29:52 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:29:52 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:29:52 --> Database Driver Class Initialized
INFO - 2017-05-12 11:29:52 --> Parser Class Initialized
DEBUG - 2017-05-12 11:29:52 --> Session Class Initialized
INFO - 2017-05-12 11:29:52 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:29:52 --> Session routines successfully run
INFO - 2017-05-12 11:29:52 --> Form Validation Class Initialized
INFO - 2017-05-12 11:29:52 --> Controller Class Initialized
INFO - 2017-05-12 11:29:52 --> Model Class Initialized
INFO - 2017-05-12 11:29:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:29:52 --> Config Class Initialized
INFO - 2017-05-12 11:29:52 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:29:52 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:29:52 --> Utf8 Class Initialized
INFO - 2017-05-12 11:29:52 --> URI Class Initialized
INFO - 2017-05-12 11:29:52 --> Router Class Initialized
INFO - 2017-05-12 11:29:52 --> Output Class Initialized
INFO - 2017-05-12 11:29:52 --> Security Class Initialized
DEBUG - 2017-05-12 11:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:29:52 --> Input Class Initialized
INFO - 2017-05-12 11:29:52 --> Language Class Initialized
INFO - 2017-05-12 11:29:52 --> Loader Class Initialized
INFO - 2017-05-12 11:29:52 --> Helper loaded: url_helper
INFO - 2017-05-12 11:29:52 --> Helper loaded: form_helper
INFO - 2017-05-12 11:29:52 --> Helper loaded: html_helper
INFO - 2017-05-12 11:29:52 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:29:52 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:29:52 --> Database Driver Class Initialized
INFO - 2017-05-12 11:29:52 --> Parser Class Initialized
DEBUG - 2017-05-12 11:29:52 --> Session Class Initialized
INFO - 2017-05-12 11:29:52 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:29:52 --> Session routines successfully run
INFO - 2017-05-12 11:29:52 --> Form Validation Class Initialized
INFO - 2017-05-12 11:29:52 --> Controller Class Initialized
INFO - 2017-05-12 11:29:52 --> Model Class Initialized
INFO - 2017-05-12 11:29:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-12 11:29:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:29:52 --> Final output sent to browser
DEBUG - 2017-05-12 11:29:52 --> Total execution time: 0.4639
INFO - 2017-05-12 11:30:03 --> Config Class Initialized
INFO - 2017-05-12 11:30:03 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:30:03 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:30:03 --> Utf8 Class Initialized
INFO - 2017-05-12 11:30:03 --> URI Class Initialized
INFO - 2017-05-12 11:30:03 --> Router Class Initialized
INFO - 2017-05-12 11:30:03 --> Output Class Initialized
INFO - 2017-05-12 11:30:03 --> Security Class Initialized
DEBUG - 2017-05-12 11:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:30:03 --> Input Class Initialized
INFO - 2017-05-12 11:30:03 --> Language Class Initialized
INFO - 2017-05-12 11:30:03 --> Loader Class Initialized
INFO - 2017-05-12 11:30:03 --> Helper loaded: url_helper
INFO - 2017-05-12 11:30:03 --> Helper loaded: form_helper
INFO - 2017-05-12 11:30:03 --> Helper loaded: html_helper
INFO - 2017-05-12 11:30:03 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:30:03 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:30:03 --> Database Driver Class Initialized
INFO - 2017-05-12 11:30:03 --> Parser Class Initialized
DEBUG - 2017-05-12 11:30:03 --> Session Class Initialized
INFO - 2017-05-12 11:30:03 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:30:03 --> Session routines successfully run
INFO - 2017-05-12 11:30:03 --> Form Validation Class Initialized
INFO - 2017-05-12 11:30:03 --> Controller Class Initialized
INFO - 2017-05-12 11:30:03 --> Model Class Initialized
INFO - 2017-05-12 11:30:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:30:03 --> Config Class Initialized
INFO - 2017-05-12 11:30:03 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:30:03 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:30:03 --> Utf8 Class Initialized
INFO - 2017-05-12 11:30:03 --> URI Class Initialized
INFO - 2017-05-12 11:30:03 --> Router Class Initialized
INFO - 2017-05-12 11:30:04 --> Output Class Initialized
INFO - 2017-05-12 11:30:04 --> Security Class Initialized
DEBUG - 2017-05-12 11:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:30:04 --> Input Class Initialized
INFO - 2017-05-12 11:30:04 --> Language Class Initialized
INFO - 2017-05-12 11:30:04 --> Loader Class Initialized
INFO - 2017-05-12 11:30:04 --> Helper loaded: url_helper
INFO - 2017-05-12 11:30:04 --> Helper loaded: form_helper
INFO - 2017-05-12 11:30:04 --> Helper loaded: html_helper
INFO - 2017-05-12 11:30:04 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:30:04 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:30:04 --> Database Driver Class Initialized
INFO - 2017-05-12 11:30:04 --> Parser Class Initialized
DEBUG - 2017-05-12 11:30:04 --> Session Class Initialized
INFO - 2017-05-12 11:30:04 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:30:04 --> Session routines successfully run
INFO - 2017-05-12 11:30:04 --> Form Validation Class Initialized
INFO - 2017-05-12 11:30:04 --> Controller Class Initialized
INFO - 2017-05-12 11:30:04 --> Model Class Initialized
INFO - 2017-05-12 11:30:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-12 11:30:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:30:04 --> Final output sent to browser
DEBUG - 2017-05-12 11:30:04 --> Total execution time: 0.4631
INFO - 2017-05-12 11:30:16 --> Config Class Initialized
INFO - 2017-05-12 11:30:16 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:30:16 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:30:16 --> Utf8 Class Initialized
INFO - 2017-05-12 11:30:16 --> URI Class Initialized
INFO - 2017-05-12 11:30:16 --> Router Class Initialized
INFO - 2017-05-12 11:30:16 --> Output Class Initialized
INFO - 2017-05-12 11:30:16 --> Security Class Initialized
DEBUG - 2017-05-12 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:30:16 --> Input Class Initialized
INFO - 2017-05-12 11:30:16 --> Language Class Initialized
INFO - 2017-05-12 11:30:16 --> Loader Class Initialized
INFO - 2017-05-12 11:30:16 --> Helper loaded: url_helper
INFO - 2017-05-12 11:30:16 --> Helper loaded: form_helper
INFO - 2017-05-12 11:30:16 --> Helper loaded: html_helper
INFO - 2017-05-12 11:30:16 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:30:16 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:30:16 --> Database Driver Class Initialized
INFO - 2017-05-12 11:30:16 --> Parser Class Initialized
DEBUG - 2017-05-12 11:30:16 --> Session Class Initialized
INFO - 2017-05-12 11:30:16 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:30:16 --> Session routines successfully run
INFO - 2017-05-12 11:30:16 --> Form Validation Class Initialized
INFO - 2017-05-12 11:30:16 --> Controller Class Initialized
INFO - 2017-05-12 11:30:16 --> Model Class Initialized
INFO - 2017-05-12 11:30:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-05-12 11:30:16 --> Config Class Initialized
INFO - 2017-05-12 11:30:16 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:30:16 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:30:16 --> Utf8 Class Initialized
INFO - 2017-05-12 11:30:16 --> URI Class Initialized
INFO - 2017-05-12 11:30:16 --> Router Class Initialized
INFO - 2017-05-12 11:30:16 --> Output Class Initialized
INFO - 2017-05-12 11:30:16 --> Security Class Initialized
DEBUG - 2017-05-12 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:30:16 --> Input Class Initialized
INFO - 2017-05-12 11:30:16 --> Language Class Initialized
INFO - 2017-05-12 11:30:16 --> Loader Class Initialized
INFO - 2017-05-12 11:30:17 --> Helper loaded: url_helper
INFO - 2017-05-12 11:30:17 --> Helper loaded: form_helper
INFO - 2017-05-12 11:30:17 --> Helper loaded: html_helper
INFO - 2017-05-12 11:30:17 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:30:17 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:30:17 --> Database Driver Class Initialized
INFO - 2017-05-12 11:30:17 --> Parser Class Initialized
DEBUG - 2017-05-12 11:30:17 --> Session Class Initialized
INFO - 2017-05-12 11:30:17 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:30:17 --> Session routines successfully run
INFO - 2017-05-12 11:30:17 --> Form Validation Class Initialized
INFO - 2017-05-12 11:30:17 --> Controller Class Initialized
DEBUG - 2017-05-12 11:30:17 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-05-12 11:30:17 --> Model Class Initialized
DEBUG - 2017-05-12 11:30:17 --> Pagination Class Initialized
INFO - 2017-05-12 11:30:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-05-12 11:30:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-05-12 11:30:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-05-12 11:30:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-05-12 11:30:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:30:17 --> Final output sent to browser
DEBUG - 2017-05-12 11:30:17 --> Total execution time: 0.6011
INFO - 2017-05-12 11:30:19 --> Config Class Initialized
INFO - 2017-05-12 11:30:19 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:30:19 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:30:19 --> Utf8 Class Initialized
INFO - 2017-05-12 11:30:19 --> URI Class Initialized
INFO - 2017-05-12 11:30:19 --> Router Class Initialized
INFO - 2017-05-12 11:30:19 --> Output Class Initialized
INFO - 2017-05-12 11:30:19 --> Security Class Initialized
DEBUG - 2017-05-12 11:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:30:19 --> Input Class Initialized
INFO - 2017-05-12 11:30:19 --> Language Class Initialized
INFO - 2017-05-12 11:30:19 --> Loader Class Initialized
INFO - 2017-05-12 11:30:19 --> Helper loaded: url_helper
INFO - 2017-05-12 11:30:19 --> Helper loaded: form_helper
INFO - 2017-05-12 11:30:19 --> Helper loaded: html_helper
INFO - 2017-05-12 11:30:19 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:30:19 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:30:19 --> Database Driver Class Initialized
INFO - 2017-05-12 11:30:19 --> Parser Class Initialized
DEBUG - 2017-05-12 11:30:19 --> Session Class Initialized
INFO - 2017-05-12 11:30:19 --> Helper loaded: string_helper
DEBUG - 2017-05-12 11:30:19 --> Session routines successfully run
INFO - 2017-05-12 11:30:19 --> Form Validation Class Initialized
INFO - 2017-05-12 11:30:19 --> Controller Class Initialized
INFO - 2017-05-12 11:30:19 --> Model Class Initialized
INFO - 2017-05-12 11:30:19 --> Config Class Initialized
INFO - 2017-05-12 11:30:19 --> Hooks Class Initialized
DEBUG - 2017-05-12 11:30:19 --> UTF-8 Support Enabled
INFO - 2017-05-12 11:30:19 --> Utf8 Class Initialized
INFO - 2017-05-12 11:30:19 --> URI Class Initialized
INFO - 2017-05-12 11:30:19 --> Router Class Initialized
INFO - 2017-05-12 11:30:19 --> Output Class Initialized
INFO - 2017-05-12 11:30:19 --> Security Class Initialized
DEBUG - 2017-05-12 11:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 11:30:19 --> Input Class Initialized
INFO - 2017-05-12 11:30:19 --> Language Class Initialized
INFO - 2017-05-12 11:30:19 --> Loader Class Initialized
INFO - 2017-05-12 11:30:19 --> Helper loaded: url_helper
INFO - 2017-05-12 11:30:19 --> Helper loaded: form_helper
INFO - 2017-05-12 11:30:20 --> Helper loaded: html_helper
INFO - 2017-05-12 11:30:20 --> Helper loaded: custom_helper
INFO - 2017-05-12 11:30:20 --> Helper loaded: cache_helper
INFO - 2017-05-12 11:30:20 --> Database Driver Class Initialized
INFO - 2017-05-12 11:30:20 --> Parser Class Initialized
DEBUG - 2017-05-12 11:30:20 --> Session Class Initialized
INFO - 2017-05-12 11:30:20 --> Helper loaded: string_helper
ERROR - 2017-05-12 11:30:20 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-05-12 11:30:20 --> Session routines successfully run
INFO - 2017-05-12 11:30:20 --> Form Validation Class Initialized
INFO - 2017-05-12 11:30:20 --> Controller Class Initialized
INFO - 2017-05-12 11:30:20 --> Model Class Initialized
INFO - 2017-05-12 11:30:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-05-12 11:30:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-05-12 11:30:20 --> Final output sent to browser
DEBUG - 2017-05-12 11:30:20 --> Total execution time: 0.5070
