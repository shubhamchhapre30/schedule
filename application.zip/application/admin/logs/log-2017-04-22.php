<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-04-22 11:18:00 --> Config Class Initialized
INFO - 2017-04-22 11:18:01 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:18:01 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:18:01 --> Utf8 Class Initialized
INFO - 2017-04-22 11:18:01 --> URI Class Initialized
DEBUG - 2017-04-22 11:18:01 --> No URI present. Default controller set.
INFO - 2017-04-22 11:18:01 --> Router Class Initialized
INFO - 2017-04-22 11:18:01 --> Output Class Initialized
INFO - 2017-04-22 11:18:01 --> Security Class Initialized
DEBUG - 2017-04-22 11:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:18:01 --> Input Class Initialized
INFO - 2017-04-22 11:18:01 --> Language Class Initialized
INFO - 2017-04-22 11:18:01 --> Loader Class Initialized
INFO - 2017-04-22 11:18:01 --> Helper loaded: url_helper
INFO - 2017-04-22 11:18:01 --> Helper loaded: form_helper
INFO - 2017-04-22 11:18:01 --> Helper loaded: html_helper
INFO - 2017-04-22 11:18:01 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:18:01 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:18:01 --> Database Driver Class Initialized
INFO - 2017-04-22 11:18:01 --> Parser Class Initialized
DEBUG - 2017-04-22 11:18:01 --> Session Class Initialized
INFO - 2017-04-22 11:18:01 --> Helper loaded: string_helper
ERROR - 2017-04-22 11:18:01 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-22 11:18:01 --> Session routines successfully run
INFO - 2017-04-22 11:18:01 --> Form Validation Class Initialized
INFO - 2017-04-22 11:18:01 --> Controller Class Initialized
INFO - 2017-04-22 11:18:01 --> Model Class Initialized
INFO - 2017-04-22 11:18:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-22 11:18:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:18:01 --> Final output sent to browser
DEBUG - 2017-04-22 11:18:01 --> Total execution time: 1.2257
INFO - 2017-04-22 11:35:27 --> Config Class Initialized
INFO - 2017-04-22 11:35:27 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:35:27 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:35:27 --> Utf8 Class Initialized
INFO - 2017-04-22 11:35:27 --> URI Class Initialized
DEBUG - 2017-04-22 11:35:27 --> No URI present. Default controller set.
INFO - 2017-04-22 11:35:27 --> Router Class Initialized
INFO - 2017-04-22 11:35:27 --> Output Class Initialized
INFO - 2017-04-22 11:35:27 --> Security Class Initialized
DEBUG - 2017-04-22 11:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:35:27 --> Input Class Initialized
INFO - 2017-04-22 11:35:27 --> Language Class Initialized
INFO - 2017-04-22 11:35:27 --> Loader Class Initialized
INFO - 2017-04-22 11:35:27 --> Helper loaded: url_helper
INFO - 2017-04-22 11:35:27 --> Helper loaded: form_helper
INFO - 2017-04-22 11:35:27 --> Helper loaded: html_helper
INFO - 2017-04-22 11:35:27 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:35:27 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:35:27 --> Database Driver Class Initialized
INFO - 2017-04-22 11:35:27 --> Parser Class Initialized
DEBUG - 2017-04-22 11:35:27 --> Session Class Initialized
INFO - 2017-04-22 11:35:27 --> Helper loaded: string_helper
ERROR - 2017-04-22 11:35:27 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-22 11:35:27 --> Session routines successfully run
INFO - 2017-04-22 11:35:27 --> Form Validation Class Initialized
INFO - 2017-04-22 11:35:27 --> Controller Class Initialized
INFO - 2017-04-22 11:35:27 --> Model Class Initialized
INFO - 2017-04-22 11:35:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-22 11:35:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:35:28 --> Final output sent to browser
DEBUG - 2017-04-22 11:35:28 --> Total execution time: 0.2928
INFO - 2017-04-22 11:35:41 --> Config Class Initialized
INFO - 2017-04-22 11:35:41 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:35:41 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:35:41 --> Utf8 Class Initialized
INFO - 2017-04-22 11:35:41 --> URI Class Initialized
INFO - 2017-04-22 11:35:41 --> Router Class Initialized
INFO - 2017-04-22 11:35:41 --> Output Class Initialized
INFO - 2017-04-22 11:35:41 --> Security Class Initialized
DEBUG - 2017-04-22 11:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:35:41 --> Input Class Initialized
INFO - 2017-04-22 11:35:41 --> Language Class Initialized
INFO - 2017-04-22 11:35:41 --> Loader Class Initialized
INFO - 2017-04-22 11:35:41 --> Helper loaded: url_helper
INFO - 2017-04-22 11:35:41 --> Helper loaded: form_helper
INFO - 2017-04-22 11:35:41 --> Helper loaded: html_helper
INFO - 2017-04-22 11:35:41 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:35:41 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:35:41 --> Database Driver Class Initialized
INFO - 2017-04-22 11:35:41 --> Parser Class Initialized
DEBUG - 2017-04-22 11:35:41 --> Session Class Initialized
INFO - 2017-04-22 11:35:41 --> Helper loaded: string_helper
ERROR - 2017-04-22 11:35:41 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-22 11:35:41 --> Session routines successfully run
INFO - 2017-04-22 11:35:41 --> Form Validation Class Initialized
INFO - 2017-04-22 11:35:41 --> Controller Class Initialized
INFO - 2017-04-22 11:35:41 --> Model Class Initialized
INFO - 2017-04-22 11:35:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-04-22 11:35:41 --> Config Class Initialized
INFO - 2017-04-22 11:35:41 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:35:41 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:35:41 --> Utf8 Class Initialized
INFO - 2017-04-22 11:35:41 --> URI Class Initialized
INFO - 2017-04-22 11:35:41 --> Router Class Initialized
INFO - 2017-04-22 11:35:41 --> Output Class Initialized
INFO - 2017-04-22 11:35:41 --> Security Class Initialized
DEBUG - 2017-04-22 11:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:35:41 --> Input Class Initialized
INFO - 2017-04-22 11:35:41 --> Language Class Initialized
INFO - 2017-04-22 11:35:41 --> Loader Class Initialized
INFO - 2017-04-22 11:35:41 --> Helper loaded: url_helper
INFO - 2017-04-22 11:35:41 --> Helper loaded: form_helper
INFO - 2017-04-22 11:35:41 --> Helper loaded: html_helper
INFO - 2017-04-22 11:35:41 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:35:41 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:35:41 --> Database Driver Class Initialized
INFO - 2017-04-22 11:35:41 --> Parser Class Initialized
DEBUG - 2017-04-22 11:35:41 --> Session Class Initialized
INFO - 2017-04-22 11:35:41 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:35:41 --> Session routines successfully run
INFO - 2017-04-22 11:35:41 --> Form Validation Class Initialized
INFO - 2017-04-22 11:35:41 --> Controller Class Initialized
INFO - 2017-04-22 11:35:41 --> Model Class Initialized
INFO - 2017-04-22 11:35:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-22 11:35:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:35:41 --> Final output sent to browser
DEBUG - 2017-04-22 11:35:41 --> Total execution time: 0.1493
INFO - 2017-04-22 11:35:54 --> Config Class Initialized
INFO - 2017-04-22 11:35:54 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:35:54 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:35:54 --> Utf8 Class Initialized
INFO - 2017-04-22 11:35:54 --> URI Class Initialized
INFO - 2017-04-22 11:35:54 --> Router Class Initialized
INFO - 2017-04-22 11:35:54 --> Output Class Initialized
INFO - 2017-04-22 11:35:54 --> Security Class Initialized
DEBUG - 2017-04-22 11:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:35:54 --> Input Class Initialized
INFO - 2017-04-22 11:35:54 --> Language Class Initialized
INFO - 2017-04-22 11:35:54 --> Loader Class Initialized
INFO - 2017-04-22 11:35:54 --> Helper loaded: url_helper
INFO - 2017-04-22 11:35:54 --> Helper loaded: form_helper
INFO - 2017-04-22 11:35:54 --> Helper loaded: html_helper
INFO - 2017-04-22 11:35:54 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:35:54 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:35:54 --> Database Driver Class Initialized
INFO - 2017-04-22 11:35:54 --> Parser Class Initialized
DEBUG - 2017-04-22 11:35:54 --> Session Class Initialized
INFO - 2017-04-22 11:35:54 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:35:54 --> Session routines successfully run
INFO - 2017-04-22 11:35:54 --> Form Validation Class Initialized
INFO - 2017-04-22 11:35:54 --> Controller Class Initialized
INFO - 2017-04-22 11:35:54 --> Model Class Initialized
INFO - 2017-04-22 11:35:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-04-22 11:35:54 --> Config Class Initialized
INFO - 2017-04-22 11:35:54 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:35:54 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:35:54 --> Utf8 Class Initialized
INFO - 2017-04-22 11:35:54 --> URI Class Initialized
INFO - 2017-04-22 11:35:54 --> Router Class Initialized
INFO - 2017-04-22 11:35:54 --> Output Class Initialized
INFO - 2017-04-22 11:35:54 --> Security Class Initialized
DEBUG - 2017-04-22 11:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:35:54 --> Input Class Initialized
INFO - 2017-04-22 11:35:54 --> Language Class Initialized
INFO - 2017-04-22 11:35:54 --> Loader Class Initialized
INFO - 2017-04-22 11:35:54 --> Helper loaded: url_helper
INFO - 2017-04-22 11:35:54 --> Helper loaded: form_helper
INFO - 2017-04-22 11:35:54 --> Helper loaded: html_helper
INFO - 2017-04-22 11:35:54 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:35:54 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:35:54 --> Database Driver Class Initialized
INFO - 2017-04-22 11:35:54 --> Parser Class Initialized
DEBUG - 2017-04-22 11:35:54 --> Session Class Initialized
INFO - 2017-04-22 11:35:54 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:35:54 --> Session routines successfully run
INFO - 2017-04-22 11:35:54 --> Form Validation Class Initialized
INFO - 2017-04-22 11:35:54 --> Controller Class Initialized
DEBUG - 2017-04-22 11:35:54 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:35:54 --> Model Class Initialized
DEBUG - 2017-04-22 11:35:55 --> Pagination Class Initialized
INFO - 2017-04-22 11:35:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:35:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:35:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-22 11:35:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:35:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:35:55 --> Final output sent to browser
DEBUG - 2017-04-22 11:35:55 --> Total execution time: 0.4946
INFO - 2017-04-22 11:35:58 --> Config Class Initialized
INFO - 2017-04-22 11:35:58 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:35:58 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:35:58 --> Utf8 Class Initialized
INFO - 2017-04-22 11:35:58 --> URI Class Initialized
INFO - 2017-04-22 11:35:58 --> Router Class Initialized
INFO - 2017-04-22 11:35:58 --> Output Class Initialized
INFO - 2017-04-22 11:35:58 --> Security Class Initialized
DEBUG - 2017-04-22 11:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:35:58 --> Input Class Initialized
INFO - 2017-04-22 11:35:58 --> Language Class Initialized
INFO - 2017-04-22 11:35:58 --> Loader Class Initialized
INFO - 2017-04-22 11:35:58 --> Helper loaded: url_helper
INFO - 2017-04-22 11:35:58 --> Helper loaded: form_helper
INFO - 2017-04-22 11:35:58 --> Helper loaded: html_helper
INFO - 2017-04-22 11:35:58 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:35:58 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:35:58 --> Database Driver Class Initialized
INFO - 2017-04-22 11:35:58 --> Parser Class Initialized
DEBUG - 2017-04-22 11:35:58 --> Session Class Initialized
INFO - 2017-04-22 11:35:58 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:35:58 --> Session routines successfully run
INFO - 2017-04-22 11:35:58 --> Form Validation Class Initialized
INFO - 2017-04-22 11:35:58 --> Controller Class Initialized
DEBUG - 2017-04-22 11:35:58 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:35:58 --> Model Class Initialized
DEBUG - 2017-04-22 11:35:58 --> Pagination Class Initialized
INFO - 2017-04-22 11:35:58 --> Config Class Initialized
INFO - 2017-04-22 11:35:58 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:35:58 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:35:58 --> Utf8 Class Initialized
INFO - 2017-04-22 11:35:58 --> URI Class Initialized
INFO - 2017-04-22 11:35:58 --> Router Class Initialized
INFO - 2017-04-22 11:35:58 --> Output Class Initialized
INFO - 2017-04-22 11:35:58 --> Security Class Initialized
DEBUG - 2017-04-22 11:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:35:58 --> Input Class Initialized
INFO - 2017-04-22 11:35:58 --> Language Class Initialized
INFO - 2017-04-22 11:35:58 --> Loader Class Initialized
INFO - 2017-04-22 11:35:58 --> Helper loaded: url_helper
INFO - 2017-04-22 11:35:58 --> Helper loaded: form_helper
INFO - 2017-04-22 11:35:58 --> Helper loaded: html_helper
INFO - 2017-04-22 11:35:58 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:35:58 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:35:58 --> Database Driver Class Initialized
INFO - 2017-04-22 11:35:58 --> Parser Class Initialized
DEBUG - 2017-04-22 11:35:58 --> Session Class Initialized
INFO - 2017-04-22 11:35:58 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:35:58 --> Session routines successfully run
INFO - 2017-04-22 11:35:58 --> Form Validation Class Initialized
INFO - 2017-04-22 11:35:58 --> Controller Class Initialized
DEBUG - 2017-04-22 11:35:58 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:35:58 --> Model Class Initialized
DEBUG - 2017-04-22 11:35:58 --> Pagination Class Initialized
INFO - 2017-04-22 11:35:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:35:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:36:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:36:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:36:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:36:01 --> Final output sent to browser
DEBUG - 2017-04-22 11:36:01 --> Total execution time: 3.2564
INFO - 2017-04-22 11:36:06 --> Config Class Initialized
INFO - 2017-04-22 11:36:06 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:36:06 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:36:06 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:06 --> URI Class Initialized
INFO - 2017-04-22 11:36:06 --> Router Class Initialized
INFO - 2017-04-22 11:36:06 --> Output Class Initialized
INFO - 2017-04-22 11:36:06 --> Security Class Initialized
DEBUG - 2017-04-22 11:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:36:06 --> Input Class Initialized
INFO - 2017-04-22 11:36:06 --> Language Class Initialized
INFO - 2017-04-22 11:36:06 --> Loader Class Initialized
INFO - 2017-04-22 11:36:06 --> Helper loaded: url_helper
INFO - 2017-04-22 11:36:06 --> Helper loaded: form_helper
INFO - 2017-04-22 11:36:06 --> Helper loaded: html_helper
INFO - 2017-04-22 11:36:06 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:36:06 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:36:06 --> Database Driver Class Initialized
INFO - 2017-04-22 11:36:06 --> Parser Class Initialized
DEBUG - 2017-04-22 11:36:06 --> Session Class Initialized
INFO - 2017-04-22 11:36:06 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:36:06 --> Session routines successfully run
INFO - 2017-04-22 11:36:06 --> Form Validation Class Initialized
INFO - 2017-04-22 11:36:06 --> Controller Class Initialized
DEBUG - 2017-04-22 11:36:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:36:06 --> Model Class Initialized
DEBUG - 2017-04-22 11:36:06 --> Pagination Class Initialized
INFO - 2017-04-22 11:36:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:36:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:36:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:36:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:36:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:36:06 --> Final output sent to browser
DEBUG - 2017-04-22 11:36:06 --> Total execution time: 0.2927
INFO - 2017-04-22 11:36:07 --> Config Class Initialized
INFO - 2017-04-22 11:36:07 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:36:07 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:36:07 --> Config Class Initialized
INFO - 2017-04-22 11:36:07 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:07 --> Hooks Class Initialized
INFO - 2017-04-22 11:36:07 --> URI Class Initialized
DEBUG - 2017-04-22 11:36:07 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:36:07 --> Router Class Initialized
INFO - 2017-04-22 11:36:07 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:07 --> URI Class Initialized
INFO - 2017-04-22 11:36:07 --> Output Class Initialized
INFO - 2017-04-22 11:36:07 --> Router Class Initialized
INFO - 2017-04-22 11:36:07 --> Security Class Initialized
INFO - 2017-04-22 11:36:07 --> Output Class Initialized
DEBUG - 2017-04-22 11:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:36:07 --> Security Class Initialized
INFO - 2017-04-22 11:36:07 --> Input Class Initialized
INFO - 2017-04-22 11:36:07 --> Language Class Initialized
DEBUG - 2017-04-22 11:36:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-04-22 11:36:07 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:36:07 --> Input Class Initialized
INFO - 2017-04-22 11:36:07 --> Language Class Initialized
ERROR - 2017-04-22 11:36:07 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:36:07 --> Config Class Initialized
INFO - 2017-04-22 11:36:07 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:36:07 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:36:07 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:07 --> URI Class Initialized
INFO - 2017-04-22 11:36:07 --> Router Class Initialized
INFO - 2017-04-22 11:36:07 --> Output Class Initialized
INFO - 2017-04-22 11:36:07 --> Security Class Initialized
DEBUG - 2017-04-22 11:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:36:07 --> Input Class Initialized
INFO - 2017-04-22 11:36:07 --> Language Class Initialized
ERROR - 2017-04-22 11:36:07 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:36:07 --> Config Class Initialized
INFO - 2017-04-22 11:36:07 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:36:07 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:36:07 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:07 --> URI Class Initialized
INFO - 2017-04-22 11:36:07 --> Router Class Initialized
INFO - 2017-04-22 11:36:07 --> Output Class Initialized
INFO - 2017-04-22 11:36:07 --> Security Class Initialized
DEBUG - 2017-04-22 11:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:36:07 --> Input Class Initialized
INFO - 2017-04-22 11:36:07 --> Language Class Initialized
ERROR - 2017-04-22 11:36:07 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:36:12 --> Config Class Initialized
INFO - 2017-04-22 11:36:12 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:36:12 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:36:12 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:12 --> URI Class Initialized
INFO - 2017-04-22 11:36:12 --> Router Class Initialized
INFO - 2017-04-22 11:36:12 --> Output Class Initialized
INFO - 2017-04-22 11:36:12 --> Security Class Initialized
DEBUG - 2017-04-22 11:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:36:12 --> Input Class Initialized
INFO - 2017-04-22 11:36:12 --> Language Class Initialized
INFO - 2017-04-22 11:36:12 --> Loader Class Initialized
INFO - 2017-04-22 11:36:12 --> Helper loaded: url_helper
INFO - 2017-04-22 11:36:12 --> Helper loaded: form_helper
INFO - 2017-04-22 11:36:12 --> Helper loaded: html_helper
INFO - 2017-04-22 11:36:12 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:36:12 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:36:12 --> Database Driver Class Initialized
INFO - 2017-04-22 11:36:12 --> Parser Class Initialized
DEBUG - 2017-04-22 11:36:12 --> Session Class Initialized
INFO - 2017-04-22 11:36:12 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:36:12 --> Session routines successfully run
INFO - 2017-04-22 11:36:12 --> Form Validation Class Initialized
INFO - 2017-04-22 11:36:12 --> Controller Class Initialized
DEBUG - 2017-04-22 11:36:12 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:36:12 --> Model Class Initialized
DEBUG - 2017-04-22 11:36:12 --> Pagination Class Initialized
INFO - 2017-04-22 11:36:16 --> Config Class Initialized
INFO - 2017-04-22 11:36:16 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:36:16 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:36:16 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:16 --> URI Class Initialized
INFO - 2017-04-22 11:36:16 --> Router Class Initialized
INFO - 2017-04-22 11:36:16 --> Output Class Initialized
INFO - 2017-04-22 11:36:16 --> Security Class Initialized
DEBUG - 2017-04-22 11:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:36:16 --> Input Class Initialized
INFO - 2017-04-22 11:36:16 --> Language Class Initialized
INFO - 2017-04-22 11:36:16 --> Loader Class Initialized
INFO - 2017-04-22 11:36:16 --> Helper loaded: url_helper
INFO - 2017-04-22 11:36:16 --> Helper loaded: form_helper
INFO - 2017-04-22 11:36:16 --> Helper loaded: html_helper
INFO - 2017-04-22 11:36:16 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:36:16 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:36:16 --> Database Driver Class Initialized
INFO - 2017-04-22 11:36:16 --> Parser Class Initialized
DEBUG - 2017-04-22 11:36:16 --> Session Class Initialized
INFO - 2017-04-22 11:36:16 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:36:16 --> Session routines successfully run
INFO - 2017-04-22 11:36:16 --> Form Validation Class Initialized
INFO - 2017-04-22 11:36:16 --> Controller Class Initialized
DEBUG - 2017-04-22 11:36:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:36:16 --> Model Class Initialized
DEBUG - 2017-04-22 11:36:16 --> Pagination Class Initialized
INFO - 2017-04-22 11:36:19 --> Config Class Initialized
INFO - 2017-04-22 11:36:19 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:36:19 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:36:19 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:19 --> URI Class Initialized
INFO - 2017-04-22 11:36:19 --> Router Class Initialized
INFO - 2017-04-22 11:36:19 --> Output Class Initialized
INFO - 2017-04-22 11:36:19 --> Security Class Initialized
DEBUG - 2017-04-22 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:36:19 --> Input Class Initialized
INFO - 2017-04-22 11:36:19 --> Language Class Initialized
INFO - 2017-04-22 11:36:19 --> Loader Class Initialized
INFO - 2017-04-22 11:36:19 --> Helper loaded: url_helper
INFO - 2017-04-22 11:36:19 --> Helper loaded: form_helper
INFO - 2017-04-22 11:36:19 --> Helper loaded: html_helper
INFO - 2017-04-22 11:36:19 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:36:19 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:36:19 --> Database Driver Class Initialized
INFO - 2017-04-22 11:36:19 --> Parser Class Initialized
DEBUG - 2017-04-22 11:36:19 --> Session Class Initialized
INFO - 2017-04-22 11:36:19 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:36:19 --> Session routines successfully run
INFO - 2017-04-22 11:36:19 --> Form Validation Class Initialized
INFO - 2017-04-22 11:36:19 --> Controller Class Initialized
DEBUG - 2017-04-22 11:36:19 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:36:19 --> Model Class Initialized
DEBUG - 2017-04-22 11:36:19 --> Pagination Class Initialized
DEBUG - 2017-04-22 11:36:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-22 11:36:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-04-22 11:36:19 --> Could not find the language line "form_validation_company_email_check"
INFO - 2017-04-22 11:36:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:36:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-22 11:36:19 --> Severity: Notice --> Undefined variable: app_info C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 398
ERROR - 2017-04-22 11:36:19 --> Severity: Notice --> Undefined variable: app_info C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 412
ERROR - 2017-04-22 11:36:19 --> Severity: Notice --> Undefined variable: app_info C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 418
INFO - 2017-04-22 11:36:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:36:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:36:19 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:36:19 --> Final output sent to browser
DEBUG - 2017-04-22 11:36:19 --> Total execution time: 0.2485
INFO - 2017-04-22 11:36:19 --> Config Class Initialized
INFO - 2017-04-22 11:36:19 --> Config Class Initialized
INFO - 2017-04-22 11:36:19 --> Hooks Class Initialized
INFO - 2017-04-22 11:36:19 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:36:19 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:36:19 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:36:19 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:19 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:19 --> URI Class Initialized
INFO - 2017-04-22 11:36:19 --> URI Class Initialized
INFO - 2017-04-22 11:36:19 --> Router Class Initialized
INFO - 2017-04-22 11:36:19 --> Router Class Initialized
INFO - 2017-04-22 11:36:19 --> Output Class Initialized
INFO - 2017-04-22 11:36:19 --> Output Class Initialized
INFO - 2017-04-22 11:36:19 --> Security Class Initialized
INFO - 2017-04-22 11:36:19 --> Security Class Initialized
DEBUG - 2017-04-22 11:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-22 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:36:19 --> Input Class Initialized
INFO - 2017-04-22 11:36:19 --> Input Class Initialized
INFO - 2017-04-22 11:36:19 --> Language Class Initialized
INFO - 2017-04-22 11:36:19 --> Language Class Initialized
ERROR - 2017-04-22 11:36:19 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:36:19 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:36:19 --> Config Class Initialized
INFO - 2017-04-22 11:36:19 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:36:19 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:36:19 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:19 --> URI Class Initialized
INFO - 2017-04-22 11:36:19 --> Router Class Initialized
INFO - 2017-04-22 11:36:19 --> Output Class Initialized
INFO - 2017-04-22 11:36:19 --> Security Class Initialized
DEBUG - 2017-04-22 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:36:19 --> Input Class Initialized
INFO - 2017-04-22 11:36:19 --> Language Class Initialized
ERROR - 2017-04-22 11:36:19 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:36:19 --> Config Class Initialized
INFO - 2017-04-22 11:36:19 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:36:19 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:36:19 --> Utf8 Class Initialized
INFO - 2017-04-22 11:36:19 --> URI Class Initialized
INFO - 2017-04-22 11:36:19 --> Router Class Initialized
INFO - 2017-04-22 11:36:19 --> Output Class Initialized
INFO - 2017-04-22 11:36:19 --> Security Class Initialized
DEBUG - 2017-04-22 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:36:19 --> Input Class Initialized
INFO - 2017-04-22 11:36:19 --> Language Class Initialized
ERROR - 2017-04-22 11:36:19 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:37:58 --> Config Class Initialized
INFO - 2017-04-22 11:37:58 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:37:58 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:37:58 --> Utf8 Class Initialized
INFO - 2017-04-22 11:37:58 --> URI Class Initialized
INFO - 2017-04-22 11:37:58 --> Router Class Initialized
INFO - 2017-04-22 11:37:58 --> Output Class Initialized
INFO - 2017-04-22 11:37:58 --> Security Class Initialized
DEBUG - 2017-04-22 11:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:37:58 --> Input Class Initialized
INFO - 2017-04-22 11:37:58 --> Language Class Initialized
INFO - 2017-04-22 11:37:58 --> Loader Class Initialized
INFO - 2017-04-22 11:37:58 --> Helper loaded: url_helper
INFO - 2017-04-22 11:37:58 --> Helper loaded: form_helper
INFO - 2017-04-22 11:37:58 --> Helper loaded: html_helper
INFO - 2017-04-22 11:37:58 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:37:58 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:37:58 --> Database Driver Class Initialized
INFO - 2017-04-22 11:37:58 --> Parser Class Initialized
DEBUG - 2017-04-22 11:37:58 --> Session Class Initialized
INFO - 2017-04-22 11:37:58 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:37:58 --> Session routines successfully run
INFO - 2017-04-22 11:37:58 --> Form Validation Class Initialized
INFO - 2017-04-22 11:37:58 --> Controller Class Initialized
DEBUG - 2017-04-22 11:37:58 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:37:58 --> Model Class Initialized
DEBUG - 2017-04-22 11:37:58 --> Pagination Class Initialized
DEBUG - 2017-04-22 11:37:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-22 11:37:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-04-22 11:37:58 --> Could not find the language line "form_validation_company_email_check"
INFO - 2017-04-22 11:37:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:37:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-22 11:37:58 --> Severity: Notice --> Undefined variable: app_info C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 5
ERROR - 2017-04-22 11:37:58 --> Severity: Notice --> Undefined variable: app_info C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 412
ERROR - 2017-04-22 11:37:58 --> Severity: Notice --> Undefined variable: app_info C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 418
INFO - 2017-04-22 11:37:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:37:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:37:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:37:58 --> Final output sent to browser
DEBUG - 2017-04-22 11:37:58 --> Total execution time: 0.2562
INFO - 2017-04-22 11:37:59 --> Config Class Initialized
INFO - 2017-04-22 11:37:59 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:37:59 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:37:59 --> Utf8 Class Initialized
INFO - 2017-04-22 11:37:59 --> URI Class Initialized
INFO - 2017-04-22 11:37:59 --> Config Class Initialized
INFO - 2017-04-22 11:37:59 --> Hooks Class Initialized
INFO - 2017-04-22 11:37:59 --> Router Class Initialized
DEBUG - 2017-04-22 11:37:59 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:37:59 --> Output Class Initialized
INFO - 2017-04-22 11:37:59 --> Utf8 Class Initialized
INFO - 2017-04-22 11:37:59 --> URI Class Initialized
INFO - 2017-04-22 11:37:59 --> Security Class Initialized
INFO - 2017-04-22 11:37:59 --> Router Class Initialized
DEBUG - 2017-04-22 11:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:37:59 --> Output Class Initialized
INFO - 2017-04-22 11:37:59 --> Input Class Initialized
INFO - 2017-04-22 11:37:59 --> Language Class Initialized
INFO - 2017-04-22 11:37:59 --> Security Class Initialized
ERROR - 2017-04-22 11:37:59 --> 404 Page Not Found: Default/assets
DEBUG - 2017-04-22 11:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:37:59 --> Input Class Initialized
INFO - 2017-04-22 11:37:59 --> Language Class Initialized
ERROR - 2017-04-22 11:37:59 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:37:59 --> Config Class Initialized
INFO - 2017-04-22 11:37:59 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:37:59 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:37:59 --> Utf8 Class Initialized
INFO - 2017-04-22 11:37:59 --> URI Class Initialized
INFO - 2017-04-22 11:37:59 --> Router Class Initialized
INFO - 2017-04-22 11:37:59 --> Output Class Initialized
INFO - 2017-04-22 11:37:59 --> Security Class Initialized
DEBUG - 2017-04-22 11:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:37:59 --> Input Class Initialized
INFO - 2017-04-22 11:37:59 --> Language Class Initialized
ERROR - 2017-04-22 11:37:59 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:37:59 --> Config Class Initialized
INFO - 2017-04-22 11:37:59 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:37:59 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:37:59 --> Utf8 Class Initialized
INFO - 2017-04-22 11:37:59 --> URI Class Initialized
INFO - 2017-04-22 11:37:59 --> Router Class Initialized
INFO - 2017-04-22 11:37:59 --> Output Class Initialized
INFO - 2017-04-22 11:37:59 --> Security Class Initialized
DEBUG - 2017-04-22 11:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:37:59 --> Input Class Initialized
INFO - 2017-04-22 11:37:59 --> Language Class Initialized
ERROR - 2017-04-22 11:37:59 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:38:06 --> Config Class Initialized
INFO - 2017-04-22 11:38:06 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:38:06 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:38:06 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:06 --> URI Class Initialized
INFO - 2017-04-22 11:38:06 --> Router Class Initialized
INFO - 2017-04-22 11:38:06 --> Output Class Initialized
INFO - 2017-04-22 11:38:06 --> Security Class Initialized
DEBUG - 2017-04-22 11:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:38:06 --> Input Class Initialized
INFO - 2017-04-22 11:38:06 --> Language Class Initialized
INFO - 2017-04-22 11:38:06 --> Loader Class Initialized
INFO - 2017-04-22 11:38:06 --> Helper loaded: url_helper
INFO - 2017-04-22 11:38:06 --> Helper loaded: form_helper
INFO - 2017-04-22 11:38:06 --> Helper loaded: html_helper
INFO - 2017-04-22 11:38:06 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:38:06 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:38:06 --> Database Driver Class Initialized
INFO - 2017-04-22 11:38:06 --> Parser Class Initialized
DEBUG - 2017-04-22 11:38:06 --> Session Class Initialized
INFO - 2017-04-22 11:38:06 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:38:06 --> Session routines successfully run
INFO - 2017-04-22 11:38:06 --> Form Validation Class Initialized
INFO - 2017-04-22 11:38:06 --> Controller Class Initialized
DEBUG - 2017-04-22 11:38:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:38:06 --> Model Class Initialized
DEBUG - 2017-04-22 11:38:06 --> Pagination Class Initialized
INFO - 2017-04-22 11:38:06 --> Config Class Initialized
INFO - 2017-04-22 11:38:06 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:38:06 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:38:06 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:06 --> URI Class Initialized
INFO - 2017-04-22 11:38:06 --> Router Class Initialized
INFO - 2017-04-22 11:38:06 --> Output Class Initialized
INFO - 2017-04-22 11:38:06 --> Security Class Initialized
DEBUG - 2017-04-22 11:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:38:06 --> Input Class Initialized
INFO - 2017-04-22 11:38:06 --> Language Class Initialized
INFO - 2017-04-22 11:38:06 --> Loader Class Initialized
INFO - 2017-04-22 11:38:06 --> Helper loaded: url_helper
INFO - 2017-04-22 11:38:06 --> Helper loaded: form_helper
INFO - 2017-04-22 11:38:06 --> Helper loaded: html_helper
INFO - 2017-04-22 11:38:06 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:38:06 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:38:06 --> Database Driver Class Initialized
INFO - 2017-04-22 11:38:06 --> Parser Class Initialized
DEBUG - 2017-04-22 11:38:06 --> Session Class Initialized
INFO - 2017-04-22 11:38:06 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:38:06 --> Session routines successfully run
INFO - 2017-04-22 11:38:06 --> Form Validation Class Initialized
INFO - 2017-04-22 11:38:06 --> Controller Class Initialized
DEBUG - 2017-04-22 11:38:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:38:06 --> Model Class Initialized
DEBUG - 2017-04-22 11:38:06 --> Pagination Class Initialized
INFO - 2017-04-22 11:38:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:38:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:38:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:38:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:38:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:38:09 --> Final output sent to browser
DEBUG - 2017-04-22 11:38:09 --> Total execution time: 3.1598
INFO - 2017-04-22 11:38:13 --> Config Class Initialized
INFO - 2017-04-22 11:38:13 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:38:13 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:38:13 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:13 --> URI Class Initialized
INFO - 2017-04-22 11:38:13 --> Router Class Initialized
INFO - 2017-04-22 11:38:13 --> Output Class Initialized
INFO - 2017-04-22 11:38:13 --> Security Class Initialized
DEBUG - 2017-04-22 11:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:38:13 --> Input Class Initialized
INFO - 2017-04-22 11:38:13 --> Language Class Initialized
INFO - 2017-04-22 11:38:13 --> Loader Class Initialized
INFO - 2017-04-22 11:38:13 --> Helper loaded: url_helper
INFO - 2017-04-22 11:38:13 --> Helper loaded: form_helper
INFO - 2017-04-22 11:38:13 --> Helper loaded: html_helper
INFO - 2017-04-22 11:38:13 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:38:13 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:38:13 --> Database Driver Class Initialized
INFO - 2017-04-22 11:38:13 --> Parser Class Initialized
DEBUG - 2017-04-22 11:38:13 --> Session Class Initialized
INFO - 2017-04-22 11:38:13 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:38:13 --> Session routines successfully run
INFO - 2017-04-22 11:38:13 --> Form Validation Class Initialized
INFO - 2017-04-22 11:38:13 --> Controller Class Initialized
DEBUG - 2017-04-22 11:38:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:38:13 --> Model Class Initialized
DEBUG - 2017-04-22 11:38:13 --> Pagination Class Initialized
INFO - 2017-04-22 11:38:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:38:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:38:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:38:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:38:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:38:13 --> Final output sent to browser
DEBUG - 2017-04-22 11:38:13 --> Total execution time: 0.2182
INFO - 2017-04-22 11:38:13 --> Config Class Initialized
INFO - 2017-04-22 11:38:13 --> Config Class Initialized
INFO - 2017-04-22 11:38:13 --> Hooks Class Initialized
INFO - 2017-04-22 11:38:13 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:38:13 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:38:13 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:38:13 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:13 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:13 --> URI Class Initialized
INFO - 2017-04-22 11:38:13 --> URI Class Initialized
INFO - 2017-04-22 11:38:13 --> Router Class Initialized
INFO - 2017-04-22 11:38:13 --> Router Class Initialized
INFO - 2017-04-22 11:38:13 --> Output Class Initialized
INFO - 2017-04-22 11:38:13 --> Output Class Initialized
INFO - 2017-04-22 11:38:13 --> Security Class Initialized
INFO - 2017-04-22 11:38:13 --> Security Class Initialized
DEBUG - 2017-04-22 11:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-22 11:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:38:13 --> Input Class Initialized
INFO - 2017-04-22 11:38:13 --> Input Class Initialized
INFO - 2017-04-22 11:38:13 --> Language Class Initialized
INFO - 2017-04-22 11:38:13 --> Language Class Initialized
ERROR - 2017-04-22 11:38:13 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:38:13 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:38:13 --> Config Class Initialized
INFO - 2017-04-22 11:38:13 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:38:13 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:38:13 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:13 --> URI Class Initialized
INFO - 2017-04-22 11:38:13 --> Router Class Initialized
INFO - 2017-04-22 11:38:13 --> Output Class Initialized
INFO - 2017-04-22 11:38:13 --> Security Class Initialized
DEBUG - 2017-04-22 11:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:38:13 --> Input Class Initialized
INFO - 2017-04-22 11:38:13 --> Language Class Initialized
ERROR - 2017-04-22 11:38:13 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:38:13 --> Config Class Initialized
INFO - 2017-04-22 11:38:13 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:38:13 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:38:13 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:13 --> URI Class Initialized
INFO - 2017-04-22 11:38:13 --> Router Class Initialized
INFO - 2017-04-22 11:38:13 --> Output Class Initialized
INFO - 2017-04-22 11:38:13 --> Security Class Initialized
DEBUG - 2017-04-22 11:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:38:13 --> Input Class Initialized
INFO - 2017-04-22 11:38:13 --> Language Class Initialized
ERROR - 2017-04-22 11:38:13 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:38:16 --> Config Class Initialized
INFO - 2017-04-22 11:38:16 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:38:16 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:38:16 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:16 --> URI Class Initialized
INFO - 2017-04-22 11:38:16 --> Router Class Initialized
INFO - 2017-04-22 11:38:16 --> Output Class Initialized
INFO - 2017-04-22 11:38:16 --> Security Class Initialized
DEBUG - 2017-04-22 11:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:38:16 --> Input Class Initialized
INFO - 2017-04-22 11:38:16 --> Language Class Initialized
INFO - 2017-04-22 11:38:16 --> Loader Class Initialized
INFO - 2017-04-22 11:38:16 --> Helper loaded: url_helper
INFO - 2017-04-22 11:38:16 --> Helper loaded: form_helper
INFO - 2017-04-22 11:38:16 --> Helper loaded: html_helper
INFO - 2017-04-22 11:38:16 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:38:16 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:38:16 --> Database Driver Class Initialized
INFO - 2017-04-22 11:38:16 --> Parser Class Initialized
DEBUG - 2017-04-22 11:38:16 --> Session Class Initialized
INFO - 2017-04-22 11:38:16 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:38:16 --> Session routines successfully run
INFO - 2017-04-22 11:38:16 --> Form Validation Class Initialized
INFO - 2017-04-22 11:38:16 --> Controller Class Initialized
DEBUG - 2017-04-22 11:38:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:38:16 --> Model Class Initialized
DEBUG - 2017-04-22 11:38:16 --> Pagination Class Initialized
DEBUG - 2017-04-22 11:38:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-22 11:38:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-04-22 11:38:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:38:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-22 11:38:16 --> Severity: Notice --> Undefined variable: app_info C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 5
ERROR - 2017-04-22 11:38:16 --> Severity: Notice --> Undefined variable: app_info C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 412
ERROR - 2017-04-22 11:38:16 --> Severity: Notice --> Undefined variable: app_info C:\xampp\htdocs\schedullo\application\admin\views\default\layout\company\add_company.php 418
INFO - 2017-04-22 11:38:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:38:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:38:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:38:16 --> Final output sent to browser
DEBUG - 2017-04-22 11:38:16 --> Total execution time: 0.2393
INFO - 2017-04-22 11:38:16 --> Config Class Initialized
INFO - 2017-04-22 11:38:16 --> Config Class Initialized
INFO - 2017-04-22 11:38:16 --> Hooks Class Initialized
INFO - 2017-04-22 11:38:16 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:38:16 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:38:16 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:38:16 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:16 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:16 --> URI Class Initialized
INFO - 2017-04-22 11:38:16 --> URI Class Initialized
INFO - 2017-04-22 11:38:16 --> Router Class Initialized
INFO - 2017-04-22 11:38:16 --> Router Class Initialized
INFO - 2017-04-22 11:38:16 --> Output Class Initialized
INFO - 2017-04-22 11:38:16 --> Output Class Initialized
INFO - 2017-04-22 11:38:16 --> Security Class Initialized
INFO - 2017-04-22 11:38:16 --> Security Class Initialized
DEBUG - 2017-04-22 11:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-22 11:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:38:16 --> Input Class Initialized
INFO - 2017-04-22 11:38:16 --> Input Class Initialized
INFO - 2017-04-22 11:38:16 --> Language Class Initialized
INFO - 2017-04-22 11:38:16 --> Language Class Initialized
ERROR - 2017-04-22 11:38:16 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:38:16 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:38:16 --> Config Class Initialized
INFO - 2017-04-22 11:38:17 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:38:17 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:38:17 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:17 --> URI Class Initialized
INFO - 2017-04-22 11:38:17 --> Router Class Initialized
INFO - 2017-04-22 11:38:17 --> Output Class Initialized
INFO - 2017-04-22 11:38:17 --> Security Class Initialized
DEBUG - 2017-04-22 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:38:17 --> Input Class Initialized
INFO - 2017-04-22 11:38:17 --> Language Class Initialized
ERROR - 2017-04-22 11:38:17 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:38:17 --> Config Class Initialized
INFO - 2017-04-22 11:38:17 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:38:17 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:38:17 --> Utf8 Class Initialized
INFO - 2017-04-22 11:38:17 --> URI Class Initialized
INFO - 2017-04-22 11:38:17 --> Router Class Initialized
INFO - 2017-04-22 11:38:17 --> Output Class Initialized
INFO - 2017-04-22 11:38:17 --> Security Class Initialized
DEBUG - 2017-04-22 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:38:17 --> Input Class Initialized
INFO - 2017-04-22 11:38:17 --> Language Class Initialized
ERROR - 2017-04-22 11:38:17 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:39:48 --> Config Class Initialized
INFO - 2017-04-22 11:39:48 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:39:48 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:39:48 --> Utf8 Class Initialized
INFO - 2017-04-22 11:39:48 --> URI Class Initialized
INFO - 2017-04-22 11:39:48 --> Router Class Initialized
INFO - 2017-04-22 11:39:48 --> Output Class Initialized
INFO - 2017-04-22 11:39:48 --> Security Class Initialized
DEBUG - 2017-04-22 11:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:39:48 --> Input Class Initialized
INFO - 2017-04-22 11:39:48 --> Language Class Initialized
INFO - 2017-04-22 11:39:48 --> Loader Class Initialized
INFO - 2017-04-22 11:39:48 --> Helper loaded: url_helper
INFO - 2017-04-22 11:39:48 --> Helper loaded: form_helper
INFO - 2017-04-22 11:39:48 --> Helper loaded: html_helper
INFO - 2017-04-22 11:39:48 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:39:48 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:39:48 --> Database Driver Class Initialized
INFO - 2017-04-22 11:39:48 --> Parser Class Initialized
DEBUG - 2017-04-22 11:39:48 --> Session Class Initialized
INFO - 2017-04-22 11:39:48 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:39:48 --> Session routines successfully run
INFO - 2017-04-22 11:39:48 --> Form Validation Class Initialized
INFO - 2017-04-22 11:39:48 --> Controller Class Initialized
DEBUG - 2017-04-22 11:39:48 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:39:48 --> Model Class Initialized
DEBUG - 2017-04-22 11:39:48 --> Pagination Class Initialized
INFO - 2017-04-22 11:39:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:39:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:39:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:39:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:39:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:39:48 --> Final output sent to browser
DEBUG - 2017-04-22 11:39:48 --> Total execution time: 0.2222
INFO - 2017-04-22 11:39:48 --> Config Class Initialized
INFO - 2017-04-22 11:39:48 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:39:48 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:39:48 --> Utf8 Class Initialized
INFO - 2017-04-22 11:39:48 --> URI Class Initialized
INFO - 2017-04-22 11:39:48 --> Router Class Initialized
INFO - 2017-04-22 11:39:48 --> Output Class Initialized
INFO - 2017-04-22 11:39:48 --> Security Class Initialized
DEBUG - 2017-04-22 11:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:39:48 --> Input Class Initialized
INFO - 2017-04-22 11:39:48 --> Language Class Initialized
ERROR - 2017-04-22 11:39:48 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:43:17 --> Config Class Initialized
INFO - 2017-04-22 11:43:17 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:43:17 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:43:17 --> Utf8 Class Initialized
INFO - 2017-04-22 11:43:17 --> URI Class Initialized
INFO - 2017-04-22 11:43:17 --> Router Class Initialized
INFO - 2017-04-22 11:43:17 --> Output Class Initialized
INFO - 2017-04-22 11:43:17 --> Security Class Initialized
DEBUG - 2017-04-22 11:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:43:17 --> Input Class Initialized
INFO - 2017-04-22 11:43:17 --> Language Class Initialized
INFO - 2017-04-22 11:43:17 --> Loader Class Initialized
INFO - 2017-04-22 11:43:17 --> Helper loaded: url_helper
INFO - 2017-04-22 11:43:17 --> Helper loaded: form_helper
INFO - 2017-04-22 11:43:17 --> Helper loaded: html_helper
INFO - 2017-04-22 11:43:17 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:43:17 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:43:17 --> Database Driver Class Initialized
INFO - 2017-04-22 11:43:17 --> Parser Class Initialized
DEBUG - 2017-04-22 11:43:17 --> Session Class Initialized
INFO - 2017-04-22 11:43:17 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:43:17 --> Session routines successfully run
INFO - 2017-04-22 11:43:17 --> Form Validation Class Initialized
INFO - 2017-04-22 11:43:17 --> Controller Class Initialized
DEBUG - 2017-04-22 11:43:17 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:43:17 --> Model Class Initialized
DEBUG - 2017-04-22 11:43:17 --> Pagination Class Initialized
INFO - 2017-04-22 11:43:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:43:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:43:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:43:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:43:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:43:20 --> Final output sent to browser
DEBUG - 2017-04-22 11:43:20 --> Total execution time: 3.0942
INFO - 2017-04-22 11:43:29 --> Config Class Initialized
INFO - 2017-04-22 11:43:29 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:43:29 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:43:29 --> Utf8 Class Initialized
INFO - 2017-04-22 11:43:29 --> URI Class Initialized
INFO - 2017-04-22 11:43:29 --> Router Class Initialized
INFO - 2017-04-22 11:43:29 --> Output Class Initialized
INFO - 2017-04-22 11:43:29 --> Security Class Initialized
DEBUG - 2017-04-22 11:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:43:29 --> Input Class Initialized
INFO - 2017-04-22 11:43:29 --> Language Class Initialized
INFO - 2017-04-22 11:43:29 --> Loader Class Initialized
INFO - 2017-04-22 11:43:29 --> Helper loaded: url_helper
INFO - 2017-04-22 11:43:29 --> Helper loaded: form_helper
INFO - 2017-04-22 11:43:29 --> Helper loaded: html_helper
INFO - 2017-04-22 11:43:29 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:43:29 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:43:29 --> Database Driver Class Initialized
INFO - 2017-04-22 11:43:29 --> Parser Class Initialized
DEBUG - 2017-04-22 11:43:29 --> Session Class Initialized
INFO - 2017-04-22 11:43:29 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:43:29 --> Session routines successfully run
INFO - 2017-04-22 11:43:29 --> Form Validation Class Initialized
INFO - 2017-04-22 11:43:29 --> Controller Class Initialized
DEBUG - 2017-04-22 11:43:29 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:43:29 --> Model Class Initialized
DEBUG - 2017-04-22 11:43:29 --> Pagination Class Initialized
DEBUG - 2017-04-22 11:43:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-22 11:43:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:43:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:43:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:43:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:43:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:43:29 --> Final output sent to browser
DEBUG - 2017-04-22 11:43:30 --> Total execution time: 0.3045
INFO - 2017-04-22 11:43:30 --> Config Class Initialized
INFO - 2017-04-22 11:43:30 --> Config Class Initialized
INFO - 2017-04-22 11:43:30 --> Hooks Class Initialized
INFO - 2017-04-22 11:43:30 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:43:30 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:43:30 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:43:30 --> Utf8 Class Initialized
INFO - 2017-04-22 11:43:30 --> Utf8 Class Initialized
INFO - 2017-04-22 11:43:30 --> URI Class Initialized
INFO - 2017-04-22 11:43:30 --> URI Class Initialized
INFO - 2017-04-22 11:43:30 --> Router Class Initialized
INFO - 2017-04-22 11:43:30 --> Router Class Initialized
INFO - 2017-04-22 11:43:30 --> Output Class Initialized
INFO - 2017-04-22 11:43:30 --> Output Class Initialized
INFO - 2017-04-22 11:43:30 --> Security Class Initialized
INFO - 2017-04-22 11:43:30 --> Security Class Initialized
DEBUG - 2017-04-22 11:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:43:30 --> Input Class Initialized
DEBUG - 2017-04-22 11:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:43:30 --> Input Class Initialized
INFO - 2017-04-22 11:43:30 --> Language Class Initialized
INFO - 2017-04-22 11:43:30 --> Language Class Initialized
ERROR - 2017-04-22 11:43:30 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:43:30 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:43:30 --> Config Class Initialized
INFO - 2017-04-22 11:43:30 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:43:30 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:43:30 --> Utf8 Class Initialized
INFO - 2017-04-22 11:43:30 --> URI Class Initialized
INFO - 2017-04-22 11:43:30 --> Router Class Initialized
INFO - 2017-04-22 11:43:30 --> Output Class Initialized
INFO - 2017-04-22 11:43:30 --> Security Class Initialized
DEBUG - 2017-04-22 11:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:43:30 --> Input Class Initialized
INFO - 2017-04-22 11:43:30 --> Language Class Initialized
ERROR - 2017-04-22 11:43:30 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:43:30 --> Config Class Initialized
INFO - 2017-04-22 11:43:30 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:43:30 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:43:30 --> Utf8 Class Initialized
INFO - 2017-04-22 11:43:30 --> URI Class Initialized
INFO - 2017-04-22 11:43:30 --> Router Class Initialized
INFO - 2017-04-22 11:43:30 --> Output Class Initialized
INFO - 2017-04-22 11:43:30 --> Security Class Initialized
DEBUG - 2017-04-22 11:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:43:30 --> Input Class Initialized
INFO - 2017-04-22 11:43:30 --> Language Class Initialized
ERROR - 2017-04-22 11:43:30 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:43:45 --> Config Class Initialized
INFO - 2017-04-22 11:43:45 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:43:45 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:43:45 --> Utf8 Class Initialized
INFO - 2017-04-22 11:43:45 --> URI Class Initialized
INFO - 2017-04-22 11:43:45 --> Router Class Initialized
INFO - 2017-04-22 11:43:45 --> Output Class Initialized
INFO - 2017-04-22 11:43:45 --> Security Class Initialized
DEBUG - 2017-04-22 11:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:43:45 --> Input Class Initialized
INFO - 2017-04-22 11:43:45 --> Language Class Initialized
INFO - 2017-04-22 11:43:45 --> Loader Class Initialized
INFO - 2017-04-22 11:43:45 --> Helper loaded: url_helper
INFO - 2017-04-22 11:43:45 --> Helper loaded: form_helper
INFO - 2017-04-22 11:43:45 --> Helper loaded: html_helper
INFO - 2017-04-22 11:43:45 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:43:45 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:43:45 --> Database Driver Class Initialized
INFO - 2017-04-22 11:43:45 --> Parser Class Initialized
DEBUG - 2017-04-22 11:43:45 --> Session Class Initialized
INFO - 2017-04-22 11:43:45 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:43:45 --> Session routines successfully run
INFO - 2017-04-22 11:43:45 --> Form Validation Class Initialized
INFO - 2017-04-22 11:43:45 --> Controller Class Initialized
DEBUG - 2017-04-22 11:43:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:43:45 --> Model Class Initialized
DEBUG - 2017-04-22 11:43:45 --> Pagination Class Initialized
INFO - 2017-04-22 11:43:47 --> Config Class Initialized
INFO - 2017-04-22 11:43:47 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:43:47 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:43:47 --> Utf8 Class Initialized
INFO - 2017-04-22 11:43:47 --> URI Class Initialized
INFO - 2017-04-22 11:43:47 --> Router Class Initialized
INFO - 2017-04-22 11:43:47 --> Output Class Initialized
INFO - 2017-04-22 11:43:47 --> Security Class Initialized
DEBUG - 2017-04-22 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:43:47 --> Input Class Initialized
INFO - 2017-04-22 11:43:47 --> Language Class Initialized
INFO - 2017-04-22 11:43:47 --> Loader Class Initialized
INFO - 2017-04-22 11:43:47 --> Helper loaded: url_helper
INFO - 2017-04-22 11:43:47 --> Helper loaded: form_helper
INFO - 2017-04-22 11:43:47 --> Helper loaded: html_helper
INFO - 2017-04-22 11:43:47 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:43:47 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:43:47 --> Database Driver Class Initialized
INFO - 2017-04-22 11:43:47 --> Parser Class Initialized
DEBUG - 2017-04-22 11:43:47 --> Session Class Initialized
INFO - 2017-04-22 11:43:47 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:43:47 --> Session routines successfully run
INFO - 2017-04-22 11:43:47 --> Form Validation Class Initialized
INFO - 2017-04-22 11:43:47 --> Controller Class Initialized
DEBUG - 2017-04-22 11:43:47 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:43:47 --> Model Class Initialized
DEBUG - 2017-04-22 11:43:47 --> Pagination Class Initialized
INFO - 2017-04-22 11:43:51 --> Config Class Initialized
INFO - 2017-04-22 11:43:51 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:43:51 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:43:51 --> Utf8 Class Initialized
INFO - 2017-04-22 11:43:51 --> URI Class Initialized
INFO - 2017-04-22 11:43:51 --> Router Class Initialized
INFO - 2017-04-22 11:43:51 --> Output Class Initialized
INFO - 2017-04-22 11:43:51 --> Security Class Initialized
DEBUG - 2017-04-22 11:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:43:51 --> Input Class Initialized
INFO - 2017-04-22 11:43:51 --> Language Class Initialized
INFO - 2017-04-22 11:43:51 --> Loader Class Initialized
INFO - 2017-04-22 11:43:51 --> Helper loaded: url_helper
INFO - 2017-04-22 11:43:51 --> Helper loaded: form_helper
INFO - 2017-04-22 11:43:51 --> Helper loaded: html_helper
INFO - 2017-04-22 11:43:51 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:43:51 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:43:51 --> Database Driver Class Initialized
INFO - 2017-04-22 11:43:51 --> Parser Class Initialized
DEBUG - 2017-04-22 11:43:51 --> Session Class Initialized
INFO - 2017-04-22 11:43:51 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:43:51 --> Session routines successfully run
INFO - 2017-04-22 11:43:51 --> Form Validation Class Initialized
INFO - 2017-04-22 11:43:51 --> Controller Class Initialized
DEBUG - 2017-04-22 11:43:51 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:43:51 --> Model Class Initialized
DEBUG - 2017-04-22 11:43:51 --> Pagination Class Initialized
INFO - 2017-04-22 11:47:11 --> Config Class Initialized
INFO - 2017-04-22 11:47:11 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:11 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:11 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:11 --> URI Class Initialized
INFO - 2017-04-22 11:47:11 --> Router Class Initialized
INFO - 2017-04-22 11:47:11 --> Output Class Initialized
INFO - 2017-04-22 11:47:11 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:11 --> Input Class Initialized
INFO - 2017-04-22 11:47:11 --> Language Class Initialized
INFO - 2017-04-22 11:47:11 --> Loader Class Initialized
INFO - 2017-04-22 11:47:11 --> Helper loaded: url_helper
INFO - 2017-04-22 11:47:11 --> Helper loaded: form_helper
INFO - 2017-04-22 11:47:11 --> Helper loaded: html_helper
INFO - 2017-04-22 11:47:11 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:47:11 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:47:11 --> Database Driver Class Initialized
INFO - 2017-04-22 11:47:11 --> Parser Class Initialized
DEBUG - 2017-04-22 11:47:11 --> Session Class Initialized
INFO - 2017-04-22 11:47:11 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:47:11 --> Session routines successfully run
INFO - 2017-04-22 11:47:11 --> Form Validation Class Initialized
INFO - 2017-04-22 11:47:11 --> Controller Class Initialized
DEBUG - 2017-04-22 11:47:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:47:11 --> Model Class Initialized
DEBUG - 2017-04-22 11:47:11 --> Pagination Class Initialized
DEBUG - 2017-04-22 11:47:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-22 11:47:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:47:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:47:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:47:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:47:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:47:11 --> Final output sent to browser
DEBUG - 2017-04-22 11:47:11 --> Total execution time: 0.2524
INFO - 2017-04-22 11:47:12 --> Config Class Initialized
INFO - 2017-04-22 11:47:12 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:12 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:12 --> Config Class Initialized
INFO - 2017-04-22 11:47:12 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:12 --> Hooks Class Initialized
INFO - 2017-04-22 11:47:12 --> URI Class Initialized
DEBUG - 2017-04-22 11:47:12 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:12 --> Router Class Initialized
INFO - 2017-04-22 11:47:12 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:12 --> URI Class Initialized
INFO - 2017-04-22 11:47:12 --> Output Class Initialized
INFO - 2017-04-22 11:47:12 --> Router Class Initialized
INFO - 2017-04-22 11:47:12 --> Security Class Initialized
INFO - 2017-04-22 11:47:12 --> Output Class Initialized
DEBUG - 2017-04-22 11:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:12 --> Security Class Initialized
INFO - 2017-04-22 11:47:12 --> Input Class Initialized
INFO - 2017-04-22 11:47:12 --> Language Class Initialized
DEBUG - 2017-04-22 11:47:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-04-22 11:47:12 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:12 --> Input Class Initialized
INFO - 2017-04-22 11:47:12 --> Language Class Initialized
ERROR - 2017-04-22 11:47:12 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:12 --> Config Class Initialized
INFO - 2017-04-22 11:47:12 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:12 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:12 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:12 --> URI Class Initialized
INFO - 2017-04-22 11:47:12 --> Router Class Initialized
INFO - 2017-04-22 11:47:12 --> Output Class Initialized
INFO - 2017-04-22 11:47:12 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:12 --> Input Class Initialized
INFO - 2017-04-22 11:47:12 --> Language Class Initialized
ERROR - 2017-04-22 11:47:12 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:12 --> Config Class Initialized
INFO - 2017-04-22 11:47:12 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:12 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:12 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:12 --> URI Class Initialized
INFO - 2017-04-22 11:47:12 --> Router Class Initialized
INFO - 2017-04-22 11:47:12 --> Output Class Initialized
INFO - 2017-04-22 11:47:12 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:12 --> Input Class Initialized
INFO - 2017-04-22 11:47:12 --> Language Class Initialized
ERROR - 2017-04-22 11:47:12 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:16 --> Config Class Initialized
INFO - 2017-04-22 11:47:16 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:16 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:16 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:16 --> URI Class Initialized
INFO - 2017-04-22 11:47:16 --> Router Class Initialized
INFO - 2017-04-22 11:47:16 --> Output Class Initialized
INFO - 2017-04-22 11:47:16 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:16 --> Input Class Initialized
INFO - 2017-04-22 11:47:16 --> Language Class Initialized
INFO - 2017-04-22 11:47:16 --> Loader Class Initialized
INFO - 2017-04-22 11:47:16 --> Helper loaded: url_helper
INFO - 2017-04-22 11:47:16 --> Helper loaded: form_helper
INFO - 2017-04-22 11:47:16 --> Helper loaded: html_helper
INFO - 2017-04-22 11:47:16 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:47:16 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:47:16 --> Database Driver Class Initialized
INFO - 2017-04-22 11:47:16 --> Parser Class Initialized
DEBUG - 2017-04-22 11:47:16 --> Session Class Initialized
INFO - 2017-04-22 11:47:16 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:47:16 --> Session routines successfully run
INFO - 2017-04-22 11:47:16 --> Form Validation Class Initialized
INFO - 2017-04-22 11:47:16 --> Controller Class Initialized
DEBUG - 2017-04-22 11:47:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:47:16 --> Model Class Initialized
DEBUG - 2017-04-22 11:47:16 --> Pagination Class Initialized
INFO - 2017-04-22 11:47:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:47:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:47:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:47:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:47:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:47:16 --> Final output sent to browser
DEBUG - 2017-04-22 11:47:16 --> Total execution time: 0.2404
INFO - 2017-04-22 11:47:25 --> Config Class Initialized
INFO - 2017-04-22 11:47:25 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:25 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:25 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:25 --> URI Class Initialized
INFO - 2017-04-22 11:47:25 --> Router Class Initialized
INFO - 2017-04-22 11:47:25 --> Output Class Initialized
INFO - 2017-04-22 11:47:25 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:25 --> Input Class Initialized
INFO - 2017-04-22 11:47:25 --> Language Class Initialized
INFO - 2017-04-22 11:47:25 --> Loader Class Initialized
INFO - 2017-04-22 11:47:25 --> Helper loaded: url_helper
INFO - 2017-04-22 11:47:25 --> Helper loaded: form_helper
INFO - 2017-04-22 11:47:25 --> Helper loaded: html_helper
INFO - 2017-04-22 11:47:25 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:47:25 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:47:25 --> Database Driver Class Initialized
INFO - 2017-04-22 11:47:25 --> Parser Class Initialized
DEBUG - 2017-04-22 11:47:25 --> Session Class Initialized
INFO - 2017-04-22 11:47:25 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:47:25 --> Session routines successfully run
INFO - 2017-04-22 11:47:25 --> Form Validation Class Initialized
INFO - 2017-04-22 11:47:25 --> Controller Class Initialized
DEBUG - 2017-04-22 11:47:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:47:25 --> Model Class Initialized
DEBUG - 2017-04-22 11:47:25 --> Pagination Class Initialized
INFO - 2017-04-22 11:47:25 --> Config Class Initialized
INFO - 2017-04-22 11:47:25 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:25 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:25 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:25 --> URI Class Initialized
INFO - 2017-04-22 11:47:25 --> Router Class Initialized
INFO - 2017-04-22 11:47:25 --> Output Class Initialized
INFO - 2017-04-22 11:47:25 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:25 --> Input Class Initialized
INFO - 2017-04-22 11:47:25 --> Language Class Initialized
INFO - 2017-04-22 11:47:25 --> Loader Class Initialized
INFO - 2017-04-22 11:47:25 --> Helper loaded: url_helper
INFO - 2017-04-22 11:47:25 --> Helper loaded: form_helper
INFO - 2017-04-22 11:47:25 --> Helper loaded: html_helper
INFO - 2017-04-22 11:47:25 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:47:25 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:47:25 --> Database Driver Class Initialized
INFO - 2017-04-22 11:47:25 --> Parser Class Initialized
DEBUG - 2017-04-22 11:47:25 --> Session Class Initialized
INFO - 2017-04-22 11:47:25 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:47:25 --> Session routines successfully run
INFO - 2017-04-22 11:47:25 --> Form Validation Class Initialized
INFO - 2017-04-22 11:47:25 --> Controller Class Initialized
DEBUG - 2017-04-22 11:47:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:47:25 --> Model Class Initialized
DEBUG - 2017-04-22 11:47:25 --> Pagination Class Initialized
INFO - 2017-04-22 11:47:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:47:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:47:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:47:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:47:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:47:28 --> Final output sent to browser
DEBUG - 2017-04-22 11:47:29 --> Total execution time: 3.2100
INFO - 2017-04-22 11:47:33 --> Config Class Initialized
INFO - 2017-04-22 11:47:33 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:33 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:33 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:33 --> URI Class Initialized
INFO - 2017-04-22 11:47:33 --> Router Class Initialized
INFO - 2017-04-22 11:47:33 --> Output Class Initialized
INFO - 2017-04-22 11:47:33 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:33 --> Input Class Initialized
INFO - 2017-04-22 11:47:33 --> Language Class Initialized
INFO - 2017-04-22 11:47:33 --> Loader Class Initialized
INFO - 2017-04-22 11:47:33 --> Helper loaded: url_helper
INFO - 2017-04-22 11:47:33 --> Helper loaded: form_helper
INFO - 2017-04-22 11:47:33 --> Helper loaded: html_helper
INFO - 2017-04-22 11:47:33 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:47:33 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:47:33 --> Database Driver Class Initialized
INFO - 2017-04-22 11:47:34 --> Parser Class Initialized
DEBUG - 2017-04-22 11:47:34 --> Session Class Initialized
INFO - 2017-04-22 11:47:34 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:47:34 --> Session routines successfully run
INFO - 2017-04-22 11:47:34 --> Form Validation Class Initialized
INFO - 2017-04-22 11:47:34 --> Controller Class Initialized
DEBUG - 2017-04-22 11:47:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:47:34 --> Model Class Initialized
DEBUG - 2017-04-22 11:47:34 --> Pagination Class Initialized
INFO - 2017-04-22 11:47:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:47:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:47:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:47:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:47:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:47:34 --> Final output sent to browser
DEBUG - 2017-04-22 11:47:34 --> Total execution time: 0.2403
INFO - 2017-04-22 11:47:34 --> Config Class Initialized
INFO - 2017-04-22 11:47:34 --> Config Class Initialized
INFO - 2017-04-22 11:47:34 --> Hooks Class Initialized
INFO - 2017-04-22 11:47:34 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:34 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:47:34 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:34 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:34 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:34 --> URI Class Initialized
INFO - 2017-04-22 11:47:34 --> URI Class Initialized
INFO - 2017-04-22 11:47:34 --> Router Class Initialized
INFO - 2017-04-22 11:47:34 --> Router Class Initialized
INFO - 2017-04-22 11:47:34 --> Output Class Initialized
INFO - 2017-04-22 11:47:34 --> Output Class Initialized
INFO - 2017-04-22 11:47:34 --> Security Class Initialized
INFO - 2017-04-22 11:47:34 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:34 --> Input Class Initialized
INFO - 2017-04-22 11:47:34 --> Language Class Initialized
DEBUG - 2017-04-22 11:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-04-22 11:47:34 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:34 --> Input Class Initialized
INFO - 2017-04-22 11:47:34 --> Language Class Initialized
ERROR - 2017-04-22 11:47:34 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:34 --> Config Class Initialized
INFO - 2017-04-22 11:47:34 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:34 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:34 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:34 --> URI Class Initialized
INFO - 2017-04-22 11:47:34 --> Router Class Initialized
INFO - 2017-04-22 11:47:34 --> Output Class Initialized
INFO - 2017-04-22 11:47:34 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:34 --> Input Class Initialized
INFO - 2017-04-22 11:47:34 --> Language Class Initialized
ERROR - 2017-04-22 11:47:34 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:34 --> Config Class Initialized
INFO - 2017-04-22 11:47:34 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:34 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:34 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:34 --> URI Class Initialized
INFO - 2017-04-22 11:47:34 --> Router Class Initialized
INFO - 2017-04-22 11:47:34 --> Output Class Initialized
INFO - 2017-04-22 11:47:34 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:34 --> Input Class Initialized
INFO - 2017-04-22 11:47:34 --> Language Class Initialized
ERROR - 2017-04-22 11:47:34 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:42 --> Config Class Initialized
INFO - 2017-04-22 11:47:42 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:42 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:42 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:42 --> URI Class Initialized
INFO - 2017-04-22 11:47:42 --> Router Class Initialized
INFO - 2017-04-22 11:47:42 --> Output Class Initialized
INFO - 2017-04-22 11:47:42 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:42 --> Input Class Initialized
INFO - 2017-04-22 11:47:42 --> Language Class Initialized
INFO - 2017-04-22 11:47:42 --> Loader Class Initialized
INFO - 2017-04-22 11:47:42 --> Helper loaded: url_helper
INFO - 2017-04-22 11:47:42 --> Helper loaded: form_helper
INFO - 2017-04-22 11:47:42 --> Helper loaded: html_helper
INFO - 2017-04-22 11:47:42 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:47:42 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:47:42 --> Database Driver Class Initialized
INFO - 2017-04-22 11:47:42 --> Parser Class Initialized
DEBUG - 2017-04-22 11:47:42 --> Session Class Initialized
INFO - 2017-04-22 11:47:42 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:47:42 --> Session routines successfully run
INFO - 2017-04-22 11:47:42 --> Form Validation Class Initialized
INFO - 2017-04-22 11:47:42 --> Controller Class Initialized
DEBUG - 2017-04-22 11:47:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:47:42 --> Model Class Initialized
DEBUG - 2017-04-22 11:47:42 --> Pagination Class Initialized
DEBUG - 2017-04-22 11:47:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-22 11:47:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-04-22 11:47:42 --> Could not find the language line "form_validation_company_email_check"
INFO - 2017-04-22 11:47:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:47:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:47:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:47:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:47:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:47:42 --> Final output sent to browser
DEBUG - 2017-04-22 11:47:42 --> Total execution time: 0.2717
INFO - 2017-04-22 11:47:42 --> Config Class Initialized
INFO - 2017-04-22 11:47:42 --> Hooks Class Initialized
INFO - 2017-04-22 11:47:42 --> Config Class Initialized
INFO - 2017-04-22 11:47:42 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:42 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:47:42 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:42 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:42 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:42 --> URI Class Initialized
INFO - 2017-04-22 11:47:42 --> URI Class Initialized
INFO - 2017-04-22 11:47:42 --> Router Class Initialized
INFO - 2017-04-22 11:47:42 --> Router Class Initialized
INFO - 2017-04-22 11:47:42 --> Output Class Initialized
INFO - 2017-04-22 11:47:42 --> Output Class Initialized
INFO - 2017-04-22 11:47:42 --> Security Class Initialized
INFO - 2017-04-22 11:47:42 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-22 11:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:42 --> Input Class Initialized
INFO - 2017-04-22 11:47:42 --> Input Class Initialized
INFO - 2017-04-22 11:47:42 --> Language Class Initialized
INFO - 2017-04-22 11:47:42 --> Language Class Initialized
ERROR - 2017-04-22 11:47:42 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:47:42 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:42 --> Config Class Initialized
INFO - 2017-04-22 11:47:42 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:42 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:42 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:42 --> URI Class Initialized
INFO - 2017-04-22 11:47:42 --> Router Class Initialized
INFO - 2017-04-22 11:47:42 --> Output Class Initialized
INFO - 2017-04-22 11:47:42 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:42 --> Input Class Initialized
INFO - 2017-04-22 11:47:42 --> Language Class Initialized
ERROR - 2017-04-22 11:47:42 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:42 --> Config Class Initialized
INFO - 2017-04-22 11:47:42 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:42 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:42 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:42 --> URI Class Initialized
INFO - 2017-04-22 11:47:42 --> Router Class Initialized
INFO - 2017-04-22 11:47:42 --> Output Class Initialized
INFO - 2017-04-22 11:47:42 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:42 --> Input Class Initialized
INFO - 2017-04-22 11:47:42 --> Language Class Initialized
ERROR - 2017-04-22 11:47:42 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:52 --> Config Class Initialized
INFO - 2017-04-22 11:47:52 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:52 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:52 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:52 --> URI Class Initialized
INFO - 2017-04-22 11:47:52 --> Router Class Initialized
INFO - 2017-04-22 11:47:52 --> Output Class Initialized
INFO - 2017-04-22 11:47:52 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:52 --> Input Class Initialized
INFO - 2017-04-22 11:47:52 --> Language Class Initialized
INFO - 2017-04-22 11:47:52 --> Loader Class Initialized
INFO - 2017-04-22 11:47:52 --> Helper loaded: url_helper
INFO - 2017-04-22 11:47:52 --> Helper loaded: form_helper
INFO - 2017-04-22 11:47:52 --> Helper loaded: html_helper
INFO - 2017-04-22 11:47:52 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:47:52 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:47:52 --> Database Driver Class Initialized
INFO - 2017-04-22 11:47:52 --> Parser Class Initialized
DEBUG - 2017-04-22 11:47:52 --> Session Class Initialized
INFO - 2017-04-22 11:47:52 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:47:52 --> Session routines successfully run
INFO - 2017-04-22 11:47:52 --> Form Validation Class Initialized
INFO - 2017-04-22 11:47:52 --> Controller Class Initialized
DEBUG - 2017-04-22 11:47:52 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:47:52 --> Model Class Initialized
DEBUG - 2017-04-22 11:47:52 --> Pagination Class Initialized
INFO - 2017-04-22 11:47:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:47:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:47:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:47:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:47:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:47:55 --> Final output sent to browser
DEBUG - 2017-04-22 11:47:55 --> Total execution time: 3.0934
INFO - 2017-04-22 11:47:58 --> Config Class Initialized
INFO - 2017-04-22 11:47:58 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:58 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:58 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:58 --> URI Class Initialized
INFO - 2017-04-22 11:47:58 --> Router Class Initialized
INFO - 2017-04-22 11:47:58 --> Output Class Initialized
INFO - 2017-04-22 11:47:58 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:58 --> Input Class Initialized
INFO - 2017-04-22 11:47:58 --> Language Class Initialized
INFO - 2017-04-22 11:47:58 --> Loader Class Initialized
INFO - 2017-04-22 11:47:58 --> Helper loaded: url_helper
INFO - 2017-04-22 11:47:58 --> Helper loaded: form_helper
INFO - 2017-04-22 11:47:58 --> Helper loaded: html_helper
INFO - 2017-04-22 11:47:58 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:47:58 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:47:58 --> Database Driver Class Initialized
INFO - 2017-04-22 11:47:58 --> Parser Class Initialized
DEBUG - 2017-04-22 11:47:58 --> Session Class Initialized
INFO - 2017-04-22 11:47:58 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:47:58 --> Session routines successfully run
INFO - 2017-04-22 11:47:58 --> Form Validation Class Initialized
INFO - 2017-04-22 11:47:58 --> Controller Class Initialized
DEBUG - 2017-04-22 11:47:59 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:47:59 --> Model Class Initialized
DEBUG - 2017-04-22 11:47:59 --> Pagination Class Initialized
INFO - 2017-04-22 11:47:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:47:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:47:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:47:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:47:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:47:59 --> Final output sent to browser
DEBUG - 2017-04-22 11:47:59 --> Total execution time: 0.2310
INFO - 2017-04-22 11:47:59 --> Config Class Initialized
INFO - 2017-04-22 11:47:59 --> Config Class Initialized
INFO - 2017-04-22 11:47:59 --> Hooks Class Initialized
INFO - 2017-04-22 11:47:59 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:59 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:47:59 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:59 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:59 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:59 --> URI Class Initialized
INFO - 2017-04-22 11:47:59 --> URI Class Initialized
INFO - 2017-04-22 11:47:59 --> Router Class Initialized
INFO - 2017-04-22 11:47:59 --> Router Class Initialized
INFO - 2017-04-22 11:47:59 --> Output Class Initialized
INFO - 2017-04-22 11:47:59 --> Output Class Initialized
INFO - 2017-04-22 11:47:59 --> Security Class Initialized
INFO - 2017-04-22 11:47:59 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:59 --> Input Class Initialized
DEBUG - 2017-04-22 11:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:59 --> Input Class Initialized
INFO - 2017-04-22 11:47:59 --> Language Class Initialized
INFO - 2017-04-22 11:47:59 --> Language Class Initialized
ERROR - 2017-04-22 11:47:59 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:47:59 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:59 --> Config Class Initialized
INFO - 2017-04-22 11:47:59 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:59 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:59 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:59 --> URI Class Initialized
INFO - 2017-04-22 11:47:59 --> Router Class Initialized
INFO - 2017-04-22 11:47:59 --> Output Class Initialized
INFO - 2017-04-22 11:47:59 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:59 --> Input Class Initialized
INFO - 2017-04-22 11:47:59 --> Language Class Initialized
ERROR - 2017-04-22 11:47:59 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:47:59 --> Config Class Initialized
INFO - 2017-04-22 11:47:59 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:47:59 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:47:59 --> Utf8 Class Initialized
INFO - 2017-04-22 11:47:59 --> URI Class Initialized
INFO - 2017-04-22 11:47:59 --> Router Class Initialized
INFO - 2017-04-22 11:47:59 --> Output Class Initialized
INFO - 2017-04-22 11:47:59 --> Security Class Initialized
DEBUG - 2017-04-22 11:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:47:59 --> Input Class Initialized
INFO - 2017-04-22 11:47:59 --> Language Class Initialized
ERROR - 2017-04-22 11:47:59 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:02 --> Config Class Initialized
INFO - 2017-04-22 11:48:02 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:02 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:02 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:02 --> URI Class Initialized
INFO - 2017-04-22 11:48:02 --> Router Class Initialized
INFO - 2017-04-22 11:48:02 --> Output Class Initialized
INFO - 2017-04-22 11:48:02 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:02 --> Input Class Initialized
INFO - 2017-04-22 11:48:02 --> Language Class Initialized
INFO - 2017-04-22 11:48:02 --> Loader Class Initialized
INFO - 2017-04-22 11:48:02 --> Helper loaded: url_helper
INFO - 2017-04-22 11:48:02 --> Helper loaded: form_helper
INFO - 2017-04-22 11:48:02 --> Helper loaded: html_helper
INFO - 2017-04-22 11:48:02 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:48:02 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:48:02 --> Database Driver Class Initialized
INFO - 2017-04-22 11:48:02 --> Parser Class Initialized
DEBUG - 2017-04-22 11:48:02 --> Session Class Initialized
INFO - 2017-04-22 11:48:02 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:48:02 --> Session routines successfully run
INFO - 2017-04-22 11:48:02 --> Form Validation Class Initialized
INFO - 2017-04-22 11:48:02 --> Controller Class Initialized
DEBUG - 2017-04-22 11:48:02 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:48:02 --> Model Class Initialized
DEBUG - 2017-04-22 11:48:02 --> Pagination Class Initialized
DEBUG - 2017-04-22 11:48:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-22 11:48:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-04-22 11:48:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:48:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:48:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:48:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:48:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:48:02 --> Final output sent to browser
DEBUG - 2017-04-22 11:48:02 --> Total execution time: 0.2483
INFO - 2017-04-22 11:48:02 --> Config Class Initialized
INFO - 2017-04-22 11:48:02 --> Config Class Initialized
INFO - 2017-04-22 11:48:02 --> Hooks Class Initialized
INFO - 2017-04-22 11:48:02 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:02 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:48:02 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:02 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:02 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:02 --> URI Class Initialized
INFO - 2017-04-22 11:48:02 --> URI Class Initialized
INFO - 2017-04-22 11:48:02 --> Router Class Initialized
INFO - 2017-04-22 11:48:02 --> Router Class Initialized
INFO - 2017-04-22 11:48:02 --> Output Class Initialized
INFO - 2017-04-22 11:48:02 --> Output Class Initialized
INFO - 2017-04-22 11:48:02 --> Security Class Initialized
INFO - 2017-04-22 11:48:02 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-22 11:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:03 --> Input Class Initialized
INFO - 2017-04-22 11:48:03 --> Input Class Initialized
INFO - 2017-04-22 11:48:03 --> Language Class Initialized
INFO - 2017-04-22 11:48:03 --> Language Class Initialized
ERROR - 2017-04-22 11:48:03 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:48:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:03 --> Config Class Initialized
INFO - 2017-04-22 11:48:03 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:03 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:03 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:03 --> URI Class Initialized
INFO - 2017-04-22 11:48:03 --> Router Class Initialized
INFO - 2017-04-22 11:48:03 --> Output Class Initialized
INFO - 2017-04-22 11:48:03 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:03 --> Input Class Initialized
INFO - 2017-04-22 11:48:03 --> Language Class Initialized
ERROR - 2017-04-22 11:48:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:03 --> Config Class Initialized
INFO - 2017-04-22 11:48:03 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:03 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:03 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:03 --> URI Class Initialized
INFO - 2017-04-22 11:48:03 --> Router Class Initialized
INFO - 2017-04-22 11:48:03 --> Output Class Initialized
INFO - 2017-04-22 11:48:03 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:03 --> Input Class Initialized
INFO - 2017-04-22 11:48:03 --> Language Class Initialized
ERROR - 2017-04-22 11:48:03 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:10 --> Config Class Initialized
INFO - 2017-04-22 11:48:10 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:10 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:10 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:10 --> URI Class Initialized
INFO - 2017-04-22 11:48:10 --> Router Class Initialized
INFO - 2017-04-22 11:48:10 --> Output Class Initialized
INFO - 2017-04-22 11:48:10 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:10 --> Input Class Initialized
INFO - 2017-04-22 11:48:10 --> Language Class Initialized
INFO - 2017-04-22 11:48:10 --> Loader Class Initialized
INFO - 2017-04-22 11:48:10 --> Helper loaded: url_helper
INFO - 2017-04-22 11:48:10 --> Helper loaded: form_helper
INFO - 2017-04-22 11:48:10 --> Helper loaded: html_helper
INFO - 2017-04-22 11:48:10 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:48:10 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:48:10 --> Database Driver Class Initialized
INFO - 2017-04-22 11:48:10 --> Parser Class Initialized
DEBUG - 2017-04-22 11:48:10 --> Session Class Initialized
INFO - 2017-04-22 11:48:10 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:48:10 --> Session routines successfully run
INFO - 2017-04-22 11:48:10 --> Form Validation Class Initialized
INFO - 2017-04-22 11:48:10 --> Controller Class Initialized
DEBUG - 2017-04-22 11:48:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:48:10 --> Model Class Initialized
DEBUG - 2017-04-22 11:48:10 --> Pagination Class Initialized
INFO - 2017-04-22 11:48:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:48:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:48:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:48:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:48:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:48:13 --> Final output sent to browser
DEBUG - 2017-04-22 11:48:13 --> Total execution time: 3.0343
INFO - 2017-04-22 11:48:17 --> Config Class Initialized
INFO - 2017-04-22 11:48:17 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:17 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:17 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:17 --> URI Class Initialized
INFO - 2017-04-22 11:48:17 --> Router Class Initialized
INFO - 2017-04-22 11:48:17 --> Output Class Initialized
INFO - 2017-04-22 11:48:17 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:17 --> Input Class Initialized
INFO - 2017-04-22 11:48:17 --> Language Class Initialized
INFO - 2017-04-22 11:48:17 --> Loader Class Initialized
INFO - 2017-04-22 11:48:17 --> Helper loaded: url_helper
INFO - 2017-04-22 11:48:17 --> Helper loaded: form_helper
INFO - 2017-04-22 11:48:17 --> Helper loaded: html_helper
INFO - 2017-04-22 11:48:17 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:48:17 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:48:17 --> Database Driver Class Initialized
INFO - 2017-04-22 11:48:17 --> Parser Class Initialized
DEBUG - 2017-04-22 11:48:17 --> Session Class Initialized
INFO - 2017-04-22 11:48:17 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:48:17 --> Session routines successfully run
INFO - 2017-04-22 11:48:17 --> Form Validation Class Initialized
INFO - 2017-04-22 11:48:17 --> Controller Class Initialized
DEBUG - 2017-04-22 11:48:17 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:48:17 --> Model Class Initialized
DEBUG - 2017-04-22 11:48:17 --> Pagination Class Initialized
DEBUG - 2017-04-22 11:48:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-22 11:48:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:48:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:48:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:48:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:48:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:48:17 --> Final output sent to browser
DEBUG - 2017-04-22 11:48:17 --> Total execution time: 0.2571
INFO - 2017-04-22 11:48:17 --> Config Class Initialized
INFO - 2017-04-22 11:48:17 --> Hooks Class Initialized
INFO - 2017-04-22 11:48:17 --> Config Class Initialized
DEBUG - 2017-04-22 11:48:17 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:17 --> Hooks Class Initialized
INFO - 2017-04-22 11:48:17 --> Utf8 Class Initialized
DEBUG - 2017-04-22 11:48:17 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:17 --> URI Class Initialized
INFO - 2017-04-22 11:48:17 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:17 --> URI Class Initialized
INFO - 2017-04-22 11:48:17 --> Router Class Initialized
INFO - 2017-04-22 11:48:17 --> Router Class Initialized
INFO - 2017-04-22 11:48:17 --> Output Class Initialized
INFO - 2017-04-22 11:48:17 --> Output Class Initialized
INFO - 2017-04-22 11:48:17 --> Security Class Initialized
INFO - 2017-04-22 11:48:17 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-22 11:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:17 --> Input Class Initialized
INFO - 2017-04-22 11:48:17 --> Input Class Initialized
INFO - 2017-04-22 11:48:17 --> Language Class Initialized
INFO - 2017-04-22 11:48:17 --> Language Class Initialized
ERROR - 2017-04-22 11:48:17 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:48:17 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:17 --> Config Class Initialized
INFO - 2017-04-22 11:48:17 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:17 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:17 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:17 --> URI Class Initialized
INFO - 2017-04-22 11:48:17 --> Router Class Initialized
INFO - 2017-04-22 11:48:17 --> Output Class Initialized
INFO - 2017-04-22 11:48:17 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:17 --> Input Class Initialized
INFO - 2017-04-22 11:48:17 --> Language Class Initialized
ERROR - 2017-04-22 11:48:17 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:17 --> Config Class Initialized
INFO - 2017-04-22 11:48:17 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:17 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:17 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:17 --> URI Class Initialized
INFO - 2017-04-22 11:48:17 --> Router Class Initialized
INFO - 2017-04-22 11:48:17 --> Output Class Initialized
INFO - 2017-04-22 11:48:17 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:17 --> Input Class Initialized
INFO - 2017-04-22 11:48:17 --> Language Class Initialized
ERROR - 2017-04-22 11:48:17 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:19 --> Config Class Initialized
INFO - 2017-04-22 11:48:19 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:19 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:19 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:19 --> URI Class Initialized
INFO - 2017-04-22 11:48:19 --> Router Class Initialized
INFO - 2017-04-22 11:48:19 --> Output Class Initialized
INFO - 2017-04-22 11:48:19 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:19 --> Input Class Initialized
INFO - 2017-04-22 11:48:19 --> Language Class Initialized
INFO - 2017-04-22 11:48:20 --> Loader Class Initialized
INFO - 2017-04-22 11:48:20 --> Helper loaded: url_helper
INFO - 2017-04-22 11:48:20 --> Helper loaded: form_helper
INFO - 2017-04-22 11:48:20 --> Helper loaded: html_helper
INFO - 2017-04-22 11:48:20 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:48:20 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:48:20 --> Database Driver Class Initialized
INFO - 2017-04-22 11:48:20 --> Parser Class Initialized
DEBUG - 2017-04-22 11:48:20 --> Session Class Initialized
INFO - 2017-04-22 11:48:20 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:48:20 --> Session routines successfully run
INFO - 2017-04-22 11:48:20 --> Form Validation Class Initialized
INFO - 2017-04-22 11:48:20 --> Controller Class Initialized
DEBUG - 2017-04-22 11:48:20 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:48:20 --> Model Class Initialized
DEBUG - 2017-04-22 11:48:20 --> Pagination Class Initialized
DEBUG - 2017-04-22 11:48:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-22 11:48:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-04-22 11:48:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:48:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:48:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:48:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:48:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:48:20 --> Final output sent to browser
DEBUG - 2017-04-22 11:48:20 --> Total execution time: 0.2588
INFO - 2017-04-22 11:48:20 --> Config Class Initialized
INFO - 2017-04-22 11:48:20 --> Config Class Initialized
INFO - 2017-04-22 11:48:20 --> Hooks Class Initialized
INFO - 2017-04-22 11:48:20 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:20 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:48:20 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:20 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:20 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:20 --> URI Class Initialized
INFO - 2017-04-22 11:48:20 --> URI Class Initialized
INFO - 2017-04-22 11:48:20 --> Router Class Initialized
INFO - 2017-04-22 11:48:20 --> Router Class Initialized
INFO - 2017-04-22 11:48:20 --> Output Class Initialized
INFO - 2017-04-22 11:48:20 --> Output Class Initialized
INFO - 2017-04-22 11:48:20 --> Security Class Initialized
INFO - 2017-04-22 11:48:20 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-22 11:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:20 --> Input Class Initialized
INFO - 2017-04-22 11:48:20 --> Input Class Initialized
INFO - 2017-04-22 11:48:20 --> Language Class Initialized
INFO - 2017-04-22 11:48:20 --> Language Class Initialized
ERROR - 2017-04-22 11:48:20 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:48:20 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:20 --> Config Class Initialized
INFO - 2017-04-22 11:48:20 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:20 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:20 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:20 --> URI Class Initialized
INFO - 2017-04-22 11:48:20 --> Router Class Initialized
INFO - 2017-04-22 11:48:20 --> Output Class Initialized
INFO - 2017-04-22 11:48:20 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:20 --> Input Class Initialized
INFO - 2017-04-22 11:48:20 --> Language Class Initialized
ERROR - 2017-04-22 11:48:20 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:20 --> Config Class Initialized
INFO - 2017-04-22 11:48:20 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:20 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:20 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:20 --> URI Class Initialized
INFO - 2017-04-22 11:48:20 --> Router Class Initialized
INFO - 2017-04-22 11:48:20 --> Output Class Initialized
INFO - 2017-04-22 11:48:20 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:20 --> Input Class Initialized
INFO - 2017-04-22 11:48:20 --> Language Class Initialized
ERROR - 2017-04-22 11:48:20 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:23 --> Config Class Initialized
INFO - 2017-04-22 11:48:23 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:23 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:23 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:23 --> URI Class Initialized
INFO - 2017-04-22 11:48:23 --> Router Class Initialized
INFO - 2017-04-22 11:48:23 --> Output Class Initialized
INFO - 2017-04-22 11:48:23 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:23 --> Input Class Initialized
INFO - 2017-04-22 11:48:23 --> Language Class Initialized
INFO - 2017-04-22 11:48:23 --> Loader Class Initialized
INFO - 2017-04-22 11:48:23 --> Helper loaded: url_helper
INFO - 2017-04-22 11:48:23 --> Helper loaded: form_helper
INFO - 2017-04-22 11:48:23 --> Helper loaded: html_helper
INFO - 2017-04-22 11:48:23 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:48:23 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:48:23 --> Database Driver Class Initialized
INFO - 2017-04-22 11:48:23 --> Parser Class Initialized
DEBUG - 2017-04-22 11:48:23 --> Session Class Initialized
INFO - 2017-04-22 11:48:23 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:48:23 --> Session routines successfully run
INFO - 2017-04-22 11:48:23 --> Form Validation Class Initialized
INFO - 2017-04-22 11:48:23 --> Controller Class Initialized
DEBUG - 2017-04-22 11:48:23 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:48:23 --> Model Class Initialized
DEBUG - 2017-04-22 11:48:23 --> Pagination Class Initialized
INFO - 2017-04-22 11:48:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:48:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:48:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:48:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:48:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:48:23 --> Final output sent to browser
DEBUG - 2017-04-22 11:48:23 --> Total execution time: 0.2488
INFO - 2017-04-22 11:48:27 --> Config Class Initialized
INFO - 2017-04-22 11:48:27 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:27 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:27 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:27 --> URI Class Initialized
INFO - 2017-04-22 11:48:27 --> Router Class Initialized
INFO - 2017-04-22 11:48:27 --> Output Class Initialized
INFO - 2017-04-22 11:48:27 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:27 --> Input Class Initialized
INFO - 2017-04-22 11:48:27 --> Language Class Initialized
INFO - 2017-04-22 11:48:27 --> Loader Class Initialized
INFO - 2017-04-22 11:48:27 --> Helper loaded: url_helper
INFO - 2017-04-22 11:48:27 --> Helper loaded: form_helper
INFO - 2017-04-22 11:48:27 --> Helper loaded: html_helper
INFO - 2017-04-22 11:48:27 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:48:27 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:48:27 --> Database Driver Class Initialized
INFO - 2017-04-22 11:48:27 --> Parser Class Initialized
DEBUG - 2017-04-22 11:48:27 --> Session Class Initialized
INFO - 2017-04-22 11:48:27 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:48:27 --> Session routines successfully run
INFO - 2017-04-22 11:48:27 --> Form Validation Class Initialized
INFO - 2017-04-22 11:48:27 --> Controller Class Initialized
DEBUG - 2017-04-22 11:48:27 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:48:27 --> Model Class Initialized
DEBUG - 2017-04-22 11:48:27 --> Pagination Class Initialized
INFO - 2017-04-22 11:48:27 --> Config Class Initialized
INFO - 2017-04-22 11:48:27 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:27 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:27 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:27 --> URI Class Initialized
INFO - 2017-04-22 11:48:27 --> Router Class Initialized
INFO - 2017-04-22 11:48:27 --> Output Class Initialized
INFO - 2017-04-22 11:48:27 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:27 --> Input Class Initialized
INFO - 2017-04-22 11:48:27 --> Language Class Initialized
INFO - 2017-04-22 11:48:27 --> Loader Class Initialized
INFO - 2017-04-22 11:48:27 --> Helper loaded: url_helper
INFO - 2017-04-22 11:48:27 --> Helper loaded: form_helper
INFO - 2017-04-22 11:48:27 --> Helper loaded: html_helper
INFO - 2017-04-22 11:48:27 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:48:27 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:48:27 --> Database Driver Class Initialized
INFO - 2017-04-22 11:48:27 --> Parser Class Initialized
DEBUG - 2017-04-22 11:48:27 --> Session Class Initialized
INFO - 2017-04-22 11:48:27 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:48:27 --> Session routines successfully run
INFO - 2017-04-22 11:48:27 --> Form Validation Class Initialized
INFO - 2017-04-22 11:48:27 --> Controller Class Initialized
DEBUG - 2017-04-22 11:48:27 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:48:27 --> Model Class Initialized
DEBUG - 2017-04-22 11:48:27 --> Pagination Class Initialized
INFO - 2017-04-22 11:48:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:48:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:48:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:48:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:48:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:48:30 --> Final output sent to browser
DEBUG - 2017-04-22 11:48:30 --> Total execution time: 3.1100
INFO - 2017-04-22 11:48:41 --> Config Class Initialized
INFO - 2017-04-22 11:48:41 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:41 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:41 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:41 --> URI Class Initialized
INFO - 2017-04-22 11:48:41 --> Router Class Initialized
INFO - 2017-04-22 11:48:41 --> Output Class Initialized
INFO - 2017-04-22 11:48:41 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:41 --> Input Class Initialized
INFO - 2017-04-22 11:48:41 --> Language Class Initialized
INFO - 2017-04-22 11:48:41 --> Loader Class Initialized
INFO - 2017-04-22 11:48:41 --> Helper loaded: url_helper
INFO - 2017-04-22 11:48:41 --> Helper loaded: form_helper
INFO - 2017-04-22 11:48:41 --> Helper loaded: html_helper
INFO - 2017-04-22 11:48:41 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:48:41 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:48:41 --> Database Driver Class Initialized
INFO - 2017-04-22 11:48:41 --> Parser Class Initialized
DEBUG - 2017-04-22 11:48:41 --> Session Class Initialized
INFO - 2017-04-22 11:48:41 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:48:41 --> Session routines successfully run
INFO - 2017-04-22 11:48:41 --> Form Validation Class Initialized
INFO - 2017-04-22 11:48:41 --> Controller Class Initialized
DEBUG - 2017-04-22 11:48:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:48:42 --> Model Class Initialized
DEBUG - 2017-04-22 11:48:42 --> Pagination Class Initialized
INFO - 2017-04-22 11:48:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:48:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:48:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:48:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:48:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:48:42 --> Final output sent to browser
DEBUG - 2017-04-22 11:48:42 --> Total execution time: 0.2475
INFO - 2017-04-22 11:48:42 --> Config Class Initialized
INFO - 2017-04-22 11:48:42 --> Config Class Initialized
INFO - 2017-04-22 11:48:42 --> Hooks Class Initialized
INFO - 2017-04-22 11:48:42 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:42 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:48:42 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:42 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:42 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:42 --> URI Class Initialized
INFO - 2017-04-22 11:48:42 --> URI Class Initialized
INFO - 2017-04-22 11:48:42 --> Router Class Initialized
INFO - 2017-04-22 11:48:42 --> Router Class Initialized
INFO - 2017-04-22 11:48:42 --> Output Class Initialized
INFO - 2017-04-22 11:48:42 --> Output Class Initialized
INFO - 2017-04-22 11:48:42 --> Security Class Initialized
INFO - 2017-04-22 11:48:42 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:42 --> Input Class Initialized
DEBUG - 2017-04-22 11:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:42 --> Input Class Initialized
INFO - 2017-04-22 11:48:42 --> Language Class Initialized
INFO - 2017-04-22 11:48:42 --> Language Class Initialized
ERROR - 2017-04-22 11:48:42 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:48:42 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:42 --> Config Class Initialized
INFO - 2017-04-22 11:48:42 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:42 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:42 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:42 --> URI Class Initialized
INFO - 2017-04-22 11:48:42 --> Router Class Initialized
INFO - 2017-04-22 11:48:42 --> Output Class Initialized
INFO - 2017-04-22 11:48:42 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:42 --> Input Class Initialized
INFO - 2017-04-22 11:48:42 --> Language Class Initialized
ERROR - 2017-04-22 11:48:42 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:42 --> Config Class Initialized
INFO - 2017-04-22 11:48:42 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:42 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:42 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:42 --> URI Class Initialized
INFO - 2017-04-22 11:48:42 --> Router Class Initialized
INFO - 2017-04-22 11:48:42 --> Output Class Initialized
INFO - 2017-04-22 11:48:42 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:42 --> Input Class Initialized
INFO - 2017-04-22 11:48:42 --> Language Class Initialized
ERROR - 2017-04-22 11:48:42 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:45 --> Config Class Initialized
INFO - 2017-04-22 11:48:45 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:45 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:45 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:45 --> URI Class Initialized
INFO - 2017-04-22 11:48:45 --> Router Class Initialized
INFO - 2017-04-22 11:48:45 --> Output Class Initialized
INFO - 2017-04-22 11:48:45 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:45 --> Input Class Initialized
INFO - 2017-04-22 11:48:45 --> Language Class Initialized
INFO - 2017-04-22 11:48:45 --> Loader Class Initialized
INFO - 2017-04-22 11:48:45 --> Helper loaded: url_helper
INFO - 2017-04-22 11:48:45 --> Helper loaded: form_helper
INFO - 2017-04-22 11:48:45 --> Helper loaded: html_helper
INFO - 2017-04-22 11:48:45 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:48:45 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:48:45 --> Database Driver Class Initialized
INFO - 2017-04-22 11:48:45 --> Parser Class Initialized
DEBUG - 2017-04-22 11:48:45 --> Session Class Initialized
INFO - 2017-04-22 11:48:45 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:48:45 --> Session routines successfully run
INFO - 2017-04-22 11:48:45 --> Form Validation Class Initialized
INFO - 2017-04-22 11:48:45 --> Controller Class Initialized
DEBUG - 2017-04-22 11:48:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:48:45 --> Model Class Initialized
DEBUG - 2017-04-22 11:48:45 --> Pagination Class Initialized
INFO - 2017-04-22 11:48:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:48:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:48:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:48:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:48:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:48:48 --> Final output sent to browser
DEBUG - 2017-04-22 11:48:48 --> Total execution time: 3.0612
INFO - 2017-04-22 11:48:50 --> Config Class Initialized
INFO - 2017-04-22 11:48:50 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:50 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:50 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:50 --> URI Class Initialized
INFO - 2017-04-22 11:48:50 --> Router Class Initialized
INFO - 2017-04-22 11:48:50 --> Output Class Initialized
INFO - 2017-04-22 11:48:50 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:50 --> Input Class Initialized
INFO - 2017-04-22 11:48:50 --> Language Class Initialized
INFO - 2017-04-22 11:48:50 --> Loader Class Initialized
INFO - 2017-04-22 11:48:50 --> Helper loaded: url_helper
INFO - 2017-04-22 11:48:50 --> Helper loaded: form_helper
INFO - 2017-04-22 11:48:50 --> Helper loaded: html_helper
INFO - 2017-04-22 11:48:50 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:48:50 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:48:50 --> Database Driver Class Initialized
INFO - 2017-04-22 11:48:50 --> Parser Class Initialized
DEBUG - 2017-04-22 11:48:50 --> Session Class Initialized
INFO - 2017-04-22 11:48:50 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:48:50 --> Session routines successfully run
INFO - 2017-04-22 11:48:50 --> Form Validation Class Initialized
INFO - 2017-04-22 11:48:50 --> Controller Class Initialized
DEBUG - 2017-04-22 11:48:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:48:50 --> Model Class Initialized
DEBUG - 2017-04-22 11:48:50 --> Pagination Class Initialized
INFO - 2017-04-22 11:48:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:48:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:48:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:48:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:48:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:48:50 --> Final output sent to browser
DEBUG - 2017-04-22 11:48:50 --> Total execution time: 0.2571
INFO - 2017-04-22 11:48:50 --> Config Class Initialized
INFO - 2017-04-22 11:48:50 --> Config Class Initialized
INFO - 2017-04-22 11:48:50 --> Hooks Class Initialized
INFO - 2017-04-22 11:48:50 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:48:50 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:50 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:50 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:50 --> URI Class Initialized
INFO - 2017-04-22 11:48:50 --> URI Class Initialized
INFO - 2017-04-22 11:48:50 --> Router Class Initialized
INFO - 2017-04-22 11:48:50 --> Router Class Initialized
INFO - 2017-04-22 11:48:50 --> Output Class Initialized
INFO - 2017-04-22 11:48:50 --> Output Class Initialized
INFO - 2017-04-22 11:48:50 --> Security Class Initialized
INFO - 2017-04-22 11:48:50 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-22 11:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:50 --> Input Class Initialized
INFO - 2017-04-22 11:48:50 --> Input Class Initialized
INFO - 2017-04-22 11:48:50 --> Language Class Initialized
INFO - 2017-04-22 11:48:50 --> Language Class Initialized
ERROR - 2017-04-22 11:48:50 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:48:50 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:51 --> Config Class Initialized
INFO - 2017-04-22 11:48:51 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:51 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:51 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:51 --> URI Class Initialized
INFO - 2017-04-22 11:48:51 --> Router Class Initialized
INFO - 2017-04-22 11:48:51 --> Output Class Initialized
INFO - 2017-04-22 11:48:51 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:51 --> Input Class Initialized
INFO - 2017-04-22 11:48:51 --> Language Class Initialized
ERROR - 2017-04-22 11:48:51 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:51 --> Config Class Initialized
INFO - 2017-04-22 11:48:51 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:51 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:51 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:51 --> URI Class Initialized
INFO - 2017-04-22 11:48:51 --> Router Class Initialized
INFO - 2017-04-22 11:48:51 --> Output Class Initialized
INFO - 2017-04-22 11:48:51 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:51 --> Input Class Initialized
INFO - 2017-04-22 11:48:51 --> Language Class Initialized
ERROR - 2017-04-22 11:48:51 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:48:56 --> Config Class Initialized
INFO - 2017-04-22 11:48:56 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:48:56 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:48:56 --> Utf8 Class Initialized
INFO - 2017-04-22 11:48:56 --> URI Class Initialized
INFO - 2017-04-22 11:48:56 --> Router Class Initialized
INFO - 2017-04-22 11:48:56 --> Output Class Initialized
INFO - 2017-04-22 11:48:56 --> Security Class Initialized
DEBUG - 2017-04-22 11:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:48:56 --> Input Class Initialized
INFO - 2017-04-22 11:48:56 --> Language Class Initialized
INFO - 2017-04-22 11:48:56 --> Loader Class Initialized
INFO - 2017-04-22 11:48:56 --> Helper loaded: url_helper
INFO - 2017-04-22 11:48:56 --> Helper loaded: form_helper
INFO - 2017-04-22 11:48:56 --> Helper loaded: html_helper
INFO - 2017-04-22 11:48:56 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:48:56 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:48:56 --> Database Driver Class Initialized
INFO - 2017-04-22 11:48:56 --> Parser Class Initialized
DEBUG - 2017-04-22 11:48:56 --> Session Class Initialized
INFO - 2017-04-22 11:48:56 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:48:56 --> Session routines successfully run
INFO - 2017-04-22 11:48:56 --> Form Validation Class Initialized
INFO - 2017-04-22 11:48:56 --> Controller Class Initialized
DEBUG - 2017-04-22 11:48:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:48:56 --> Model Class Initialized
DEBUG - 2017-04-22 11:48:56 --> Pagination Class Initialized
INFO - 2017-04-22 11:48:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:48:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:48:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:48:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:48:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:48:59 --> Final output sent to browser
DEBUG - 2017-04-22 11:48:59 --> Total execution time: 3.0338
INFO - 2017-04-22 11:49:10 --> Config Class Initialized
INFO - 2017-04-22 11:49:10 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:49:10 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:49:10 --> Utf8 Class Initialized
INFO - 2017-04-22 11:49:10 --> URI Class Initialized
INFO - 2017-04-22 11:49:10 --> Router Class Initialized
INFO - 2017-04-22 11:49:10 --> Output Class Initialized
INFO - 2017-04-22 11:49:10 --> Security Class Initialized
DEBUG - 2017-04-22 11:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:49:10 --> Input Class Initialized
INFO - 2017-04-22 11:49:10 --> Language Class Initialized
INFO - 2017-04-22 11:49:10 --> Loader Class Initialized
INFO - 2017-04-22 11:49:10 --> Helper loaded: url_helper
INFO - 2017-04-22 11:49:10 --> Helper loaded: form_helper
INFO - 2017-04-22 11:49:10 --> Helper loaded: html_helper
INFO - 2017-04-22 11:49:10 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:49:10 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:49:10 --> Database Driver Class Initialized
INFO - 2017-04-22 11:49:10 --> Parser Class Initialized
DEBUG - 2017-04-22 11:49:10 --> Session Class Initialized
INFO - 2017-04-22 11:49:10 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:49:10 --> Session routines successfully run
INFO - 2017-04-22 11:49:10 --> Form Validation Class Initialized
INFO - 2017-04-22 11:49:10 --> Controller Class Initialized
DEBUG - 2017-04-22 11:49:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:49:10 --> Model Class Initialized
DEBUG - 2017-04-22 11:49:10 --> Pagination Class Initialized
INFO - 2017-04-22 11:49:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:49:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:49:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2017-04-22 11:49:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:49:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:49:10 --> Final output sent to browser
DEBUG - 2017-04-22 11:49:10 --> Total execution time: 0.2600
INFO - 2017-04-22 11:49:10 --> Config Class Initialized
INFO - 2017-04-22 11:49:10 --> Config Class Initialized
INFO - 2017-04-22 11:49:10 --> Hooks Class Initialized
INFO - 2017-04-22 11:49:10 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:49:10 --> UTF-8 Support Enabled
DEBUG - 2017-04-22 11:49:10 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:49:10 --> Utf8 Class Initialized
INFO - 2017-04-22 11:49:10 --> Utf8 Class Initialized
INFO - 2017-04-22 11:49:10 --> URI Class Initialized
INFO - 2017-04-22 11:49:10 --> URI Class Initialized
INFO - 2017-04-22 11:49:10 --> Router Class Initialized
INFO - 2017-04-22 11:49:10 --> Router Class Initialized
INFO - 2017-04-22 11:49:10 --> Output Class Initialized
INFO - 2017-04-22 11:49:10 --> Output Class Initialized
INFO - 2017-04-22 11:49:10 --> Security Class Initialized
INFO - 2017-04-22 11:49:10 --> Security Class Initialized
DEBUG - 2017-04-22 11:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-04-22 11:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:49:10 --> Input Class Initialized
INFO - 2017-04-22 11:49:10 --> Input Class Initialized
INFO - 2017-04-22 11:49:10 --> Language Class Initialized
INFO - 2017-04-22 11:49:10 --> Language Class Initialized
ERROR - 2017-04-22 11:49:10 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-22 11:49:10 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:49:11 --> Config Class Initialized
INFO - 2017-04-22 11:49:11 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:49:11 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:49:11 --> Utf8 Class Initialized
INFO - 2017-04-22 11:49:11 --> URI Class Initialized
INFO - 2017-04-22 11:49:11 --> Router Class Initialized
INFO - 2017-04-22 11:49:11 --> Output Class Initialized
INFO - 2017-04-22 11:49:11 --> Security Class Initialized
DEBUG - 2017-04-22 11:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:49:11 --> Input Class Initialized
INFO - 2017-04-22 11:49:11 --> Language Class Initialized
ERROR - 2017-04-22 11:49:11 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:49:11 --> Config Class Initialized
INFO - 2017-04-22 11:49:11 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:49:11 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:49:11 --> Utf8 Class Initialized
INFO - 2017-04-22 11:49:11 --> URI Class Initialized
INFO - 2017-04-22 11:49:11 --> Router Class Initialized
INFO - 2017-04-22 11:49:11 --> Output Class Initialized
INFO - 2017-04-22 11:49:11 --> Security Class Initialized
DEBUG - 2017-04-22 11:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:49:11 --> Input Class Initialized
INFO - 2017-04-22 11:49:11 --> Language Class Initialized
ERROR - 2017-04-22 11:49:11 --> 404 Page Not Found: Default/assets
INFO - 2017-04-22 11:49:14 --> Config Class Initialized
INFO - 2017-04-22 11:49:14 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:49:14 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:49:14 --> Utf8 Class Initialized
INFO - 2017-04-22 11:49:14 --> URI Class Initialized
INFO - 2017-04-22 11:49:14 --> Router Class Initialized
INFO - 2017-04-22 11:49:14 --> Output Class Initialized
INFO - 2017-04-22 11:49:14 --> Security Class Initialized
DEBUG - 2017-04-22 11:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:49:14 --> Input Class Initialized
INFO - 2017-04-22 11:49:14 --> Language Class Initialized
INFO - 2017-04-22 11:49:14 --> Loader Class Initialized
INFO - 2017-04-22 11:49:14 --> Helper loaded: url_helper
INFO - 2017-04-22 11:49:14 --> Helper loaded: form_helper
INFO - 2017-04-22 11:49:14 --> Helper loaded: html_helper
INFO - 2017-04-22 11:49:14 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:49:14 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:49:14 --> Database Driver Class Initialized
INFO - 2017-04-22 11:49:14 --> Parser Class Initialized
DEBUG - 2017-04-22 11:49:14 --> Session Class Initialized
INFO - 2017-04-22 11:49:14 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:49:14 --> Session routines successfully run
INFO - 2017-04-22 11:49:14 --> Form Validation Class Initialized
INFO - 2017-04-22 11:49:14 --> Controller Class Initialized
DEBUG - 2017-04-22 11:49:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:49:14 --> Model Class Initialized
DEBUG - 2017-04-22 11:49:14 --> Pagination Class Initialized
INFO - 2017-04-22 11:49:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:49:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:49:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:49:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:49:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:49:17 --> Final output sent to browser
DEBUG - 2017-04-22 11:49:17 --> Total execution time: 3.2091
INFO - 2017-04-22 11:49:56 --> Config Class Initialized
INFO - 2017-04-22 11:49:56 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:49:56 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:49:56 --> Utf8 Class Initialized
INFO - 2017-04-22 11:49:56 --> URI Class Initialized
INFO - 2017-04-22 11:49:56 --> Router Class Initialized
INFO - 2017-04-22 11:49:56 --> Output Class Initialized
INFO - 2017-04-22 11:49:56 --> Security Class Initialized
DEBUG - 2017-04-22 11:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:49:56 --> Input Class Initialized
INFO - 2017-04-22 11:49:56 --> Language Class Initialized
INFO - 2017-04-22 11:49:56 --> Loader Class Initialized
INFO - 2017-04-22 11:49:56 --> Helper loaded: url_helper
INFO - 2017-04-22 11:49:56 --> Helper loaded: form_helper
INFO - 2017-04-22 11:49:56 --> Helper loaded: html_helper
INFO - 2017-04-22 11:49:56 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:49:56 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:49:56 --> Database Driver Class Initialized
INFO - 2017-04-22 11:49:56 --> Parser Class Initialized
DEBUG - 2017-04-22 11:49:56 --> Session Class Initialized
INFO - 2017-04-22 11:49:56 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:49:56 --> Session routines successfully run
INFO - 2017-04-22 11:49:56 --> Form Validation Class Initialized
INFO - 2017-04-22 11:49:56 --> Controller Class Initialized
DEBUG - 2017-04-22 11:49:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-22 11:49:56 --> Model Class Initialized
DEBUG - 2017-04-22 11:49:56 --> Pagination Class Initialized
INFO - 2017-04-22 11:49:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-22 11:49:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-22 11:49:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-22 11:50:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-22 11:50:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:50:00 --> Final output sent to browser
DEBUG - 2017-04-22 11:50:00 --> Total execution time: 3.5942
INFO - 2017-04-22 11:50:04 --> Config Class Initialized
INFO - 2017-04-22 11:50:04 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:50:04 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:50:04 --> Utf8 Class Initialized
INFO - 2017-04-22 11:50:04 --> URI Class Initialized
INFO - 2017-04-22 11:50:04 --> Router Class Initialized
INFO - 2017-04-22 11:50:04 --> Output Class Initialized
INFO - 2017-04-22 11:50:04 --> Security Class Initialized
DEBUG - 2017-04-22 11:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:50:04 --> Input Class Initialized
INFO - 2017-04-22 11:50:04 --> Language Class Initialized
INFO - 2017-04-22 11:50:04 --> Loader Class Initialized
INFO - 2017-04-22 11:50:04 --> Helper loaded: url_helper
INFO - 2017-04-22 11:50:04 --> Helper loaded: form_helper
INFO - 2017-04-22 11:50:04 --> Helper loaded: html_helper
INFO - 2017-04-22 11:50:04 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:50:04 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:50:04 --> Database Driver Class Initialized
INFO - 2017-04-22 11:50:04 --> Parser Class Initialized
DEBUG - 2017-04-22 11:50:04 --> Session Class Initialized
INFO - 2017-04-22 11:50:04 --> Helper loaded: string_helper
DEBUG - 2017-04-22 11:50:04 --> Session routines successfully run
INFO - 2017-04-22 11:50:04 --> Form Validation Class Initialized
INFO - 2017-04-22 11:50:04 --> Controller Class Initialized
INFO - 2017-04-22 11:50:04 --> Model Class Initialized
INFO - 2017-04-22 11:50:04 --> Config Class Initialized
INFO - 2017-04-22 11:50:04 --> Hooks Class Initialized
DEBUG - 2017-04-22 11:50:04 --> UTF-8 Support Enabled
INFO - 2017-04-22 11:50:04 --> Utf8 Class Initialized
INFO - 2017-04-22 11:50:05 --> URI Class Initialized
INFO - 2017-04-22 11:50:05 --> Router Class Initialized
INFO - 2017-04-22 11:50:05 --> Output Class Initialized
INFO - 2017-04-22 11:50:05 --> Security Class Initialized
DEBUG - 2017-04-22 11:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-22 11:50:05 --> Input Class Initialized
INFO - 2017-04-22 11:50:05 --> Language Class Initialized
INFO - 2017-04-22 11:50:05 --> Loader Class Initialized
INFO - 2017-04-22 11:50:05 --> Helper loaded: url_helper
INFO - 2017-04-22 11:50:05 --> Helper loaded: form_helper
INFO - 2017-04-22 11:50:05 --> Helper loaded: html_helper
INFO - 2017-04-22 11:50:05 --> Helper loaded: custom_helper
INFO - 2017-04-22 11:50:05 --> Helper loaded: cache_helper
INFO - 2017-04-22 11:50:05 --> Database Driver Class Initialized
INFO - 2017-04-22 11:50:05 --> Parser Class Initialized
DEBUG - 2017-04-22 11:50:05 --> Session Class Initialized
INFO - 2017-04-22 11:50:05 --> Helper loaded: string_helper
ERROR - 2017-04-22 11:50:05 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-22 11:50:05 --> Session routines successfully run
INFO - 2017-04-22 11:50:05 --> Form Validation Class Initialized
INFO - 2017-04-22 11:50:05 --> Controller Class Initialized
INFO - 2017-04-22 11:50:05 --> Model Class Initialized
INFO - 2017-04-22 11:50:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-22 11:50:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-22 11:50:05 --> Final output sent to browser
DEBUG - 2017-04-22 11:50:05 --> Total execution time: 0.2212
