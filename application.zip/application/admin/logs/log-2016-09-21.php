<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-21 12:36:56 --> Config Class Initialized
INFO - 2016-09-21 12:36:56 --> Hooks Class Initialized
DEBUG - 2016-09-21 12:36:56 --> UTF-8 Support Enabled
INFO - 2016-09-21 12:36:56 --> Utf8 Class Initialized
INFO - 2016-09-21 12:36:56 --> URI Class Initialized
DEBUG - 2016-09-21 12:36:56 --> No URI present. Default controller set.
INFO - 2016-09-21 12:36:56 --> Router Class Initialized
INFO - 2016-09-21 12:36:56 --> Output Class Initialized
INFO - 2016-09-21 12:36:56 --> Security Class Initialized
DEBUG - 2016-09-21 12:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 12:36:56 --> Input Class Initialized
INFO - 2016-09-21 12:36:56 --> Language Class Initialized
INFO - 2016-09-21 12:36:56 --> Loader Class Initialized
INFO - 2016-09-21 12:36:56 --> Helper loaded: url_helper
INFO - 2016-09-21 12:36:56 --> Helper loaded: form_helper
INFO - 2016-09-21 12:36:56 --> Helper loaded: html_helper
INFO - 2016-09-21 12:36:56 --> Helper loaded: custom_helper
INFO - 2016-09-21 12:36:56 --> Helper loaded: cache_helper
INFO - 2016-09-21 12:36:56 --> Database Driver Class Initialized
INFO - 2016-09-21 12:36:56 --> Parser Class Initialized
DEBUG - 2016-09-21 12:36:56 --> Session Class Initialized
INFO - 2016-09-21 12:36:56 --> Helper loaded: string_helper
ERROR - 2016-09-21 12:36:56 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2016-09-21 12:36:56 --> Session routines successfully run
INFO - 2016-09-21 12:36:56 --> Form Validation Class Initialized
INFO - 2016-09-21 12:36:56 --> Controller Class Initialized
INFO - 2016-09-21 12:36:56 --> Model Class Initialized
INFO - 2016-09-21 12:36:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 12:36:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 12:36:56 --> Final output sent to browser
DEBUG - 2016-09-21 12:36:56 --> Total execution time: 0.3438
INFO - 2016-09-21 12:37:56 --> Config Class Initialized
INFO - 2016-09-21 12:37:56 --> Hooks Class Initialized
DEBUG - 2016-09-21 12:37:56 --> UTF-8 Support Enabled
INFO - 2016-09-21 12:37:56 --> Utf8 Class Initialized
INFO - 2016-09-21 12:37:56 --> URI Class Initialized
INFO - 2016-09-21 12:37:56 --> Router Class Initialized
INFO - 2016-09-21 12:37:56 --> Output Class Initialized
INFO - 2016-09-21 12:37:56 --> Security Class Initialized
DEBUG - 2016-09-21 12:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 12:37:56 --> Input Class Initialized
INFO - 2016-09-21 12:37:56 --> Language Class Initialized
ERROR - 2016-09-21 12:37:56 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:13:30 --> Config Class Initialized
INFO - 2016-09-21 13:13:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:13:30 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:13:30 --> Utf8 Class Initialized
INFO - 2016-09-21 13:13:30 --> URI Class Initialized
DEBUG - 2016-09-21 13:13:30 --> No URI present. Default controller set.
INFO - 2016-09-21 13:13:30 --> Router Class Initialized
INFO - 2016-09-21 13:13:30 --> Output Class Initialized
INFO - 2016-09-21 13:13:30 --> Security Class Initialized
DEBUG - 2016-09-21 13:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:13:30 --> Input Class Initialized
INFO - 2016-09-21 13:13:30 --> Language Class Initialized
INFO - 2016-09-21 13:13:30 --> Loader Class Initialized
INFO - 2016-09-21 13:13:30 --> Helper loaded: url_helper
INFO - 2016-09-21 13:13:30 --> Helper loaded: form_helper
INFO - 2016-09-21 13:13:30 --> Helper loaded: html_helper
INFO - 2016-09-21 13:13:30 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:13:30 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:13:30 --> Database Driver Class Initialized
INFO - 2016-09-21 13:13:30 --> Parser Class Initialized
DEBUG - 2016-09-21 13:13:30 --> Session Class Initialized
INFO - 2016-09-21 13:13:30 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:13:30 --> Session routines successfully run
INFO - 2016-09-21 13:13:30 --> Form Validation Class Initialized
INFO - 2016-09-21 13:13:30 --> Controller Class Initialized
INFO - 2016-09-21 13:13:30 --> Model Class Initialized
INFO - 2016-09-21 13:13:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:13:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:13:30 --> Final output sent to browser
DEBUG - 2016-09-21 13:13:30 --> Total execution time: 0.1419
INFO - 2016-09-21 13:19:09 --> Config Class Initialized
INFO - 2016-09-21 13:19:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:19:09 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:19:09 --> Utf8 Class Initialized
INFO - 2016-09-21 13:19:09 --> URI Class Initialized
DEBUG - 2016-09-21 13:19:09 --> No URI present. Default controller set.
INFO - 2016-09-21 13:19:09 --> Router Class Initialized
INFO - 2016-09-21 13:19:09 --> Output Class Initialized
INFO - 2016-09-21 13:19:09 --> Security Class Initialized
DEBUG - 2016-09-21 13:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:19:09 --> Input Class Initialized
INFO - 2016-09-21 13:19:09 --> Language Class Initialized
INFO - 2016-09-21 13:19:09 --> Loader Class Initialized
INFO - 2016-09-21 13:19:09 --> Helper loaded: url_helper
INFO - 2016-09-21 13:19:09 --> Helper loaded: form_helper
INFO - 2016-09-21 13:19:09 --> Helper loaded: html_helper
INFO - 2016-09-21 13:19:09 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:19:09 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:19:09 --> Database Driver Class Initialized
INFO - 2016-09-21 13:19:09 --> Parser Class Initialized
DEBUG - 2016-09-21 13:19:09 --> Session Class Initialized
INFO - 2016-09-21 13:19:09 --> Helper loaded: string_helper
ERROR - 2016-09-21 13:19:09 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2016-09-21 13:19:09 --> Session routines successfully run
INFO - 2016-09-21 13:19:09 --> Form Validation Class Initialized
INFO - 2016-09-21 13:19:09 --> Controller Class Initialized
INFO - 2016-09-21 13:19:09 --> Model Class Initialized
INFO - 2016-09-21 13:19:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:19:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:19:09 --> Final output sent to browser
DEBUG - 2016-09-21 13:19:09 --> Total execution time: 0.1479
INFO - 2016-09-21 13:19:10 --> Config Class Initialized
INFO - 2016-09-21 13:19:10 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:19:10 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:19:10 --> Utf8 Class Initialized
INFO - 2016-09-21 13:19:10 --> URI Class Initialized
INFO - 2016-09-21 13:19:10 --> Router Class Initialized
INFO - 2016-09-21 13:19:10 --> Output Class Initialized
INFO - 2016-09-21 13:19:10 --> Security Class Initialized
DEBUG - 2016-09-21 13:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:19:10 --> Input Class Initialized
INFO - 2016-09-21 13:19:10 --> Language Class Initialized
ERROR - 2016-09-21 13:19:10 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:23:36 --> Config Class Initialized
INFO - 2016-09-21 13:23:36 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:23:36 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:23:36 --> Utf8 Class Initialized
INFO - 2016-09-21 13:23:36 --> URI Class Initialized
DEBUG - 2016-09-21 13:23:36 --> No URI present. Default controller set.
INFO - 2016-09-21 13:23:36 --> Router Class Initialized
INFO - 2016-09-21 13:23:36 --> Output Class Initialized
INFO - 2016-09-21 13:23:36 --> Security Class Initialized
DEBUG - 2016-09-21 13:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:23:36 --> Input Class Initialized
INFO - 2016-09-21 13:23:36 --> Language Class Initialized
INFO - 2016-09-21 13:23:36 --> Loader Class Initialized
INFO - 2016-09-21 13:23:36 --> Helper loaded: url_helper
INFO - 2016-09-21 13:23:36 --> Helper loaded: form_helper
INFO - 2016-09-21 13:23:36 --> Helper loaded: html_helper
INFO - 2016-09-21 13:23:36 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:23:36 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:23:36 --> Database Driver Class Initialized
INFO - 2016-09-21 13:23:36 --> Parser Class Initialized
DEBUG - 2016-09-21 13:23:36 --> Session Class Initialized
INFO - 2016-09-21 13:23:36 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:23:36 --> Session routines successfully run
INFO - 2016-09-21 13:23:36 --> Form Validation Class Initialized
INFO - 2016-09-21 13:23:36 --> Controller Class Initialized
INFO - 2016-09-21 13:23:36 --> Model Class Initialized
INFO - 2016-09-21 13:23:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:23:36 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:23:36 --> Final output sent to browser
DEBUG - 2016-09-21 13:23:36 --> Total execution time: 0.1561
INFO - 2016-09-21 13:27:29 --> Config Class Initialized
INFO - 2016-09-21 13:27:29 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:27:29 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:27:29 --> Utf8 Class Initialized
INFO - 2016-09-21 13:27:29 --> URI Class Initialized
DEBUG - 2016-09-21 13:27:29 --> No URI present. Default controller set.
INFO - 2016-09-21 13:27:29 --> Router Class Initialized
INFO - 2016-09-21 13:27:29 --> Output Class Initialized
INFO - 2016-09-21 13:27:29 --> Security Class Initialized
DEBUG - 2016-09-21 13:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:27:29 --> Input Class Initialized
INFO - 2016-09-21 13:27:29 --> Language Class Initialized
INFO - 2016-09-21 13:27:29 --> Loader Class Initialized
INFO - 2016-09-21 13:27:29 --> Helper loaded: url_helper
INFO - 2016-09-21 13:27:29 --> Helper loaded: form_helper
INFO - 2016-09-21 13:27:29 --> Helper loaded: html_helper
INFO - 2016-09-21 13:27:29 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:27:29 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:27:29 --> Database Driver Class Initialized
INFO - 2016-09-21 13:27:29 --> Parser Class Initialized
DEBUG - 2016-09-21 13:27:29 --> Session Class Initialized
INFO - 2016-09-21 13:27:29 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:27:29 --> Session routines successfully run
INFO - 2016-09-21 13:27:29 --> Form Validation Class Initialized
INFO - 2016-09-21 13:27:29 --> Controller Class Initialized
INFO - 2016-09-21 13:27:29 --> Model Class Initialized
INFO - 2016-09-21 13:27:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:27:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:27:29 --> Final output sent to browser
DEBUG - 2016-09-21 13:27:29 --> Total execution time: 0.1506
INFO - 2016-09-21 13:29:43 --> Config Class Initialized
INFO - 2016-09-21 13:29:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:29:43 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:29:43 --> Utf8 Class Initialized
INFO - 2016-09-21 13:29:43 --> URI Class Initialized
INFO - 2016-09-21 13:29:43 --> Router Class Initialized
INFO - 2016-09-21 13:29:43 --> Output Class Initialized
INFO - 2016-09-21 13:29:43 --> Security Class Initialized
DEBUG - 2016-09-21 13:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:29:43 --> Input Class Initialized
INFO - 2016-09-21 13:29:43 --> Language Class Initialized
ERROR - 2016-09-21 13:29:43 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:31:49 --> Config Class Initialized
INFO - 2016-09-21 13:31:49 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:31:49 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:31:49 --> Utf8 Class Initialized
INFO - 2016-09-21 13:31:49 --> URI Class Initialized
INFO - 2016-09-21 13:31:49 --> Router Class Initialized
INFO - 2016-09-21 13:31:49 --> Output Class Initialized
INFO - 2016-09-21 13:31:49 --> Security Class Initialized
DEBUG - 2016-09-21 13:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:31:49 --> Input Class Initialized
INFO - 2016-09-21 13:31:49 --> Language Class Initialized
ERROR - 2016-09-21 13:31:49 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:31:52 --> Config Class Initialized
INFO - 2016-09-21 13:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:31:52 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:31:52 --> Utf8 Class Initialized
INFO - 2016-09-21 13:31:52 --> URI Class Initialized
DEBUG - 2016-09-21 13:31:52 --> No URI present. Default controller set.
INFO - 2016-09-21 13:31:52 --> Router Class Initialized
INFO - 2016-09-21 13:31:52 --> Output Class Initialized
INFO - 2016-09-21 13:31:52 --> Security Class Initialized
DEBUG - 2016-09-21 13:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:31:52 --> Input Class Initialized
INFO - 2016-09-21 13:31:52 --> Language Class Initialized
INFO - 2016-09-21 13:31:52 --> Loader Class Initialized
INFO - 2016-09-21 13:31:52 --> Helper loaded: url_helper
INFO - 2016-09-21 13:31:52 --> Helper loaded: form_helper
INFO - 2016-09-21 13:31:52 --> Helper loaded: html_helper
INFO - 2016-09-21 13:31:52 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:31:52 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:31:52 --> Database Driver Class Initialized
INFO - 2016-09-21 13:31:52 --> Parser Class Initialized
DEBUG - 2016-09-21 13:31:52 --> Session Class Initialized
INFO - 2016-09-21 13:31:52 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:31:52 --> Session routines successfully run
INFO - 2016-09-21 13:31:52 --> Form Validation Class Initialized
INFO - 2016-09-21 13:31:52 --> Controller Class Initialized
INFO - 2016-09-21 13:31:52 --> Model Class Initialized
INFO - 2016-09-21 13:31:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:31:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:31:52 --> Final output sent to browser
DEBUG - 2016-09-21 13:31:52 --> Total execution time: 0.1654
INFO - 2016-09-21 13:32:07 --> Config Class Initialized
INFO - 2016-09-21 13:32:07 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:32:07 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:32:07 --> Utf8 Class Initialized
INFO - 2016-09-21 13:32:07 --> URI Class Initialized
INFO - 2016-09-21 13:32:07 --> Router Class Initialized
INFO - 2016-09-21 13:32:07 --> Output Class Initialized
INFO - 2016-09-21 13:32:07 --> Security Class Initialized
DEBUG - 2016-09-21 13:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:32:07 --> Input Class Initialized
INFO - 2016-09-21 13:32:07 --> Language Class Initialized
ERROR - 2016-09-21 13:32:07 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:33:59 --> Config Class Initialized
INFO - 2016-09-21 13:33:59 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:33:59 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:33:59 --> Utf8 Class Initialized
INFO - 2016-09-21 13:33:59 --> URI Class Initialized
INFO - 2016-09-21 13:33:59 --> Router Class Initialized
INFO - 2016-09-21 13:33:59 --> Output Class Initialized
INFO - 2016-09-21 13:33:59 --> Security Class Initialized
DEBUG - 2016-09-21 13:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:33:59 --> Input Class Initialized
INFO - 2016-09-21 13:33:59 --> Language Class Initialized
ERROR - 2016-09-21 13:33:59 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:34:57 --> Config Class Initialized
INFO - 2016-09-21 13:34:57 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:34:57 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:34:57 --> Utf8 Class Initialized
INFO - 2016-09-21 13:34:57 --> URI Class Initialized
DEBUG - 2016-09-21 13:34:57 --> No URI present. Default controller set.
INFO - 2016-09-21 13:34:57 --> Router Class Initialized
INFO - 2016-09-21 13:34:57 --> Output Class Initialized
INFO - 2016-09-21 13:34:57 --> Security Class Initialized
DEBUG - 2016-09-21 13:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:34:57 --> Input Class Initialized
INFO - 2016-09-21 13:34:57 --> Language Class Initialized
INFO - 2016-09-21 13:34:57 --> Loader Class Initialized
INFO - 2016-09-21 13:34:57 --> Helper loaded: url_helper
INFO - 2016-09-21 13:34:57 --> Helper loaded: form_helper
INFO - 2016-09-21 13:34:57 --> Helper loaded: html_helper
INFO - 2016-09-21 13:34:57 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:34:57 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:34:57 --> Database Driver Class Initialized
INFO - 2016-09-21 13:34:57 --> Parser Class Initialized
DEBUG - 2016-09-21 13:34:57 --> Session Class Initialized
INFO - 2016-09-21 13:34:57 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:34:57 --> Session routines successfully run
INFO - 2016-09-21 13:34:57 --> Form Validation Class Initialized
INFO - 2016-09-21 13:34:57 --> Controller Class Initialized
INFO - 2016-09-21 13:34:57 --> Model Class Initialized
INFO - 2016-09-21 13:34:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:34:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:34:57 --> Final output sent to browser
DEBUG - 2016-09-21 13:34:57 --> Total execution time: 0.1509
INFO - 2016-09-21 13:35:15 --> Config Class Initialized
INFO - 2016-09-21 13:35:15 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:35:16 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:35:16 --> Utf8 Class Initialized
INFO - 2016-09-21 13:35:16 --> URI Class Initialized
INFO - 2016-09-21 13:35:16 --> Router Class Initialized
INFO - 2016-09-21 13:35:16 --> Output Class Initialized
INFO - 2016-09-21 13:35:16 --> Security Class Initialized
DEBUG - 2016-09-21 13:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:35:16 --> Input Class Initialized
INFO - 2016-09-21 13:35:16 --> Language Class Initialized
ERROR - 2016-09-21 13:35:16 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:35:23 --> Config Class Initialized
INFO - 2016-09-21 13:35:23 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:35:23 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:35:23 --> Utf8 Class Initialized
INFO - 2016-09-21 13:35:23 --> URI Class Initialized
DEBUG - 2016-09-21 13:35:23 --> No URI present. Default controller set.
INFO - 2016-09-21 13:35:23 --> Router Class Initialized
INFO - 2016-09-21 13:35:23 --> Output Class Initialized
INFO - 2016-09-21 13:35:23 --> Security Class Initialized
DEBUG - 2016-09-21 13:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:35:23 --> Input Class Initialized
INFO - 2016-09-21 13:35:23 --> Language Class Initialized
INFO - 2016-09-21 13:35:23 --> Loader Class Initialized
INFO - 2016-09-21 13:35:23 --> Helper loaded: url_helper
INFO - 2016-09-21 13:35:23 --> Helper loaded: form_helper
INFO - 2016-09-21 13:35:23 --> Helper loaded: html_helper
INFO - 2016-09-21 13:35:23 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:35:23 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:35:23 --> Database Driver Class Initialized
INFO - 2016-09-21 13:35:23 --> Parser Class Initialized
DEBUG - 2016-09-21 13:35:23 --> Session Class Initialized
INFO - 2016-09-21 13:35:23 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:35:23 --> Session routines successfully run
INFO - 2016-09-21 13:35:23 --> Form Validation Class Initialized
INFO - 2016-09-21 13:35:23 --> Controller Class Initialized
INFO - 2016-09-21 13:35:23 --> Model Class Initialized
INFO - 2016-09-21 13:35:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:35:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:35:23 --> Final output sent to browser
DEBUG - 2016-09-21 13:35:23 --> Total execution time: 0.1523
INFO - 2016-09-21 13:35:30 --> Config Class Initialized
INFO - 2016-09-21 13:35:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:35:30 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:35:30 --> Utf8 Class Initialized
INFO - 2016-09-21 13:35:30 --> URI Class Initialized
INFO - 2016-09-21 13:35:30 --> Router Class Initialized
INFO - 2016-09-21 13:35:30 --> Output Class Initialized
INFO - 2016-09-21 13:35:30 --> Security Class Initialized
DEBUG - 2016-09-21 13:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:35:30 --> Input Class Initialized
INFO - 2016-09-21 13:35:30 --> Language Class Initialized
ERROR - 2016-09-21 13:35:30 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:35:34 --> Config Class Initialized
INFO - 2016-09-21 13:35:34 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:35:34 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:35:34 --> Utf8 Class Initialized
INFO - 2016-09-21 13:35:34 --> URI Class Initialized
DEBUG - 2016-09-21 13:35:34 --> No URI present. Default controller set.
INFO - 2016-09-21 13:35:34 --> Router Class Initialized
INFO - 2016-09-21 13:35:34 --> Output Class Initialized
INFO - 2016-09-21 13:35:34 --> Security Class Initialized
DEBUG - 2016-09-21 13:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:35:34 --> Input Class Initialized
INFO - 2016-09-21 13:35:34 --> Language Class Initialized
INFO - 2016-09-21 13:35:34 --> Loader Class Initialized
INFO - 2016-09-21 13:35:34 --> Helper loaded: url_helper
INFO - 2016-09-21 13:35:34 --> Helper loaded: form_helper
INFO - 2016-09-21 13:35:34 --> Helper loaded: html_helper
INFO - 2016-09-21 13:35:34 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:35:34 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:35:34 --> Database Driver Class Initialized
INFO - 2016-09-21 13:35:34 --> Parser Class Initialized
DEBUG - 2016-09-21 13:35:34 --> Session Class Initialized
INFO - 2016-09-21 13:35:34 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:35:34 --> Session routines successfully run
INFO - 2016-09-21 13:35:34 --> Form Validation Class Initialized
INFO - 2016-09-21 13:35:34 --> Controller Class Initialized
INFO - 2016-09-21 13:35:34 --> Model Class Initialized
INFO - 2016-09-21 13:35:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:35:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:35:34 --> Final output sent to browser
DEBUG - 2016-09-21 13:35:34 --> Total execution time: 0.1526
INFO - 2016-09-21 13:37:01 --> Config Class Initialized
INFO - 2016-09-21 13:37:01 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:37:01 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:37:01 --> Utf8 Class Initialized
INFO - 2016-09-21 13:37:01 --> URI Class Initialized
DEBUG - 2016-09-21 13:37:01 --> No URI present. Default controller set.
INFO - 2016-09-21 13:37:01 --> Router Class Initialized
INFO - 2016-09-21 13:37:01 --> Output Class Initialized
INFO - 2016-09-21 13:37:01 --> Security Class Initialized
DEBUG - 2016-09-21 13:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:37:01 --> Input Class Initialized
INFO - 2016-09-21 13:37:01 --> Language Class Initialized
INFO - 2016-09-21 13:37:01 --> Loader Class Initialized
INFO - 2016-09-21 13:37:01 --> Helper loaded: url_helper
INFO - 2016-09-21 13:37:01 --> Helper loaded: form_helper
INFO - 2016-09-21 13:37:01 --> Helper loaded: html_helper
INFO - 2016-09-21 13:37:01 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:37:01 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:37:01 --> Database Driver Class Initialized
INFO - 2016-09-21 13:37:01 --> Parser Class Initialized
DEBUG - 2016-09-21 13:37:01 --> Session Class Initialized
INFO - 2016-09-21 13:37:01 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:37:01 --> Session routines successfully run
INFO - 2016-09-21 13:37:01 --> Form Validation Class Initialized
INFO - 2016-09-21 13:37:01 --> Controller Class Initialized
INFO - 2016-09-21 13:37:01 --> Model Class Initialized
INFO - 2016-09-21 13:37:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:37:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:37:01 --> Final output sent to browser
DEBUG - 2016-09-21 13:37:01 --> Total execution time: 0.1574
INFO - 2016-09-21 13:37:14 --> Config Class Initialized
INFO - 2016-09-21 13:37:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:37:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:37:14 --> Utf8 Class Initialized
INFO - 2016-09-21 13:37:14 --> URI Class Initialized
INFO - 2016-09-21 13:37:14 --> Router Class Initialized
INFO - 2016-09-21 13:37:14 --> Output Class Initialized
INFO - 2016-09-21 13:37:14 --> Security Class Initialized
DEBUG - 2016-09-21 13:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:37:14 --> Input Class Initialized
INFO - 2016-09-21 13:37:14 --> Language Class Initialized
ERROR - 2016-09-21 13:37:14 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:37:16 --> Config Class Initialized
INFO - 2016-09-21 13:37:16 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:37:16 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:37:16 --> Utf8 Class Initialized
INFO - 2016-09-21 13:37:16 --> URI Class Initialized
DEBUG - 2016-09-21 13:37:16 --> No URI present. Default controller set.
INFO - 2016-09-21 13:37:16 --> Router Class Initialized
INFO - 2016-09-21 13:37:16 --> Output Class Initialized
INFO - 2016-09-21 13:37:16 --> Security Class Initialized
DEBUG - 2016-09-21 13:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:37:16 --> Input Class Initialized
INFO - 2016-09-21 13:37:16 --> Language Class Initialized
INFO - 2016-09-21 13:37:16 --> Loader Class Initialized
INFO - 2016-09-21 13:37:16 --> Helper loaded: url_helper
INFO - 2016-09-21 13:37:16 --> Helper loaded: form_helper
INFO - 2016-09-21 13:37:16 --> Helper loaded: html_helper
INFO - 2016-09-21 13:37:16 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:37:16 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:37:16 --> Database Driver Class Initialized
INFO - 2016-09-21 13:37:16 --> Parser Class Initialized
DEBUG - 2016-09-21 13:37:16 --> Session Class Initialized
INFO - 2016-09-21 13:37:16 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:37:16 --> Session routines successfully run
INFO - 2016-09-21 13:37:16 --> Form Validation Class Initialized
INFO - 2016-09-21 13:37:16 --> Controller Class Initialized
INFO - 2016-09-21 13:37:16 --> Model Class Initialized
INFO - 2016-09-21 13:37:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:37:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:37:16 --> Final output sent to browser
DEBUG - 2016-09-21 13:37:16 --> Total execution time: 0.1542
INFO - 2016-09-21 13:37:32 --> Config Class Initialized
INFO - 2016-09-21 13:37:32 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:37:32 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:37:32 --> Utf8 Class Initialized
INFO - 2016-09-21 13:37:32 --> URI Class Initialized
INFO - 2016-09-21 13:37:32 --> Router Class Initialized
INFO - 2016-09-21 13:37:32 --> Output Class Initialized
INFO - 2016-09-21 13:37:32 --> Security Class Initialized
DEBUG - 2016-09-21 13:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:37:32 --> Input Class Initialized
INFO - 2016-09-21 13:37:32 --> Language Class Initialized
ERROR - 2016-09-21 13:37:32 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:38:37 --> Config Class Initialized
INFO - 2016-09-21 13:38:37 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:38:37 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:38:37 --> Utf8 Class Initialized
INFO - 2016-09-21 13:38:37 --> URI Class Initialized
INFO - 2016-09-21 13:38:37 --> Router Class Initialized
INFO - 2016-09-21 13:38:37 --> Output Class Initialized
INFO - 2016-09-21 13:38:37 --> Security Class Initialized
DEBUG - 2016-09-21 13:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:38:37 --> Input Class Initialized
INFO - 2016-09-21 13:38:37 --> Language Class Initialized
ERROR - 2016-09-21 13:38:37 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:39:07 --> Config Class Initialized
INFO - 2016-09-21 13:39:07 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:39:07 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:39:07 --> Utf8 Class Initialized
INFO - 2016-09-21 13:39:07 --> URI Class Initialized
INFO - 2016-09-21 13:39:07 --> Router Class Initialized
INFO - 2016-09-21 13:39:07 --> Output Class Initialized
INFO - 2016-09-21 13:39:08 --> Security Class Initialized
DEBUG - 2016-09-21 13:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:39:08 --> Input Class Initialized
INFO - 2016-09-21 13:39:08 --> Language Class Initialized
ERROR - 2016-09-21 13:39:08 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:39:10 --> Config Class Initialized
INFO - 2016-09-21 13:39:10 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:39:10 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:39:10 --> Utf8 Class Initialized
INFO - 2016-09-21 13:39:10 --> URI Class Initialized
INFO - 2016-09-21 13:39:10 --> Router Class Initialized
INFO - 2016-09-21 13:39:10 --> Output Class Initialized
INFO - 2016-09-21 13:39:10 --> Security Class Initialized
DEBUG - 2016-09-21 13:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:39:10 --> Input Class Initialized
INFO - 2016-09-21 13:39:10 --> Language Class Initialized
ERROR - 2016-09-21 13:39:10 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:39:12 --> Config Class Initialized
INFO - 2016-09-21 13:39:12 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:39:12 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:39:12 --> Utf8 Class Initialized
INFO - 2016-09-21 13:39:12 --> URI Class Initialized
DEBUG - 2016-09-21 13:39:12 --> No URI present. Default controller set.
INFO - 2016-09-21 13:39:12 --> Router Class Initialized
INFO - 2016-09-21 13:39:12 --> Output Class Initialized
INFO - 2016-09-21 13:39:12 --> Security Class Initialized
DEBUG - 2016-09-21 13:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:39:12 --> Input Class Initialized
INFO - 2016-09-21 13:39:12 --> Language Class Initialized
INFO - 2016-09-21 13:39:12 --> Loader Class Initialized
INFO - 2016-09-21 13:39:12 --> Helper loaded: url_helper
INFO - 2016-09-21 13:39:12 --> Helper loaded: form_helper
INFO - 2016-09-21 13:39:12 --> Helper loaded: html_helper
INFO - 2016-09-21 13:39:12 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:39:12 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:39:12 --> Database Driver Class Initialized
INFO - 2016-09-21 13:39:12 --> Parser Class Initialized
DEBUG - 2016-09-21 13:39:12 --> Session Class Initialized
INFO - 2016-09-21 13:39:12 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:39:12 --> Session routines successfully run
INFO - 2016-09-21 13:39:12 --> Form Validation Class Initialized
INFO - 2016-09-21 13:39:12 --> Controller Class Initialized
INFO - 2016-09-21 13:39:12 --> Model Class Initialized
INFO - 2016-09-21 13:39:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:39:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:39:12 --> Final output sent to browser
DEBUG - 2016-09-21 13:39:12 --> Total execution time: 0.1558
INFO - 2016-09-21 13:39:14 --> Config Class Initialized
INFO - 2016-09-21 13:39:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:39:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:39:14 --> Utf8 Class Initialized
INFO - 2016-09-21 13:39:14 --> URI Class Initialized
INFO - 2016-09-21 13:39:14 --> Router Class Initialized
INFO - 2016-09-21 13:39:14 --> Output Class Initialized
INFO - 2016-09-21 13:39:14 --> Security Class Initialized
DEBUG - 2016-09-21 13:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:39:14 --> Input Class Initialized
INFO - 2016-09-21 13:39:14 --> Language Class Initialized
ERROR - 2016-09-21 13:39:14 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:39:16 --> Config Class Initialized
INFO - 2016-09-21 13:39:16 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:39:16 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:39:16 --> Utf8 Class Initialized
INFO - 2016-09-21 13:39:16 --> URI Class Initialized
DEBUG - 2016-09-21 13:39:16 --> No URI present. Default controller set.
INFO - 2016-09-21 13:39:16 --> Router Class Initialized
INFO - 2016-09-21 13:39:16 --> Output Class Initialized
INFO - 2016-09-21 13:39:16 --> Security Class Initialized
DEBUG - 2016-09-21 13:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:39:16 --> Input Class Initialized
INFO - 2016-09-21 13:39:16 --> Language Class Initialized
INFO - 2016-09-21 13:39:16 --> Loader Class Initialized
INFO - 2016-09-21 13:39:16 --> Helper loaded: url_helper
INFO - 2016-09-21 13:39:16 --> Helper loaded: form_helper
INFO - 2016-09-21 13:39:16 --> Helper loaded: html_helper
INFO - 2016-09-21 13:39:16 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:39:16 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:39:16 --> Database Driver Class Initialized
INFO - 2016-09-21 13:39:16 --> Parser Class Initialized
DEBUG - 2016-09-21 13:39:16 --> Session Class Initialized
INFO - 2016-09-21 13:39:16 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:39:16 --> Session routines successfully run
INFO - 2016-09-21 13:39:16 --> Form Validation Class Initialized
INFO - 2016-09-21 13:39:16 --> Controller Class Initialized
INFO - 2016-09-21 13:39:16 --> Model Class Initialized
INFO - 2016-09-21 13:39:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:39:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:39:16 --> Final output sent to browser
DEBUG - 2016-09-21 13:39:16 --> Total execution time: 0.1624
INFO - 2016-09-21 13:44:01 --> Config Class Initialized
INFO - 2016-09-21 13:44:01 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:44:01 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:44:01 --> Utf8 Class Initialized
INFO - 2016-09-21 13:44:01 --> URI Class Initialized
DEBUG - 2016-09-21 13:44:01 --> No URI present. Default controller set.
INFO - 2016-09-21 13:44:01 --> Router Class Initialized
INFO - 2016-09-21 13:44:01 --> Output Class Initialized
INFO - 2016-09-21 13:44:01 --> Security Class Initialized
DEBUG - 2016-09-21 13:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:44:01 --> Input Class Initialized
INFO - 2016-09-21 13:44:01 --> Language Class Initialized
INFO - 2016-09-21 13:44:01 --> Loader Class Initialized
INFO - 2016-09-21 13:44:01 --> Helper loaded: url_helper
INFO - 2016-09-21 13:44:01 --> Helper loaded: form_helper
INFO - 2016-09-21 13:44:01 --> Helper loaded: html_helper
INFO - 2016-09-21 13:44:01 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:44:01 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:44:01 --> Database Driver Class Initialized
INFO - 2016-09-21 13:44:01 --> Parser Class Initialized
DEBUG - 2016-09-21 13:44:01 --> Session Class Initialized
INFO - 2016-09-21 13:44:01 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:44:01 --> Session routines successfully run
INFO - 2016-09-21 13:44:01 --> Form Validation Class Initialized
INFO - 2016-09-21 13:44:01 --> Controller Class Initialized
INFO - 2016-09-21 13:44:01 --> Model Class Initialized
INFO - 2016-09-21 13:44:03 --> Config Class Initialized
INFO - 2016-09-21 13:44:03 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:44:03 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:44:03 --> Utf8 Class Initialized
INFO - 2016-09-21 13:44:03 --> URI Class Initialized
DEBUG - 2016-09-21 13:44:03 --> No URI present. Default controller set.
INFO - 2016-09-21 13:44:03 --> Router Class Initialized
INFO - 2016-09-21 13:44:03 --> Output Class Initialized
INFO - 2016-09-21 13:44:03 --> Security Class Initialized
DEBUG - 2016-09-21 13:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:44:03 --> Input Class Initialized
INFO - 2016-09-21 13:44:03 --> Language Class Initialized
INFO - 2016-09-21 13:44:03 --> Loader Class Initialized
INFO - 2016-09-21 13:44:03 --> Helper loaded: url_helper
INFO - 2016-09-21 13:44:03 --> Helper loaded: form_helper
INFO - 2016-09-21 13:44:03 --> Helper loaded: html_helper
INFO - 2016-09-21 13:44:03 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:44:03 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:44:03 --> Database Driver Class Initialized
INFO - 2016-09-21 13:44:03 --> Parser Class Initialized
DEBUG - 2016-09-21 13:44:03 --> Session Class Initialized
INFO - 2016-09-21 13:44:03 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:44:03 --> Session routines successfully run
INFO - 2016-09-21 13:44:03 --> Form Validation Class Initialized
INFO - 2016-09-21 13:44:03 --> Controller Class Initialized
INFO - 2016-09-21 13:44:03 --> Model Class Initialized
INFO - 2016-09-21 13:44:58 --> Config Class Initialized
INFO - 2016-09-21 13:44:58 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:44:58 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:44:58 --> Utf8 Class Initialized
INFO - 2016-09-21 13:44:58 --> URI Class Initialized
DEBUG - 2016-09-21 13:44:58 --> No URI present. Default controller set.
INFO - 2016-09-21 13:44:58 --> Router Class Initialized
INFO - 2016-09-21 13:44:58 --> Output Class Initialized
INFO - 2016-09-21 13:44:58 --> Security Class Initialized
DEBUG - 2016-09-21 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:44:58 --> Input Class Initialized
INFO - 2016-09-21 13:44:58 --> Language Class Initialized
INFO - 2016-09-21 13:44:58 --> Loader Class Initialized
INFO - 2016-09-21 13:44:58 --> Helper loaded: url_helper
INFO - 2016-09-21 13:44:58 --> Helper loaded: form_helper
INFO - 2016-09-21 13:44:58 --> Helper loaded: html_helper
INFO - 2016-09-21 13:44:58 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:44:58 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:44:58 --> Database Driver Class Initialized
INFO - 2016-09-21 13:44:58 --> Parser Class Initialized
DEBUG - 2016-09-21 13:44:58 --> Session Class Initialized
INFO - 2016-09-21 13:44:58 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:44:58 --> Session routines successfully run
INFO - 2016-09-21 13:44:58 --> Form Validation Class Initialized
INFO - 2016-09-21 13:44:58 --> Controller Class Initialized
INFO - 2016-09-21 13:44:58 --> Model Class Initialized
INFO - 2016-09-21 13:45:01 --> Config Class Initialized
INFO - 2016-09-21 13:45:01 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:45:01 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:45:01 --> Utf8 Class Initialized
INFO - 2016-09-21 13:45:01 --> URI Class Initialized
DEBUG - 2016-09-21 13:45:01 --> No URI present. Default controller set.
INFO - 2016-09-21 13:45:01 --> Router Class Initialized
INFO - 2016-09-21 13:45:01 --> Output Class Initialized
INFO - 2016-09-21 13:45:01 --> Security Class Initialized
DEBUG - 2016-09-21 13:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:45:01 --> Input Class Initialized
INFO - 2016-09-21 13:45:01 --> Language Class Initialized
INFO - 2016-09-21 13:45:01 --> Loader Class Initialized
INFO - 2016-09-21 13:45:01 --> Helper loaded: url_helper
INFO - 2016-09-21 13:45:01 --> Helper loaded: form_helper
INFO - 2016-09-21 13:45:01 --> Helper loaded: html_helper
INFO - 2016-09-21 13:45:01 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:45:01 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:45:01 --> Database Driver Class Initialized
INFO - 2016-09-21 13:45:01 --> Parser Class Initialized
DEBUG - 2016-09-21 13:45:01 --> Session Class Initialized
INFO - 2016-09-21 13:45:01 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:45:01 --> Session routines successfully run
INFO - 2016-09-21 13:45:01 --> Form Validation Class Initialized
INFO - 2016-09-21 13:45:01 --> Controller Class Initialized
INFO - 2016-09-21 13:45:01 --> Model Class Initialized
INFO - 2016-09-21 13:45:10 --> Config Class Initialized
INFO - 2016-09-21 13:45:10 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:45:10 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:45:10 --> Utf8 Class Initialized
INFO - 2016-09-21 13:45:10 --> URI Class Initialized
DEBUG - 2016-09-21 13:45:10 --> No URI present. Default controller set.
INFO - 2016-09-21 13:45:10 --> Router Class Initialized
INFO - 2016-09-21 13:45:10 --> Output Class Initialized
INFO - 2016-09-21 13:45:10 --> Security Class Initialized
DEBUG - 2016-09-21 13:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:45:10 --> Input Class Initialized
INFO - 2016-09-21 13:45:10 --> Language Class Initialized
INFO - 2016-09-21 13:45:10 --> Loader Class Initialized
INFO - 2016-09-21 13:45:10 --> Helper loaded: url_helper
INFO - 2016-09-21 13:45:10 --> Helper loaded: form_helper
INFO - 2016-09-21 13:45:10 --> Helper loaded: html_helper
INFO - 2016-09-21 13:45:10 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:45:10 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:45:10 --> Database Driver Class Initialized
INFO - 2016-09-21 13:45:10 --> Parser Class Initialized
DEBUG - 2016-09-21 13:45:10 --> Session Class Initialized
INFO - 2016-09-21 13:45:10 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:45:10 --> Session routines successfully run
INFO - 2016-09-21 13:45:10 --> Form Validation Class Initialized
INFO - 2016-09-21 13:45:10 --> Controller Class Initialized
INFO - 2016-09-21 13:45:10 --> Model Class Initialized
INFO - 2016-09-21 13:45:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:45:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:45:10 --> Final output sent to browser
DEBUG - 2016-09-21 13:45:11 --> Total execution time: 0.1628
INFO - 2016-09-21 13:45:31 --> Config Class Initialized
INFO - 2016-09-21 13:45:31 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:45:31 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:45:31 --> Utf8 Class Initialized
INFO - 2016-09-21 13:45:31 --> URI Class Initialized
INFO - 2016-09-21 13:45:31 --> Router Class Initialized
INFO - 2016-09-21 13:45:31 --> Output Class Initialized
INFO - 2016-09-21 13:45:31 --> Security Class Initialized
DEBUG - 2016-09-21 13:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:45:31 --> Input Class Initialized
INFO - 2016-09-21 13:45:31 --> Language Class Initialized
ERROR - 2016-09-21 13:45:31 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:51:09 --> Config Class Initialized
INFO - 2016-09-21 13:51:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:51:09 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:51:09 --> Utf8 Class Initialized
INFO - 2016-09-21 13:51:09 --> URI Class Initialized
INFO - 2016-09-21 13:51:09 --> Router Class Initialized
INFO - 2016-09-21 13:51:09 --> Output Class Initialized
INFO - 2016-09-21 13:51:09 --> Security Class Initialized
DEBUG - 2016-09-21 13:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:51:09 --> Input Class Initialized
INFO - 2016-09-21 13:51:09 --> Language Class Initialized
ERROR - 2016-09-21 13:51:09 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:52:26 --> Config Class Initialized
INFO - 2016-09-21 13:52:26 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:52:26 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:52:26 --> Utf8 Class Initialized
INFO - 2016-09-21 13:52:26 --> URI Class Initialized
DEBUG - 2016-09-21 13:52:26 --> No URI present. Default controller set.
INFO - 2016-09-21 13:52:26 --> Router Class Initialized
INFO - 2016-09-21 13:52:26 --> Output Class Initialized
INFO - 2016-09-21 13:52:26 --> Security Class Initialized
DEBUG - 2016-09-21 13:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:52:26 --> Input Class Initialized
INFO - 2016-09-21 13:52:26 --> Language Class Initialized
INFO - 2016-09-21 13:52:26 --> Loader Class Initialized
INFO - 2016-09-21 13:52:26 --> Helper loaded: url_helper
INFO - 2016-09-21 13:52:26 --> Helper loaded: form_helper
INFO - 2016-09-21 13:52:26 --> Helper loaded: html_helper
INFO - 2016-09-21 13:52:26 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:52:26 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:52:26 --> Database Driver Class Initialized
INFO - 2016-09-21 13:52:26 --> Parser Class Initialized
DEBUG - 2016-09-21 13:52:26 --> Session Class Initialized
INFO - 2016-09-21 13:52:26 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:52:26 --> Session routines successfully run
INFO - 2016-09-21 13:52:26 --> Form Validation Class Initialized
INFO - 2016-09-21 13:52:26 --> Controller Class Initialized
INFO - 2016-09-21 13:52:26 --> Model Class Initialized
INFO - 2016-09-21 13:52:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:52:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:52:26 --> Final output sent to browser
DEBUG - 2016-09-21 13:52:26 --> Total execution time: 0.1619
INFO - 2016-09-21 13:52:56 --> Config Class Initialized
INFO - 2016-09-21 13:52:56 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:52:56 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:52:56 --> Utf8 Class Initialized
INFO - 2016-09-21 13:52:56 --> URI Class Initialized
INFO - 2016-09-21 13:52:56 --> Router Class Initialized
INFO - 2016-09-21 13:52:56 --> Output Class Initialized
INFO - 2016-09-21 13:52:56 --> Security Class Initialized
DEBUG - 2016-09-21 13:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:52:56 --> Input Class Initialized
INFO - 2016-09-21 13:52:56 --> Language Class Initialized
INFO - 2016-09-21 13:52:56 --> Loader Class Initialized
INFO - 2016-09-21 13:52:56 --> Helper loaded: url_helper
INFO - 2016-09-21 13:52:56 --> Helper loaded: form_helper
INFO - 2016-09-21 13:52:56 --> Helper loaded: html_helper
INFO - 2016-09-21 13:52:56 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:52:56 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:52:56 --> Database Driver Class Initialized
INFO - 2016-09-21 13:52:56 --> Parser Class Initialized
DEBUG - 2016-09-21 13:52:56 --> Session Class Initialized
INFO - 2016-09-21 13:52:56 --> Helper loaded: string_helper
DEBUG - 2016-09-21 13:52:56 --> Session routines successfully run
INFO - 2016-09-21 13:52:56 --> Form Validation Class Initialized
INFO - 2016-09-21 13:52:56 --> Controller Class Initialized
INFO - 2016-09-21 13:52:56 --> Model Class Initialized
INFO - 2016-09-21 13:52:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:52:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:52:56 --> Final output sent to browser
DEBUG - 2016-09-21 13:52:56 --> Total execution time: 0.1578
INFO - 2016-09-21 13:53:13 --> Config Class Initialized
INFO - 2016-09-21 13:53:13 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:53:13 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:53:13 --> Utf8 Class Initialized
INFO - 2016-09-21 13:53:13 --> URI Class Initialized
INFO - 2016-09-21 13:53:13 --> Router Class Initialized
INFO - 2016-09-21 13:53:13 --> Output Class Initialized
INFO - 2016-09-21 13:53:13 --> Security Class Initialized
DEBUG - 2016-09-21 13:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:53:13 --> Input Class Initialized
INFO - 2016-09-21 13:53:13 --> Language Class Initialized
ERROR - 2016-09-21 13:53:13 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:55:36 --> Config Class Initialized
INFO - 2016-09-21 13:55:36 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:55:37 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:55:37 --> Utf8 Class Initialized
INFO - 2016-09-21 13:55:37 --> URI Class Initialized
INFO - 2016-09-21 13:55:37 --> Router Class Initialized
INFO - 2016-09-21 13:55:37 --> Output Class Initialized
INFO - 2016-09-21 13:55:37 --> Security Class Initialized
DEBUG - 2016-09-21 13:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:55:37 --> Input Class Initialized
INFO - 2016-09-21 13:55:37 --> Language Class Initialized
ERROR - 2016-09-21 13:55:37 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 13:58:45 --> Config Class Initialized
INFO - 2016-09-21 13:58:45 --> Hooks Class Initialized
DEBUG - 2016-09-21 13:58:45 --> UTF-8 Support Enabled
INFO - 2016-09-21 13:58:45 --> Utf8 Class Initialized
INFO - 2016-09-21 13:58:45 --> URI Class Initialized
DEBUG - 2016-09-21 13:58:45 --> No URI present. Default controller set.
INFO - 2016-09-21 13:58:45 --> Router Class Initialized
INFO - 2016-09-21 13:58:45 --> Output Class Initialized
INFO - 2016-09-21 13:58:45 --> Security Class Initialized
DEBUG - 2016-09-21 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 13:58:45 --> Input Class Initialized
INFO - 2016-09-21 13:58:45 --> Language Class Initialized
INFO - 2016-09-21 13:58:45 --> Loader Class Initialized
INFO - 2016-09-21 13:58:45 --> Helper loaded: url_helper
INFO - 2016-09-21 13:58:45 --> Helper loaded: form_helper
INFO - 2016-09-21 13:58:45 --> Helper loaded: html_helper
INFO - 2016-09-21 13:58:45 --> Helper loaded: custom_helper
INFO - 2016-09-21 13:58:45 --> Helper loaded: cache_helper
INFO - 2016-09-21 13:58:45 --> Database Driver Class Initialized
INFO - 2016-09-21 13:58:45 --> Parser Class Initialized
DEBUG - 2016-09-21 13:58:45 --> Session Class Initialized
INFO - 2016-09-21 13:58:45 --> Helper loaded: string_helper
ERROR - 2016-09-21 13:58:45 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2016-09-21 13:58:45 --> Session routines successfully run
INFO - 2016-09-21 13:58:45 --> Form Validation Class Initialized
INFO - 2016-09-21 13:58:45 --> Controller Class Initialized
INFO - 2016-09-21 13:58:45 --> Model Class Initialized
INFO - 2016-09-21 13:58:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 13:58:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 13:58:45 --> Final output sent to browser
DEBUG - 2016-09-21 13:58:45 --> Total execution time: 0.1668
INFO - 2016-09-21 14:00:37 --> Config Class Initialized
INFO - 2016-09-21 14:00:37 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:00:37 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:00:37 --> Utf8 Class Initialized
INFO - 2016-09-21 14:00:37 --> URI Class Initialized
DEBUG - 2016-09-21 14:00:37 --> No URI present. Default controller set.
INFO - 2016-09-21 14:00:37 --> Router Class Initialized
INFO - 2016-09-21 14:00:37 --> Output Class Initialized
INFO - 2016-09-21 14:00:37 --> Security Class Initialized
DEBUG - 2016-09-21 14:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:00:37 --> Input Class Initialized
INFO - 2016-09-21 14:00:37 --> Language Class Initialized
INFO - 2016-09-21 14:00:37 --> Loader Class Initialized
INFO - 2016-09-21 14:00:37 --> Helper loaded: url_helper
INFO - 2016-09-21 14:00:37 --> Helper loaded: form_helper
INFO - 2016-09-21 14:00:37 --> Helper loaded: html_helper
INFO - 2016-09-21 14:00:37 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:00:37 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:00:37 --> Database Driver Class Initialized
INFO - 2016-09-21 14:00:37 --> Parser Class Initialized
DEBUG - 2016-09-21 14:00:37 --> Session Class Initialized
INFO - 2016-09-21 14:00:37 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:00:37 --> Session routines successfully run
INFO - 2016-09-21 14:00:37 --> Form Validation Class Initialized
INFO - 2016-09-21 14:00:37 --> Controller Class Initialized
INFO - 2016-09-21 14:00:37 --> Model Class Initialized
INFO - 2016-09-21 14:00:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:00:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:00:37 --> Final output sent to browser
DEBUG - 2016-09-21 14:00:37 --> Total execution time: 0.1688
INFO - 2016-09-21 14:00:38 --> Config Class Initialized
INFO - 2016-09-21 14:00:38 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:00:38 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:00:38 --> Utf8 Class Initialized
INFO - 2016-09-21 14:00:38 --> URI Class Initialized
INFO - 2016-09-21 14:00:38 --> Router Class Initialized
INFO - 2016-09-21 14:00:38 --> Output Class Initialized
INFO - 2016-09-21 14:00:38 --> Security Class Initialized
DEBUG - 2016-09-21 14:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:00:38 --> Input Class Initialized
INFO - 2016-09-21 14:00:38 --> Language Class Initialized
ERROR - 2016-09-21 14:00:38 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:00:41 --> Config Class Initialized
INFO - 2016-09-21 14:00:41 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:00:41 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:00:41 --> Utf8 Class Initialized
INFO - 2016-09-21 14:00:41 --> URI Class Initialized
DEBUG - 2016-09-21 14:00:41 --> No URI present. Default controller set.
INFO - 2016-09-21 14:00:41 --> Router Class Initialized
INFO - 2016-09-21 14:00:41 --> Output Class Initialized
INFO - 2016-09-21 14:00:41 --> Security Class Initialized
DEBUG - 2016-09-21 14:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:00:41 --> Input Class Initialized
INFO - 2016-09-21 14:00:41 --> Language Class Initialized
INFO - 2016-09-21 14:00:41 --> Loader Class Initialized
INFO - 2016-09-21 14:00:41 --> Helper loaded: url_helper
INFO - 2016-09-21 14:00:41 --> Helper loaded: form_helper
INFO - 2016-09-21 14:00:41 --> Helper loaded: html_helper
INFO - 2016-09-21 14:00:41 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:00:41 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:00:41 --> Database Driver Class Initialized
INFO - 2016-09-21 14:00:41 --> Parser Class Initialized
DEBUG - 2016-09-21 14:00:41 --> Session Class Initialized
INFO - 2016-09-21 14:00:41 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:00:41 --> Session routines successfully run
INFO - 2016-09-21 14:00:41 --> Form Validation Class Initialized
INFO - 2016-09-21 14:00:41 --> Controller Class Initialized
INFO - 2016-09-21 14:00:41 --> Model Class Initialized
INFO - 2016-09-21 14:00:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:00:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:00:41 --> Final output sent to browser
DEBUG - 2016-09-21 14:00:41 --> Total execution time: 0.1682
INFO - 2016-09-21 14:00:42 --> Config Class Initialized
INFO - 2016-09-21 14:00:42 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:00:42 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:00:42 --> Utf8 Class Initialized
INFO - 2016-09-21 14:00:42 --> URI Class Initialized
INFO - 2016-09-21 14:00:42 --> Router Class Initialized
INFO - 2016-09-21 14:00:42 --> Output Class Initialized
INFO - 2016-09-21 14:00:42 --> Security Class Initialized
DEBUG - 2016-09-21 14:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:00:42 --> Input Class Initialized
INFO - 2016-09-21 14:00:42 --> Language Class Initialized
ERROR - 2016-09-21 14:00:42 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:01:00 --> Config Class Initialized
INFO - 2016-09-21 14:01:00 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:01:00 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:01:00 --> Utf8 Class Initialized
INFO - 2016-09-21 14:01:00 --> URI Class Initialized
INFO - 2016-09-21 14:01:00 --> Router Class Initialized
INFO - 2016-09-21 14:01:00 --> Output Class Initialized
INFO - 2016-09-21 14:01:00 --> Security Class Initialized
DEBUG - 2016-09-21 14:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:01:00 --> Input Class Initialized
INFO - 2016-09-21 14:01:00 --> Language Class Initialized
ERROR - 2016-09-21 14:01:00 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:09:16 --> Config Class Initialized
INFO - 2016-09-21 14:09:16 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:09:16 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:09:16 --> Utf8 Class Initialized
INFO - 2016-09-21 14:09:16 --> URI Class Initialized
INFO - 2016-09-21 14:09:16 --> Router Class Initialized
INFO - 2016-09-21 14:09:16 --> Output Class Initialized
INFO - 2016-09-21 14:09:16 --> Security Class Initialized
DEBUG - 2016-09-21 14:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:09:16 --> Input Class Initialized
INFO - 2016-09-21 14:09:16 --> Language Class Initialized
ERROR - 2016-09-21 14:09:16 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:09:19 --> Config Class Initialized
INFO - 2016-09-21 14:09:19 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:09:19 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:09:19 --> Utf8 Class Initialized
INFO - 2016-09-21 14:09:19 --> URI Class Initialized
INFO - 2016-09-21 14:09:19 --> Router Class Initialized
INFO - 2016-09-21 14:09:19 --> Output Class Initialized
INFO - 2016-09-21 14:09:19 --> Security Class Initialized
DEBUG - 2016-09-21 14:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:09:19 --> Input Class Initialized
INFO - 2016-09-21 14:09:19 --> Language Class Initialized
ERROR - 2016-09-21 14:09:19 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:09:20 --> Config Class Initialized
INFO - 2016-09-21 14:09:20 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:09:20 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:09:20 --> Utf8 Class Initialized
INFO - 2016-09-21 14:09:20 --> URI Class Initialized
INFO - 2016-09-21 14:09:20 --> Router Class Initialized
INFO - 2016-09-21 14:09:20 --> Output Class Initialized
INFO - 2016-09-21 14:09:20 --> Security Class Initialized
DEBUG - 2016-09-21 14:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:09:20 --> Input Class Initialized
INFO - 2016-09-21 14:09:20 --> Language Class Initialized
ERROR - 2016-09-21 14:09:20 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:09:21 --> Config Class Initialized
INFO - 2016-09-21 14:09:21 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:09:21 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:09:21 --> Utf8 Class Initialized
INFO - 2016-09-21 14:09:21 --> URI Class Initialized
INFO - 2016-09-21 14:09:21 --> Router Class Initialized
INFO - 2016-09-21 14:09:21 --> Output Class Initialized
INFO - 2016-09-21 14:09:21 --> Security Class Initialized
DEBUG - 2016-09-21 14:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:09:21 --> Input Class Initialized
INFO - 2016-09-21 14:09:21 --> Language Class Initialized
ERROR - 2016-09-21 14:09:21 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:09:24 --> Config Class Initialized
INFO - 2016-09-21 14:09:24 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:09:24 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:09:24 --> Utf8 Class Initialized
INFO - 2016-09-21 14:09:24 --> URI Class Initialized
INFO - 2016-09-21 14:09:24 --> Router Class Initialized
INFO - 2016-09-21 14:09:24 --> Output Class Initialized
INFO - 2016-09-21 14:09:24 --> Security Class Initialized
DEBUG - 2016-09-21 14:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:09:24 --> Input Class Initialized
INFO - 2016-09-21 14:09:24 --> Language Class Initialized
INFO - 2016-09-21 14:09:24 --> Loader Class Initialized
INFO - 2016-09-21 14:09:24 --> Helper loaded: url_helper
INFO - 2016-09-21 14:09:24 --> Helper loaded: form_helper
INFO - 2016-09-21 14:09:24 --> Helper loaded: html_helper
INFO - 2016-09-21 14:09:24 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:09:24 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:09:24 --> Database Driver Class Initialized
INFO - 2016-09-21 14:09:24 --> Parser Class Initialized
DEBUG - 2016-09-21 14:09:24 --> Session Class Initialized
INFO - 2016-09-21 14:09:24 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:09:24 --> Session routines successfully run
INFO - 2016-09-21 14:09:24 --> Form Validation Class Initialized
INFO - 2016-09-21 14:09:24 --> Controller Class Initialized
INFO - 2016-09-21 14:09:24 --> Model Class Initialized
INFO - 2016-09-21 14:09:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:09:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:09:24 --> Final output sent to browser
DEBUG - 2016-09-21 14:09:24 --> Total execution time: 0.1701
INFO - 2016-09-21 14:09:28 --> Config Class Initialized
INFO - 2016-09-21 14:09:28 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:09:28 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:09:28 --> Utf8 Class Initialized
INFO - 2016-09-21 14:09:28 --> URI Class Initialized
DEBUG - 2016-09-21 14:09:28 --> No URI present. Default controller set.
INFO - 2016-09-21 14:09:28 --> Router Class Initialized
INFO - 2016-09-21 14:09:28 --> Output Class Initialized
INFO - 2016-09-21 14:09:28 --> Security Class Initialized
DEBUG - 2016-09-21 14:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:09:28 --> Input Class Initialized
INFO - 2016-09-21 14:09:28 --> Language Class Initialized
INFO - 2016-09-21 14:09:28 --> Loader Class Initialized
INFO - 2016-09-21 14:09:28 --> Helper loaded: url_helper
INFO - 2016-09-21 14:09:28 --> Helper loaded: form_helper
INFO - 2016-09-21 14:09:28 --> Helper loaded: html_helper
INFO - 2016-09-21 14:09:28 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:09:28 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:09:28 --> Database Driver Class Initialized
INFO - 2016-09-21 14:09:28 --> Parser Class Initialized
DEBUG - 2016-09-21 14:09:28 --> Session Class Initialized
INFO - 2016-09-21 14:09:28 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:09:28 --> Session routines successfully run
INFO - 2016-09-21 14:09:28 --> Form Validation Class Initialized
INFO - 2016-09-21 14:09:28 --> Controller Class Initialized
INFO - 2016-09-21 14:09:28 --> Model Class Initialized
INFO - 2016-09-21 14:09:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:09:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:09:28 --> Final output sent to browser
DEBUG - 2016-09-21 14:09:28 --> Total execution time: 0.1729
INFO - 2016-09-21 14:09:42 --> Config Class Initialized
INFO - 2016-09-21 14:09:42 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:09:42 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:09:42 --> Utf8 Class Initialized
INFO - 2016-09-21 14:09:42 --> URI Class Initialized
INFO - 2016-09-21 14:09:42 --> Router Class Initialized
INFO - 2016-09-21 14:09:42 --> Output Class Initialized
INFO - 2016-09-21 14:09:42 --> Security Class Initialized
DEBUG - 2016-09-21 14:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:09:42 --> Input Class Initialized
INFO - 2016-09-21 14:09:42 --> Language Class Initialized
ERROR - 2016-09-21 14:09:42 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:11:22 --> Config Class Initialized
INFO - 2016-09-21 14:11:22 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:11:22 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:11:22 --> Utf8 Class Initialized
INFO - 2016-09-21 14:11:22 --> URI Class Initialized
INFO - 2016-09-21 14:11:22 --> Router Class Initialized
INFO - 2016-09-21 14:11:22 --> Output Class Initialized
INFO - 2016-09-21 14:11:22 --> Security Class Initialized
DEBUG - 2016-09-21 14:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:11:22 --> Input Class Initialized
INFO - 2016-09-21 14:11:22 --> Language Class Initialized
ERROR - 2016-09-21 14:11:22 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:11:59 --> Config Class Initialized
INFO - 2016-09-21 14:11:59 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:11:59 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:11:59 --> Utf8 Class Initialized
INFO - 2016-09-21 14:11:59 --> URI Class Initialized
DEBUG - 2016-09-21 14:11:59 --> No URI present. Default controller set.
INFO - 2016-09-21 14:11:59 --> Router Class Initialized
INFO - 2016-09-21 14:11:59 --> Output Class Initialized
INFO - 2016-09-21 14:11:59 --> Security Class Initialized
DEBUG - 2016-09-21 14:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:11:59 --> Input Class Initialized
INFO - 2016-09-21 14:11:59 --> Language Class Initialized
INFO - 2016-09-21 14:11:59 --> Loader Class Initialized
INFO - 2016-09-21 14:11:59 --> Helper loaded: url_helper
INFO - 2016-09-21 14:11:59 --> Helper loaded: form_helper
INFO - 2016-09-21 14:11:59 --> Helper loaded: html_helper
INFO - 2016-09-21 14:11:59 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:11:59 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:11:59 --> Database Driver Class Initialized
INFO - 2016-09-21 14:11:59 --> Parser Class Initialized
DEBUG - 2016-09-21 14:11:59 --> Session Class Initialized
INFO - 2016-09-21 14:11:59 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:11:59 --> Session routines successfully run
INFO - 2016-09-21 14:11:59 --> Form Validation Class Initialized
INFO - 2016-09-21 14:11:59 --> Controller Class Initialized
INFO - 2016-09-21 14:11:59 --> Model Class Initialized
INFO - 2016-09-21 14:11:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:11:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:11:59 --> Final output sent to browser
DEBUG - 2016-09-21 14:11:59 --> Total execution time: 0.1700
INFO - 2016-09-21 14:14:13 --> Config Class Initialized
INFO - 2016-09-21 14:14:13 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:14:13 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:14:13 --> Utf8 Class Initialized
INFO - 2016-09-21 14:14:13 --> URI Class Initialized
INFO - 2016-09-21 14:14:13 --> Router Class Initialized
INFO - 2016-09-21 14:14:13 --> Output Class Initialized
INFO - 2016-09-21 14:14:13 --> Security Class Initialized
DEBUG - 2016-09-21 14:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:14:13 --> Input Class Initialized
INFO - 2016-09-21 14:14:13 --> Language Class Initialized
ERROR - 2016-09-21 14:14:13 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:14:14 --> Config Class Initialized
INFO - 2016-09-21 14:14:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:14:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:14:14 --> Utf8 Class Initialized
INFO - 2016-09-21 14:14:14 --> URI Class Initialized
DEBUG - 2016-09-21 14:14:14 --> No URI present. Default controller set.
INFO - 2016-09-21 14:14:14 --> Router Class Initialized
INFO - 2016-09-21 14:14:14 --> Output Class Initialized
INFO - 2016-09-21 14:14:14 --> Security Class Initialized
DEBUG - 2016-09-21 14:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:14:14 --> Input Class Initialized
INFO - 2016-09-21 14:14:14 --> Language Class Initialized
INFO - 2016-09-21 14:14:14 --> Loader Class Initialized
INFO - 2016-09-21 14:14:14 --> Helper loaded: url_helper
INFO - 2016-09-21 14:14:14 --> Helper loaded: form_helper
INFO - 2016-09-21 14:14:14 --> Helper loaded: html_helper
INFO - 2016-09-21 14:14:14 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:14:14 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:14:14 --> Database Driver Class Initialized
INFO - 2016-09-21 14:14:14 --> Parser Class Initialized
DEBUG - 2016-09-21 14:14:14 --> Session Class Initialized
INFO - 2016-09-21 14:14:14 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:14:14 --> Session routines successfully run
INFO - 2016-09-21 14:14:14 --> Form Validation Class Initialized
INFO - 2016-09-21 14:14:14 --> Controller Class Initialized
INFO - 2016-09-21 14:14:14 --> Model Class Initialized
INFO - 2016-09-21 14:14:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:14:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:14:14 --> Final output sent to browser
DEBUG - 2016-09-21 14:14:14 --> Total execution time: 0.2787
INFO - 2016-09-21 14:14:21 --> Config Class Initialized
INFO - 2016-09-21 14:14:21 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:14:21 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:14:21 --> Utf8 Class Initialized
INFO - 2016-09-21 14:14:21 --> URI Class Initialized
INFO - 2016-09-21 14:14:21 --> Router Class Initialized
INFO - 2016-09-21 14:14:21 --> Output Class Initialized
INFO - 2016-09-21 14:14:21 --> Security Class Initialized
DEBUG - 2016-09-21 14:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:14:21 --> Input Class Initialized
INFO - 2016-09-21 14:14:21 --> Language Class Initialized
ERROR - 2016-09-21 14:14:21 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:14:23 --> Config Class Initialized
INFO - 2016-09-21 14:14:23 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:14:23 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:14:23 --> Utf8 Class Initialized
INFO - 2016-09-21 14:14:23 --> URI Class Initialized
DEBUG - 2016-09-21 14:14:23 --> No URI present. Default controller set.
INFO - 2016-09-21 14:14:23 --> Router Class Initialized
INFO - 2016-09-21 14:14:23 --> Output Class Initialized
INFO - 2016-09-21 14:14:23 --> Security Class Initialized
DEBUG - 2016-09-21 14:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:14:23 --> Input Class Initialized
INFO - 2016-09-21 14:14:23 --> Language Class Initialized
INFO - 2016-09-21 14:14:23 --> Loader Class Initialized
INFO - 2016-09-21 14:14:23 --> Helper loaded: url_helper
INFO - 2016-09-21 14:14:23 --> Helper loaded: form_helper
INFO - 2016-09-21 14:14:23 --> Helper loaded: html_helper
INFO - 2016-09-21 14:14:23 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:14:23 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:14:23 --> Database Driver Class Initialized
INFO - 2016-09-21 14:14:23 --> Parser Class Initialized
DEBUG - 2016-09-21 14:14:23 --> Session Class Initialized
INFO - 2016-09-21 14:14:23 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:14:23 --> Session routines successfully run
INFO - 2016-09-21 14:14:23 --> Form Validation Class Initialized
INFO - 2016-09-21 14:14:23 --> Controller Class Initialized
INFO - 2016-09-21 14:14:23 --> Model Class Initialized
INFO - 2016-09-21 14:14:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:14:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:14:23 --> Final output sent to browser
DEBUG - 2016-09-21 14:14:23 --> Total execution time: 0.1755
INFO - 2016-09-21 14:16:40 --> Config Class Initialized
INFO - 2016-09-21 14:16:40 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:16:40 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:16:40 --> Utf8 Class Initialized
INFO - 2016-09-21 14:16:40 --> URI Class Initialized
INFO - 2016-09-21 14:16:40 --> Router Class Initialized
INFO - 2016-09-21 14:16:40 --> Output Class Initialized
INFO - 2016-09-21 14:16:40 --> Security Class Initialized
DEBUG - 2016-09-21 14:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:16:40 --> Input Class Initialized
INFO - 2016-09-21 14:16:40 --> Language Class Initialized
ERROR - 2016-09-21 14:16:40 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:16:45 --> Config Class Initialized
INFO - 2016-09-21 14:16:45 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:16:45 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:16:45 --> Utf8 Class Initialized
INFO - 2016-09-21 14:16:45 --> URI Class Initialized
DEBUG - 2016-09-21 14:16:45 --> No URI present. Default controller set.
INFO - 2016-09-21 14:16:45 --> Router Class Initialized
INFO - 2016-09-21 14:16:45 --> Output Class Initialized
INFO - 2016-09-21 14:16:45 --> Security Class Initialized
DEBUG - 2016-09-21 14:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:16:45 --> Input Class Initialized
INFO - 2016-09-21 14:16:45 --> Language Class Initialized
INFO - 2016-09-21 14:16:45 --> Loader Class Initialized
INFO - 2016-09-21 14:16:45 --> Helper loaded: url_helper
INFO - 2016-09-21 14:16:45 --> Helper loaded: form_helper
INFO - 2016-09-21 14:16:45 --> Helper loaded: html_helper
INFO - 2016-09-21 14:16:45 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:16:45 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:16:45 --> Database Driver Class Initialized
INFO - 2016-09-21 14:16:45 --> Parser Class Initialized
DEBUG - 2016-09-21 14:16:45 --> Session Class Initialized
INFO - 2016-09-21 14:16:45 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:16:45 --> Session routines successfully run
INFO - 2016-09-21 14:16:45 --> Form Validation Class Initialized
INFO - 2016-09-21 14:16:45 --> Controller Class Initialized
INFO - 2016-09-21 14:16:45 --> Model Class Initialized
INFO - 2016-09-21 14:16:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:16:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:16:45 --> Final output sent to browser
DEBUG - 2016-09-21 14:16:45 --> Total execution time: 0.1758
INFO - 2016-09-21 14:17:49 --> Config Class Initialized
INFO - 2016-09-21 14:17:49 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:17:49 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:17:49 --> Utf8 Class Initialized
INFO - 2016-09-21 14:17:49 --> URI Class Initialized
INFO - 2016-09-21 14:17:49 --> Router Class Initialized
INFO - 2016-09-21 14:17:49 --> Output Class Initialized
INFO - 2016-09-21 14:17:49 --> Security Class Initialized
DEBUG - 2016-09-21 14:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:17:49 --> Input Class Initialized
INFO - 2016-09-21 14:17:49 --> Language Class Initialized
ERROR - 2016-09-21 14:17:49 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:19:49 --> Config Class Initialized
INFO - 2016-09-21 14:19:49 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:19:49 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:19:49 --> Utf8 Class Initialized
INFO - 2016-09-21 14:19:49 --> URI Class Initialized
DEBUG - 2016-09-21 14:19:49 --> No URI present. Default controller set.
INFO - 2016-09-21 14:19:49 --> Router Class Initialized
INFO - 2016-09-21 14:19:49 --> Output Class Initialized
INFO - 2016-09-21 14:19:49 --> Security Class Initialized
DEBUG - 2016-09-21 14:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:19:49 --> Input Class Initialized
INFO - 2016-09-21 14:19:49 --> Language Class Initialized
INFO - 2016-09-21 14:19:49 --> Loader Class Initialized
INFO - 2016-09-21 14:19:49 --> Helper loaded: url_helper
INFO - 2016-09-21 14:19:49 --> Helper loaded: form_helper
INFO - 2016-09-21 14:19:49 --> Helper loaded: html_helper
INFO - 2016-09-21 14:19:49 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:19:49 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:19:49 --> Database Driver Class Initialized
INFO - 2016-09-21 14:19:49 --> Parser Class Initialized
DEBUG - 2016-09-21 14:19:49 --> Session Class Initialized
INFO - 2016-09-21 14:19:49 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:19:49 --> Session routines successfully run
INFO - 2016-09-21 14:19:49 --> Form Validation Class Initialized
INFO - 2016-09-21 14:19:49 --> Controller Class Initialized
INFO - 2016-09-21 14:19:49 --> Model Class Initialized
INFO - 2016-09-21 14:19:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:19:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:19:49 --> Final output sent to browser
DEBUG - 2016-09-21 14:19:49 --> Total execution time: 0.1742
INFO - 2016-09-21 14:20:05 --> Config Class Initialized
INFO - 2016-09-21 14:20:05 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:20:05 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:20:05 --> Utf8 Class Initialized
INFO - 2016-09-21 14:20:05 --> URI Class Initialized
INFO - 2016-09-21 14:20:05 --> Router Class Initialized
INFO - 2016-09-21 14:20:05 --> Output Class Initialized
INFO - 2016-09-21 14:20:05 --> Security Class Initialized
DEBUG - 2016-09-21 14:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:20:05 --> Input Class Initialized
INFO - 2016-09-21 14:20:05 --> Language Class Initialized
ERROR - 2016-09-21 14:20:05 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:26:12 --> Config Class Initialized
INFO - 2016-09-21 14:26:12 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:26:12 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:26:12 --> Utf8 Class Initialized
INFO - 2016-09-21 14:26:12 --> URI Class Initialized
INFO - 2016-09-21 14:26:12 --> Router Class Initialized
INFO - 2016-09-21 14:26:12 --> Output Class Initialized
INFO - 2016-09-21 14:26:12 --> Security Class Initialized
DEBUG - 2016-09-21 14:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:26:12 --> Input Class Initialized
INFO - 2016-09-21 14:26:12 --> Language Class Initialized
ERROR - 2016-09-21 14:26:12 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:26:15 --> Config Class Initialized
INFO - 2016-09-21 14:26:15 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:26:15 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:26:15 --> Utf8 Class Initialized
INFO - 2016-09-21 14:26:15 --> URI Class Initialized
DEBUG - 2016-09-21 14:26:15 --> No URI present. Default controller set.
INFO - 2016-09-21 14:26:15 --> Router Class Initialized
INFO - 2016-09-21 14:26:15 --> Output Class Initialized
INFO - 2016-09-21 14:26:15 --> Security Class Initialized
DEBUG - 2016-09-21 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:26:15 --> Input Class Initialized
INFO - 2016-09-21 14:26:15 --> Language Class Initialized
INFO - 2016-09-21 14:26:15 --> Loader Class Initialized
INFO - 2016-09-21 14:26:15 --> Helper loaded: url_helper
INFO - 2016-09-21 14:26:15 --> Helper loaded: form_helper
INFO - 2016-09-21 14:26:15 --> Helper loaded: html_helper
INFO - 2016-09-21 14:26:15 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:26:15 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:26:15 --> Database Driver Class Initialized
INFO - 2016-09-21 14:26:15 --> Parser Class Initialized
DEBUG - 2016-09-21 14:26:15 --> Session Class Initialized
INFO - 2016-09-21 14:26:15 --> Helper loaded: string_helper
ERROR - 2016-09-21 14:26:15 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2016-09-21 14:26:15 --> Session routines successfully run
INFO - 2016-09-21 14:26:15 --> Form Validation Class Initialized
INFO - 2016-09-21 14:26:15 --> Controller Class Initialized
INFO - 2016-09-21 14:26:15 --> Model Class Initialized
INFO - 2016-09-21 14:26:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:26:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:26:16 --> Final output sent to browser
DEBUG - 2016-09-21 14:26:16 --> Total execution time: 0.1897
INFO - 2016-09-21 14:26:31 --> Config Class Initialized
INFO - 2016-09-21 14:26:31 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:26:31 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:26:31 --> Utf8 Class Initialized
INFO - 2016-09-21 14:26:31 --> URI Class Initialized
INFO - 2016-09-21 14:26:31 --> Router Class Initialized
INFO - 2016-09-21 14:26:31 --> Output Class Initialized
INFO - 2016-09-21 14:26:31 --> Security Class Initialized
DEBUG - 2016-09-21 14:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:26:31 --> Input Class Initialized
INFO - 2016-09-21 14:26:31 --> Language Class Initialized
ERROR - 2016-09-21 14:26:31 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:28:16 --> Config Class Initialized
INFO - 2016-09-21 14:28:16 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:28:16 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:28:16 --> Utf8 Class Initialized
INFO - 2016-09-21 14:28:16 --> URI Class Initialized
INFO - 2016-09-21 14:28:16 --> Router Class Initialized
INFO - 2016-09-21 14:28:16 --> Output Class Initialized
INFO - 2016-09-21 14:28:16 --> Security Class Initialized
DEBUG - 2016-09-21 14:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:28:16 --> Input Class Initialized
INFO - 2016-09-21 14:28:16 --> Language Class Initialized
ERROR - 2016-09-21 14:28:16 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:29:26 --> Config Class Initialized
INFO - 2016-09-21 14:29:26 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:29:26 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:29:26 --> Utf8 Class Initialized
INFO - 2016-09-21 14:29:26 --> URI Class Initialized
INFO - 2016-09-21 14:29:26 --> Router Class Initialized
INFO - 2016-09-21 14:29:26 --> Output Class Initialized
INFO - 2016-09-21 14:29:26 --> Security Class Initialized
DEBUG - 2016-09-21 14:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:29:26 --> Input Class Initialized
INFO - 2016-09-21 14:29:26 --> Language Class Initialized
ERROR - 2016-09-21 14:29:26 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:29:28 --> Config Class Initialized
INFO - 2016-09-21 14:29:28 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:29:28 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:29:28 --> Utf8 Class Initialized
INFO - 2016-09-21 14:29:28 --> URI Class Initialized
DEBUG - 2016-09-21 14:29:28 --> No URI present. Default controller set.
INFO - 2016-09-21 14:29:28 --> Router Class Initialized
INFO - 2016-09-21 14:29:28 --> Output Class Initialized
INFO - 2016-09-21 14:29:28 --> Security Class Initialized
DEBUG - 2016-09-21 14:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:29:28 --> Input Class Initialized
INFO - 2016-09-21 14:29:28 --> Language Class Initialized
INFO - 2016-09-21 14:29:28 --> Loader Class Initialized
INFO - 2016-09-21 14:29:28 --> Helper loaded: url_helper
INFO - 2016-09-21 14:29:28 --> Helper loaded: form_helper
INFO - 2016-09-21 14:29:28 --> Helper loaded: html_helper
INFO - 2016-09-21 14:29:28 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:29:28 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:29:28 --> Database Driver Class Initialized
INFO - 2016-09-21 14:29:28 --> Parser Class Initialized
DEBUG - 2016-09-21 14:29:28 --> Session Class Initialized
INFO - 2016-09-21 14:29:28 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:29:28 --> Session routines successfully run
INFO - 2016-09-21 14:29:28 --> Form Validation Class Initialized
INFO - 2016-09-21 14:29:28 --> Controller Class Initialized
INFO - 2016-09-21 14:29:28 --> Model Class Initialized
INFO - 2016-09-21 14:29:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:29:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:29:28 --> Final output sent to browser
DEBUG - 2016-09-21 14:29:28 --> Total execution time: 0.3291
INFO - 2016-09-21 14:29:29 --> Config Class Initialized
INFO - 2016-09-21 14:29:29 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:29:29 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:29:29 --> Utf8 Class Initialized
INFO - 2016-09-21 14:29:29 --> URI Class Initialized
DEBUG - 2016-09-21 14:29:29 --> No URI present. Default controller set.
INFO - 2016-09-21 14:29:29 --> Router Class Initialized
INFO - 2016-09-21 14:29:29 --> Output Class Initialized
INFO - 2016-09-21 14:29:29 --> Security Class Initialized
DEBUG - 2016-09-21 14:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:29:29 --> Input Class Initialized
INFO - 2016-09-21 14:29:29 --> Language Class Initialized
INFO - 2016-09-21 14:29:29 --> Loader Class Initialized
INFO - 2016-09-21 14:29:29 --> Helper loaded: url_helper
INFO - 2016-09-21 14:29:29 --> Helper loaded: form_helper
INFO - 2016-09-21 14:29:29 --> Helper loaded: html_helper
INFO - 2016-09-21 14:29:29 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:29:29 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:29:29 --> Database Driver Class Initialized
INFO - 2016-09-21 14:29:29 --> Parser Class Initialized
DEBUG - 2016-09-21 14:29:29 --> Session Class Initialized
INFO - 2016-09-21 14:29:29 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:29:29 --> Session routines successfully run
INFO - 2016-09-21 14:29:29 --> Form Validation Class Initialized
INFO - 2016-09-21 14:29:29 --> Controller Class Initialized
INFO - 2016-09-21 14:29:29 --> Model Class Initialized
INFO - 2016-09-21 14:29:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:29:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:29:29 --> Final output sent to browser
DEBUG - 2016-09-21 14:29:29 --> Total execution time: 0.1862
INFO - 2016-09-21 14:29:31 --> Config Class Initialized
INFO - 2016-09-21 14:29:31 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:29:31 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:29:31 --> Utf8 Class Initialized
INFO - 2016-09-21 14:29:31 --> URI Class Initialized
DEBUG - 2016-09-21 14:29:31 --> No URI present. Default controller set.
INFO - 2016-09-21 14:29:31 --> Router Class Initialized
INFO - 2016-09-21 14:29:31 --> Output Class Initialized
INFO - 2016-09-21 14:29:31 --> Security Class Initialized
DEBUG - 2016-09-21 14:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:29:31 --> Input Class Initialized
INFO - 2016-09-21 14:29:31 --> Language Class Initialized
INFO - 2016-09-21 14:29:31 --> Loader Class Initialized
INFO - 2016-09-21 14:29:31 --> Helper loaded: url_helper
INFO - 2016-09-21 14:29:31 --> Helper loaded: form_helper
INFO - 2016-09-21 14:29:31 --> Helper loaded: html_helper
INFO - 2016-09-21 14:29:31 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:29:31 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:29:31 --> Database Driver Class Initialized
INFO - 2016-09-21 14:29:31 --> Parser Class Initialized
DEBUG - 2016-09-21 14:29:31 --> Session Class Initialized
INFO - 2016-09-21 14:29:31 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:29:31 --> Session routines successfully run
INFO - 2016-09-21 14:29:31 --> Form Validation Class Initialized
INFO - 2016-09-21 14:29:31 --> Controller Class Initialized
INFO - 2016-09-21 14:29:31 --> Model Class Initialized
INFO - 2016-09-21 14:29:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:29:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:29:31 --> Final output sent to browser
DEBUG - 2016-09-21 14:29:31 --> Total execution time: 0.1788
INFO - 2016-09-21 14:31:05 --> Config Class Initialized
INFO - 2016-09-21 14:31:05 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:31:05 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:31:05 --> Utf8 Class Initialized
INFO - 2016-09-21 14:31:05 --> URI Class Initialized
DEBUG - 2016-09-21 14:31:05 --> No URI present. Default controller set.
INFO - 2016-09-21 14:31:05 --> Router Class Initialized
INFO - 2016-09-21 14:31:05 --> Output Class Initialized
INFO - 2016-09-21 14:31:05 --> Security Class Initialized
DEBUG - 2016-09-21 14:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:31:05 --> Input Class Initialized
INFO - 2016-09-21 14:31:05 --> Language Class Initialized
INFO - 2016-09-21 14:31:05 --> Loader Class Initialized
INFO - 2016-09-21 14:31:05 --> Helper loaded: url_helper
INFO - 2016-09-21 14:31:05 --> Helper loaded: form_helper
INFO - 2016-09-21 14:31:05 --> Helper loaded: html_helper
INFO - 2016-09-21 14:31:05 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:31:05 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:31:05 --> Database Driver Class Initialized
INFO - 2016-09-21 14:31:05 --> Parser Class Initialized
DEBUG - 2016-09-21 14:31:05 --> Session Class Initialized
INFO - 2016-09-21 14:31:05 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:31:05 --> Session routines successfully run
INFO - 2016-09-21 14:31:05 --> Form Validation Class Initialized
INFO - 2016-09-21 14:31:05 --> Controller Class Initialized
INFO - 2016-09-21 14:31:06 --> Model Class Initialized
INFO - 2016-09-21 14:31:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:31:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:31:06 --> Final output sent to browser
DEBUG - 2016-09-21 14:31:06 --> Total execution time: 0.1831
INFO - 2016-09-21 14:31:17 --> Config Class Initialized
INFO - 2016-09-21 14:31:17 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:31:17 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:31:17 --> Utf8 Class Initialized
INFO - 2016-09-21 14:31:17 --> URI Class Initialized
INFO - 2016-09-21 14:31:17 --> Router Class Initialized
INFO - 2016-09-21 14:31:17 --> Output Class Initialized
INFO - 2016-09-21 14:31:17 --> Security Class Initialized
DEBUG - 2016-09-21 14:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:31:17 --> Input Class Initialized
INFO - 2016-09-21 14:31:17 --> Language Class Initialized
ERROR - 2016-09-21 14:31:17 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:31:27 --> Config Class Initialized
INFO - 2016-09-21 14:31:27 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:31:27 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:31:27 --> Utf8 Class Initialized
INFO - 2016-09-21 14:31:27 --> URI Class Initialized
INFO - 2016-09-21 14:31:27 --> Router Class Initialized
INFO - 2016-09-21 14:31:27 --> Output Class Initialized
INFO - 2016-09-21 14:31:27 --> Security Class Initialized
DEBUG - 2016-09-21 14:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:31:27 --> Input Class Initialized
INFO - 2016-09-21 14:31:27 --> Language Class Initialized
ERROR - 2016-09-21 14:31:27 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:31:58 --> Config Class Initialized
INFO - 2016-09-21 14:31:58 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:31:58 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:31:58 --> Utf8 Class Initialized
INFO - 2016-09-21 14:31:58 --> URI Class Initialized
DEBUG - 2016-09-21 14:31:58 --> No URI present. Default controller set.
INFO - 2016-09-21 14:31:58 --> Router Class Initialized
INFO - 2016-09-21 14:31:58 --> Output Class Initialized
INFO - 2016-09-21 14:31:58 --> Security Class Initialized
DEBUG - 2016-09-21 14:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:31:58 --> Input Class Initialized
INFO - 2016-09-21 14:31:58 --> Language Class Initialized
INFO - 2016-09-21 14:31:58 --> Loader Class Initialized
INFO - 2016-09-21 14:31:58 --> Helper loaded: url_helper
INFO - 2016-09-21 14:31:58 --> Helper loaded: form_helper
INFO - 2016-09-21 14:31:58 --> Helper loaded: html_helper
INFO - 2016-09-21 14:31:58 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:31:58 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:31:58 --> Database Driver Class Initialized
INFO - 2016-09-21 14:31:58 --> Parser Class Initialized
DEBUG - 2016-09-21 14:31:58 --> Session Class Initialized
INFO - 2016-09-21 14:31:58 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:31:58 --> Session routines successfully run
INFO - 2016-09-21 14:31:58 --> Form Validation Class Initialized
INFO - 2016-09-21 14:31:58 --> Controller Class Initialized
INFO - 2016-09-21 14:31:58 --> Model Class Initialized
INFO - 2016-09-21 14:31:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:31:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:31:58 --> Final output sent to browser
DEBUG - 2016-09-21 14:31:58 --> Total execution time: 0.1856
INFO - 2016-09-21 14:33:51 --> Config Class Initialized
INFO - 2016-09-21 14:33:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:33:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:33:51 --> Utf8 Class Initialized
INFO - 2016-09-21 14:33:51 --> URI Class Initialized
INFO - 2016-09-21 14:33:51 --> Router Class Initialized
INFO - 2016-09-21 14:33:51 --> Output Class Initialized
INFO - 2016-09-21 14:33:51 --> Security Class Initialized
DEBUG - 2016-09-21 14:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:33:51 --> Input Class Initialized
INFO - 2016-09-21 14:33:51 --> Language Class Initialized
ERROR - 2016-09-21 14:33:51 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:34:09 --> Config Class Initialized
INFO - 2016-09-21 14:34:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:34:09 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:34:09 --> Utf8 Class Initialized
INFO - 2016-09-21 14:34:09 --> URI Class Initialized
INFO - 2016-09-21 14:34:09 --> Router Class Initialized
INFO - 2016-09-21 14:34:09 --> Output Class Initialized
INFO - 2016-09-21 14:34:09 --> Security Class Initialized
DEBUG - 2016-09-21 14:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:34:09 --> Input Class Initialized
INFO - 2016-09-21 14:34:09 --> Language Class Initialized
ERROR - 2016-09-21 14:34:09 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:34:14 --> Config Class Initialized
INFO - 2016-09-21 14:34:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:34:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:34:14 --> Utf8 Class Initialized
INFO - 2016-09-21 14:34:14 --> URI Class Initialized
INFO - 2016-09-21 14:34:14 --> Router Class Initialized
INFO - 2016-09-21 14:34:14 --> Output Class Initialized
INFO - 2016-09-21 14:34:14 --> Security Class Initialized
DEBUG - 2016-09-21 14:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:34:14 --> Input Class Initialized
INFO - 2016-09-21 14:34:14 --> Language Class Initialized
ERROR - 2016-09-21 14:34:14 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:38:37 --> Config Class Initialized
INFO - 2016-09-21 14:38:37 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:38:37 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:38:37 --> Utf8 Class Initialized
INFO - 2016-09-21 14:38:37 --> URI Class Initialized
INFO - 2016-09-21 14:38:37 --> Router Class Initialized
INFO - 2016-09-21 14:38:37 --> Output Class Initialized
INFO - 2016-09-21 14:38:37 --> Security Class Initialized
DEBUG - 2016-09-21 14:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:38:37 --> Input Class Initialized
INFO - 2016-09-21 14:38:37 --> Language Class Initialized
ERROR - 2016-09-21 14:38:37 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:38:48 --> Config Class Initialized
INFO - 2016-09-21 14:38:48 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:38:48 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:38:48 --> Utf8 Class Initialized
INFO - 2016-09-21 14:38:48 --> URI Class Initialized
INFO - 2016-09-21 14:38:48 --> Router Class Initialized
INFO - 2016-09-21 14:38:48 --> Output Class Initialized
INFO - 2016-09-21 14:38:48 --> Security Class Initialized
DEBUG - 2016-09-21 14:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:38:48 --> Input Class Initialized
INFO - 2016-09-21 14:38:48 --> Language Class Initialized
ERROR - 2016-09-21 14:38:48 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:39:25 --> Config Class Initialized
INFO - 2016-09-21 14:39:25 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:39:25 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:39:25 --> Utf8 Class Initialized
INFO - 2016-09-21 14:39:25 --> URI Class Initialized
INFO - 2016-09-21 14:39:25 --> Router Class Initialized
INFO - 2016-09-21 14:39:25 --> Output Class Initialized
INFO - 2016-09-21 14:39:25 --> Security Class Initialized
DEBUG - 2016-09-21 14:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:39:25 --> Input Class Initialized
INFO - 2016-09-21 14:39:25 --> Language Class Initialized
ERROR - 2016-09-21 14:39:25 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:39:29 --> Config Class Initialized
INFO - 2016-09-21 14:39:29 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:39:29 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:39:29 --> Utf8 Class Initialized
INFO - 2016-09-21 14:39:29 --> URI Class Initialized
INFO - 2016-09-21 14:39:29 --> Router Class Initialized
INFO - 2016-09-21 14:39:29 --> Output Class Initialized
INFO - 2016-09-21 14:39:29 --> Security Class Initialized
DEBUG - 2016-09-21 14:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:39:29 --> Input Class Initialized
INFO - 2016-09-21 14:39:29 --> Language Class Initialized
ERROR - 2016-09-21 14:39:29 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:39:39 --> Config Class Initialized
INFO - 2016-09-21 14:39:39 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:39:39 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:39:39 --> Utf8 Class Initialized
INFO - 2016-09-21 14:39:39 --> URI Class Initialized
INFO - 2016-09-21 14:39:39 --> Router Class Initialized
INFO - 2016-09-21 14:39:39 --> Output Class Initialized
INFO - 2016-09-21 14:39:39 --> Security Class Initialized
DEBUG - 2016-09-21 14:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:39:39 --> Input Class Initialized
INFO - 2016-09-21 14:39:39 --> Language Class Initialized
ERROR - 2016-09-21 14:39:39 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:39:41 --> Config Class Initialized
INFO - 2016-09-21 14:39:41 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:39:41 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:39:41 --> Utf8 Class Initialized
INFO - 2016-09-21 14:39:41 --> URI Class Initialized
INFO - 2016-09-21 14:39:41 --> Router Class Initialized
INFO - 2016-09-21 14:39:41 --> Output Class Initialized
INFO - 2016-09-21 14:39:41 --> Security Class Initialized
DEBUG - 2016-09-21 14:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:39:41 --> Input Class Initialized
INFO - 2016-09-21 14:39:41 --> Language Class Initialized
ERROR - 2016-09-21 14:39:41 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:40:15 --> Config Class Initialized
INFO - 2016-09-21 14:40:15 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:40:15 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:40:15 --> Utf8 Class Initialized
INFO - 2016-09-21 14:40:15 --> URI Class Initialized
INFO - 2016-09-21 14:40:15 --> Router Class Initialized
INFO - 2016-09-21 14:40:15 --> Output Class Initialized
INFO - 2016-09-21 14:40:15 --> Security Class Initialized
DEBUG - 2016-09-21 14:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:40:15 --> Input Class Initialized
INFO - 2016-09-21 14:40:15 --> Language Class Initialized
ERROR - 2016-09-21 14:40:15 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:47:30 --> Config Class Initialized
INFO - 2016-09-21 14:47:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:47:30 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:47:30 --> Utf8 Class Initialized
INFO - 2016-09-21 14:47:30 --> URI Class Initialized
INFO - 2016-09-21 14:47:30 --> Router Class Initialized
INFO - 2016-09-21 14:47:30 --> Output Class Initialized
INFO - 2016-09-21 14:47:30 --> Security Class Initialized
DEBUG - 2016-09-21 14:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:47:30 --> Input Class Initialized
INFO - 2016-09-21 14:47:30 --> Language Class Initialized
ERROR - 2016-09-21 14:47:30 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:48:48 --> Config Class Initialized
INFO - 2016-09-21 14:48:48 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:48:48 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:48:48 --> Utf8 Class Initialized
INFO - 2016-09-21 14:48:48 --> URI Class Initialized
INFO - 2016-09-21 14:48:48 --> Router Class Initialized
INFO - 2016-09-21 14:48:48 --> Output Class Initialized
INFO - 2016-09-21 14:48:48 --> Security Class Initialized
DEBUG - 2016-09-21 14:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:48:48 --> Input Class Initialized
INFO - 2016-09-21 14:48:48 --> Language Class Initialized
ERROR - 2016-09-21 14:48:48 --> 404 Page Not Found: Schedullo/admin
INFO - 2016-09-21 14:48:58 --> Config Class Initialized
INFO - 2016-09-21 14:48:58 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:48:58 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:48:58 --> Utf8 Class Initialized
INFO - 2016-09-21 14:48:58 --> URI Class Initialized
DEBUG - 2016-09-21 14:48:58 --> No URI present. Default controller set.
INFO - 2016-09-21 14:48:58 --> Router Class Initialized
INFO - 2016-09-21 14:48:58 --> Output Class Initialized
INFO - 2016-09-21 14:48:58 --> Security Class Initialized
DEBUG - 2016-09-21 14:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:48:58 --> Input Class Initialized
INFO - 2016-09-21 14:48:58 --> Language Class Initialized
INFO - 2016-09-21 14:48:58 --> Loader Class Initialized
INFO - 2016-09-21 14:48:58 --> Helper loaded: url_helper
INFO - 2016-09-21 14:48:58 --> Helper loaded: form_helper
INFO - 2016-09-21 14:48:58 --> Helper loaded: html_helper
INFO - 2016-09-21 14:48:58 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:48:58 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:48:58 --> Database Driver Class Initialized
INFO - 2016-09-21 14:48:58 --> Parser Class Initialized
DEBUG - 2016-09-21 14:48:58 --> Session Class Initialized
INFO - 2016-09-21 14:48:58 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:48:58 --> Session routines successfully run
INFO - 2016-09-21 14:48:58 --> Form Validation Class Initialized
INFO - 2016-09-21 14:48:58 --> Controller Class Initialized
INFO - 2016-09-21 14:48:58 --> Model Class Initialized
INFO - 2016-09-21 14:48:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:48:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:48:58 --> Final output sent to browser
DEBUG - 2016-09-21 14:48:58 --> Total execution time: 0.1875
INFO - 2016-09-21 14:49:11 --> Config Class Initialized
INFO - 2016-09-21 14:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:49:11 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:49:11 --> Utf8 Class Initialized
INFO - 2016-09-21 14:49:11 --> URI Class Initialized
DEBUG - 2016-09-21 14:49:11 --> No URI present. Default controller set.
INFO - 2016-09-21 14:49:11 --> Router Class Initialized
INFO - 2016-09-21 14:49:11 --> Output Class Initialized
INFO - 2016-09-21 14:49:11 --> Security Class Initialized
DEBUG - 2016-09-21 14:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:49:11 --> Input Class Initialized
INFO - 2016-09-21 14:49:11 --> Language Class Initialized
INFO - 2016-09-21 14:49:11 --> Loader Class Initialized
INFO - 2016-09-21 14:49:11 --> Helper loaded: url_helper
INFO - 2016-09-21 14:49:11 --> Helper loaded: form_helper
INFO - 2016-09-21 14:49:11 --> Helper loaded: html_helper
INFO - 2016-09-21 14:49:11 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:49:11 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:49:11 --> Database Driver Class Initialized
INFO - 2016-09-21 14:49:11 --> Parser Class Initialized
DEBUG - 2016-09-21 14:49:11 --> Session Class Initialized
INFO - 2016-09-21 14:49:11 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:49:11 --> Session routines successfully run
INFO - 2016-09-21 14:49:11 --> Form Validation Class Initialized
INFO - 2016-09-21 14:49:11 --> Controller Class Initialized
INFO - 2016-09-21 14:49:11 --> Model Class Initialized
INFO - 2016-09-21 14:49:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 14:49:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:49:11 --> Final output sent to browser
DEBUG - 2016-09-21 14:49:11 --> Total execution time: 0.1888
INFO - 2016-09-21 14:49:28 --> Config Class Initialized
INFO - 2016-09-21 14:49:28 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:49:28 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:49:28 --> Utf8 Class Initialized
INFO - 2016-09-21 14:49:28 --> URI Class Initialized
INFO - 2016-09-21 14:49:28 --> Router Class Initialized
INFO - 2016-09-21 14:49:28 --> Output Class Initialized
INFO - 2016-09-21 14:49:28 --> Security Class Initialized
DEBUG - 2016-09-21 14:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:49:28 --> Input Class Initialized
INFO - 2016-09-21 14:49:28 --> Language Class Initialized
INFO - 2016-09-21 14:49:28 --> Loader Class Initialized
INFO - 2016-09-21 14:49:28 --> Helper loaded: url_helper
INFO - 2016-09-21 14:49:28 --> Helper loaded: form_helper
INFO - 2016-09-21 14:49:28 --> Helper loaded: html_helper
INFO - 2016-09-21 14:49:28 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:49:28 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:49:28 --> Database Driver Class Initialized
INFO - 2016-09-21 14:49:28 --> Parser Class Initialized
DEBUG - 2016-09-21 14:49:28 --> Session Class Initialized
INFO - 2016-09-21 14:49:28 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:49:28 --> Session routines successfully run
INFO - 2016-09-21 14:49:28 --> Form Validation Class Initialized
INFO - 2016-09-21 14:49:28 --> Controller Class Initialized
INFO - 2016-09-21 14:49:28 --> Model Class Initialized
INFO - 2016-09-21 14:49:59 --> Config Class Initialized
INFO - 2016-09-21 14:49:59 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:49:59 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:49:59 --> Utf8 Class Initialized
INFO - 2016-09-21 14:49:59 --> URI Class Initialized
INFO - 2016-09-21 14:49:59 --> Router Class Initialized
INFO - 2016-09-21 14:49:59 --> Output Class Initialized
INFO - 2016-09-21 14:49:59 --> Security Class Initialized
DEBUG - 2016-09-21 14:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:49:59 --> Input Class Initialized
INFO - 2016-09-21 14:49:59 --> Language Class Initialized
INFO - 2016-09-21 14:49:59 --> Loader Class Initialized
INFO - 2016-09-21 14:49:59 --> Helper loaded: url_helper
INFO - 2016-09-21 14:49:59 --> Helper loaded: form_helper
INFO - 2016-09-21 14:49:59 --> Helper loaded: html_helper
INFO - 2016-09-21 14:49:59 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:49:59 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:49:59 --> Database Driver Class Initialized
INFO - 2016-09-21 14:49:59 --> Parser Class Initialized
DEBUG - 2016-09-21 14:49:59 --> Session Class Initialized
INFO - 2016-09-21 14:49:59 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:49:59 --> Session routines successfully run
INFO - 2016-09-21 14:49:59 --> Form Validation Class Initialized
INFO - 2016-09-21 14:49:59 --> Controller Class Initialized
INFO - 2016-09-21 14:49:59 --> Model Class Initialized
INFO - 2016-09-21 14:49:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 14:50:49 --> Config Class Initialized
INFO - 2016-09-21 14:50:49 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:50:49 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:50:49 --> Utf8 Class Initialized
INFO - 2016-09-21 14:50:49 --> URI Class Initialized
INFO - 2016-09-21 14:50:49 --> Router Class Initialized
INFO - 2016-09-21 14:50:49 --> Output Class Initialized
INFO - 2016-09-21 14:50:49 --> Security Class Initialized
DEBUG - 2016-09-21 14:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:50:49 --> Input Class Initialized
INFO - 2016-09-21 14:50:49 --> Language Class Initialized
INFO - 2016-09-21 14:50:49 --> Loader Class Initialized
INFO - 2016-09-21 14:50:49 --> Helper loaded: url_helper
INFO - 2016-09-21 14:50:49 --> Helper loaded: form_helper
INFO - 2016-09-21 14:50:49 --> Helper loaded: html_helper
INFO - 2016-09-21 14:50:49 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:50:49 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:50:49 --> Database Driver Class Initialized
INFO - 2016-09-21 14:50:49 --> Parser Class Initialized
DEBUG - 2016-09-21 14:50:49 --> Session Class Initialized
INFO - 2016-09-21 14:50:49 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:50:49 --> Session routines successfully run
INFO - 2016-09-21 14:50:49 --> Form Validation Class Initialized
INFO - 2016-09-21 14:50:49 --> Controller Class Initialized
INFO - 2016-09-21 14:50:49 --> Model Class Initialized
INFO - 2016-09-21 14:50:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 14:50:49 --> Config Class Initialized
INFO - 2016-09-21 14:50:49 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:50:49 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:50:49 --> Utf8 Class Initialized
INFO - 2016-09-21 14:50:49 --> URI Class Initialized
INFO - 2016-09-21 14:50:49 --> Router Class Initialized
INFO - 2016-09-21 14:50:49 --> Output Class Initialized
INFO - 2016-09-21 14:50:49 --> Security Class Initialized
DEBUG - 2016-09-21 14:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:50:49 --> Input Class Initialized
INFO - 2016-09-21 14:50:49 --> Language Class Initialized
INFO - 2016-09-21 14:50:49 --> Loader Class Initialized
INFO - 2016-09-21 14:50:49 --> Helper loaded: url_helper
INFO - 2016-09-21 14:50:49 --> Helper loaded: form_helper
INFO - 2016-09-21 14:50:49 --> Helper loaded: html_helper
INFO - 2016-09-21 14:50:49 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:50:49 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:50:49 --> Database Driver Class Initialized
INFO - 2016-09-21 14:50:49 --> Parser Class Initialized
DEBUG - 2016-09-21 14:50:49 --> Session Class Initialized
INFO - 2016-09-21 14:50:49 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:50:49 --> Session routines successfully run
INFO - 2016-09-21 14:50:49 --> Form Validation Class Initialized
INFO - 2016-09-21 14:50:49 --> Controller Class Initialized
DEBUG - 2016-09-21 14:50:49 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:50:49 --> Model Class Initialized
DEBUG - 2016-09-21 14:50:49 --> Pagination Class Initialized
INFO - 2016-09-21 14:50:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:50:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:50:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 14:50:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:50:49 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:50:49 --> Final output sent to browser
DEBUG - 2016-09-21 14:50:49 --> Total execution time: 0.2291
INFO - 2016-09-21 14:51:02 --> Config Class Initialized
INFO - 2016-09-21 14:51:02 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:51:02 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:51:02 --> Utf8 Class Initialized
INFO - 2016-09-21 14:51:02 --> URI Class Initialized
INFO - 2016-09-21 14:51:02 --> Router Class Initialized
INFO - 2016-09-21 14:51:02 --> Output Class Initialized
INFO - 2016-09-21 14:51:02 --> Security Class Initialized
DEBUG - 2016-09-21 14:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:51:02 --> Input Class Initialized
INFO - 2016-09-21 14:51:02 --> Language Class Initialized
INFO - 2016-09-21 14:51:02 --> Loader Class Initialized
INFO - 2016-09-21 14:51:02 --> Helper loaded: url_helper
INFO - 2016-09-21 14:51:02 --> Helper loaded: form_helper
INFO - 2016-09-21 14:51:02 --> Helper loaded: html_helper
INFO - 2016-09-21 14:51:02 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:51:02 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:51:02 --> Database Driver Class Initialized
INFO - 2016-09-21 14:51:02 --> Parser Class Initialized
DEBUG - 2016-09-21 14:51:02 --> Session Class Initialized
INFO - 2016-09-21 14:51:02 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:51:02 --> Session routines successfully run
INFO - 2016-09-21 14:51:02 --> Form Validation Class Initialized
INFO - 2016-09-21 14:51:02 --> Controller Class Initialized
DEBUG - 2016-09-21 14:51:02 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:51:02 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:02 --> Pagination Class Initialized
INFO - 2016-09-21 14:51:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:51:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:51:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 14:51:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:51:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:51:02 --> Final output sent to browser
DEBUG - 2016-09-21 14:51:02 --> Total execution time: 0.2211
INFO - 2016-09-21 14:53:39 --> Config Class Initialized
INFO - 2016-09-21 14:53:39 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:53:39 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:53:39 --> Utf8 Class Initialized
INFO - 2016-09-21 14:53:39 --> URI Class Initialized
INFO - 2016-09-21 14:53:39 --> Router Class Initialized
INFO - 2016-09-21 14:53:39 --> Output Class Initialized
INFO - 2016-09-21 14:53:39 --> Security Class Initialized
DEBUG - 2016-09-21 14:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:53:39 --> Input Class Initialized
INFO - 2016-09-21 14:53:39 --> Language Class Initialized
INFO - 2016-09-21 14:53:39 --> Loader Class Initialized
INFO - 2016-09-21 14:53:39 --> Helper loaded: url_helper
INFO - 2016-09-21 14:53:39 --> Helper loaded: form_helper
INFO - 2016-09-21 14:53:39 --> Helper loaded: html_helper
INFO - 2016-09-21 14:53:39 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:53:39 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:53:39 --> Database Driver Class Initialized
INFO - 2016-09-21 14:53:39 --> Parser Class Initialized
DEBUG - 2016-09-21 14:53:39 --> Session Class Initialized
INFO - 2016-09-21 14:53:39 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:53:39 --> Session routines successfully run
INFO - 2016-09-21 14:53:39 --> Form Validation Class Initialized
INFO - 2016-09-21 14:53:39 --> Controller Class Initialized
DEBUG - 2016-09-21 14:53:39 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:53:39 --> Model Class Initialized
DEBUG - 2016-09-21 14:53:39 --> Pagination Class Initialized
INFO - 2016-09-21 14:53:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:53:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:53:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 14:53:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:53:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:53:39 --> Final output sent to browser
DEBUG - 2016-09-21 14:53:39 --> Total execution time: 0.2596
INFO - 2016-09-21 14:53:42 --> Config Class Initialized
INFO - 2016-09-21 14:53:42 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:53:42 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:53:42 --> Utf8 Class Initialized
INFO - 2016-09-21 14:53:42 --> URI Class Initialized
INFO - 2016-09-21 14:53:42 --> Router Class Initialized
INFO - 2016-09-21 14:53:42 --> Output Class Initialized
INFO - 2016-09-21 14:53:42 --> Security Class Initialized
DEBUG - 2016-09-21 14:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:53:42 --> Input Class Initialized
INFO - 2016-09-21 14:53:42 --> Language Class Initialized
INFO - 2016-09-21 14:53:42 --> Loader Class Initialized
INFO - 2016-09-21 14:53:42 --> Helper loaded: url_helper
INFO - 2016-09-21 14:53:42 --> Helper loaded: form_helper
INFO - 2016-09-21 14:53:42 --> Helper loaded: html_helper
INFO - 2016-09-21 14:53:42 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:53:42 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:53:42 --> Database Driver Class Initialized
INFO - 2016-09-21 14:53:42 --> Parser Class Initialized
DEBUG - 2016-09-21 14:53:42 --> Session Class Initialized
INFO - 2016-09-21 14:53:42 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:53:42 --> Session routines successfully run
INFO - 2016-09-21 14:53:42 --> Form Validation Class Initialized
INFO - 2016-09-21 14:53:42 --> Controller Class Initialized
DEBUG - 2016-09-21 14:53:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:53:42 --> Model Class Initialized
DEBUG - 2016-09-21 14:53:42 --> Pagination Class Initialized
INFO - 2016-09-21 14:53:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:53:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:53:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 14:53:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:53:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:53:42 --> Final output sent to browser
DEBUG - 2016-09-21 14:53:42 --> Total execution time: 0.2293
INFO - 2016-09-21 14:54:25 --> Config Class Initialized
INFO - 2016-09-21 14:54:25 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:54:25 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:54:25 --> Utf8 Class Initialized
INFO - 2016-09-21 14:54:25 --> URI Class Initialized
INFO - 2016-09-21 14:54:25 --> Router Class Initialized
INFO - 2016-09-21 14:54:25 --> Output Class Initialized
INFO - 2016-09-21 14:54:25 --> Security Class Initialized
DEBUG - 2016-09-21 14:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:54:25 --> Input Class Initialized
INFO - 2016-09-21 14:54:25 --> Language Class Initialized
INFO - 2016-09-21 14:54:25 --> Loader Class Initialized
INFO - 2016-09-21 14:54:25 --> Helper loaded: url_helper
INFO - 2016-09-21 14:54:25 --> Helper loaded: form_helper
INFO - 2016-09-21 14:54:25 --> Helper loaded: html_helper
INFO - 2016-09-21 14:54:25 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:54:25 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:54:25 --> Database Driver Class Initialized
INFO - 2016-09-21 14:54:25 --> Parser Class Initialized
DEBUG - 2016-09-21 14:54:25 --> Session Class Initialized
INFO - 2016-09-21 14:54:25 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:54:25 --> Session routines successfully run
INFO - 2016-09-21 14:54:25 --> Form Validation Class Initialized
INFO - 2016-09-21 14:54:25 --> Controller Class Initialized
DEBUG - 2016-09-21 14:54:25 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:54:25 --> Model Class Initialized
DEBUG - 2016-09-21 14:54:25 --> Pagination Class Initialized
INFO - 2016-09-21 14:54:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:54:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:54:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 14:54:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:54:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:54:25 --> Final output sent to browser
DEBUG - 2016-09-21 14:54:25 --> Total execution time: 0.2374
INFO - 2016-09-21 14:54:30 --> Config Class Initialized
INFO - 2016-09-21 14:54:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:54:30 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:54:30 --> Utf8 Class Initialized
INFO - 2016-09-21 14:54:30 --> URI Class Initialized
INFO - 2016-09-21 14:54:30 --> Router Class Initialized
INFO - 2016-09-21 14:54:30 --> Output Class Initialized
INFO - 2016-09-21 14:54:30 --> Security Class Initialized
DEBUG - 2016-09-21 14:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:54:30 --> Input Class Initialized
INFO - 2016-09-21 14:54:30 --> Language Class Initialized
INFO - 2016-09-21 14:54:30 --> Loader Class Initialized
INFO - 2016-09-21 14:54:30 --> Helper loaded: url_helper
INFO - 2016-09-21 14:54:30 --> Helper loaded: form_helper
INFO - 2016-09-21 14:54:30 --> Helper loaded: html_helper
INFO - 2016-09-21 14:54:30 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:54:30 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:54:30 --> Database Driver Class Initialized
INFO - 2016-09-21 14:54:30 --> Parser Class Initialized
DEBUG - 2016-09-21 14:54:30 --> Session Class Initialized
INFO - 2016-09-21 14:54:30 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:54:30 --> Session routines successfully run
INFO - 2016-09-21 14:54:30 --> Form Validation Class Initialized
INFO - 2016-09-21 14:54:30 --> Controller Class Initialized
DEBUG - 2016-09-21 14:54:30 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:54:30 --> Model Class Initialized
INFO - 2016-09-21 14:54:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:54:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 14:54:30 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\schedullo\application\admin\views\default\layout\admin\addAdmin.php 66
INFO - 2016-09-21 14:54:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/addAdmin.php
INFO - 2016-09-21 14:54:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:54:31 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:54:31 --> Final output sent to browser
DEBUG - 2016-09-21 14:54:31 --> Total execution time: 1.3078
INFO - 2016-09-21 14:54:31 --> Config Class Initialized
INFO - 2016-09-21 14:54:31 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:54:31 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:54:31 --> Config Class Initialized
INFO - 2016-09-21 14:54:31 --> Utf8 Class Initialized
INFO - 2016-09-21 14:54:31 --> Hooks Class Initialized
INFO - 2016-09-21 14:54:31 --> URI Class Initialized
DEBUG - 2016-09-21 14:54:31 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:54:31 --> Router Class Initialized
INFO - 2016-09-21 14:54:31 --> Utf8 Class Initialized
INFO - 2016-09-21 14:54:31 --> URI Class Initialized
INFO - 2016-09-21 14:54:31 --> Output Class Initialized
INFO - 2016-09-21 14:54:31 --> Router Class Initialized
INFO - 2016-09-21 14:54:31 --> Security Class Initialized
INFO - 2016-09-21 14:54:31 --> Output Class Initialized
DEBUG - 2016-09-21 14:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:54:31 --> Security Class Initialized
INFO - 2016-09-21 14:54:31 --> Input Class Initialized
INFO - 2016-09-21 14:54:31 --> Language Class Initialized
DEBUG - 2016-09-21 14:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-21 14:54:31 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 14:54:31 --> Input Class Initialized
INFO - 2016-09-21 14:54:31 --> Language Class Initialized
ERROR - 2016-09-21 14:54:31 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 14:54:34 --> Config Class Initialized
INFO - 2016-09-21 14:54:34 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:54:34 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:54:34 --> Utf8 Class Initialized
INFO - 2016-09-21 14:54:34 --> URI Class Initialized
INFO - 2016-09-21 14:54:34 --> Router Class Initialized
INFO - 2016-09-21 14:54:34 --> Output Class Initialized
INFO - 2016-09-21 14:54:34 --> Security Class Initialized
DEBUG - 2016-09-21 14:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:54:34 --> Input Class Initialized
INFO - 2016-09-21 14:54:34 --> Language Class Initialized
INFO - 2016-09-21 14:54:34 --> Loader Class Initialized
INFO - 2016-09-21 14:54:34 --> Helper loaded: url_helper
INFO - 2016-09-21 14:54:34 --> Helper loaded: form_helper
INFO - 2016-09-21 14:54:34 --> Helper loaded: html_helper
INFO - 2016-09-21 14:54:34 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:54:34 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:54:34 --> Database Driver Class Initialized
INFO - 2016-09-21 14:54:34 --> Parser Class Initialized
DEBUG - 2016-09-21 14:54:34 --> Session Class Initialized
INFO - 2016-09-21 14:54:34 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:54:34 --> Session routines successfully run
INFO - 2016-09-21 14:54:34 --> Form Validation Class Initialized
INFO - 2016-09-21 14:54:34 --> Controller Class Initialized
DEBUG - 2016-09-21 14:54:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:54:34 --> Model Class Initialized
DEBUG - 2016-09-21 14:54:34 --> Pagination Class Initialized
INFO - 2016-09-21 14:54:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:54:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:54:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 14:54:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:54:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:54:34 --> Final output sent to browser
DEBUG - 2016-09-21 14:54:34 --> Total execution time: 0.2561
INFO - 2016-09-21 14:54:39 --> Config Class Initialized
INFO - 2016-09-21 14:54:39 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:54:39 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:54:39 --> Utf8 Class Initialized
INFO - 2016-09-21 14:54:39 --> URI Class Initialized
INFO - 2016-09-21 14:54:39 --> Router Class Initialized
INFO - 2016-09-21 14:54:39 --> Output Class Initialized
INFO - 2016-09-21 14:54:39 --> Security Class Initialized
DEBUG - 2016-09-21 14:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:54:39 --> Input Class Initialized
INFO - 2016-09-21 14:54:39 --> Language Class Initialized
INFO - 2016-09-21 14:54:39 --> Loader Class Initialized
INFO - 2016-09-21 14:54:39 --> Helper loaded: url_helper
INFO - 2016-09-21 14:54:39 --> Helper loaded: form_helper
INFO - 2016-09-21 14:54:39 --> Helper loaded: html_helper
INFO - 2016-09-21 14:54:39 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:54:39 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:54:39 --> Database Driver Class Initialized
INFO - 2016-09-21 14:54:39 --> Parser Class Initialized
DEBUG - 2016-09-21 14:54:39 --> Session Class Initialized
INFO - 2016-09-21 14:54:39 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:54:39 --> Session routines successfully run
INFO - 2016-09-21 14:54:39 --> Form Validation Class Initialized
INFO - 2016-09-21 14:54:39 --> Controller Class Initialized
DEBUG - 2016-09-21 14:54:39 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:54:39 --> Model Class Initialized
DEBUG - 2016-09-21 14:54:39 --> Pagination Class Initialized
INFO - 2016-09-21 14:54:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:54:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:54:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 14:54:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:54:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:54:39 --> Final output sent to browser
DEBUG - 2016-09-21 14:54:39 --> Total execution time: 0.3303
INFO - 2016-09-21 14:56:51 --> Config Class Initialized
INFO - 2016-09-21 14:56:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:56:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:56:51 --> Utf8 Class Initialized
INFO - 2016-09-21 14:56:51 --> URI Class Initialized
INFO - 2016-09-21 14:56:51 --> Router Class Initialized
INFO - 2016-09-21 14:56:51 --> Output Class Initialized
INFO - 2016-09-21 14:56:51 --> Security Class Initialized
DEBUG - 2016-09-21 14:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:56:51 --> Input Class Initialized
INFO - 2016-09-21 14:56:51 --> Language Class Initialized
INFO - 2016-09-21 14:56:51 --> Loader Class Initialized
INFO - 2016-09-21 14:56:51 --> Helper loaded: url_helper
INFO - 2016-09-21 14:56:51 --> Helper loaded: form_helper
INFO - 2016-09-21 14:56:51 --> Helper loaded: html_helper
INFO - 2016-09-21 14:56:51 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:56:51 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:56:51 --> Database Driver Class Initialized
INFO - 2016-09-21 14:56:51 --> Parser Class Initialized
DEBUG - 2016-09-21 14:56:51 --> Session Class Initialized
INFO - 2016-09-21 14:56:51 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:56:51 --> Session routines successfully run
INFO - 2016-09-21 14:56:51 --> Form Validation Class Initialized
INFO - 2016-09-21 14:56:51 --> Controller Class Initialized
DEBUG - 2016-09-21 14:56:51 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:56:51 --> Model Class Initialized
DEBUG - 2016-09-21 14:56:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 14:56:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:56:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/addAdmin.php
INFO - 2016-09-21 14:56:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:56:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:56:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:56:51 --> Final output sent to browser
DEBUG - 2016-09-21 14:56:51 --> Total execution time: 0.2332
INFO - 2016-09-21 14:56:51 --> Config Class Initialized
INFO - 2016-09-21 14:56:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:56:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:56:51 --> Utf8 Class Initialized
INFO - 2016-09-21 14:56:51 --> URI Class Initialized
INFO - 2016-09-21 14:56:51 --> Router Class Initialized
INFO - 2016-09-21 14:56:51 --> Output Class Initialized
INFO - 2016-09-21 14:56:51 --> Security Class Initialized
INFO - 2016-09-21 14:56:51 --> Config Class Initialized
DEBUG - 2016-09-21 14:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:56:51 --> Hooks Class Initialized
INFO - 2016-09-21 14:56:51 --> Input Class Initialized
DEBUG - 2016-09-21 14:56:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:56:51 --> Language Class Initialized
INFO - 2016-09-21 14:56:51 --> Utf8 Class Initialized
INFO - 2016-09-21 14:56:51 --> URI Class Initialized
ERROR - 2016-09-21 14:56:51 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 14:56:51 --> Router Class Initialized
INFO - 2016-09-21 14:56:51 --> Output Class Initialized
INFO - 2016-09-21 14:56:51 --> Security Class Initialized
DEBUG - 2016-09-21 14:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:56:51 --> Input Class Initialized
INFO - 2016-09-21 14:56:51 --> Language Class Initialized
ERROR - 2016-09-21 14:56:51 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 14:57:30 --> Config Class Initialized
INFO - 2016-09-21 14:57:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:57:30 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:57:30 --> Utf8 Class Initialized
INFO - 2016-09-21 14:57:30 --> URI Class Initialized
INFO - 2016-09-21 14:57:30 --> Router Class Initialized
INFO - 2016-09-21 14:57:30 --> Output Class Initialized
INFO - 2016-09-21 14:57:30 --> Security Class Initialized
DEBUG - 2016-09-21 14:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:57:30 --> Input Class Initialized
INFO - 2016-09-21 14:57:30 --> Language Class Initialized
INFO - 2016-09-21 14:57:30 --> Loader Class Initialized
INFO - 2016-09-21 14:57:30 --> Helper loaded: url_helper
INFO - 2016-09-21 14:57:30 --> Helper loaded: form_helper
INFO - 2016-09-21 14:57:30 --> Helper loaded: html_helper
INFO - 2016-09-21 14:57:30 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:57:30 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:57:30 --> Database Driver Class Initialized
INFO - 2016-09-21 14:57:30 --> Parser Class Initialized
DEBUG - 2016-09-21 14:57:30 --> Session Class Initialized
INFO - 2016-09-21 14:57:30 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:57:30 --> Session routines successfully run
INFO - 2016-09-21 14:57:30 --> Form Validation Class Initialized
INFO - 2016-09-21 14:57:30 --> Controller Class Initialized
DEBUG - 2016-09-21 14:57:30 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:57:30 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 14:57:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 14:57:30 --> Config Class Initialized
INFO - 2016-09-21 14:57:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:57:30 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:57:30 --> Utf8 Class Initialized
INFO - 2016-09-21 14:57:30 --> URI Class Initialized
INFO - 2016-09-21 14:57:30 --> Router Class Initialized
INFO - 2016-09-21 14:57:30 --> Output Class Initialized
INFO - 2016-09-21 14:57:30 --> Security Class Initialized
DEBUG - 2016-09-21 14:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:57:30 --> Input Class Initialized
INFO - 2016-09-21 14:57:30 --> Language Class Initialized
INFO - 2016-09-21 14:57:30 --> Loader Class Initialized
INFO - 2016-09-21 14:57:30 --> Helper loaded: url_helper
INFO - 2016-09-21 14:57:30 --> Helper loaded: form_helper
INFO - 2016-09-21 14:57:30 --> Helper loaded: html_helper
INFO - 2016-09-21 14:57:30 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:57:30 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:57:30 --> Database Driver Class Initialized
INFO - 2016-09-21 14:57:30 --> Parser Class Initialized
DEBUG - 2016-09-21 14:57:30 --> Session Class Initialized
INFO - 2016-09-21 14:57:30 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:57:30 --> Session routines successfully run
INFO - 2016-09-21 14:57:30 --> Form Validation Class Initialized
INFO - 2016-09-21 14:57:30 --> Controller Class Initialized
DEBUG - 2016-09-21 14:57:30 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:57:30 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:30 --> Pagination Class Initialized
INFO - 2016-09-21 14:57:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:57:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:57:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 14:57:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:57:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:57:30 --> Final output sent to browser
DEBUG - 2016-09-21 14:57:30 --> Total execution time: 0.2860
INFO - 2016-09-21 14:57:44 --> Config Class Initialized
INFO - 2016-09-21 14:57:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:57:44 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:57:44 --> Utf8 Class Initialized
INFO - 2016-09-21 14:57:44 --> URI Class Initialized
INFO - 2016-09-21 14:57:44 --> Router Class Initialized
INFO - 2016-09-21 14:57:45 --> Output Class Initialized
INFO - 2016-09-21 14:57:45 --> Security Class Initialized
DEBUG - 2016-09-21 14:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:57:45 --> Input Class Initialized
INFO - 2016-09-21 14:57:45 --> Language Class Initialized
INFO - 2016-09-21 14:57:45 --> Loader Class Initialized
INFO - 2016-09-21 14:57:45 --> Helper loaded: url_helper
INFO - 2016-09-21 14:57:45 --> Helper loaded: form_helper
INFO - 2016-09-21 14:57:45 --> Helper loaded: html_helper
INFO - 2016-09-21 14:57:45 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:57:45 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:57:45 --> Database Driver Class Initialized
INFO - 2016-09-21 14:57:45 --> Parser Class Initialized
DEBUG - 2016-09-21 14:57:45 --> Session Class Initialized
INFO - 2016-09-21 14:57:45 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:57:45 --> Session routines successfully run
INFO - 2016-09-21 14:57:45 --> Form Validation Class Initialized
INFO - 2016-09-21 14:57:45 --> Controller Class Initialized
DEBUG - 2016-09-21 14:57:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:57:45 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:45 --> Pagination Class Initialized
INFO - 2016-09-21 14:57:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:57:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:57:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 14:57:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:57:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:57:45 --> Final output sent to browser
DEBUG - 2016-09-21 14:57:45 --> Total execution time: 0.2333
INFO - 2016-09-21 14:57:48 --> Config Class Initialized
INFO - 2016-09-21 14:57:48 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:57:48 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:57:48 --> Utf8 Class Initialized
INFO - 2016-09-21 14:57:48 --> URI Class Initialized
INFO - 2016-09-21 14:57:48 --> Router Class Initialized
INFO - 2016-09-21 14:57:48 --> Output Class Initialized
INFO - 2016-09-21 14:57:48 --> Security Class Initialized
DEBUG - 2016-09-21 14:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:57:48 --> Input Class Initialized
INFO - 2016-09-21 14:57:48 --> Language Class Initialized
INFO - 2016-09-21 14:57:48 --> Loader Class Initialized
INFO - 2016-09-21 14:57:48 --> Helper loaded: url_helper
INFO - 2016-09-21 14:57:48 --> Helper loaded: form_helper
INFO - 2016-09-21 14:57:48 --> Helper loaded: html_helper
INFO - 2016-09-21 14:57:48 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:57:48 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:57:48 --> Database Driver Class Initialized
INFO - 2016-09-21 14:57:48 --> Parser Class Initialized
DEBUG - 2016-09-21 14:57:48 --> Session Class Initialized
INFO - 2016-09-21 14:57:48 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:57:48 --> Session routines successfully run
INFO - 2016-09-21 14:57:48 --> Form Validation Class Initialized
INFO - 2016-09-21 14:57:48 --> Controller Class Initialized
INFO - 2016-09-21 14:57:48 --> Model Class Initialized
INFO - 2016-09-21 14:57:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:57:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:57:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/dashboard.php
INFO - 2016-09-21 14:57:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:57:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:57:48 --> Final output sent to browser
DEBUG - 2016-09-21 14:57:48 --> Total execution time: 0.2371
INFO - 2016-09-21 14:57:50 --> Config Class Initialized
INFO - 2016-09-21 14:57:50 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:57:50 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:57:50 --> Utf8 Class Initialized
INFO - 2016-09-21 14:57:50 --> URI Class Initialized
INFO - 2016-09-21 14:57:50 --> Router Class Initialized
INFO - 2016-09-21 14:57:50 --> Output Class Initialized
INFO - 2016-09-21 14:57:50 --> Security Class Initialized
DEBUG - 2016-09-21 14:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:57:50 --> Input Class Initialized
INFO - 2016-09-21 14:57:50 --> Language Class Initialized
INFO - 2016-09-21 14:57:50 --> Loader Class Initialized
INFO - 2016-09-21 14:57:50 --> Helper loaded: url_helper
INFO - 2016-09-21 14:57:50 --> Helper loaded: form_helper
INFO - 2016-09-21 14:57:50 --> Helper loaded: html_helper
INFO - 2016-09-21 14:57:50 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:57:50 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:57:50 --> Database Driver Class Initialized
INFO - 2016-09-21 14:57:50 --> Parser Class Initialized
DEBUG - 2016-09-21 14:57:50 --> Session Class Initialized
INFO - 2016-09-21 14:57:50 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:57:50 --> Session routines successfully run
INFO - 2016-09-21 14:57:50 --> Form Validation Class Initialized
INFO - 2016-09-21 14:57:50 --> Controller Class Initialized
DEBUG - 2016-09-21 14:57:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:57:50 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:50 --> Pagination Class Initialized
INFO - 2016-09-21 14:57:50 --> Config Class Initialized
INFO - 2016-09-21 14:57:50 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:57:50 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:57:50 --> Utf8 Class Initialized
INFO - 2016-09-21 14:57:50 --> URI Class Initialized
INFO - 2016-09-21 14:57:50 --> Router Class Initialized
INFO - 2016-09-21 14:57:50 --> Output Class Initialized
INFO - 2016-09-21 14:57:50 --> Security Class Initialized
DEBUG - 2016-09-21 14:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:57:50 --> Input Class Initialized
INFO - 2016-09-21 14:57:50 --> Language Class Initialized
INFO - 2016-09-21 14:57:50 --> Loader Class Initialized
INFO - 2016-09-21 14:57:50 --> Helper loaded: url_helper
INFO - 2016-09-21 14:57:50 --> Helper loaded: form_helper
INFO - 2016-09-21 14:57:50 --> Helper loaded: html_helper
INFO - 2016-09-21 14:57:50 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:57:50 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:57:50 --> Database Driver Class Initialized
INFO - 2016-09-21 14:57:50 --> Parser Class Initialized
DEBUG - 2016-09-21 14:57:50 --> Session Class Initialized
INFO - 2016-09-21 14:57:50 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:57:50 --> Session routines successfully run
INFO - 2016-09-21 14:57:50 --> Form Validation Class Initialized
INFO - 2016-09-21 14:57:50 --> Controller Class Initialized
DEBUG - 2016-09-21 14:57:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:57:50 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:50 --> Pagination Class Initialized
INFO - 2016-09-21 14:57:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:57:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:50 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 14:57:51 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2016-09-21 14:57:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2016-09-21 14:57:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:57:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:57:51 --> Final output sent to browser
DEBUG - 2016-09-21 14:57:51 --> Total execution time: 0.8942
INFO - 2016-09-21 14:57:55 --> Config Class Initialized
INFO - 2016-09-21 14:57:55 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:57:55 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:57:55 --> Utf8 Class Initialized
INFO - 2016-09-21 14:57:55 --> URI Class Initialized
INFO - 2016-09-21 14:57:55 --> Router Class Initialized
INFO - 2016-09-21 14:57:55 --> Output Class Initialized
INFO - 2016-09-21 14:57:55 --> Security Class Initialized
DEBUG - 2016-09-21 14:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:57:55 --> Input Class Initialized
INFO - 2016-09-21 14:57:55 --> Language Class Initialized
INFO - 2016-09-21 14:57:55 --> Loader Class Initialized
INFO - 2016-09-21 14:57:55 --> Helper loaded: url_helper
INFO - 2016-09-21 14:57:55 --> Helper loaded: form_helper
INFO - 2016-09-21 14:57:55 --> Helper loaded: html_helper
INFO - 2016-09-21 14:57:55 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:57:55 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:57:55 --> Database Driver Class Initialized
INFO - 2016-09-21 14:57:55 --> Parser Class Initialized
DEBUG - 2016-09-21 14:57:55 --> Session Class Initialized
INFO - 2016-09-21 14:57:55 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:57:55 --> Session routines successfully run
INFO - 2016-09-21 14:57:55 --> Form Validation Class Initialized
INFO - 2016-09-21 14:57:55 --> Controller Class Initialized
DEBUG - 2016-09-21 14:57:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:57:55 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:55 --> Pagination Class Initialized
DEBUG - 2016-09-21 14:57:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 14:57:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 14:57:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 14:57:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2016-09-21 14:57:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 14:57:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 14:57:55 --> Final output sent to browser
DEBUG - 2016-09-21 14:57:55 --> Total execution time: 0.2831
INFO - 2016-09-21 14:57:55 --> Config Class Initialized
INFO - 2016-09-21 14:57:55 --> Config Class Initialized
INFO - 2016-09-21 14:57:55 --> Hooks Class Initialized
INFO - 2016-09-21 14:57:55 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 14:57:55 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:57:55 --> Utf8 Class Initialized
INFO - 2016-09-21 14:57:55 --> Utf8 Class Initialized
INFO - 2016-09-21 14:57:55 --> URI Class Initialized
INFO - 2016-09-21 14:57:55 --> URI Class Initialized
INFO - 2016-09-21 14:57:55 --> Router Class Initialized
INFO - 2016-09-21 14:57:55 --> Router Class Initialized
INFO - 2016-09-21 14:57:55 --> Output Class Initialized
INFO - 2016-09-21 14:57:55 --> Output Class Initialized
INFO - 2016-09-21 14:57:55 --> Security Class Initialized
INFO - 2016-09-21 14:57:55 --> Security Class Initialized
DEBUG - 2016-09-21 14:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 14:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:57:55 --> Input Class Initialized
INFO - 2016-09-21 14:57:55 --> Input Class Initialized
INFO - 2016-09-21 14:57:55 --> Language Class Initialized
INFO - 2016-09-21 14:57:55 --> Language Class Initialized
ERROR - 2016-09-21 14:57:55 --> 404 Page Not Found: Default/assets
ERROR - 2016-09-21 14:57:55 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 14:57:55 --> Config Class Initialized
INFO - 2016-09-21 14:57:55 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:57:55 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:57:55 --> Utf8 Class Initialized
INFO - 2016-09-21 14:57:55 --> URI Class Initialized
INFO - 2016-09-21 14:57:55 --> Router Class Initialized
INFO - 2016-09-21 14:57:55 --> Output Class Initialized
INFO - 2016-09-21 14:57:55 --> Security Class Initialized
DEBUG - 2016-09-21 14:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:57:55 --> Input Class Initialized
INFO - 2016-09-21 14:57:55 --> Language Class Initialized
INFO - 2016-09-21 14:57:55 --> Loader Class Initialized
INFO - 2016-09-21 14:57:55 --> Helper loaded: url_helper
INFO - 2016-09-21 14:57:55 --> Helper loaded: form_helper
INFO - 2016-09-21 14:57:55 --> Helper loaded: html_helper
INFO - 2016-09-21 14:57:55 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:57:55 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:57:55 --> Database Driver Class Initialized
INFO - 2016-09-21 14:57:55 --> Parser Class Initialized
DEBUG - 2016-09-21 14:57:55 --> Session Class Initialized
INFO - 2016-09-21 14:57:56 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:57:56 --> Session routines successfully run
INFO - 2016-09-21 14:57:56 --> Form Validation Class Initialized
INFO - 2016-09-21 14:57:56 --> Controller Class Initialized
DEBUG - 2016-09-21 14:57:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:57:56 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:56 --> Pagination Class Initialized
ERROR - 2016-09-21 14:57:56 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2016-09-21 14:57:56 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2016-09-21 14:57:56 --> Final output sent to browser
DEBUG - 2016-09-21 14:57:56 --> Total execution time: 0.2339
INFO - 2016-09-21 14:58:14 --> Config Class Initialized
INFO - 2016-09-21 14:58:14 --> Config Class Initialized
INFO - 2016-09-21 14:58:14 --> Hooks Class Initialized
INFO - 2016-09-21 14:58:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:58:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:58:14 --> Utf8 Class Initialized
DEBUG - 2016-09-21 14:58:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 14:58:14 --> Utf8 Class Initialized
INFO - 2016-09-21 14:58:14 --> URI Class Initialized
INFO - 2016-09-21 14:58:14 --> URI Class Initialized
INFO - 2016-09-21 14:58:14 --> Router Class Initialized
INFO - 2016-09-21 14:58:14 --> Router Class Initialized
INFO - 2016-09-21 14:58:14 --> Output Class Initialized
INFO - 2016-09-21 14:58:14 --> Output Class Initialized
INFO - 2016-09-21 14:58:14 --> Security Class Initialized
INFO - 2016-09-21 14:58:14 --> Security Class Initialized
DEBUG - 2016-09-21 14:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 14:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 14:58:14 --> Input Class Initialized
INFO - 2016-09-21 14:58:14 --> Input Class Initialized
INFO - 2016-09-21 14:58:14 --> Language Class Initialized
INFO - 2016-09-21 14:58:14 --> Language Class Initialized
INFO - 2016-09-21 14:58:14 --> Loader Class Initialized
INFO - 2016-09-21 14:58:14 --> Loader Class Initialized
INFO - 2016-09-21 14:58:14 --> Helper loaded: url_helper
INFO - 2016-09-21 14:58:14 --> Helper loaded: url_helper
INFO - 2016-09-21 14:58:14 --> Helper loaded: form_helper
INFO - 2016-09-21 14:58:14 --> Helper loaded: form_helper
INFO - 2016-09-21 14:58:14 --> Helper loaded: html_helper
INFO - 2016-09-21 14:58:14 --> Helper loaded: html_helper
INFO - 2016-09-21 14:58:14 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:58:14 --> Helper loaded: custom_helper
INFO - 2016-09-21 14:58:14 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:58:14 --> Helper loaded: cache_helper
INFO - 2016-09-21 14:58:14 --> Database Driver Class Initialized
INFO - 2016-09-21 14:58:14 --> Database Driver Class Initialized
INFO - 2016-09-21 14:58:14 --> Parser Class Initialized
INFO - 2016-09-21 14:58:14 --> Parser Class Initialized
DEBUG - 2016-09-21 14:58:14 --> Session Class Initialized
DEBUG - 2016-09-21 14:58:14 --> Session Class Initialized
INFO - 2016-09-21 14:58:14 --> Helper loaded: string_helper
INFO - 2016-09-21 14:58:14 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:58:14 --> Session routines successfully run
DEBUG - 2016-09-21 14:58:14 --> Session routines successfully run
INFO - 2016-09-21 14:58:14 --> Form Validation Class Initialized
INFO - 2016-09-21 14:58:14 --> Form Validation Class Initialized
INFO - 2016-09-21 14:58:14 --> Controller Class Initialized
INFO - 2016-09-21 14:58:14 --> Controller Class Initialized
DEBUG - 2016-09-21 14:58:14 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2016-09-21 14:58:14 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 14:58:14 --> Model Class Initialized
INFO - 2016-09-21 14:58:14 --> Model Class Initialized
DEBUG - 2016-09-21 14:58:14 --> Pagination Class Initialized
DEBUG - 2016-09-21 14:58:14 --> Pagination Class Initialized
INFO - 2016-09-21 14:58:14 --> Final output sent to browser
DEBUG - 2016-09-21 14:58:14 --> Total execution time: 0.3049
INFO - 2016-09-21 14:58:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2016-09-21 14:58:14 --> Final output sent to browser
DEBUG - 2016-09-21 14:58:14 --> Total execution time: 0.3301
INFO - 2016-09-21 15:02:51 --> Config Class Initialized
INFO - 2016-09-21 15:02:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:02:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:02:51 --> Utf8 Class Initialized
INFO - 2016-09-21 15:02:51 --> URI Class Initialized
INFO - 2016-09-21 15:02:51 --> Router Class Initialized
INFO - 2016-09-21 15:02:51 --> Output Class Initialized
INFO - 2016-09-21 15:02:51 --> Security Class Initialized
DEBUG - 2016-09-21 15:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:02:51 --> Input Class Initialized
INFO - 2016-09-21 15:02:51 --> Language Class Initialized
INFO - 2016-09-21 15:02:51 --> Loader Class Initialized
INFO - 2016-09-21 15:02:51 --> Helper loaded: url_helper
INFO - 2016-09-21 15:02:51 --> Helper loaded: form_helper
INFO - 2016-09-21 15:02:51 --> Helper loaded: html_helper
INFO - 2016-09-21 15:02:51 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:02:51 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:02:51 --> Database Driver Class Initialized
INFO - 2016-09-21 15:02:51 --> Parser Class Initialized
DEBUG - 2016-09-21 15:02:51 --> Session Class Initialized
INFO - 2016-09-21 15:02:51 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:02:51 --> Session routines successfully run
INFO - 2016-09-21 15:02:51 --> Form Validation Class Initialized
INFO - 2016-09-21 15:02:51 --> Controller Class Initialized
DEBUG - 2016-09-21 15:02:51 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:02:51 --> Model Class Initialized
DEBUG - 2016-09-21 15:02:51 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:02:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:02:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:02:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:02:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2016-09-21 15:02:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:02:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:02:51 --> Final output sent to browser
DEBUG - 2016-09-21 15:02:51 --> Total execution time: 0.4615
INFO - 2016-09-21 15:02:51 --> Config Class Initialized
INFO - 2016-09-21 15:02:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:02:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:02:51 --> Utf8 Class Initialized
INFO - 2016-09-21 15:02:51 --> URI Class Initialized
INFO - 2016-09-21 15:02:51 --> Router Class Initialized
INFO - 2016-09-21 15:02:51 --> Output Class Initialized
INFO - 2016-09-21 15:02:51 --> Security Class Initialized
DEBUG - 2016-09-21 15:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:02:51 --> Input Class Initialized
INFO - 2016-09-21 15:02:51 --> Language Class Initialized
ERROR - 2016-09-21 15:02:51 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:02:51 --> Config Class Initialized
INFO - 2016-09-21 15:02:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:02:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:02:51 --> Utf8 Class Initialized
INFO - 2016-09-21 15:02:51 --> URI Class Initialized
INFO - 2016-09-21 15:02:51 --> Router Class Initialized
INFO - 2016-09-21 15:02:51 --> Output Class Initialized
INFO - 2016-09-21 15:02:51 --> Security Class Initialized
DEBUG - 2016-09-21 15:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:02:51 --> Input Class Initialized
INFO - 2016-09-21 15:02:51 --> Language Class Initialized
ERROR - 2016-09-21 15:02:51 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:02:52 --> Config Class Initialized
INFO - 2016-09-21 15:02:52 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:02:52 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:02:52 --> Utf8 Class Initialized
INFO - 2016-09-21 15:02:52 --> URI Class Initialized
INFO - 2016-09-21 15:02:52 --> Router Class Initialized
INFO - 2016-09-21 15:02:52 --> Output Class Initialized
INFO - 2016-09-21 15:02:52 --> Security Class Initialized
DEBUG - 2016-09-21 15:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:02:52 --> Input Class Initialized
INFO - 2016-09-21 15:02:52 --> Language Class Initialized
ERROR - 2016-09-21 15:02:52 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:02:52 --> Config Class Initialized
INFO - 2016-09-21 15:02:52 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:02:52 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:02:52 --> Utf8 Class Initialized
INFO - 2016-09-21 15:02:52 --> URI Class Initialized
INFO - 2016-09-21 15:02:52 --> Router Class Initialized
INFO - 2016-09-21 15:02:52 --> Output Class Initialized
INFO - 2016-09-21 15:02:52 --> Security Class Initialized
DEBUG - 2016-09-21 15:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:02:52 --> Input Class Initialized
INFO - 2016-09-21 15:02:52 --> Language Class Initialized
ERROR - 2016-09-21 15:02:52 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:02:52 --> Config Class Initialized
INFO - 2016-09-21 15:02:52 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:02:52 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:02:52 --> Utf8 Class Initialized
INFO - 2016-09-21 15:02:52 --> URI Class Initialized
INFO - 2016-09-21 15:02:52 --> Router Class Initialized
INFO - 2016-09-21 15:02:52 --> Output Class Initialized
INFO - 2016-09-21 15:02:52 --> Security Class Initialized
DEBUG - 2016-09-21 15:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:02:52 --> Input Class Initialized
INFO - 2016-09-21 15:02:52 --> Language Class Initialized
INFO - 2016-09-21 15:02:52 --> Loader Class Initialized
INFO - 2016-09-21 15:02:52 --> Helper loaded: url_helper
INFO - 2016-09-21 15:02:52 --> Helper loaded: form_helper
INFO - 2016-09-21 15:02:52 --> Helper loaded: html_helper
INFO - 2016-09-21 15:02:52 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:02:52 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:02:52 --> Database Driver Class Initialized
INFO - 2016-09-21 15:02:52 --> Parser Class Initialized
DEBUG - 2016-09-21 15:02:52 --> Session Class Initialized
INFO - 2016-09-21 15:02:52 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:02:52 --> Session routines successfully run
INFO - 2016-09-21 15:02:52 --> Form Validation Class Initialized
INFO - 2016-09-21 15:02:52 --> Controller Class Initialized
DEBUG - 2016-09-21 15:02:52 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:02:52 --> Model Class Initialized
DEBUG - 2016-09-21 15:02:52 --> Pagination Class Initialized
ERROR - 2016-09-21 15:02:52 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2016-09-21 15:02:52 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2016-09-21 15:02:52 --> Final output sent to browser
DEBUG - 2016-09-21 15:02:52 --> Total execution time: 0.2404
INFO - 2016-09-21 15:03:18 --> Config Class Initialized
INFO - 2016-09-21 15:03:18 --> Config Class Initialized
INFO - 2016-09-21 15:03:18 --> Hooks Class Initialized
INFO - 2016-09-21 15:03:18 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:03:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:03:18 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:03:18 --> Utf8 Class Initialized
INFO - 2016-09-21 15:03:18 --> Utf8 Class Initialized
INFO - 2016-09-21 15:03:18 --> URI Class Initialized
INFO - 2016-09-21 15:03:18 --> URI Class Initialized
INFO - 2016-09-21 15:03:18 --> Router Class Initialized
INFO - 2016-09-21 15:03:18 --> Router Class Initialized
INFO - 2016-09-21 15:03:18 --> Output Class Initialized
INFO - 2016-09-21 15:03:18 --> Output Class Initialized
INFO - 2016-09-21 15:03:18 --> Security Class Initialized
INFO - 2016-09-21 15:03:18 --> Security Class Initialized
DEBUG - 2016-09-21 15:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:03:18 --> Input Class Initialized
INFO - 2016-09-21 15:03:18 --> Input Class Initialized
INFO - 2016-09-21 15:03:18 --> Language Class Initialized
INFO - 2016-09-21 15:03:18 --> Language Class Initialized
INFO - 2016-09-21 15:03:18 --> Loader Class Initialized
INFO - 2016-09-21 15:03:18 --> Loader Class Initialized
INFO - 2016-09-21 15:03:18 --> Helper loaded: url_helper
INFO - 2016-09-21 15:03:18 --> Helper loaded: url_helper
INFO - 2016-09-21 15:03:18 --> Helper loaded: form_helper
INFO - 2016-09-21 15:03:18 --> Helper loaded: form_helper
INFO - 2016-09-21 15:03:18 --> Helper loaded: html_helper
INFO - 2016-09-21 15:03:18 --> Helper loaded: html_helper
INFO - 2016-09-21 15:03:18 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:03:18 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:03:18 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:03:18 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:03:18 --> Database Driver Class Initialized
INFO - 2016-09-21 15:03:18 --> Database Driver Class Initialized
INFO - 2016-09-21 15:03:18 --> Parser Class Initialized
INFO - 2016-09-21 15:03:18 --> Parser Class Initialized
DEBUG - 2016-09-21 15:03:18 --> Session Class Initialized
DEBUG - 2016-09-21 15:03:18 --> Session Class Initialized
INFO - 2016-09-21 15:03:18 --> Helper loaded: string_helper
INFO - 2016-09-21 15:03:18 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:03:18 --> Session routines successfully run
DEBUG - 2016-09-21 15:03:18 --> Session routines successfully run
INFO - 2016-09-21 15:03:18 --> Form Validation Class Initialized
INFO - 2016-09-21 15:03:18 --> Form Validation Class Initialized
INFO - 2016-09-21 15:03:18 --> Controller Class Initialized
INFO - 2016-09-21 15:03:18 --> Controller Class Initialized
DEBUG - 2016-09-21 15:03:18 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2016-09-21 15:03:18 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:03:18 --> Model Class Initialized
INFO - 2016-09-21 15:03:18 --> Model Class Initialized
DEBUG - 2016-09-21 15:03:18 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:03:18 --> Pagination Class Initialized
INFO - 2016-09-21 15:03:18 --> Final output sent to browser
INFO - 2016-09-21 15:03:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
DEBUG - 2016-09-21 15:03:18 --> Total execution time: 0.3702
INFO - 2016-09-21 15:03:18 --> Final output sent to browser
DEBUG - 2016-09-21 15:03:19 --> Total execution time: 0.3875
INFO - 2016-09-21 15:09:33 --> Config Class Initialized
INFO - 2016-09-21 15:09:33 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:09:33 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:09:33 --> Utf8 Class Initialized
INFO - 2016-09-21 15:09:33 --> URI Class Initialized
INFO - 2016-09-21 15:09:33 --> Router Class Initialized
INFO - 2016-09-21 15:09:33 --> Output Class Initialized
INFO - 2016-09-21 15:09:33 --> Security Class Initialized
DEBUG - 2016-09-21 15:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:09:33 --> Input Class Initialized
INFO - 2016-09-21 15:09:33 --> Language Class Initialized
INFO - 2016-09-21 15:09:33 --> Loader Class Initialized
INFO - 2016-09-21 15:09:33 --> Helper loaded: url_helper
INFO - 2016-09-21 15:09:33 --> Helper loaded: form_helper
INFO - 2016-09-21 15:09:33 --> Helper loaded: html_helper
INFO - 2016-09-21 15:09:33 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:09:33 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:09:33 --> Database Driver Class Initialized
INFO - 2016-09-21 15:09:33 --> Parser Class Initialized
DEBUG - 2016-09-21 15:09:33 --> Session Class Initialized
INFO - 2016-09-21 15:09:33 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:09:33 --> Session routines successfully run
INFO - 2016-09-21 15:09:33 --> Form Validation Class Initialized
INFO - 2016-09-21 15:09:33 --> Controller Class Initialized
DEBUG - 2016-09-21 15:09:33 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:09:33 --> Model Class Initialized
DEBUG - 2016-09-21 15:09:33 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:09:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:09:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:09:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:09:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2016-09-21 15:09:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:09:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:09:33 --> Final output sent to browser
DEBUG - 2016-09-21 15:09:33 --> Total execution time: 0.3958
INFO - 2016-09-21 15:09:33 --> Config Class Initialized
INFO - 2016-09-21 15:09:33 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:09:33 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:09:33 --> Utf8 Class Initialized
INFO - 2016-09-21 15:09:33 --> URI Class Initialized
INFO - 2016-09-21 15:09:33 --> Router Class Initialized
INFO - 2016-09-21 15:09:33 --> Output Class Initialized
INFO - 2016-09-21 15:09:33 --> Security Class Initialized
DEBUG - 2016-09-21 15:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:09:33 --> Input Class Initialized
INFO - 2016-09-21 15:09:33 --> Language Class Initialized
ERROR - 2016-09-21 15:09:33 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:09:34 --> Config Class Initialized
INFO - 2016-09-21 15:09:34 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:09:34 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:09:34 --> Utf8 Class Initialized
INFO - 2016-09-21 15:09:34 --> URI Class Initialized
INFO - 2016-09-21 15:09:34 --> Router Class Initialized
INFO - 2016-09-21 15:09:34 --> Config Class Initialized
INFO - 2016-09-21 15:09:34 --> Output Class Initialized
INFO - 2016-09-21 15:09:34 --> Hooks Class Initialized
INFO - 2016-09-21 15:09:34 --> Security Class Initialized
DEBUG - 2016-09-21 15:09:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:09:34 --> Utf8 Class Initialized
INFO - 2016-09-21 15:09:34 --> Input Class Initialized
INFO - 2016-09-21 15:09:34 --> URI Class Initialized
INFO - 2016-09-21 15:09:34 --> Language Class Initialized
INFO - 2016-09-21 15:09:34 --> Router Class Initialized
ERROR - 2016-09-21 15:09:34 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:09:34 --> Output Class Initialized
INFO - 2016-09-21 15:09:34 --> Security Class Initialized
DEBUG - 2016-09-21 15:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:09:34 --> Input Class Initialized
INFO - 2016-09-21 15:09:34 --> Language Class Initialized
ERROR - 2016-09-21 15:09:34 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:09:34 --> Config Class Initialized
INFO - 2016-09-21 15:09:34 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:09:34 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:09:34 --> Utf8 Class Initialized
INFO - 2016-09-21 15:09:34 --> URI Class Initialized
INFO - 2016-09-21 15:09:34 --> Router Class Initialized
INFO - 2016-09-21 15:09:34 --> Output Class Initialized
INFO - 2016-09-21 15:09:34 --> Security Class Initialized
DEBUG - 2016-09-21 15:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:09:34 --> Input Class Initialized
INFO - 2016-09-21 15:09:34 --> Language Class Initialized
ERROR - 2016-09-21 15:09:34 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:09:34 --> Config Class Initialized
INFO - 2016-09-21 15:09:34 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:09:34 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:09:34 --> Utf8 Class Initialized
INFO - 2016-09-21 15:09:34 --> URI Class Initialized
INFO - 2016-09-21 15:09:34 --> Router Class Initialized
INFO - 2016-09-21 15:09:34 --> Output Class Initialized
INFO - 2016-09-21 15:09:34 --> Security Class Initialized
DEBUG - 2016-09-21 15:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:09:34 --> Input Class Initialized
INFO - 2016-09-21 15:09:34 --> Language Class Initialized
INFO - 2016-09-21 15:09:34 --> Loader Class Initialized
INFO - 2016-09-21 15:09:34 --> Helper loaded: url_helper
INFO - 2016-09-21 15:09:34 --> Helper loaded: form_helper
INFO - 2016-09-21 15:09:34 --> Helper loaded: html_helper
INFO - 2016-09-21 15:09:34 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:09:34 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:09:34 --> Database Driver Class Initialized
INFO - 2016-09-21 15:09:34 --> Parser Class Initialized
DEBUG - 2016-09-21 15:09:34 --> Session Class Initialized
INFO - 2016-09-21 15:09:34 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:09:34 --> Session routines successfully run
INFO - 2016-09-21 15:09:34 --> Form Validation Class Initialized
INFO - 2016-09-21 15:09:34 --> Controller Class Initialized
DEBUG - 2016-09-21 15:09:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:09:34 --> Model Class Initialized
DEBUG - 2016-09-21 15:09:34 --> Pagination Class Initialized
ERROR - 2016-09-21 15:09:34 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2016-09-21 15:09:34 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2016-09-21 15:09:34 --> Final output sent to browser
DEBUG - 2016-09-21 15:09:34 --> Total execution time: 0.2546
INFO - 2016-09-21 15:09:49 --> Config Class Initialized
INFO - 2016-09-21 15:09:49 --> Config Class Initialized
INFO - 2016-09-21 15:09:49 --> Hooks Class Initialized
INFO - 2016-09-21 15:09:49 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:09:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:09:49 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:09:49 --> Utf8 Class Initialized
INFO - 2016-09-21 15:09:49 --> Utf8 Class Initialized
INFO - 2016-09-21 15:09:49 --> URI Class Initialized
INFO - 2016-09-21 15:09:49 --> URI Class Initialized
INFO - 2016-09-21 15:09:49 --> Router Class Initialized
INFO - 2016-09-21 15:09:49 --> Router Class Initialized
INFO - 2016-09-21 15:09:49 --> Output Class Initialized
INFO - 2016-09-21 15:09:49 --> Output Class Initialized
INFO - 2016-09-21 15:09:49 --> Security Class Initialized
INFO - 2016-09-21 15:09:49 --> Security Class Initialized
DEBUG - 2016-09-21 15:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:09:49 --> Input Class Initialized
INFO - 2016-09-21 15:09:49 --> Input Class Initialized
INFO - 2016-09-21 15:09:49 --> Language Class Initialized
INFO - 2016-09-21 15:09:49 --> Language Class Initialized
INFO - 2016-09-21 15:09:49 --> Loader Class Initialized
INFO - 2016-09-21 15:09:49 --> Loader Class Initialized
INFO - 2016-09-21 15:09:49 --> Helper loaded: url_helper
INFO - 2016-09-21 15:09:49 --> Helper loaded: url_helper
INFO - 2016-09-21 15:09:49 --> Helper loaded: form_helper
INFO - 2016-09-21 15:09:49 --> Helper loaded: form_helper
INFO - 2016-09-21 15:09:49 --> Helper loaded: html_helper
INFO - 2016-09-21 15:09:49 --> Helper loaded: html_helper
INFO - 2016-09-21 15:09:49 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:09:49 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:09:49 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:09:49 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:09:49 --> Database Driver Class Initialized
INFO - 2016-09-21 15:09:49 --> Database Driver Class Initialized
INFO - 2016-09-21 15:09:49 --> Parser Class Initialized
INFO - 2016-09-21 15:09:49 --> Parser Class Initialized
DEBUG - 2016-09-21 15:09:49 --> Session Class Initialized
DEBUG - 2016-09-21 15:09:49 --> Session Class Initialized
INFO - 2016-09-21 15:09:49 --> Helper loaded: string_helper
INFO - 2016-09-21 15:09:49 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:09:49 --> Session routines successfully run
DEBUG - 2016-09-21 15:09:49 --> Session routines successfully run
INFO - 2016-09-21 15:09:49 --> Form Validation Class Initialized
INFO - 2016-09-21 15:09:49 --> Form Validation Class Initialized
INFO - 2016-09-21 15:09:49 --> Controller Class Initialized
INFO - 2016-09-21 15:09:49 --> Controller Class Initialized
DEBUG - 2016-09-21 15:09:49 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2016-09-21 15:09:49 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:09:49 --> Model Class Initialized
INFO - 2016-09-21 15:09:49 --> Model Class Initialized
DEBUG - 2016-09-21 15:09:50 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:09:50 --> Pagination Class Initialized
INFO - 2016-09-21 15:09:50 --> Final output sent to browser
INFO - 2016-09-21 15:09:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
DEBUG - 2016-09-21 15:09:50 --> Total execution time: 0.3501
INFO - 2016-09-21 15:09:50 --> Final output sent to browser
DEBUG - 2016-09-21 15:09:50 --> Total execution time: 0.3696
INFO - 2016-09-21 15:11:42 --> Config Class Initialized
INFO - 2016-09-21 15:11:42 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:11:42 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:11:42 --> Utf8 Class Initialized
INFO - 2016-09-21 15:11:42 --> URI Class Initialized
INFO - 2016-09-21 15:11:42 --> Router Class Initialized
INFO - 2016-09-21 15:11:42 --> Output Class Initialized
INFO - 2016-09-21 15:11:42 --> Security Class Initialized
DEBUG - 2016-09-21 15:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:11:42 --> Input Class Initialized
INFO - 2016-09-21 15:11:42 --> Language Class Initialized
INFO - 2016-09-21 15:11:42 --> Loader Class Initialized
INFO - 2016-09-21 15:11:42 --> Helper loaded: url_helper
INFO - 2016-09-21 15:11:42 --> Helper loaded: form_helper
INFO - 2016-09-21 15:11:42 --> Helper loaded: html_helper
INFO - 2016-09-21 15:11:42 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:11:42 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:11:42 --> Database Driver Class Initialized
INFO - 2016-09-21 15:11:42 --> Parser Class Initialized
DEBUG - 2016-09-21 15:11:42 --> Session Class Initialized
INFO - 2016-09-21 15:11:42 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:11:42 --> Session routines successfully run
INFO - 2016-09-21 15:11:42 --> Form Validation Class Initialized
INFO - 2016-09-21 15:11:42 --> Controller Class Initialized
DEBUG - 2016-09-21 15:11:42 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:11:42 --> Model Class Initialized
DEBUG - 2016-09-21 15:11:42 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:11:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:11:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:11:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:11:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2016-09-21 15:11:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:11:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:11:43 --> Final output sent to browser
DEBUG - 2016-09-21 15:11:43 --> Total execution time: 0.2966
INFO - 2016-09-21 15:11:43 --> Config Class Initialized
INFO - 2016-09-21 15:11:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:11:43 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:11:43 --> Utf8 Class Initialized
INFO - 2016-09-21 15:11:43 --> URI Class Initialized
INFO - 2016-09-21 15:11:43 --> Router Class Initialized
INFO - 2016-09-21 15:11:43 --> Output Class Initialized
INFO - 2016-09-21 15:11:43 --> Security Class Initialized
DEBUG - 2016-09-21 15:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:11:43 --> Input Class Initialized
INFO - 2016-09-21 15:11:43 --> Language Class Initialized
ERROR - 2016-09-21 15:11:43 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:11:43 --> Config Class Initialized
INFO - 2016-09-21 15:11:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:11:43 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:11:43 --> Utf8 Class Initialized
INFO - 2016-09-21 15:11:43 --> URI Class Initialized
INFO - 2016-09-21 15:11:43 --> Router Class Initialized
INFO - 2016-09-21 15:11:43 --> Output Class Initialized
INFO - 2016-09-21 15:11:43 --> Security Class Initialized
DEBUG - 2016-09-21 15:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:11:43 --> Input Class Initialized
INFO - 2016-09-21 15:11:43 --> Language Class Initialized
ERROR - 2016-09-21 15:11:43 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:11:43 --> Config Class Initialized
INFO - 2016-09-21 15:11:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:11:43 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:11:43 --> Utf8 Class Initialized
INFO - 2016-09-21 15:11:43 --> URI Class Initialized
INFO - 2016-09-21 15:11:43 --> Router Class Initialized
INFO - 2016-09-21 15:11:43 --> Output Class Initialized
INFO - 2016-09-21 15:11:43 --> Security Class Initialized
DEBUG - 2016-09-21 15:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:11:43 --> Input Class Initialized
INFO - 2016-09-21 15:11:43 --> Language Class Initialized
ERROR - 2016-09-21 15:11:43 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:11:43 --> Config Class Initialized
INFO - 2016-09-21 15:11:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:11:43 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:11:43 --> Utf8 Class Initialized
INFO - 2016-09-21 15:11:43 --> URI Class Initialized
INFO - 2016-09-21 15:11:43 --> Router Class Initialized
INFO - 2016-09-21 15:11:43 --> Output Class Initialized
INFO - 2016-09-21 15:11:43 --> Security Class Initialized
DEBUG - 2016-09-21 15:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:11:43 --> Input Class Initialized
INFO - 2016-09-21 15:11:43 --> Language Class Initialized
ERROR - 2016-09-21 15:11:43 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:11:43 --> Config Class Initialized
INFO - 2016-09-21 15:11:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:11:43 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:11:43 --> Utf8 Class Initialized
INFO - 2016-09-21 15:11:43 --> URI Class Initialized
INFO - 2016-09-21 15:11:43 --> Router Class Initialized
INFO - 2016-09-21 15:11:43 --> Output Class Initialized
INFO - 2016-09-21 15:11:43 --> Security Class Initialized
DEBUG - 2016-09-21 15:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:11:43 --> Input Class Initialized
INFO - 2016-09-21 15:11:43 --> Language Class Initialized
INFO - 2016-09-21 15:11:43 --> Loader Class Initialized
INFO - 2016-09-21 15:11:43 --> Helper loaded: url_helper
INFO - 2016-09-21 15:11:43 --> Helper loaded: form_helper
INFO - 2016-09-21 15:11:43 --> Helper loaded: html_helper
INFO - 2016-09-21 15:11:43 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:11:43 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:11:43 --> Database Driver Class Initialized
INFO - 2016-09-21 15:11:43 --> Parser Class Initialized
DEBUG - 2016-09-21 15:11:43 --> Session Class Initialized
INFO - 2016-09-21 15:11:43 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:11:43 --> Session routines successfully run
INFO - 2016-09-21 15:11:43 --> Form Validation Class Initialized
INFO - 2016-09-21 15:11:43 --> Controller Class Initialized
DEBUG - 2016-09-21 15:11:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:11:43 --> Model Class Initialized
DEBUG - 2016-09-21 15:11:43 --> Pagination Class Initialized
ERROR - 2016-09-21 15:11:43 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2016-09-21 15:11:43 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2016-09-21 15:11:43 --> Final output sent to browser
DEBUG - 2016-09-21 15:11:43 --> Total execution time: 0.2834
INFO - 2016-09-21 15:12:07 --> Config Class Initialized
INFO - 2016-09-21 15:12:07 --> Config Class Initialized
INFO - 2016-09-21 15:12:07 --> Hooks Class Initialized
INFO - 2016-09-21 15:12:07 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:12:07 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:12:07 --> Utf8 Class Initialized
DEBUG - 2016-09-21 15:12:07 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:12:07 --> Utf8 Class Initialized
INFO - 2016-09-21 15:12:07 --> URI Class Initialized
INFO - 2016-09-21 15:12:07 --> URI Class Initialized
INFO - 2016-09-21 15:12:07 --> Router Class Initialized
INFO - 2016-09-21 15:12:07 --> Router Class Initialized
INFO - 2016-09-21 15:12:07 --> Output Class Initialized
INFO - 2016-09-21 15:12:07 --> Output Class Initialized
INFO - 2016-09-21 15:12:07 --> Security Class Initialized
INFO - 2016-09-21 15:12:07 --> Security Class Initialized
DEBUG - 2016-09-21 15:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:12:07 --> Input Class Initialized
INFO - 2016-09-21 15:12:07 --> Input Class Initialized
INFO - 2016-09-21 15:12:08 --> Language Class Initialized
INFO - 2016-09-21 15:12:08 --> Language Class Initialized
INFO - 2016-09-21 15:12:08 --> Loader Class Initialized
INFO - 2016-09-21 15:12:08 --> Loader Class Initialized
INFO - 2016-09-21 15:12:08 --> Helper loaded: url_helper
INFO - 2016-09-21 15:12:08 --> Helper loaded: url_helper
INFO - 2016-09-21 15:12:08 --> Helper loaded: form_helper
INFO - 2016-09-21 15:12:08 --> Helper loaded: form_helper
INFO - 2016-09-21 15:12:08 --> Helper loaded: html_helper
INFO - 2016-09-21 15:12:08 --> Helper loaded: html_helper
INFO - 2016-09-21 15:12:08 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:12:08 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:12:08 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:12:08 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:12:08 --> Database Driver Class Initialized
INFO - 2016-09-21 15:12:08 --> Database Driver Class Initialized
INFO - 2016-09-21 15:12:08 --> Parser Class Initialized
INFO - 2016-09-21 15:12:08 --> Parser Class Initialized
DEBUG - 2016-09-21 15:12:08 --> Session Class Initialized
DEBUG - 2016-09-21 15:12:08 --> Session Class Initialized
INFO - 2016-09-21 15:12:08 --> Helper loaded: string_helper
INFO - 2016-09-21 15:12:08 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:12:08 --> Session routines successfully run
DEBUG - 2016-09-21 15:12:08 --> Session routines successfully run
INFO - 2016-09-21 15:12:08 --> Form Validation Class Initialized
INFO - 2016-09-21 15:12:08 --> Form Validation Class Initialized
INFO - 2016-09-21 15:12:08 --> Controller Class Initialized
INFO - 2016-09-21 15:12:08 --> Controller Class Initialized
DEBUG - 2016-09-21 15:12:08 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2016-09-21 15:12:08 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:12:08 --> Model Class Initialized
INFO - 2016-09-21 15:12:08 --> Model Class Initialized
DEBUG - 2016-09-21 15:12:08 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:12:08 --> Pagination Class Initialized
INFO - 2016-09-21 15:12:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2016-09-21 15:12:08 --> Final output sent to browser
INFO - 2016-09-21 15:12:08 --> Final output sent to browser
DEBUG - 2016-09-21 15:12:08 --> Total execution time: 0.3447
DEBUG - 2016-09-21 15:12:08 --> Total execution time: 0.3540
INFO - 2016-09-21 15:13:30 --> Config Class Initialized
INFO - 2016-09-21 15:13:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:13:30 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:13:30 --> Utf8 Class Initialized
INFO - 2016-09-21 15:13:30 --> URI Class Initialized
INFO - 2016-09-21 15:13:30 --> Router Class Initialized
INFO - 2016-09-21 15:13:30 --> Output Class Initialized
INFO - 2016-09-21 15:13:30 --> Security Class Initialized
DEBUG - 2016-09-21 15:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:13:30 --> Input Class Initialized
INFO - 2016-09-21 15:13:30 --> Language Class Initialized
INFO - 2016-09-21 15:13:30 --> Loader Class Initialized
INFO - 2016-09-21 15:13:30 --> Helper loaded: url_helper
INFO - 2016-09-21 15:13:30 --> Helper loaded: form_helper
INFO - 2016-09-21 15:13:30 --> Helper loaded: html_helper
INFO - 2016-09-21 15:13:30 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:13:30 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:13:30 --> Database Driver Class Initialized
INFO - 2016-09-21 15:13:30 --> Parser Class Initialized
DEBUG - 2016-09-21 15:13:30 --> Session Class Initialized
INFO - 2016-09-21 15:13:30 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:13:30 --> Session routines successfully run
INFO - 2016-09-21 15:13:30 --> Form Validation Class Initialized
INFO - 2016-09-21 15:13:30 --> Controller Class Initialized
DEBUG - 2016-09-21 15:13:30 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:13:30 --> Model Class Initialized
DEBUG - 2016-09-21 15:13:30 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:13:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:13:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:13:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:13:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2016-09-21 15:13:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:13:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:13:30 --> Final output sent to browser
DEBUG - 2016-09-21 15:13:30 --> Total execution time: 0.2967
INFO - 2016-09-21 15:13:30 --> Config Class Initialized
INFO - 2016-09-21 15:13:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:13:30 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:13:30 --> Utf8 Class Initialized
INFO - 2016-09-21 15:13:30 --> URI Class Initialized
INFO - 2016-09-21 15:13:30 --> Router Class Initialized
INFO - 2016-09-21 15:13:30 --> Output Class Initialized
INFO - 2016-09-21 15:13:30 --> Security Class Initialized
DEBUG - 2016-09-21 15:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:13:30 --> Input Class Initialized
INFO - 2016-09-21 15:13:30 --> Language Class Initialized
ERROR - 2016-09-21 15:13:30 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:13:30 --> Config Class Initialized
INFO - 2016-09-21 15:13:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:13:30 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:13:30 --> Utf8 Class Initialized
INFO - 2016-09-21 15:13:30 --> URI Class Initialized
INFO - 2016-09-21 15:13:30 --> Router Class Initialized
INFO - 2016-09-21 15:13:30 --> Output Class Initialized
INFO - 2016-09-21 15:13:30 --> Security Class Initialized
DEBUG - 2016-09-21 15:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:13:30 --> Input Class Initialized
INFO - 2016-09-21 15:13:30 --> Language Class Initialized
ERROR - 2016-09-21 15:13:30 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:13:30 --> Config Class Initialized
INFO - 2016-09-21 15:13:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:13:30 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:13:30 --> Utf8 Class Initialized
INFO - 2016-09-21 15:13:30 --> URI Class Initialized
INFO - 2016-09-21 15:13:30 --> Router Class Initialized
INFO - 2016-09-21 15:13:30 --> Output Class Initialized
INFO - 2016-09-21 15:13:30 --> Security Class Initialized
DEBUG - 2016-09-21 15:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:13:30 --> Input Class Initialized
INFO - 2016-09-21 15:13:30 --> Language Class Initialized
ERROR - 2016-09-21 15:13:30 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:13:30 --> Config Class Initialized
INFO - 2016-09-21 15:13:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:13:30 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:13:30 --> Utf8 Class Initialized
INFO - 2016-09-21 15:13:30 --> URI Class Initialized
INFO - 2016-09-21 15:13:30 --> Router Class Initialized
INFO - 2016-09-21 15:13:30 --> Output Class Initialized
INFO - 2016-09-21 15:13:30 --> Security Class Initialized
DEBUG - 2016-09-21 15:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:13:30 --> Input Class Initialized
INFO - 2016-09-21 15:13:30 --> Language Class Initialized
ERROR - 2016-09-21 15:13:30 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:13:31 --> Config Class Initialized
INFO - 2016-09-21 15:13:31 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:13:31 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:13:31 --> Utf8 Class Initialized
INFO - 2016-09-21 15:13:31 --> URI Class Initialized
INFO - 2016-09-21 15:13:31 --> Router Class Initialized
INFO - 2016-09-21 15:13:31 --> Output Class Initialized
INFO - 2016-09-21 15:13:31 --> Security Class Initialized
DEBUG - 2016-09-21 15:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:13:31 --> Input Class Initialized
INFO - 2016-09-21 15:13:31 --> Language Class Initialized
INFO - 2016-09-21 15:13:31 --> Loader Class Initialized
INFO - 2016-09-21 15:13:31 --> Helper loaded: url_helper
INFO - 2016-09-21 15:13:31 --> Helper loaded: form_helper
INFO - 2016-09-21 15:13:31 --> Helper loaded: html_helper
INFO - 2016-09-21 15:13:31 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:13:31 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:13:31 --> Database Driver Class Initialized
INFO - 2016-09-21 15:13:31 --> Parser Class Initialized
DEBUG - 2016-09-21 15:13:31 --> Session Class Initialized
INFO - 2016-09-21 15:13:31 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:13:31 --> Session routines successfully run
INFO - 2016-09-21 15:13:31 --> Form Validation Class Initialized
INFO - 2016-09-21 15:13:31 --> Controller Class Initialized
DEBUG - 2016-09-21 15:13:31 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:13:31 --> Model Class Initialized
DEBUG - 2016-09-21 15:13:31 --> Pagination Class Initialized
ERROR - 2016-09-21 15:13:31 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2016-09-21 15:13:31 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2016-09-21 15:13:31 --> Final output sent to browser
DEBUG - 2016-09-21 15:13:31 --> Total execution time: 0.2886
INFO - 2016-09-21 15:13:41 --> Config Class Initialized
INFO - 2016-09-21 15:13:41 --> Config Class Initialized
INFO - 2016-09-21 15:13:41 --> Hooks Class Initialized
INFO - 2016-09-21 15:13:41 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:13:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:13:41 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:13:41 --> Utf8 Class Initialized
INFO - 2016-09-21 15:13:41 --> Utf8 Class Initialized
INFO - 2016-09-21 15:13:41 --> URI Class Initialized
INFO - 2016-09-21 15:13:41 --> URI Class Initialized
INFO - 2016-09-21 15:13:41 --> Router Class Initialized
INFO - 2016-09-21 15:13:41 --> Router Class Initialized
INFO - 2016-09-21 15:13:41 --> Output Class Initialized
INFO - 2016-09-21 15:13:41 --> Output Class Initialized
INFO - 2016-09-21 15:13:41 --> Security Class Initialized
INFO - 2016-09-21 15:13:41 --> Security Class Initialized
DEBUG - 2016-09-21 15:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:13:41 --> Input Class Initialized
INFO - 2016-09-21 15:13:41 --> Input Class Initialized
INFO - 2016-09-21 15:13:41 --> Language Class Initialized
INFO - 2016-09-21 15:13:41 --> Language Class Initialized
INFO - 2016-09-21 15:13:41 --> Loader Class Initialized
INFO - 2016-09-21 15:13:41 --> Loader Class Initialized
INFO - 2016-09-21 15:13:41 --> Helper loaded: url_helper
INFO - 2016-09-21 15:13:41 --> Helper loaded: url_helper
INFO - 2016-09-21 15:13:41 --> Helper loaded: form_helper
INFO - 2016-09-21 15:13:41 --> Helper loaded: form_helper
INFO - 2016-09-21 15:13:41 --> Helper loaded: html_helper
INFO - 2016-09-21 15:13:41 --> Helper loaded: html_helper
INFO - 2016-09-21 15:13:41 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:13:41 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:13:41 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:13:41 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:13:41 --> Database Driver Class Initialized
INFO - 2016-09-21 15:13:41 --> Database Driver Class Initialized
INFO - 2016-09-21 15:13:41 --> Parser Class Initialized
INFO - 2016-09-21 15:13:41 --> Parser Class Initialized
DEBUG - 2016-09-21 15:13:41 --> Session Class Initialized
DEBUG - 2016-09-21 15:13:41 --> Session Class Initialized
INFO - 2016-09-21 15:13:41 --> Helper loaded: string_helper
INFO - 2016-09-21 15:13:41 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:13:41 --> Session routines successfully run
DEBUG - 2016-09-21 15:13:41 --> Session routines successfully run
INFO - 2016-09-21 15:13:41 --> Form Validation Class Initialized
INFO - 2016-09-21 15:13:41 --> Form Validation Class Initialized
INFO - 2016-09-21 15:13:41 --> Controller Class Initialized
INFO - 2016-09-21 15:13:41 --> Controller Class Initialized
DEBUG - 2016-09-21 15:13:41 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2016-09-21 15:13:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:13:41 --> Model Class Initialized
INFO - 2016-09-21 15:13:41 --> Model Class Initialized
DEBUG - 2016-09-21 15:13:41 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:13:41 --> Pagination Class Initialized
INFO - 2016-09-21 15:13:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2016-09-21 15:13:41 --> Final output sent to browser
INFO - 2016-09-21 15:13:41 --> Final output sent to browser
DEBUG - 2016-09-21 15:13:41 --> Total execution time: 0.3887
DEBUG - 2016-09-21 15:13:41 --> Total execution time: 0.3815
INFO - 2016-09-21 15:14:46 --> Config Class Initialized
INFO - 2016-09-21 15:14:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:14:46 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:14:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:14:46 --> URI Class Initialized
INFO - 2016-09-21 15:14:46 --> Router Class Initialized
INFO - 2016-09-21 15:14:46 --> Output Class Initialized
INFO - 2016-09-21 15:14:46 --> Security Class Initialized
DEBUG - 2016-09-21 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:14:46 --> Input Class Initialized
INFO - 2016-09-21 15:14:46 --> Language Class Initialized
INFO - 2016-09-21 15:14:46 --> Loader Class Initialized
INFO - 2016-09-21 15:14:46 --> Helper loaded: url_helper
INFO - 2016-09-21 15:14:46 --> Helper loaded: form_helper
INFO - 2016-09-21 15:14:46 --> Helper loaded: html_helper
INFO - 2016-09-21 15:14:46 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:14:46 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:14:46 --> Database Driver Class Initialized
INFO - 2016-09-21 15:14:46 --> Parser Class Initialized
DEBUG - 2016-09-21 15:14:46 --> Session Class Initialized
INFO - 2016-09-21 15:14:46 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:14:46 --> Session routines successfully run
INFO - 2016-09-21 15:14:46 --> Form Validation Class Initialized
INFO - 2016-09-21 15:14:46 --> Controller Class Initialized
DEBUG - 2016-09-21 15:14:46 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:14:46 --> Model Class Initialized
DEBUG - 2016-09-21 15:14:46 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:14:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:14:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:14:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:14:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2016-09-21 15:14:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:14:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:14:46 --> Final output sent to browser
DEBUG - 2016-09-21 15:14:46 --> Total execution time: 0.2993
INFO - 2016-09-21 15:14:46 --> Config Class Initialized
INFO - 2016-09-21 15:14:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:14:46 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:14:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:14:46 --> URI Class Initialized
INFO - 2016-09-21 15:14:46 --> Router Class Initialized
INFO - 2016-09-21 15:14:46 --> Output Class Initialized
INFO - 2016-09-21 15:14:46 --> Security Class Initialized
DEBUG - 2016-09-21 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:14:46 --> Input Class Initialized
INFO - 2016-09-21 15:14:46 --> Language Class Initialized
ERROR - 2016-09-21 15:14:46 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:14:46 --> Config Class Initialized
INFO - 2016-09-21 15:14:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:14:46 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:14:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:14:46 --> URI Class Initialized
INFO - 2016-09-21 15:14:46 --> Router Class Initialized
INFO - 2016-09-21 15:14:46 --> Config Class Initialized
INFO - 2016-09-21 15:14:46 --> Output Class Initialized
INFO - 2016-09-21 15:14:46 --> Hooks Class Initialized
INFO - 2016-09-21 15:14:46 --> Security Class Initialized
DEBUG - 2016-09-21 15:14:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:14:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:14:46 --> Input Class Initialized
INFO - 2016-09-21 15:14:46 --> URI Class Initialized
INFO - 2016-09-21 15:14:46 --> Language Class Initialized
INFO - 2016-09-21 15:14:46 --> Router Class Initialized
ERROR - 2016-09-21 15:14:46 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:14:46 --> Output Class Initialized
INFO - 2016-09-21 15:14:46 --> Security Class Initialized
DEBUG - 2016-09-21 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:14:46 --> Input Class Initialized
INFO - 2016-09-21 15:14:46 --> Language Class Initialized
ERROR - 2016-09-21 15:14:46 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:14:46 --> Config Class Initialized
INFO - 2016-09-21 15:14:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:14:46 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:14:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:14:46 --> URI Class Initialized
INFO - 2016-09-21 15:14:46 --> Router Class Initialized
INFO - 2016-09-21 15:14:46 --> Output Class Initialized
INFO - 2016-09-21 15:14:46 --> Security Class Initialized
DEBUG - 2016-09-21 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:14:46 --> Input Class Initialized
INFO - 2016-09-21 15:14:46 --> Language Class Initialized
ERROR - 2016-09-21 15:14:46 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:14:46 --> Config Class Initialized
INFO - 2016-09-21 15:14:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:14:46 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:14:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:14:46 --> URI Class Initialized
INFO - 2016-09-21 15:14:46 --> Router Class Initialized
INFO - 2016-09-21 15:14:46 --> Output Class Initialized
INFO - 2016-09-21 15:14:46 --> Security Class Initialized
DEBUG - 2016-09-21 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:14:46 --> Input Class Initialized
INFO - 2016-09-21 15:14:46 --> Language Class Initialized
INFO - 2016-09-21 15:14:46 --> Loader Class Initialized
INFO - 2016-09-21 15:14:46 --> Helper loaded: url_helper
INFO - 2016-09-21 15:14:46 --> Helper loaded: form_helper
INFO - 2016-09-21 15:14:46 --> Helper loaded: html_helper
INFO - 2016-09-21 15:14:46 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:14:46 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:14:46 --> Database Driver Class Initialized
INFO - 2016-09-21 15:14:47 --> Parser Class Initialized
DEBUG - 2016-09-21 15:14:47 --> Session Class Initialized
INFO - 2016-09-21 15:14:47 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:14:47 --> Session routines successfully run
INFO - 2016-09-21 15:14:47 --> Form Validation Class Initialized
INFO - 2016-09-21 15:14:47 --> Controller Class Initialized
DEBUG - 2016-09-21 15:14:47 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:14:47 --> Model Class Initialized
DEBUG - 2016-09-21 15:14:47 --> Pagination Class Initialized
ERROR - 2016-09-21 15:14:47 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2016-09-21 15:14:47 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2016-09-21 15:14:47 --> Final output sent to browser
DEBUG - 2016-09-21 15:14:47 --> Total execution time: 0.2686
INFO - 2016-09-21 15:15:03 --> Config Class Initialized
INFO - 2016-09-21 15:15:03 --> Config Class Initialized
INFO - 2016-09-21 15:15:03 --> Hooks Class Initialized
INFO - 2016-09-21 15:15:03 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:15:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:15:03 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:15:03 --> Utf8 Class Initialized
INFO - 2016-09-21 15:15:03 --> Utf8 Class Initialized
INFO - 2016-09-21 15:15:03 --> URI Class Initialized
INFO - 2016-09-21 15:15:03 --> URI Class Initialized
INFO - 2016-09-21 15:15:03 --> Router Class Initialized
INFO - 2016-09-21 15:15:03 --> Router Class Initialized
INFO - 2016-09-21 15:15:03 --> Output Class Initialized
INFO - 2016-09-21 15:15:03 --> Output Class Initialized
INFO - 2016-09-21 15:15:03 --> Security Class Initialized
INFO - 2016-09-21 15:15:03 --> Security Class Initialized
DEBUG - 2016-09-21 15:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:15:04 --> Input Class Initialized
INFO - 2016-09-21 15:15:04 --> Input Class Initialized
INFO - 2016-09-21 15:15:04 --> Language Class Initialized
INFO - 2016-09-21 15:15:04 --> Language Class Initialized
INFO - 2016-09-21 15:15:04 --> Loader Class Initialized
INFO - 2016-09-21 15:15:04 --> Loader Class Initialized
INFO - 2016-09-21 15:15:04 --> Helper loaded: url_helper
INFO - 2016-09-21 15:15:04 --> Helper loaded: url_helper
INFO - 2016-09-21 15:15:04 --> Helper loaded: form_helper
INFO - 2016-09-21 15:15:04 --> Helper loaded: form_helper
INFO - 2016-09-21 15:15:04 --> Helper loaded: html_helper
INFO - 2016-09-21 15:15:04 --> Helper loaded: html_helper
INFO - 2016-09-21 15:15:04 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:15:04 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:15:04 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:15:04 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:15:04 --> Database Driver Class Initialized
INFO - 2016-09-21 15:15:04 --> Database Driver Class Initialized
INFO - 2016-09-21 15:15:04 --> Parser Class Initialized
INFO - 2016-09-21 15:15:04 --> Parser Class Initialized
DEBUG - 2016-09-21 15:15:04 --> Session Class Initialized
DEBUG - 2016-09-21 15:15:04 --> Session Class Initialized
INFO - 2016-09-21 15:15:04 --> Helper loaded: string_helper
INFO - 2016-09-21 15:15:04 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:15:04 --> Session routines successfully run
DEBUG - 2016-09-21 15:15:04 --> Session routines successfully run
INFO - 2016-09-21 15:15:04 --> Form Validation Class Initialized
INFO - 2016-09-21 15:15:04 --> Form Validation Class Initialized
INFO - 2016-09-21 15:15:04 --> Controller Class Initialized
INFO - 2016-09-21 15:15:04 --> Controller Class Initialized
DEBUG - 2016-09-21 15:15:04 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2016-09-21 15:15:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:15:04 --> Model Class Initialized
INFO - 2016-09-21 15:15:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:15:04 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:15:04 --> Pagination Class Initialized
INFO - 2016-09-21 15:15:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2016-09-21 15:15:04 --> Final output sent to browser
INFO - 2016-09-21 15:15:04 --> Final output sent to browser
DEBUG - 2016-09-21 15:15:04 --> Total execution time: 0.3861
DEBUG - 2016-09-21 15:15:04 --> Total execution time: 0.3936
INFO - 2016-09-21 15:18:43 --> Config Class Initialized
INFO - 2016-09-21 15:18:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:18:43 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:18:43 --> Utf8 Class Initialized
INFO - 2016-09-21 15:18:43 --> URI Class Initialized
INFO - 2016-09-21 15:18:43 --> Router Class Initialized
INFO - 2016-09-21 15:18:43 --> Output Class Initialized
INFO - 2016-09-21 15:18:43 --> Security Class Initialized
DEBUG - 2016-09-21 15:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:18:43 --> Input Class Initialized
INFO - 2016-09-21 15:18:43 --> Language Class Initialized
INFO - 2016-09-21 15:18:43 --> Loader Class Initialized
INFO - 2016-09-21 15:18:43 --> Helper loaded: url_helper
INFO - 2016-09-21 15:18:43 --> Helper loaded: form_helper
INFO - 2016-09-21 15:18:43 --> Helper loaded: html_helper
INFO - 2016-09-21 15:18:43 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:18:43 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:18:43 --> Database Driver Class Initialized
INFO - 2016-09-21 15:18:43 --> Parser Class Initialized
DEBUG - 2016-09-21 15:18:43 --> Session Class Initialized
INFO - 2016-09-21 15:18:43 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:18:43 --> Session routines successfully run
INFO - 2016-09-21 15:18:43 --> Form Validation Class Initialized
INFO - 2016-09-21 15:18:43 --> Controller Class Initialized
DEBUG - 2016-09-21 15:18:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:18:43 --> Model Class Initialized
DEBUG - 2016-09-21 15:18:43 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:18:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:18:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:18:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2016-09-21 15:18:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:18:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:18:44 --> Final output sent to browser
DEBUG - 2016-09-21 15:18:44 --> Total execution time: 0.2957
INFO - 2016-09-21 15:18:44 --> Config Class Initialized
INFO - 2016-09-21 15:18:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:18:44 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:18:44 --> Utf8 Class Initialized
INFO - 2016-09-21 15:18:44 --> URI Class Initialized
INFO - 2016-09-21 15:18:44 --> Router Class Initialized
INFO - 2016-09-21 15:18:44 --> Output Class Initialized
INFO - 2016-09-21 15:18:44 --> Security Class Initialized
DEBUG - 2016-09-21 15:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:18:44 --> Input Class Initialized
INFO - 2016-09-21 15:18:44 --> Language Class Initialized
ERROR - 2016-09-21 15:18:44 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:18:44 --> Config Class Initialized
INFO - 2016-09-21 15:18:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:18:44 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:18:44 --> Utf8 Class Initialized
INFO - 2016-09-21 15:18:44 --> URI Class Initialized
INFO - 2016-09-21 15:18:44 --> Router Class Initialized
INFO - 2016-09-21 15:18:44 --> Output Class Initialized
INFO - 2016-09-21 15:18:44 --> Security Class Initialized
DEBUG - 2016-09-21 15:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:18:44 --> Input Class Initialized
INFO - 2016-09-21 15:18:44 --> Language Class Initialized
ERROR - 2016-09-21 15:18:44 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:18:44 --> Config Class Initialized
INFO - 2016-09-21 15:18:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:18:44 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:18:44 --> Utf8 Class Initialized
INFO - 2016-09-21 15:18:44 --> URI Class Initialized
INFO - 2016-09-21 15:18:44 --> Router Class Initialized
INFO - 2016-09-21 15:18:44 --> Output Class Initialized
INFO - 2016-09-21 15:18:44 --> Security Class Initialized
DEBUG - 2016-09-21 15:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:18:44 --> Input Class Initialized
INFO - 2016-09-21 15:18:44 --> Language Class Initialized
ERROR - 2016-09-21 15:18:44 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:18:44 --> Config Class Initialized
INFO - 2016-09-21 15:18:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:18:44 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:18:44 --> Utf8 Class Initialized
INFO - 2016-09-21 15:18:44 --> URI Class Initialized
INFO - 2016-09-21 15:18:44 --> Router Class Initialized
INFO - 2016-09-21 15:18:44 --> Output Class Initialized
INFO - 2016-09-21 15:18:44 --> Security Class Initialized
DEBUG - 2016-09-21 15:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:18:44 --> Input Class Initialized
INFO - 2016-09-21 15:18:44 --> Language Class Initialized
ERROR - 2016-09-21 15:18:44 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:18:44 --> Config Class Initialized
INFO - 2016-09-21 15:18:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:18:44 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:18:44 --> Utf8 Class Initialized
INFO - 2016-09-21 15:18:44 --> URI Class Initialized
INFO - 2016-09-21 15:18:44 --> Router Class Initialized
INFO - 2016-09-21 15:18:44 --> Output Class Initialized
INFO - 2016-09-21 15:18:44 --> Security Class Initialized
DEBUG - 2016-09-21 15:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:18:44 --> Input Class Initialized
INFO - 2016-09-21 15:18:44 --> Language Class Initialized
INFO - 2016-09-21 15:18:44 --> Loader Class Initialized
INFO - 2016-09-21 15:18:44 --> Helper loaded: url_helper
INFO - 2016-09-21 15:18:44 --> Helper loaded: form_helper
INFO - 2016-09-21 15:18:44 --> Helper loaded: html_helper
INFO - 2016-09-21 15:18:44 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:18:44 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:18:44 --> Database Driver Class Initialized
INFO - 2016-09-21 15:18:44 --> Parser Class Initialized
DEBUG - 2016-09-21 15:18:44 --> Session Class Initialized
INFO - 2016-09-21 15:18:44 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:18:44 --> Session routines successfully run
INFO - 2016-09-21 15:18:44 --> Form Validation Class Initialized
INFO - 2016-09-21 15:18:45 --> Controller Class Initialized
DEBUG - 2016-09-21 15:18:45 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:18:45 --> Model Class Initialized
DEBUG - 2016-09-21 15:18:45 --> Pagination Class Initialized
ERROR - 2016-09-21 15:18:45 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2016-09-21 15:18:45 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2016-09-21 15:18:45 --> Final output sent to browser
DEBUG - 2016-09-21 15:18:45 --> Total execution time: 0.2959
INFO - 2016-09-21 15:18:56 --> Config Class Initialized
INFO - 2016-09-21 15:18:56 --> Config Class Initialized
INFO - 2016-09-21 15:18:56 --> Hooks Class Initialized
INFO - 2016-09-21 15:18:56 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:18:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:18:56 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:18:56 --> Utf8 Class Initialized
INFO - 2016-09-21 15:18:56 --> Utf8 Class Initialized
INFO - 2016-09-21 15:18:56 --> URI Class Initialized
INFO - 2016-09-21 15:18:56 --> URI Class Initialized
INFO - 2016-09-21 15:18:56 --> Router Class Initialized
INFO - 2016-09-21 15:18:56 --> Router Class Initialized
INFO - 2016-09-21 15:18:56 --> Output Class Initialized
INFO - 2016-09-21 15:18:56 --> Output Class Initialized
INFO - 2016-09-21 15:18:56 --> Security Class Initialized
INFO - 2016-09-21 15:18:56 --> Security Class Initialized
DEBUG - 2016-09-21 15:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:18:56 --> Input Class Initialized
INFO - 2016-09-21 15:18:56 --> Input Class Initialized
INFO - 2016-09-21 15:18:56 --> Language Class Initialized
INFO - 2016-09-21 15:18:56 --> Language Class Initialized
INFO - 2016-09-21 15:18:56 --> Loader Class Initialized
INFO - 2016-09-21 15:18:56 --> Loader Class Initialized
INFO - 2016-09-21 15:18:56 --> Helper loaded: url_helper
INFO - 2016-09-21 15:18:56 --> Helper loaded: url_helper
INFO - 2016-09-21 15:18:57 --> Helper loaded: form_helper
INFO - 2016-09-21 15:18:57 --> Helper loaded: form_helper
INFO - 2016-09-21 15:18:57 --> Helper loaded: html_helper
INFO - 2016-09-21 15:18:57 --> Helper loaded: html_helper
INFO - 2016-09-21 15:18:57 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:18:57 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:18:57 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:18:57 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:18:57 --> Database Driver Class Initialized
INFO - 2016-09-21 15:18:57 --> Database Driver Class Initialized
INFO - 2016-09-21 15:18:57 --> Parser Class Initialized
INFO - 2016-09-21 15:18:57 --> Parser Class Initialized
DEBUG - 2016-09-21 15:18:57 --> Session Class Initialized
DEBUG - 2016-09-21 15:18:57 --> Session Class Initialized
INFO - 2016-09-21 15:18:57 --> Helper loaded: string_helper
INFO - 2016-09-21 15:18:57 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:18:57 --> Session routines successfully run
DEBUG - 2016-09-21 15:18:57 --> Session routines successfully run
INFO - 2016-09-21 15:18:57 --> Form Validation Class Initialized
INFO - 2016-09-21 15:18:57 --> Form Validation Class Initialized
INFO - 2016-09-21 15:18:57 --> Controller Class Initialized
INFO - 2016-09-21 15:18:57 --> Controller Class Initialized
DEBUG - 2016-09-21 15:18:57 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2016-09-21 15:18:57 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:18:57 --> Model Class Initialized
INFO - 2016-09-21 15:18:57 --> Model Class Initialized
DEBUG - 2016-09-21 15:18:57 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:18:57 --> Pagination Class Initialized
INFO - 2016-09-21 15:18:57 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2016-09-21 15:18:57 --> Final output sent to browser
INFO - 2016-09-21 15:18:57 --> Final output sent to browser
DEBUG - 2016-09-21 15:18:57 --> Total execution time: 0.3792
DEBUG - 2016-09-21 15:18:57 --> Total execution time: 0.3706
INFO - 2016-09-21 15:26:04 --> Config Class Initialized
INFO - 2016-09-21 15:26:04 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:26:04 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:04 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:04 --> URI Class Initialized
INFO - 2016-09-21 15:26:04 --> Router Class Initialized
INFO - 2016-09-21 15:26:04 --> Output Class Initialized
INFO - 2016-09-21 15:26:04 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:05 --> Input Class Initialized
INFO - 2016-09-21 15:26:05 --> Language Class Initialized
INFO - 2016-09-21 15:26:05 --> Loader Class Initialized
INFO - 2016-09-21 15:26:05 --> Helper loaded: url_helper
INFO - 2016-09-21 15:26:05 --> Helper loaded: form_helper
INFO - 2016-09-21 15:26:05 --> Helper loaded: html_helper
INFO - 2016-09-21 15:26:05 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:26:05 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:26:05 --> Database Driver Class Initialized
INFO - 2016-09-21 15:26:05 --> Parser Class Initialized
DEBUG - 2016-09-21 15:26:05 --> Session Class Initialized
INFO - 2016-09-21 15:26:05 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:26:05 --> Session routines successfully run
INFO - 2016-09-21 15:26:05 --> Form Validation Class Initialized
INFO - 2016-09-21 15:26:05 --> Controller Class Initialized
DEBUG - 2016-09-21 15:26:05 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:26:05 --> Model Class Initialized
DEBUG - 2016-09-21 15:26:05 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:26:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:26:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:26:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:26:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2016-09-21 15:26:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:26:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:26:05 --> Final output sent to browser
DEBUG - 2016-09-21 15:26:05 --> Total execution time: 0.4633
INFO - 2016-09-21 15:26:05 --> Config Class Initialized
INFO - 2016-09-21 15:26:05 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:26:05 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:05 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:05 --> URI Class Initialized
INFO - 2016-09-21 15:26:05 --> Router Class Initialized
INFO - 2016-09-21 15:26:05 --> Output Class Initialized
INFO - 2016-09-21 15:26:05 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:05 --> Input Class Initialized
INFO - 2016-09-21 15:26:05 --> Language Class Initialized
ERROR - 2016-09-21 15:26:05 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:26:05 --> Config Class Initialized
INFO - 2016-09-21 15:26:05 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:26:05 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:05 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:05 --> URI Class Initialized
INFO - 2016-09-21 15:26:05 --> Router Class Initialized
INFO - 2016-09-21 15:26:05 --> Output Class Initialized
INFO - 2016-09-21 15:26:05 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:05 --> Input Class Initialized
INFO - 2016-09-21 15:26:05 --> Config Class Initialized
INFO - 2016-09-21 15:26:05 --> Hooks Class Initialized
INFO - 2016-09-21 15:26:05 --> Language Class Initialized
ERROR - 2016-09-21 15:26:05 --> 404 Page Not Found: Default/assets
DEBUG - 2016-09-21 15:26:05 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:05 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:05 --> URI Class Initialized
INFO - 2016-09-21 15:26:05 --> Router Class Initialized
INFO - 2016-09-21 15:26:05 --> Output Class Initialized
INFO - 2016-09-21 15:26:05 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:05 --> Input Class Initialized
INFO - 2016-09-21 15:26:05 --> Language Class Initialized
ERROR - 2016-09-21 15:26:05 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:26:05 --> Config Class Initialized
INFO - 2016-09-21 15:26:05 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:26:05 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:05 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:05 --> URI Class Initialized
INFO - 2016-09-21 15:26:05 --> Router Class Initialized
INFO - 2016-09-21 15:26:05 --> Output Class Initialized
INFO - 2016-09-21 15:26:05 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:05 --> Input Class Initialized
INFO - 2016-09-21 15:26:05 --> Language Class Initialized
ERROR - 2016-09-21 15:26:05 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:26:05 --> Config Class Initialized
INFO - 2016-09-21 15:26:05 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:26:05 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:05 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:05 --> URI Class Initialized
INFO - 2016-09-21 15:26:06 --> Router Class Initialized
INFO - 2016-09-21 15:26:06 --> Output Class Initialized
INFO - 2016-09-21 15:26:06 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:06 --> Input Class Initialized
INFO - 2016-09-21 15:26:06 --> Language Class Initialized
INFO - 2016-09-21 15:26:06 --> Loader Class Initialized
INFO - 2016-09-21 15:26:06 --> Helper loaded: url_helper
INFO - 2016-09-21 15:26:06 --> Helper loaded: form_helper
INFO - 2016-09-21 15:26:06 --> Helper loaded: html_helper
INFO - 2016-09-21 15:26:06 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:26:06 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:26:06 --> Database Driver Class Initialized
INFO - 2016-09-21 15:26:06 --> Parser Class Initialized
DEBUG - 2016-09-21 15:26:06 --> Session Class Initialized
INFO - 2016-09-21 15:26:06 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:26:06 --> Session routines successfully run
INFO - 2016-09-21 15:26:06 --> Form Validation Class Initialized
INFO - 2016-09-21 15:26:06 --> Controller Class Initialized
DEBUG - 2016-09-21 15:26:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:26:06 --> Model Class Initialized
DEBUG - 2016-09-21 15:26:06 --> Pagination Class Initialized
ERROR - 2016-09-21 15:26:06 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2016-09-21 15:26:06 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2016-09-21 15:26:06 --> Final output sent to browser
DEBUG - 2016-09-21 15:26:06 --> Total execution time: 0.2947
INFO - 2016-09-21 15:26:20 --> Config Class Initialized
INFO - 2016-09-21 15:26:20 --> Hooks Class Initialized
INFO - 2016-09-21 15:26:20 --> Config Class Initialized
INFO - 2016-09-21 15:26:20 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:26:20 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:20 --> Utf8 Class Initialized
DEBUG - 2016-09-21 15:26:20 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:20 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:20 --> URI Class Initialized
INFO - 2016-09-21 15:26:20 --> URI Class Initialized
INFO - 2016-09-21 15:26:20 --> Router Class Initialized
INFO - 2016-09-21 15:26:20 --> Router Class Initialized
INFO - 2016-09-21 15:26:20 --> Output Class Initialized
INFO - 2016-09-21 15:26:20 --> Output Class Initialized
INFO - 2016-09-21 15:26:20 --> Security Class Initialized
INFO - 2016-09-21 15:26:20 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:20 --> Input Class Initialized
INFO - 2016-09-21 15:26:20 --> Input Class Initialized
INFO - 2016-09-21 15:26:20 --> Language Class Initialized
INFO - 2016-09-21 15:26:20 --> Language Class Initialized
INFO - 2016-09-21 15:26:20 --> Loader Class Initialized
INFO - 2016-09-21 15:26:20 --> Loader Class Initialized
INFO - 2016-09-21 15:26:20 --> Helper loaded: url_helper
INFO - 2016-09-21 15:26:20 --> Helper loaded: url_helper
INFO - 2016-09-21 15:26:20 --> Helper loaded: form_helper
INFO - 2016-09-21 15:26:20 --> Helper loaded: form_helper
INFO - 2016-09-21 15:26:20 --> Helper loaded: html_helper
INFO - 2016-09-21 15:26:20 --> Helper loaded: html_helper
INFO - 2016-09-21 15:26:20 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:26:21 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:26:21 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:26:21 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:26:21 --> Database Driver Class Initialized
INFO - 2016-09-21 15:26:21 --> Database Driver Class Initialized
INFO - 2016-09-21 15:26:21 --> Parser Class Initialized
INFO - 2016-09-21 15:26:21 --> Parser Class Initialized
DEBUG - 2016-09-21 15:26:21 --> Session Class Initialized
DEBUG - 2016-09-21 15:26:21 --> Session Class Initialized
INFO - 2016-09-21 15:26:21 --> Helper loaded: string_helper
INFO - 2016-09-21 15:26:21 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:26:21 --> Session routines successfully run
DEBUG - 2016-09-21 15:26:21 --> Session routines successfully run
INFO - 2016-09-21 15:26:21 --> Form Validation Class Initialized
INFO - 2016-09-21 15:26:21 --> Form Validation Class Initialized
INFO - 2016-09-21 15:26:21 --> Controller Class Initialized
INFO - 2016-09-21 15:26:21 --> Controller Class Initialized
DEBUG - 2016-09-21 15:26:21 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2016-09-21 15:26:21 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:26:21 --> Model Class Initialized
INFO - 2016-09-21 15:26:21 --> Model Class Initialized
DEBUG - 2016-09-21 15:26:21 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:26:21 --> Pagination Class Initialized
INFO - 2016-09-21 15:26:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2016-09-21 15:26:21 --> Final output sent to browser
INFO - 2016-09-21 15:26:21 --> Final output sent to browser
DEBUG - 2016-09-21 15:26:21 --> Total execution time: 0.4009
DEBUG - 2016-09-21 15:26:21 --> Total execution time: 0.3923
INFO - 2016-09-21 15:26:33 --> Config Class Initialized
INFO - 2016-09-21 15:26:33 --> Config Class Initialized
INFO - 2016-09-21 15:26:33 --> Hooks Class Initialized
INFO - 2016-09-21 15:26:33 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:26:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:26:33 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:33 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:33 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:33 --> URI Class Initialized
INFO - 2016-09-21 15:26:33 --> URI Class Initialized
INFO - 2016-09-21 15:26:33 --> Router Class Initialized
INFO - 2016-09-21 15:26:33 --> Router Class Initialized
INFO - 2016-09-21 15:26:33 --> Output Class Initialized
INFO - 2016-09-21 15:26:33 --> Output Class Initialized
INFO - 2016-09-21 15:26:33 --> Security Class Initialized
INFO - 2016-09-21 15:26:33 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:33 --> Input Class Initialized
INFO - 2016-09-21 15:26:33 --> Input Class Initialized
INFO - 2016-09-21 15:26:33 --> Language Class Initialized
INFO - 2016-09-21 15:26:33 --> Language Class Initialized
INFO - 2016-09-21 15:26:33 --> Loader Class Initialized
INFO - 2016-09-21 15:26:33 --> Loader Class Initialized
INFO - 2016-09-21 15:26:34 --> Helper loaded: url_helper
INFO - 2016-09-21 15:26:34 --> Helper loaded: url_helper
INFO - 2016-09-21 15:26:34 --> Helper loaded: form_helper
INFO - 2016-09-21 15:26:34 --> Helper loaded: form_helper
INFO - 2016-09-21 15:26:34 --> Helper loaded: html_helper
INFO - 2016-09-21 15:26:34 --> Helper loaded: html_helper
INFO - 2016-09-21 15:26:34 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:26:34 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:26:34 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:26:34 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:26:34 --> Database Driver Class Initialized
INFO - 2016-09-21 15:26:34 --> Database Driver Class Initialized
INFO - 2016-09-21 15:26:34 --> Parser Class Initialized
INFO - 2016-09-21 15:26:34 --> Parser Class Initialized
DEBUG - 2016-09-21 15:26:34 --> Session Class Initialized
DEBUG - 2016-09-21 15:26:34 --> Session Class Initialized
INFO - 2016-09-21 15:26:34 --> Helper loaded: string_helper
INFO - 2016-09-21 15:26:34 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:26:34 --> Session routines successfully run
DEBUG - 2016-09-21 15:26:34 --> Session routines successfully run
INFO - 2016-09-21 15:26:34 --> Form Validation Class Initialized
INFO - 2016-09-21 15:26:34 --> Form Validation Class Initialized
INFO - 2016-09-21 15:26:34 --> Controller Class Initialized
INFO - 2016-09-21 15:26:34 --> Controller Class Initialized
DEBUG - 2016-09-21 15:26:34 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2016-09-21 15:26:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:26:34 --> Model Class Initialized
INFO - 2016-09-21 15:26:34 --> Model Class Initialized
DEBUG - 2016-09-21 15:26:34 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:26:34 --> Pagination Class Initialized
INFO - 2016-09-21 15:26:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2016-09-21 15:26:34 --> Final output sent to browser
INFO - 2016-09-21 15:26:34 --> Final output sent to browser
DEBUG - 2016-09-21 15:26:34 --> Total execution time: 0.4035
DEBUG - 2016-09-21 15:26:34 --> Total execution time: 0.4117
INFO - 2016-09-21 15:26:43 --> Config Class Initialized
INFO - 2016-09-21 15:26:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:26:43 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:43 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:43 --> URI Class Initialized
INFO - 2016-09-21 15:26:43 --> Router Class Initialized
INFO - 2016-09-21 15:26:43 --> Output Class Initialized
INFO - 2016-09-21 15:26:43 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:43 --> Input Class Initialized
INFO - 2016-09-21 15:26:43 --> Language Class Initialized
INFO - 2016-09-21 15:26:43 --> Loader Class Initialized
INFO - 2016-09-21 15:26:43 --> Helper loaded: url_helper
INFO - 2016-09-21 15:26:43 --> Helper loaded: form_helper
INFO - 2016-09-21 15:26:43 --> Helper loaded: html_helper
INFO - 2016-09-21 15:26:43 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:26:43 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:26:43 --> Database Driver Class Initialized
INFO - 2016-09-21 15:26:43 --> Parser Class Initialized
DEBUG - 2016-09-21 15:26:43 --> Session Class Initialized
INFO - 2016-09-21 15:26:43 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:26:43 --> Session routines successfully run
INFO - 2016-09-21 15:26:43 --> Form Validation Class Initialized
INFO - 2016-09-21 15:26:43 --> Controller Class Initialized
DEBUG - 2016-09-21 15:26:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:26:43 --> Model Class Initialized
DEBUG - 2016-09-21 15:26:43 --> Pagination Class Initialized
INFO - 2016-09-21 15:26:43 --> Final output sent to browser
DEBUG - 2016-09-21 15:26:43 --> Total execution time: 0.2377
INFO - 2016-09-21 15:26:50 --> Config Class Initialized
INFO - 2016-09-21 15:26:50 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:26:50 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:50 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:50 --> URI Class Initialized
INFO - 2016-09-21 15:26:50 --> Router Class Initialized
INFO - 2016-09-21 15:26:50 --> Output Class Initialized
INFO - 2016-09-21 15:26:50 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:50 --> Input Class Initialized
INFO - 2016-09-21 15:26:50 --> Language Class Initialized
INFO - 2016-09-21 15:26:50 --> Loader Class Initialized
INFO - 2016-09-21 15:26:50 --> Helper loaded: url_helper
INFO - 2016-09-21 15:26:50 --> Helper loaded: form_helper
INFO - 2016-09-21 15:26:50 --> Helper loaded: html_helper
INFO - 2016-09-21 15:26:50 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:26:50 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:26:50 --> Database Driver Class Initialized
INFO - 2016-09-21 15:26:50 --> Parser Class Initialized
DEBUG - 2016-09-21 15:26:50 --> Session Class Initialized
INFO - 2016-09-21 15:26:50 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:26:50 --> Session routines successfully run
INFO - 2016-09-21 15:26:50 --> Form Validation Class Initialized
INFO - 2016-09-21 15:26:50 --> Controller Class Initialized
DEBUG - 2016-09-21 15:26:50 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:26:50 --> Model Class Initialized
DEBUG - 2016-09-21 15:26:50 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:26:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:26:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 15:26:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:26:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:26:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2016-09-21 15:26:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:26:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:26:51 --> Final output sent to browser
DEBUG - 2016-09-21 15:26:51 --> Total execution time: 0.3571
INFO - 2016-09-21 15:26:51 --> Config Class Initialized
INFO - 2016-09-21 15:26:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:26:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:51 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:51 --> URI Class Initialized
INFO - 2016-09-21 15:26:51 --> Router Class Initialized
INFO - 2016-09-21 15:26:51 --> Config Class Initialized
INFO - 2016-09-21 15:26:51 --> Output Class Initialized
INFO - 2016-09-21 15:26:51 --> Hooks Class Initialized
INFO - 2016-09-21 15:26:51 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:51 --> Utf8 Class Initialized
DEBUG - 2016-09-21 15:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:51 --> Input Class Initialized
INFO - 2016-09-21 15:26:51 --> URI Class Initialized
INFO - 2016-09-21 15:26:51 --> Language Class Initialized
INFO - 2016-09-21 15:26:51 --> Router Class Initialized
ERROR - 2016-09-21 15:26:51 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:26:51 --> Output Class Initialized
INFO - 2016-09-21 15:26:51 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:51 --> Input Class Initialized
INFO - 2016-09-21 15:26:51 --> Language Class Initialized
ERROR - 2016-09-21 15:26:51 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:26:51 --> Config Class Initialized
INFO - 2016-09-21 15:26:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:26:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:26:51 --> Utf8 Class Initialized
INFO - 2016-09-21 15:26:51 --> URI Class Initialized
INFO - 2016-09-21 15:26:51 --> Router Class Initialized
INFO - 2016-09-21 15:26:51 --> Output Class Initialized
INFO - 2016-09-21 15:26:51 --> Security Class Initialized
DEBUG - 2016-09-21 15:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:26:51 --> Input Class Initialized
INFO - 2016-09-21 15:26:51 --> Language Class Initialized
INFO - 2016-09-21 15:26:51 --> Loader Class Initialized
INFO - 2016-09-21 15:26:51 --> Helper loaded: url_helper
INFO - 2016-09-21 15:26:51 --> Helper loaded: form_helper
INFO - 2016-09-21 15:26:51 --> Helper loaded: html_helper
INFO - 2016-09-21 15:26:51 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:26:51 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:26:51 --> Database Driver Class Initialized
INFO - 2016-09-21 15:26:51 --> Parser Class Initialized
DEBUG - 2016-09-21 15:26:51 --> Session Class Initialized
INFO - 2016-09-21 15:26:51 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:26:51 --> Session routines successfully run
INFO - 2016-09-21 15:26:51 --> Form Validation Class Initialized
INFO - 2016-09-21 15:26:51 --> Controller Class Initialized
DEBUG - 2016-09-21 15:26:51 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:26:51 --> Model Class Initialized
DEBUG - 2016-09-21 15:26:51 --> Pagination Class Initialized
INFO - 2016-09-21 15:26:51 --> Final output sent to browser
DEBUG - 2016-09-21 15:26:51 --> Total execution time: 0.3476
INFO - 2016-09-21 15:27:07 --> Config Class Initialized
INFO - 2016-09-21 15:27:07 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:27:07 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:27:07 --> Utf8 Class Initialized
INFO - 2016-09-21 15:27:07 --> URI Class Initialized
INFO - 2016-09-21 15:27:07 --> Router Class Initialized
INFO - 2016-09-21 15:27:07 --> Output Class Initialized
INFO - 2016-09-21 15:27:07 --> Security Class Initialized
DEBUG - 2016-09-21 15:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:27:07 --> Input Class Initialized
INFO - 2016-09-21 15:27:07 --> Language Class Initialized
INFO - 2016-09-21 15:27:07 --> Loader Class Initialized
INFO - 2016-09-21 15:27:07 --> Helper loaded: url_helper
INFO - 2016-09-21 15:27:07 --> Helper loaded: form_helper
INFO - 2016-09-21 15:27:07 --> Helper loaded: html_helper
INFO - 2016-09-21 15:27:07 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:27:07 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:27:07 --> Database Driver Class Initialized
INFO - 2016-09-21 15:27:07 --> Parser Class Initialized
DEBUG - 2016-09-21 15:27:07 --> Session Class Initialized
INFO - 2016-09-21 15:27:07 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:27:07 --> Session routines successfully run
INFO - 2016-09-21 15:27:07 --> Form Validation Class Initialized
INFO - 2016-09-21 15:27:07 --> Controller Class Initialized
DEBUG - 2016-09-21 15:27:07 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:27:07 --> Model Class Initialized
DEBUG - 2016-09-21 15:27:07 --> Pagination Class Initialized
INFO - 2016-09-21 15:27:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:27:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:27:07 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:07 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:07 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:07 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:07 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:08 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:08 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:08 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:08 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:08 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:08 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:08 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:08 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:08 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:08 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2016-09-21 15:27:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2016-09-21 15:27:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:27:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:27:08 --> Final output sent to browser
DEBUG - 2016-09-21 15:27:08 --> Total execution time: 0.4470
INFO - 2016-09-21 15:27:20 --> Config Class Initialized
INFO - 2016-09-21 15:27:20 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:27:20 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:27:20 --> Utf8 Class Initialized
INFO - 2016-09-21 15:27:20 --> URI Class Initialized
INFO - 2016-09-21 15:27:20 --> Router Class Initialized
INFO - 2016-09-21 15:27:20 --> Output Class Initialized
INFO - 2016-09-21 15:27:20 --> Security Class Initialized
DEBUG - 2016-09-21 15:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:27:20 --> Input Class Initialized
INFO - 2016-09-21 15:27:20 --> Language Class Initialized
INFO - 2016-09-21 15:27:20 --> Loader Class Initialized
INFO - 2016-09-21 15:27:20 --> Helper loaded: url_helper
INFO - 2016-09-21 15:27:20 --> Helper loaded: form_helper
INFO - 2016-09-21 15:27:20 --> Helper loaded: html_helper
INFO - 2016-09-21 15:27:20 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:27:20 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:27:20 --> Database Driver Class Initialized
INFO - 2016-09-21 15:27:20 --> Parser Class Initialized
DEBUG - 2016-09-21 15:27:20 --> Session Class Initialized
INFO - 2016-09-21 15:27:20 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:27:20 --> Session routines successfully run
INFO - 2016-09-21 15:27:20 --> Form Validation Class Initialized
INFO - 2016-09-21 15:27:20 --> Controller Class Initialized
DEBUG - 2016-09-21 15:27:20 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:27:20 --> Model Class Initialized
DEBUG - 2016-09-21 15:27:20 --> Pagination Class Initialized
INFO - 2016-09-21 15:27:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:27:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:20 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2016-09-21 15:27:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2016-09-21 15:27:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:27:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:27:20 --> Final output sent to browser
DEBUG - 2016-09-21 15:27:20 --> Total execution time: 0.4397
INFO - 2016-09-21 15:27:31 --> Config Class Initialized
INFO - 2016-09-21 15:27:31 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:27:31 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:27:31 --> Utf8 Class Initialized
INFO - 2016-09-21 15:27:31 --> URI Class Initialized
INFO - 2016-09-21 15:27:31 --> Router Class Initialized
INFO - 2016-09-21 15:27:31 --> Output Class Initialized
INFO - 2016-09-21 15:27:31 --> Security Class Initialized
DEBUG - 2016-09-21 15:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:27:31 --> Input Class Initialized
INFO - 2016-09-21 15:27:31 --> Language Class Initialized
INFO - 2016-09-21 15:27:32 --> Loader Class Initialized
INFO - 2016-09-21 15:27:32 --> Helper loaded: url_helper
INFO - 2016-09-21 15:27:32 --> Helper loaded: form_helper
INFO - 2016-09-21 15:27:32 --> Helper loaded: html_helper
INFO - 2016-09-21 15:27:32 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:27:32 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:27:32 --> Database Driver Class Initialized
INFO - 2016-09-21 15:27:32 --> Parser Class Initialized
DEBUG - 2016-09-21 15:27:32 --> Session Class Initialized
INFO - 2016-09-21 15:27:32 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:27:32 --> Session routines successfully run
INFO - 2016-09-21 15:27:32 --> Form Validation Class Initialized
INFO - 2016-09-21 15:27:32 --> Controller Class Initialized
DEBUG - 2016-09-21 15:27:32 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:27:32 --> Model Class Initialized
DEBUG - 2016-09-21 15:27:32 --> Pagination Class Initialized
INFO - 2016-09-21 15:27:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:27:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:32 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2016-09-21 15:27:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2016-09-21 15:27:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:27:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:27:32 --> Final output sent to browser
DEBUG - 2016-09-21 15:27:32 --> Total execution time: 0.5485
INFO - 2016-09-21 15:27:36 --> Config Class Initialized
INFO - 2016-09-21 15:27:36 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:27:36 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:27:36 --> Utf8 Class Initialized
INFO - 2016-09-21 15:27:36 --> URI Class Initialized
INFO - 2016-09-21 15:27:36 --> Router Class Initialized
INFO - 2016-09-21 15:27:36 --> Output Class Initialized
INFO - 2016-09-21 15:27:36 --> Security Class Initialized
DEBUG - 2016-09-21 15:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:27:36 --> Input Class Initialized
INFO - 2016-09-21 15:27:36 --> Language Class Initialized
INFO - 2016-09-21 15:27:36 --> Loader Class Initialized
INFO - 2016-09-21 15:27:36 --> Helper loaded: url_helper
INFO - 2016-09-21 15:27:36 --> Helper loaded: form_helper
INFO - 2016-09-21 15:27:36 --> Helper loaded: html_helper
INFO - 2016-09-21 15:27:36 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:27:36 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:27:36 --> Database Driver Class Initialized
INFO - 2016-09-21 15:27:36 --> Parser Class Initialized
DEBUG - 2016-09-21 15:27:36 --> Session Class Initialized
INFO - 2016-09-21 15:27:36 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:27:36 --> Session routines successfully run
INFO - 2016-09-21 15:27:36 --> Form Validation Class Initialized
INFO - 2016-09-21 15:27:36 --> Controller Class Initialized
DEBUG - 2016-09-21 15:27:36 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:27:36 --> Model Class Initialized
DEBUG - 2016-09-21 15:27:36 --> Pagination Class Initialized
INFO - 2016-09-21 15:27:36 --> Config Class Initialized
INFO - 2016-09-21 15:27:36 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:27:36 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:27:36 --> Utf8 Class Initialized
INFO - 2016-09-21 15:27:36 --> URI Class Initialized
INFO - 2016-09-21 15:27:36 --> Router Class Initialized
INFO - 2016-09-21 15:27:36 --> Output Class Initialized
INFO - 2016-09-21 15:27:36 --> Security Class Initialized
DEBUG - 2016-09-21 15:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:27:36 --> Input Class Initialized
INFO - 2016-09-21 15:27:36 --> Language Class Initialized
INFO - 2016-09-21 15:27:36 --> Loader Class Initialized
INFO - 2016-09-21 15:27:36 --> Helper loaded: url_helper
INFO - 2016-09-21 15:27:37 --> Helper loaded: form_helper
INFO - 2016-09-21 15:27:37 --> Helper loaded: html_helper
INFO - 2016-09-21 15:27:37 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:27:37 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:27:37 --> Database Driver Class Initialized
INFO - 2016-09-21 15:27:37 --> Parser Class Initialized
DEBUG - 2016-09-21 15:27:37 --> Session Class Initialized
INFO - 2016-09-21 15:27:37 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:27:37 --> Session routines successfully run
INFO - 2016-09-21 15:27:37 --> Form Validation Class Initialized
INFO - 2016-09-21 15:27:37 --> Controller Class Initialized
DEBUG - 2016-09-21 15:27:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:27:37 --> Model Class Initialized
DEBUG - 2016-09-21 15:27:37 --> Pagination Class Initialized
INFO - 2016-09-21 15:27:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:27:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:27:37 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2016-09-21 15:27:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2016-09-21 15:27:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:27:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:27:38 --> Final output sent to browser
DEBUG - 2016-09-21 15:27:38 --> Total execution time: 1.1459
INFO - 2016-09-21 15:29:17 --> Config Class Initialized
INFO - 2016-09-21 15:29:17 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:29:17 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:29:17 --> Utf8 Class Initialized
INFO - 2016-09-21 15:29:17 --> URI Class Initialized
INFO - 2016-09-21 15:29:17 --> Router Class Initialized
INFO - 2016-09-21 15:29:17 --> Output Class Initialized
INFO - 2016-09-21 15:29:17 --> Security Class Initialized
DEBUG - 2016-09-21 15:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:29:17 --> Input Class Initialized
INFO - 2016-09-21 15:29:17 --> Language Class Initialized
INFO - 2016-09-21 15:29:17 --> Loader Class Initialized
INFO - 2016-09-21 15:29:17 --> Helper loaded: url_helper
INFO - 2016-09-21 15:29:17 --> Helper loaded: form_helper
INFO - 2016-09-21 15:29:17 --> Helper loaded: html_helper
INFO - 2016-09-21 15:29:17 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:29:17 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:29:17 --> Database Driver Class Initialized
INFO - 2016-09-21 15:29:17 --> Parser Class Initialized
DEBUG - 2016-09-21 15:29:17 --> Session Class Initialized
INFO - 2016-09-21 15:29:17 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:29:17 --> Session routines successfully run
INFO - 2016-09-21 15:29:17 --> Form Validation Class Initialized
INFO - 2016-09-21 15:29:17 --> Controller Class Initialized
DEBUG - 2016-09-21 15:29:17 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:29:17 --> Model Class Initialized
DEBUG - 2016-09-21 15:29:17 --> Pagination Class Initialized
INFO - 2016-09-21 15:29:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:29:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:17 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2016-09-21 15:29:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2016-09-21 15:29:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:29:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:29:18 --> Final output sent to browser
DEBUG - 2016-09-21 15:29:18 --> Total execution time: 1.3258
INFO - 2016-09-21 15:29:29 --> Config Class Initialized
INFO - 2016-09-21 15:29:29 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:29:29 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:29:29 --> Utf8 Class Initialized
INFO - 2016-09-21 15:29:29 --> URI Class Initialized
INFO - 2016-09-21 15:29:29 --> Router Class Initialized
INFO - 2016-09-21 15:29:29 --> Output Class Initialized
INFO - 2016-09-21 15:29:29 --> Security Class Initialized
DEBUG - 2016-09-21 15:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:29:29 --> Input Class Initialized
INFO - 2016-09-21 15:29:29 --> Language Class Initialized
INFO - 2016-09-21 15:29:29 --> Loader Class Initialized
INFO - 2016-09-21 15:29:29 --> Helper loaded: url_helper
INFO - 2016-09-21 15:29:29 --> Helper loaded: form_helper
INFO - 2016-09-21 15:29:29 --> Helper loaded: html_helper
INFO - 2016-09-21 15:29:29 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:29:29 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:29:29 --> Database Driver Class Initialized
INFO - 2016-09-21 15:29:29 --> Parser Class Initialized
DEBUG - 2016-09-21 15:29:29 --> Session Class Initialized
INFO - 2016-09-21 15:29:29 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:29:29 --> Session routines successfully run
INFO - 2016-09-21 15:29:29 --> Form Validation Class Initialized
INFO - 2016-09-21 15:29:29 --> Controller Class Initialized
DEBUG - 2016-09-21 15:29:29 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:29:29 --> Model Class Initialized
DEBUG - 2016-09-21 15:29:29 --> Pagination Class Initialized
INFO - 2016-09-21 15:29:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:29:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:29:30 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2016-09-21 15:29:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2016-09-21 15:29:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:29:30 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:29:30 --> Final output sent to browser
DEBUG - 2016-09-21 15:29:30 --> Total execution time: 1.0070
INFO - 2016-09-21 15:29:33 --> Config Class Initialized
INFO - 2016-09-21 15:29:33 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:29:33 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:29:33 --> Utf8 Class Initialized
INFO - 2016-09-21 15:29:33 --> URI Class Initialized
INFO - 2016-09-21 15:29:33 --> Router Class Initialized
INFO - 2016-09-21 15:29:33 --> Output Class Initialized
INFO - 2016-09-21 15:29:33 --> Security Class Initialized
DEBUG - 2016-09-21 15:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:29:33 --> Input Class Initialized
INFO - 2016-09-21 15:29:33 --> Language Class Initialized
INFO - 2016-09-21 15:29:33 --> Loader Class Initialized
INFO - 2016-09-21 15:29:33 --> Helper loaded: url_helper
INFO - 2016-09-21 15:29:33 --> Helper loaded: form_helper
INFO - 2016-09-21 15:29:33 --> Helper loaded: html_helper
INFO - 2016-09-21 15:29:33 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:29:33 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:29:33 --> Database Driver Class Initialized
INFO - 2016-09-21 15:29:33 --> Parser Class Initialized
DEBUG - 2016-09-21 15:29:33 --> Session Class Initialized
INFO - 2016-09-21 15:29:33 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:29:33 --> Session routines successfully run
INFO - 2016-09-21 15:29:33 --> Form Validation Class Initialized
INFO - 2016-09-21 15:29:33 --> Controller Class Initialized
DEBUG - 2016-09-21 15:29:33 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:29:33 --> Model Class Initialized
DEBUG - 2016-09-21 15:29:33 --> Pagination Class Initialized
INFO - 2016-09-21 15:29:33 --> Config Class Initialized
INFO - 2016-09-21 15:29:34 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:29:34 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:29:34 --> Utf8 Class Initialized
INFO - 2016-09-21 15:29:34 --> URI Class Initialized
INFO - 2016-09-21 15:29:34 --> Router Class Initialized
INFO - 2016-09-21 15:29:34 --> Output Class Initialized
INFO - 2016-09-21 15:29:34 --> Security Class Initialized
DEBUG - 2016-09-21 15:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:29:34 --> Input Class Initialized
INFO - 2016-09-21 15:29:34 --> Language Class Initialized
INFO - 2016-09-21 15:29:34 --> Loader Class Initialized
INFO - 2016-09-21 15:29:34 --> Helper loaded: url_helper
INFO - 2016-09-21 15:29:34 --> Helper loaded: form_helper
INFO - 2016-09-21 15:29:34 --> Helper loaded: html_helper
INFO - 2016-09-21 15:29:34 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:29:34 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:29:34 --> Database Driver Class Initialized
INFO - 2016-09-21 15:29:34 --> Parser Class Initialized
DEBUG - 2016-09-21 15:29:34 --> Session Class Initialized
INFO - 2016-09-21 15:29:34 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:29:34 --> Session routines successfully run
INFO - 2016-09-21 15:29:34 --> Form Validation Class Initialized
INFO - 2016-09-21 15:29:34 --> Controller Class Initialized
DEBUG - 2016-09-21 15:29:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:29:34 --> Model Class Initialized
DEBUG - 2016-09-21 15:29:34 --> Pagination Class Initialized
INFO - 2016-09-21 15:29:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:29:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:29:34 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
INFO - 2016-09-21 15:29:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/plan/list_plan.php
INFO - 2016-09-21 15:29:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:29:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:29:34 --> Final output sent to browser
DEBUG - 2016-09-21 15:29:34 --> Total execution time: 0.5190
INFO - 2016-09-21 15:29:37 --> Config Class Initialized
INFO - 2016-09-21 15:29:37 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:29:37 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:29:37 --> Utf8 Class Initialized
INFO - 2016-09-21 15:29:37 --> URI Class Initialized
INFO - 2016-09-21 15:29:37 --> Router Class Initialized
INFO - 2016-09-21 15:29:37 --> Output Class Initialized
INFO - 2016-09-21 15:29:37 --> Security Class Initialized
DEBUG - 2016-09-21 15:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:29:37 --> Input Class Initialized
INFO - 2016-09-21 15:29:37 --> Language Class Initialized
INFO - 2016-09-21 15:29:37 --> Loader Class Initialized
INFO - 2016-09-21 15:29:37 --> Helper loaded: url_helper
INFO - 2016-09-21 15:29:37 --> Helper loaded: form_helper
INFO - 2016-09-21 15:29:37 --> Helper loaded: html_helper
INFO - 2016-09-21 15:29:37 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:29:37 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:29:37 --> Database Driver Class Initialized
INFO - 2016-09-21 15:29:37 --> Parser Class Initialized
DEBUG - 2016-09-21 15:29:37 --> Session Class Initialized
INFO - 2016-09-21 15:29:37 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:29:37 --> Session routines successfully run
INFO - 2016-09-21 15:29:37 --> Form Validation Class Initialized
INFO - 2016-09-21 15:29:37 --> Controller Class Initialized
DEBUG - 2016-09-21 15:29:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:29:37 --> Model Class Initialized
DEBUG - 2016-09-21 15:29:37 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:29:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:29:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:29:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:29:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/plan/add_plan.php
INFO - 2016-09-21 15:29:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:29:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:29:37 --> Final output sent to browser
DEBUG - 2016-09-21 15:29:37 --> Total execution time: 0.3364
INFO - 2016-09-21 15:29:37 --> Config Class Initialized
INFO - 2016-09-21 15:29:37 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:29:37 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:29:37 --> Config Class Initialized
INFO - 2016-09-21 15:29:37 --> Hooks Class Initialized
INFO - 2016-09-21 15:29:37 --> Utf8 Class Initialized
INFO - 2016-09-21 15:29:37 --> URI Class Initialized
DEBUG - 2016-09-21 15:29:37 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:29:37 --> Router Class Initialized
INFO - 2016-09-21 15:29:37 --> Utf8 Class Initialized
INFO - 2016-09-21 15:29:37 --> URI Class Initialized
INFO - 2016-09-21 15:29:37 --> Output Class Initialized
INFO - 2016-09-21 15:29:37 --> Router Class Initialized
INFO - 2016-09-21 15:29:37 --> Security Class Initialized
INFO - 2016-09-21 15:29:37 --> Output Class Initialized
DEBUG - 2016-09-21 15:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:29:37 --> Security Class Initialized
INFO - 2016-09-21 15:29:37 --> Input Class Initialized
INFO - 2016-09-21 15:29:37 --> Language Class Initialized
DEBUG - 2016-09-21 15:29:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-21 15:29:37 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:29:37 --> Input Class Initialized
INFO - 2016-09-21 15:29:37 --> Language Class Initialized
ERROR - 2016-09-21 15:29:37 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:29:55 --> Config Class Initialized
INFO - 2016-09-21 15:29:55 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:29:55 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:29:55 --> Utf8 Class Initialized
INFO - 2016-09-21 15:29:55 --> URI Class Initialized
INFO - 2016-09-21 15:29:55 --> Router Class Initialized
INFO - 2016-09-21 15:29:55 --> Output Class Initialized
INFO - 2016-09-21 15:29:55 --> Security Class Initialized
DEBUG - 2016-09-21 15:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:29:55 --> Input Class Initialized
INFO - 2016-09-21 15:29:55 --> Language Class Initialized
INFO - 2016-09-21 15:29:55 --> Loader Class Initialized
INFO - 2016-09-21 15:29:55 --> Helper loaded: url_helper
INFO - 2016-09-21 15:29:55 --> Helper loaded: form_helper
INFO - 2016-09-21 15:29:55 --> Helper loaded: html_helper
INFO - 2016-09-21 15:29:55 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:29:55 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:29:56 --> Database Driver Class Initialized
INFO - 2016-09-21 15:29:56 --> Parser Class Initialized
DEBUG - 2016-09-21 15:29:56 --> Session Class Initialized
INFO - 2016-09-21 15:29:56 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:29:56 --> Session routines successfully run
INFO - 2016-09-21 15:29:56 --> Form Validation Class Initialized
INFO - 2016-09-21 15:29:56 --> Controller Class Initialized
DEBUG - 2016-09-21 15:29:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:29:56 --> Model Class Initialized
DEBUG - 2016-09-21 15:29:56 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:29:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:29:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 15:29:56 --> Config Class Initialized
INFO - 2016-09-21 15:29:56 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:29:56 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:29:56 --> Utf8 Class Initialized
INFO - 2016-09-21 15:29:56 --> URI Class Initialized
INFO - 2016-09-21 15:29:56 --> Router Class Initialized
INFO - 2016-09-21 15:29:56 --> Output Class Initialized
INFO - 2016-09-21 15:29:56 --> Security Class Initialized
DEBUG - 2016-09-21 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:29:56 --> Input Class Initialized
INFO - 2016-09-21 15:29:56 --> Language Class Initialized
INFO - 2016-09-21 15:29:56 --> Loader Class Initialized
INFO - 2016-09-21 15:29:56 --> Helper loaded: url_helper
INFO - 2016-09-21 15:29:56 --> Helper loaded: form_helper
INFO - 2016-09-21 15:29:56 --> Helper loaded: html_helper
INFO - 2016-09-21 15:29:56 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:29:56 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:29:56 --> Database Driver Class Initialized
INFO - 2016-09-21 15:29:56 --> Parser Class Initialized
DEBUG - 2016-09-21 15:29:56 --> Session Class Initialized
INFO - 2016-09-21 15:29:56 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:29:56 --> Session routines successfully run
INFO - 2016-09-21 15:29:56 --> Form Validation Class Initialized
INFO - 2016-09-21 15:29:56 --> Controller Class Initialized
DEBUG - 2016-09-21 15:29:56 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:29:56 --> Model Class Initialized
DEBUG - 2016-09-21 15:29:56 --> Pagination Class Initialized
INFO - 2016-09-21 15:29:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:29:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:29:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
INFO - 2016-09-21 15:29:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/plan/list_plan.php
INFO - 2016-09-21 15:29:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:29:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:29:56 --> Final output sent to browser
DEBUG - 2016-09-21 15:29:56 --> Total execution time: 0.5653
INFO - 2016-09-21 15:30:01 --> Config Class Initialized
INFO - 2016-09-21 15:30:01 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:30:01 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:30:01 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:01 --> URI Class Initialized
INFO - 2016-09-21 15:30:01 --> Router Class Initialized
INFO - 2016-09-21 15:30:01 --> Output Class Initialized
INFO - 2016-09-21 15:30:01 --> Security Class Initialized
DEBUG - 2016-09-21 15:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:30:01 --> Input Class Initialized
INFO - 2016-09-21 15:30:01 --> Language Class Initialized
INFO - 2016-09-21 15:30:01 --> Loader Class Initialized
INFO - 2016-09-21 15:30:01 --> Helper loaded: url_helper
INFO - 2016-09-21 15:30:01 --> Helper loaded: form_helper
INFO - 2016-09-21 15:30:01 --> Helper loaded: html_helper
INFO - 2016-09-21 15:30:01 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:30:01 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:30:01 --> Database Driver Class Initialized
INFO - 2016-09-21 15:30:01 --> Parser Class Initialized
DEBUG - 2016-09-21 15:30:01 --> Session Class Initialized
INFO - 2016-09-21 15:30:01 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:30:01 --> Session routines successfully run
INFO - 2016-09-21 15:30:01 --> Form Validation Class Initialized
INFO - 2016-09-21 15:30:01 --> Controller Class Initialized
DEBUG - 2016-09-21 15:30:01 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:30:01 --> Model Class Initialized
DEBUG - 2016-09-21 15:30:01 --> Pagination Class Initialized
INFO - 2016-09-21 15:30:01 --> Config Class Initialized
INFO - 2016-09-21 15:30:01 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:30:01 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:30:01 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:01 --> URI Class Initialized
INFO - 2016-09-21 15:30:01 --> Router Class Initialized
INFO - 2016-09-21 15:30:01 --> Output Class Initialized
INFO - 2016-09-21 15:30:01 --> Security Class Initialized
DEBUG - 2016-09-21 15:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:30:01 --> Input Class Initialized
INFO - 2016-09-21 15:30:01 --> Language Class Initialized
INFO - 2016-09-21 15:30:01 --> Loader Class Initialized
INFO - 2016-09-21 15:30:01 --> Helper loaded: url_helper
INFO - 2016-09-21 15:30:01 --> Helper loaded: form_helper
INFO - 2016-09-21 15:30:01 --> Helper loaded: html_helper
INFO - 2016-09-21 15:30:01 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:30:01 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:30:01 --> Database Driver Class Initialized
INFO - 2016-09-21 15:30:01 --> Parser Class Initialized
DEBUG - 2016-09-21 15:30:01 --> Session Class Initialized
INFO - 2016-09-21 15:30:01 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:30:01 --> Session routines successfully run
INFO - 2016-09-21 15:30:01 --> Form Validation Class Initialized
INFO - 2016-09-21 15:30:02 --> Controller Class Initialized
DEBUG - 2016-09-21 15:30:02 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:30:02 --> Model Class Initialized
DEBUG - 2016-09-21 15:30:02 --> Pagination Class Initialized
INFO - 2016-09-21 15:30:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:30:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:30:02 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
INFO - 2016-09-21 15:30:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/plan/list_plan.php
INFO - 2016-09-21 15:30:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:30:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:30:02 --> Final output sent to browser
DEBUG - 2016-09-21 15:30:02 --> Total execution time: 0.5592
INFO - 2016-09-21 15:30:04 --> Config Class Initialized
INFO - 2016-09-21 15:30:04 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:30:04 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:30:04 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:04 --> URI Class Initialized
INFO - 2016-09-21 15:30:04 --> Router Class Initialized
INFO - 2016-09-21 15:30:04 --> Output Class Initialized
INFO - 2016-09-21 15:30:04 --> Security Class Initialized
DEBUG - 2016-09-21 15:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:30:04 --> Input Class Initialized
INFO - 2016-09-21 15:30:04 --> Language Class Initialized
INFO - 2016-09-21 15:30:04 --> Loader Class Initialized
INFO - 2016-09-21 15:30:04 --> Helper loaded: url_helper
INFO - 2016-09-21 15:30:04 --> Helper loaded: form_helper
INFO - 2016-09-21 15:30:04 --> Helper loaded: html_helper
INFO - 2016-09-21 15:30:04 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:30:04 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:30:04 --> Database Driver Class Initialized
INFO - 2016-09-21 15:30:04 --> Parser Class Initialized
DEBUG - 2016-09-21 15:30:04 --> Session Class Initialized
INFO - 2016-09-21 15:30:04 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:30:04 --> Session routines successfully run
INFO - 2016-09-21 15:30:04 --> Form Validation Class Initialized
INFO - 2016-09-21 15:30:04 --> Controller Class Initialized
DEBUG - 2016-09-21 15:30:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:30:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:30:04 --> Pagination Class Initialized
INFO - 2016-09-21 15:30:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:30:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:30:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/plan/add_plan.php
INFO - 2016-09-21 15:30:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:30:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:30:04 --> Final output sent to browser
DEBUG - 2016-09-21 15:30:04 --> Total execution time: 0.3560
INFO - 2016-09-21 15:30:04 --> Config Class Initialized
INFO - 2016-09-21 15:30:04 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:30:04 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:30:04 --> Config Class Initialized
INFO - 2016-09-21 15:30:04 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:04 --> Hooks Class Initialized
INFO - 2016-09-21 15:30:04 --> URI Class Initialized
DEBUG - 2016-09-21 15:30:04 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:30:04 --> Router Class Initialized
INFO - 2016-09-21 15:30:04 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:04 --> URI Class Initialized
INFO - 2016-09-21 15:30:04 --> Output Class Initialized
INFO - 2016-09-21 15:30:04 --> Router Class Initialized
INFO - 2016-09-21 15:30:04 --> Security Class Initialized
INFO - 2016-09-21 15:30:04 --> Output Class Initialized
DEBUG - 2016-09-21 15:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:30:04 --> Security Class Initialized
INFO - 2016-09-21 15:30:04 --> Input Class Initialized
INFO - 2016-09-21 15:30:04 --> Language Class Initialized
DEBUG - 2016-09-21 15:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-21 15:30:04 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:30:04 --> Input Class Initialized
INFO - 2016-09-21 15:30:04 --> Language Class Initialized
ERROR - 2016-09-21 15:30:04 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:30:06 --> Config Class Initialized
INFO - 2016-09-21 15:30:06 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:30:06 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:30:06 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:06 --> URI Class Initialized
INFO - 2016-09-21 15:30:06 --> Router Class Initialized
INFO - 2016-09-21 15:30:06 --> Output Class Initialized
INFO - 2016-09-21 15:30:06 --> Security Class Initialized
DEBUG - 2016-09-21 15:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:30:06 --> Input Class Initialized
INFO - 2016-09-21 15:30:06 --> Language Class Initialized
INFO - 2016-09-21 15:30:06 --> Loader Class Initialized
INFO - 2016-09-21 15:30:06 --> Helper loaded: url_helper
INFO - 2016-09-21 15:30:06 --> Helper loaded: form_helper
INFO - 2016-09-21 15:30:06 --> Helper loaded: html_helper
INFO - 2016-09-21 15:30:06 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:30:06 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:30:06 --> Database Driver Class Initialized
INFO - 2016-09-21 15:30:06 --> Parser Class Initialized
DEBUG - 2016-09-21 15:30:06 --> Session Class Initialized
INFO - 2016-09-21 15:30:06 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:30:06 --> Session routines successfully run
INFO - 2016-09-21 15:30:06 --> Form Validation Class Initialized
INFO - 2016-09-21 15:30:06 --> Controller Class Initialized
DEBUG - 2016-09-21 15:30:06 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:30:06 --> Model Class Initialized
DEBUG - 2016-09-21 15:30:06 --> Pagination Class Initialized
INFO - 2016-09-21 15:30:06 --> Config Class Initialized
INFO - 2016-09-21 15:30:06 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:30:06 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:30:06 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:07 --> URI Class Initialized
INFO - 2016-09-21 15:30:07 --> Router Class Initialized
INFO - 2016-09-21 15:30:07 --> Output Class Initialized
INFO - 2016-09-21 15:30:07 --> Security Class Initialized
DEBUG - 2016-09-21 15:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:30:07 --> Input Class Initialized
INFO - 2016-09-21 15:30:07 --> Language Class Initialized
INFO - 2016-09-21 15:30:07 --> Loader Class Initialized
INFO - 2016-09-21 15:30:07 --> Helper loaded: url_helper
INFO - 2016-09-21 15:30:07 --> Helper loaded: form_helper
INFO - 2016-09-21 15:30:07 --> Helper loaded: html_helper
INFO - 2016-09-21 15:30:07 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:30:07 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:30:07 --> Database Driver Class Initialized
INFO - 2016-09-21 15:30:07 --> Parser Class Initialized
DEBUG - 2016-09-21 15:30:07 --> Session Class Initialized
INFO - 2016-09-21 15:30:07 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:30:07 --> Session routines successfully run
INFO - 2016-09-21 15:30:07 --> Form Validation Class Initialized
INFO - 2016-09-21 15:30:07 --> Controller Class Initialized
DEBUG - 2016-09-21 15:30:07 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:30:07 --> Model Class Initialized
DEBUG - 2016-09-21 15:30:07 --> Pagination Class Initialized
INFO - 2016-09-21 15:30:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:30:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 290
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 293
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 294
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 295
ERROR - 2016-09-21 15:30:07 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\plan\list_plan.php 296
INFO - 2016-09-21 15:30:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/plan/list_plan.php
INFO - 2016-09-21 15:30:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:30:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:30:07 --> Final output sent to browser
DEBUG - 2016-09-21 15:30:07 --> Total execution time: 0.5884
INFO - 2016-09-21 15:30:10 --> Config Class Initialized
INFO - 2016-09-21 15:30:10 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:30:10 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:30:10 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:10 --> URI Class Initialized
INFO - 2016-09-21 15:30:10 --> Router Class Initialized
INFO - 2016-09-21 15:30:10 --> Output Class Initialized
INFO - 2016-09-21 15:30:10 --> Security Class Initialized
DEBUG - 2016-09-21 15:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:30:10 --> Input Class Initialized
INFO - 2016-09-21 15:30:10 --> Language Class Initialized
INFO - 2016-09-21 15:30:10 --> Loader Class Initialized
INFO - 2016-09-21 15:30:10 --> Helper loaded: url_helper
INFO - 2016-09-21 15:30:10 --> Helper loaded: form_helper
INFO - 2016-09-21 15:30:10 --> Helper loaded: html_helper
INFO - 2016-09-21 15:30:10 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:30:10 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:30:10 --> Database Driver Class Initialized
INFO - 2016-09-21 15:30:10 --> Parser Class Initialized
DEBUG - 2016-09-21 15:30:10 --> Session Class Initialized
INFO - 2016-09-21 15:30:10 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:30:10 --> Session routines successfully run
INFO - 2016-09-21 15:30:10 --> Form Validation Class Initialized
INFO - 2016-09-21 15:30:10 --> Controller Class Initialized
DEBUG - 2016-09-21 15:30:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:30:10 --> Model Class Initialized
DEBUG - 2016-09-21 15:30:10 --> Pagination Class Initialized
INFO - 2016-09-21 15:30:10 --> Config Class Initialized
INFO - 2016-09-21 15:30:10 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:30:10 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:30:10 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:10 --> URI Class Initialized
INFO - 2016-09-21 15:30:10 --> Router Class Initialized
INFO - 2016-09-21 15:30:10 --> Output Class Initialized
INFO - 2016-09-21 15:30:10 --> Security Class Initialized
DEBUG - 2016-09-21 15:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:30:10 --> Input Class Initialized
INFO - 2016-09-21 15:30:10 --> Language Class Initialized
INFO - 2016-09-21 15:30:10 --> Loader Class Initialized
INFO - 2016-09-21 15:30:10 --> Helper loaded: url_helper
INFO - 2016-09-21 15:30:10 --> Helper loaded: form_helper
INFO - 2016-09-21 15:30:10 --> Helper loaded: html_helper
INFO - 2016-09-21 15:30:10 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:30:10 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:30:10 --> Database Driver Class Initialized
INFO - 2016-09-21 15:30:10 --> Parser Class Initialized
DEBUG - 2016-09-21 15:30:10 --> Session Class Initialized
INFO - 2016-09-21 15:30:10 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:30:10 --> Session routines successfully run
INFO - 2016-09-21 15:30:10 --> Form Validation Class Initialized
INFO - 2016-09-21 15:30:10 --> Controller Class Initialized
DEBUG - 2016-09-21 15:30:10 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:30:10 --> Model Class Initialized
DEBUG - 2016-09-21 15:30:10 --> Pagination Class Initialized
INFO - 2016-09-21 15:30:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:30:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:30:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2016-09-21 15:30:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:30:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:30:12 --> Final output sent to browser
DEBUG - 2016-09-21 15:30:12 --> Total execution time: 2.3845
INFO - 2016-09-21 15:30:16 --> Config Class Initialized
INFO - 2016-09-21 15:30:16 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:30:16 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:30:16 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:16 --> URI Class Initialized
INFO - 2016-09-21 15:30:16 --> Router Class Initialized
INFO - 2016-09-21 15:30:16 --> Output Class Initialized
INFO - 2016-09-21 15:30:16 --> Security Class Initialized
DEBUG - 2016-09-21 15:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:30:16 --> Input Class Initialized
INFO - 2016-09-21 15:30:16 --> Language Class Initialized
INFO - 2016-09-21 15:30:16 --> Loader Class Initialized
INFO - 2016-09-21 15:30:16 --> Helper loaded: url_helper
INFO - 2016-09-21 15:30:16 --> Helper loaded: form_helper
INFO - 2016-09-21 15:30:16 --> Helper loaded: html_helper
INFO - 2016-09-21 15:30:16 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:30:16 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:30:16 --> Database Driver Class Initialized
INFO - 2016-09-21 15:30:16 --> Parser Class Initialized
DEBUG - 2016-09-21 15:30:16 --> Session Class Initialized
INFO - 2016-09-21 15:30:16 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:30:16 --> Session routines successfully run
INFO - 2016-09-21 15:30:16 --> Form Validation Class Initialized
INFO - 2016-09-21 15:30:16 --> Controller Class Initialized
DEBUG - 2016-09-21 15:30:16 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:30:16 --> Model Class Initialized
DEBUG - 2016-09-21 15:30:16 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:30:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:30:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:30:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:30:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2016-09-21 15:30:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:30:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:30:16 --> Final output sent to browser
DEBUG - 2016-09-21 15:30:17 --> Total execution time: 0.4083
INFO - 2016-09-21 15:30:17 --> Config Class Initialized
INFO - 2016-09-21 15:30:17 --> Config Class Initialized
INFO - 2016-09-21 15:30:17 --> Hooks Class Initialized
INFO - 2016-09-21 15:30:17 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:30:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:30:17 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:30:17 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:17 --> Utf8 Class Initialized
INFO - 2016-09-21 15:30:17 --> URI Class Initialized
INFO - 2016-09-21 15:30:17 --> URI Class Initialized
INFO - 2016-09-21 15:30:17 --> Router Class Initialized
INFO - 2016-09-21 15:30:17 --> Router Class Initialized
INFO - 2016-09-21 15:30:17 --> Output Class Initialized
INFO - 2016-09-21 15:30:17 --> Output Class Initialized
INFO - 2016-09-21 15:30:17 --> Security Class Initialized
INFO - 2016-09-21 15:30:17 --> Security Class Initialized
DEBUG - 2016-09-21 15:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:30:17 --> Input Class Initialized
INFO - 2016-09-21 15:30:17 --> Input Class Initialized
INFO - 2016-09-21 15:30:17 --> Language Class Initialized
INFO - 2016-09-21 15:30:17 --> Language Class Initialized
ERROR - 2016-09-21 15:30:17 --> 404 Page Not Found: Default/assets
ERROR - 2016-09-21 15:30:17 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:31:41 --> Config Class Initialized
INFO - 2016-09-21 15:31:41 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:31:41 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:31:41 --> Utf8 Class Initialized
INFO - 2016-09-21 15:31:41 --> URI Class Initialized
INFO - 2016-09-21 15:31:41 --> Router Class Initialized
INFO - 2016-09-21 15:31:41 --> Output Class Initialized
INFO - 2016-09-21 15:31:41 --> Security Class Initialized
DEBUG - 2016-09-21 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:31:41 --> Input Class Initialized
INFO - 2016-09-21 15:31:41 --> Language Class Initialized
INFO - 2016-09-21 15:31:41 --> Loader Class Initialized
INFO - 2016-09-21 15:31:41 --> Helper loaded: url_helper
INFO - 2016-09-21 15:31:41 --> Helper loaded: form_helper
INFO - 2016-09-21 15:31:41 --> Helper loaded: html_helper
INFO - 2016-09-21 15:31:41 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:31:41 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:31:41 --> Database Driver Class Initialized
INFO - 2016-09-21 15:31:41 --> Parser Class Initialized
DEBUG - 2016-09-21 15:31:41 --> Session Class Initialized
INFO - 2016-09-21 15:31:41 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:31:41 --> Session routines successfully run
INFO - 2016-09-21 15:31:41 --> Form Validation Class Initialized
INFO - 2016-09-21 15:31:41 --> Controller Class Initialized
DEBUG - 2016-09-21 15:31:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:31:41 --> Model Class Initialized
DEBUG - 2016-09-21 15:31:41 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:31:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:31:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 15:31:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:31:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:31:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2016-09-21 15:31:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:31:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:31:41 --> Final output sent to browser
DEBUG - 2016-09-21 15:31:41 --> Total execution time: 0.4195
INFO - 2016-09-21 15:31:41 --> Config Class Initialized
INFO - 2016-09-21 15:31:41 --> Hooks Class Initialized
INFO - 2016-09-21 15:31:41 --> Config Class Initialized
INFO - 2016-09-21 15:31:41 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:31:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:31:42 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:31:42 --> Utf8 Class Initialized
INFO - 2016-09-21 15:31:42 --> Utf8 Class Initialized
INFO - 2016-09-21 15:31:42 --> URI Class Initialized
INFO - 2016-09-21 15:31:42 --> URI Class Initialized
INFO - 2016-09-21 15:31:42 --> Router Class Initialized
INFO - 2016-09-21 15:31:42 --> Router Class Initialized
INFO - 2016-09-21 15:31:42 --> Output Class Initialized
INFO - 2016-09-21 15:31:42 --> Output Class Initialized
INFO - 2016-09-21 15:31:42 --> Security Class Initialized
INFO - 2016-09-21 15:31:42 --> Security Class Initialized
DEBUG - 2016-09-21 15:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:31:42 --> Input Class Initialized
INFO - 2016-09-21 15:31:42 --> Input Class Initialized
INFO - 2016-09-21 15:31:42 --> Language Class Initialized
INFO - 2016-09-21 15:31:42 --> Language Class Initialized
ERROR - 2016-09-21 15:31:42 --> 404 Page Not Found: Default/assets
ERROR - 2016-09-21 15:31:42 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:31:58 --> Config Class Initialized
INFO - 2016-09-21 15:31:58 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:31:58 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:31:58 --> Utf8 Class Initialized
INFO - 2016-09-21 15:31:58 --> URI Class Initialized
INFO - 2016-09-21 15:31:58 --> Router Class Initialized
INFO - 2016-09-21 15:31:58 --> Output Class Initialized
INFO - 2016-09-21 15:31:58 --> Security Class Initialized
DEBUG - 2016-09-21 15:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:31:58 --> Input Class Initialized
INFO - 2016-09-21 15:31:58 --> Language Class Initialized
INFO - 2016-09-21 15:31:58 --> Loader Class Initialized
INFO - 2016-09-21 15:31:58 --> Helper loaded: url_helper
INFO - 2016-09-21 15:31:58 --> Helper loaded: form_helper
INFO - 2016-09-21 15:31:58 --> Helper loaded: html_helper
INFO - 2016-09-21 15:31:58 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:31:58 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:31:58 --> Database Driver Class Initialized
INFO - 2016-09-21 15:31:58 --> Parser Class Initialized
DEBUG - 2016-09-21 15:31:58 --> Session Class Initialized
INFO - 2016-09-21 15:31:58 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:31:58 --> Session routines successfully run
INFO - 2016-09-21 15:31:58 --> Form Validation Class Initialized
INFO - 2016-09-21 15:31:58 --> Controller Class Initialized
DEBUG - 2016-09-21 15:31:58 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:31:58 --> Model Class Initialized
DEBUG - 2016-09-21 15:31:58 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:31:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:31:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-09-21 15:31:58 --> Config file loaded: ../application/admin/config/chargify.php
ERROR - 2016-09-21 15:32:00 --> Severity: error --> Exception: String could not be parsed as XML C:\xampp\htdocs\schedullo\application\admin\libraries\chargify_lib\ChargifyConnector.php 428
INFO - 2016-09-21 15:32:15 --> Config Class Initialized
INFO - 2016-09-21 15:32:15 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:15 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:15 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:15 --> URI Class Initialized
INFO - 2016-09-21 15:32:15 --> Router Class Initialized
INFO - 2016-09-21 15:32:15 --> Output Class Initialized
INFO - 2016-09-21 15:32:15 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:15 --> Input Class Initialized
INFO - 2016-09-21 15:32:15 --> Language Class Initialized
INFO - 2016-09-21 15:32:15 --> Loader Class Initialized
INFO - 2016-09-21 15:32:15 --> Helper loaded: url_helper
INFO - 2016-09-21 15:32:15 --> Helper loaded: form_helper
INFO - 2016-09-21 15:32:15 --> Helper loaded: html_helper
INFO - 2016-09-21 15:32:15 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:32:15 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:32:15 --> Database Driver Class Initialized
INFO - 2016-09-21 15:32:15 --> Parser Class Initialized
DEBUG - 2016-09-21 15:32:15 --> Session Class Initialized
INFO - 2016-09-21 15:32:15 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:32:15 --> Session routines successfully run
INFO - 2016-09-21 15:32:15 --> Form Validation Class Initialized
INFO - 2016-09-21 15:32:15 --> Controller Class Initialized
DEBUG - 2016-09-21 15:32:15 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:32:15 --> Model Class Initialized
DEBUG - 2016-09-21 15:32:15 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:32:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:32:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 15:32:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:32:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:32:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2016-09-21 15:32:15 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:32:16 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:32:16 --> Final output sent to browser
DEBUG - 2016-09-21 15:32:16 --> Total execution time: 0.4050
INFO - 2016-09-21 15:32:16 --> Config Class Initialized
INFO - 2016-09-21 15:32:16 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:16 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:16 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:16 --> URI Class Initialized
INFO - 2016-09-21 15:32:16 --> Router Class Initialized
INFO - 2016-09-21 15:32:16 --> Output Class Initialized
INFO - 2016-09-21 15:32:16 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:16 --> Input Class Initialized
INFO - 2016-09-21 15:32:16 --> Language Class Initialized
ERROR - 2016-09-21 15:32:16 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:32:16 --> Config Class Initialized
INFO - 2016-09-21 15:32:16 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:16 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:16 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:16 --> Config Class Initialized
INFO - 2016-09-21 15:32:16 --> URI Class Initialized
INFO - 2016-09-21 15:32:16 --> Hooks Class Initialized
INFO - 2016-09-21 15:32:16 --> Router Class Initialized
DEBUG - 2016-09-21 15:32:16 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:16 --> Output Class Initialized
INFO - 2016-09-21 15:32:16 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:16 --> URI Class Initialized
INFO - 2016-09-21 15:32:16 --> Security Class Initialized
INFO - 2016-09-21 15:32:16 --> Router Class Initialized
DEBUG - 2016-09-21 15:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:16 --> Output Class Initialized
INFO - 2016-09-21 15:32:16 --> Input Class Initialized
INFO - 2016-09-21 15:32:16 --> Language Class Initialized
INFO - 2016-09-21 15:32:16 --> Security Class Initialized
ERROR - 2016-09-21 15:32:16 --> 404 Page Not Found: Default/assets
DEBUG - 2016-09-21 15:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:16 --> Input Class Initialized
INFO - 2016-09-21 15:32:16 --> Language Class Initialized
ERROR - 2016-09-21 15:32:16 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:32:16 --> Config Class Initialized
INFO - 2016-09-21 15:32:16 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:16 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:16 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:16 --> URI Class Initialized
INFO - 2016-09-21 15:32:16 --> Router Class Initialized
INFO - 2016-09-21 15:32:16 --> Output Class Initialized
INFO - 2016-09-21 15:32:16 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:16 --> Input Class Initialized
INFO - 2016-09-21 15:32:16 --> Language Class Initialized
ERROR - 2016-09-21 15:32:16 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:32:20 --> Config Class Initialized
INFO - 2016-09-21 15:32:20 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:20 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:20 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:20 --> URI Class Initialized
INFO - 2016-09-21 15:32:20 --> Router Class Initialized
INFO - 2016-09-21 15:32:20 --> Output Class Initialized
INFO - 2016-09-21 15:32:20 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:20 --> Input Class Initialized
INFO - 2016-09-21 15:32:20 --> Language Class Initialized
INFO - 2016-09-21 15:32:20 --> Loader Class Initialized
INFO - 2016-09-21 15:32:20 --> Helper loaded: url_helper
INFO - 2016-09-21 15:32:20 --> Helper loaded: form_helper
INFO - 2016-09-21 15:32:20 --> Helper loaded: html_helper
INFO - 2016-09-21 15:32:20 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:32:20 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:32:20 --> Database Driver Class Initialized
INFO - 2016-09-21 15:32:20 --> Parser Class Initialized
DEBUG - 2016-09-21 15:32:20 --> Session Class Initialized
INFO - 2016-09-21 15:32:20 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:32:20 --> Session routines successfully run
INFO - 2016-09-21 15:32:20 --> Form Validation Class Initialized
INFO - 2016-09-21 15:32:20 --> Controller Class Initialized
DEBUG - 2016-09-21 15:32:20 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:32:20 --> Model Class Initialized
DEBUG - 2016-09-21 15:32:20 --> Pagination Class Initialized
INFO - 2016-09-21 15:32:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:32:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:32:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2016-09-21 15:32:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:32:21 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:32:21 --> Final output sent to browser
DEBUG - 2016-09-21 15:32:21 --> Total execution time: 1.4038
INFO - 2016-09-21 15:32:26 --> Config Class Initialized
INFO - 2016-09-21 15:32:26 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:26 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:26 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:26 --> URI Class Initialized
INFO - 2016-09-21 15:32:26 --> Router Class Initialized
INFO - 2016-09-21 15:32:26 --> Output Class Initialized
INFO - 2016-09-21 15:32:26 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:26 --> Input Class Initialized
INFO - 2016-09-21 15:32:26 --> Language Class Initialized
INFO - 2016-09-21 15:32:26 --> Loader Class Initialized
INFO - 2016-09-21 15:32:26 --> Helper loaded: url_helper
INFO - 2016-09-21 15:32:26 --> Helper loaded: form_helper
INFO - 2016-09-21 15:32:26 --> Helper loaded: html_helper
INFO - 2016-09-21 15:32:26 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:32:26 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:32:26 --> Database Driver Class Initialized
INFO - 2016-09-21 15:32:26 --> Parser Class Initialized
DEBUG - 2016-09-21 15:32:26 --> Session Class Initialized
INFO - 2016-09-21 15:32:26 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:32:26 --> Session routines successfully run
INFO - 2016-09-21 15:32:26 --> Form Validation Class Initialized
INFO - 2016-09-21 15:32:26 --> Controller Class Initialized
DEBUG - 2016-09-21 15:32:26 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:32:26 --> Model Class Initialized
DEBUG - 2016-09-21 15:32:26 --> Pagination Class Initialized
INFO - 2016-09-21 15:32:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:32:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:32:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/add_company.php
INFO - 2016-09-21 15:32:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:32:27 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:32:27 --> Final output sent to browser
DEBUG - 2016-09-21 15:32:27 --> Total execution time: 1.3111
INFO - 2016-09-21 15:32:27 --> Config Class Initialized
INFO - 2016-09-21 15:32:27 --> Config Class Initialized
INFO - 2016-09-21 15:32:27 --> Hooks Class Initialized
INFO - 2016-09-21 15:32:27 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:32:27 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:27 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:27 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:27 --> URI Class Initialized
INFO - 2016-09-21 15:32:27 --> URI Class Initialized
INFO - 2016-09-21 15:32:27 --> Router Class Initialized
INFO - 2016-09-21 15:32:27 --> Router Class Initialized
INFO - 2016-09-21 15:32:27 --> Output Class Initialized
INFO - 2016-09-21 15:32:27 --> Output Class Initialized
INFO - 2016-09-21 15:32:27 --> Security Class Initialized
INFO - 2016-09-21 15:32:27 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:27 --> Input Class Initialized
INFO - 2016-09-21 15:32:27 --> Input Class Initialized
INFO - 2016-09-21 15:32:27 --> Language Class Initialized
INFO - 2016-09-21 15:32:27 --> Language Class Initialized
ERROR - 2016-09-21 15:32:27 --> 404 Page Not Found: Default/assets
ERROR - 2016-09-21 15:32:27 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:32:37 --> Config Class Initialized
INFO - 2016-09-21 15:32:37 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:37 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:37 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:37 --> URI Class Initialized
INFO - 2016-09-21 15:32:37 --> Router Class Initialized
INFO - 2016-09-21 15:32:37 --> Output Class Initialized
INFO - 2016-09-21 15:32:37 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:37 --> Input Class Initialized
INFO - 2016-09-21 15:32:37 --> Language Class Initialized
INFO - 2016-09-21 15:32:37 --> Loader Class Initialized
INFO - 2016-09-21 15:32:37 --> Helper loaded: url_helper
INFO - 2016-09-21 15:32:37 --> Helper loaded: form_helper
INFO - 2016-09-21 15:32:37 --> Helper loaded: html_helper
INFO - 2016-09-21 15:32:37 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:32:37 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:32:37 --> Database Driver Class Initialized
INFO - 2016-09-21 15:32:37 --> Parser Class Initialized
DEBUG - 2016-09-21 15:32:37 --> Session Class Initialized
INFO - 2016-09-21 15:32:37 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:32:37 --> Session routines successfully run
INFO - 2016-09-21 15:32:37 --> Form Validation Class Initialized
INFO - 2016-09-21 15:32:37 --> Controller Class Initialized
DEBUG - 2016-09-21 15:32:37 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:32:37 --> Model Class Initialized
DEBUG - 2016-09-21 15:32:37 --> Pagination Class Initialized
INFO - 2016-09-21 15:32:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:32:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:32:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2016-09-21 15:32:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:32:38 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:32:38 --> Final output sent to browser
DEBUG - 2016-09-21 15:32:38 --> Total execution time: 1.3124
INFO - 2016-09-21 15:32:40 --> Config Class Initialized
INFO - 2016-09-21 15:32:40 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:40 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:40 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:40 --> URI Class Initialized
INFO - 2016-09-21 15:32:40 --> Router Class Initialized
INFO - 2016-09-21 15:32:40 --> Output Class Initialized
INFO - 2016-09-21 15:32:40 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:40 --> Input Class Initialized
INFO - 2016-09-21 15:32:40 --> Language Class Initialized
INFO - 2016-09-21 15:32:40 --> Loader Class Initialized
INFO - 2016-09-21 15:32:40 --> Helper loaded: url_helper
INFO - 2016-09-21 15:32:40 --> Helper loaded: form_helper
INFO - 2016-09-21 15:32:40 --> Helper loaded: html_helper
INFO - 2016-09-21 15:32:40 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:32:40 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:32:40 --> Database Driver Class Initialized
INFO - 2016-09-21 15:32:40 --> Parser Class Initialized
DEBUG - 2016-09-21 15:32:40 --> Session Class Initialized
INFO - 2016-09-21 15:32:40 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:32:40 --> Session routines successfully run
INFO - 2016-09-21 15:32:40 --> Form Validation Class Initialized
INFO - 2016-09-21 15:32:40 --> Controller Class Initialized
INFO - 2016-09-21 15:32:40 --> Model Class Initialized
DEBUG - 2016-09-21 15:32:40 --> Pagination Class Initialized
INFO - 2016-09-21 15:32:40 --> Config Class Initialized
INFO - 2016-09-21 15:32:40 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:40 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:40 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:41 --> URI Class Initialized
INFO - 2016-09-21 15:32:41 --> Router Class Initialized
INFO - 2016-09-21 15:32:41 --> Output Class Initialized
INFO - 2016-09-21 15:32:41 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:41 --> Input Class Initialized
INFO - 2016-09-21 15:32:41 --> Language Class Initialized
INFO - 2016-09-21 15:32:41 --> Loader Class Initialized
INFO - 2016-09-21 15:32:41 --> Helper loaded: url_helper
INFO - 2016-09-21 15:32:41 --> Helper loaded: form_helper
INFO - 2016-09-21 15:32:41 --> Helper loaded: html_helper
INFO - 2016-09-21 15:32:41 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:32:41 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:32:41 --> Database Driver Class Initialized
INFO - 2016-09-21 15:32:41 --> Parser Class Initialized
DEBUG - 2016-09-21 15:32:41 --> Session Class Initialized
INFO - 2016-09-21 15:32:41 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:32:41 --> Session routines successfully run
INFO - 2016-09-21 15:32:41 --> Form Validation Class Initialized
INFO - 2016-09-21 15:32:41 --> Controller Class Initialized
INFO - 2016-09-21 15:32:41 --> Model Class Initialized
DEBUG - 2016-09-21 15:32:41 --> Pagination Class Initialized
INFO - 2016-09-21 15:32:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:32:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:32:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 287
ERROR - 2016-09-21 15:32:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 288
ERROR - 2016-09-21 15:32:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 289
ERROR - 2016-09-21 15:32:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\Plan_subscription\list_plan_subscription.php 290
INFO - 2016-09-21 15:32:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/Plan_subscription/list_plan_subscription.php
INFO - 2016-09-21 15:32:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:32:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:32:41 --> Final output sent to browser
DEBUG - 2016-09-21 15:32:41 --> Total execution time: 0.5308
INFO - 2016-09-21 15:32:46 --> Config Class Initialized
INFO - 2016-09-21 15:32:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:46 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:46 --> URI Class Initialized
INFO - 2016-09-21 15:32:46 --> Router Class Initialized
INFO - 2016-09-21 15:32:46 --> Output Class Initialized
INFO - 2016-09-21 15:32:46 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:46 --> Input Class Initialized
INFO - 2016-09-21 15:32:46 --> Language Class Initialized
INFO - 2016-09-21 15:32:46 --> Loader Class Initialized
INFO - 2016-09-21 15:32:46 --> Helper loaded: url_helper
INFO - 2016-09-21 15:32:46 --> Helper loaded: form_helper
INFO - 2016-09-21 15:32:46 --> Helper loaded: html_helper
INFO - 2016-09-21 15:32:46 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:32:46 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:32:46 --> Database Driver Class Initialized
INFO - 2016-09-21 15:32:46 --> Parser Class Initialized
DEBUG - 2016-09-21 15:32:46 --> Session Class Initialized
INFO - 2016-09-21 15:32:46 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:32:46 --> Session routines successfully run
INFO - 2016-09-21 15:32:46 --> Form Validation Class Initialized
INFO - 2016-09-21 15:32:46 --> Controller Class Initialized
INFO - 2016-09-21 15:32:46 --> Model Class Initialized
DEBUG - 2016-09-21 15:32:46 --> Pagination Class Initialized
INFO - 2016-09-21 15:32:46 --> Config Class Initialized
INFO - 2016-09-21 15:32:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:46 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:46 --> URI Class Initialized
INFO - 2016-09-21 15:32:46 --> Router Class Initialized
INFO - 2016-09-21 15:32:46 --> Output Class Initialized
INFO - 2016-09-21 15:32:46 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:46 --> Input Class Initialized
INFO - 2016-09-21 15:32:46 --> Language Class Initialized
INFO - 2016-09-21 15:32:46 --> Loader Class Initialized
INFO - 2016-09-21 15:32:46 --> Helper loaded: url_helper
INFO - 2016-09-21 15:32:46 --> Helper loaded: form_helper
INFO - 2016-09-21 15:32:46 --> Helper loaded: html_helper
INFO - 2016-09-21 15:32:46 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:32:46 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:32:46 --> Database Driver Class Initialized
INFO - 2016-09-21 15:32:46 --> Parser Class Initialized
DEBUG - 2016-09-21 15:32:46 --> Session Class Initialized
INFO - 2016-09-21 15:32:46 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:32:46 --> Session routines successfully run
INFO - 2016-09-21 15:32:46 --> Form Validation Class Initialized
INFO - 2016-09-21 15:32:46 --> Controller Class Initialized
INFO - 2016-09-21 15:32:46 --> Model Class Initialized
DEBUG - 2016-09-21 15:32:46 --> Pagination Class Initialized
INFO - 2016-09-21 15:32:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:32:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:32:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/list_color.php
INFO - 2016-09-21 15:32:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:32:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:32:47 --> Final output sent to browser
DEBUG - 2016-09-21 15:32:47 --> Total execution time: 0.3789
INFO - 2016-09-21 15:32:50 --> Config Class Initialized
INFO - 2016-09-21 15:32:50 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:32:50 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:50 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:50 --> URI Class Initialized
INFO - 2016-09-21 15:32:50 --> Router Class Initialized
INFO - 2016-09-21 15:32:50 --> Output Class Initialized
INFO - 2016-09-21 15:32:50 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:50 --> Input Class Initialized
INFO - 2016-09-21 15:32:50 --> Language Class Initialized
INFO - 2016-09-21 15:32:50 --> Loader Class Initialized
INFO - 2016-09-21 15:32:50 --> Helper loaded: url_helper
INFO - 2016-09-21 15:32:50 --> Helper loaded: form_helper
INFO - 2016-09-21 15:32:50 --> Helper loaded: html_helper
INFO - 2016-09-21 15:32:50 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:32:50 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:32:50 --> Database Driver Class Initialized
INFO - 2016-09-21 15:32:50 --> Parser Class Initialized
DEBUG - 2016-09-21 15:32:50 --> Session Class Initialized
INFO - 2016-09-21 15:32:50 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:32:50 --> Session routines successfully run
INFO - 2016-09-21 15:32:50 --> Form Validation Class Initialized
INFO - 2016-09-21 15:32:50 --> Controller Class Initialized
INFO - 2016-09-21 15:32:50 --> Model Class Initialized
DEBUG - 2016-09-21 15:32:50 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:32:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:32:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:32:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:32:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/add_color.php
INFO - 2016-09-21 15:32:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:32:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:32:50 --> Final output sent to browser
DEBUG - 2016-09-21 15:32:50 --> Total execution time: 0.3675
INFO - 2016-09-21 15:32:50 --> Config Class Initialized
INFO - 2016-09-21 15:32:50 --> Hooks Class Initialized
INFO - 2016-09-21 15:32:50 --> Config Class Initialized
DEBUG - 2016-09-21 15:32:50 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:50 --> Hooks Class Initialized
INFO - 2016-09-21 15:32:50 --> Utf8 Class Initialized
DEBUG - 2016-09-21 15:32:50 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:32:50 --> URI Class Initialized
INFO - 2016-09-21 15:32:50 --> Utf8 Class Initialized
INFO - 2016-09-21 15:32:50 --> URI Class Initialized
INFO - 2016-09-21 15:32:50 --> Router Class Initialized
INFO - 2016-09-21 15:32:50 --> Router Class Initialized
INFO - 2016-09-21 15:32:50 --> Output Class Initialized
INFO - 2016-09-21 15:32:50 --> Output Class Initialized
INFO - 2016-09-21 15:32:50 --> Security Class Initialized
INFO - 2016-09-21 15:32:50 --> Security Class Initialized
DEBUG - 2016-09-21 15:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:32:50 --> Input Class Initialized
INFO - 2016-09-21 15:32:50 --> Input Class Initialized
INFO - 2016-09-21 15:32:50 --> Language Class Initialized
INFO - 2016-09-21 15:32:50 --> Language Class Initialized
ERROR - 2016-09-21 15:32:50 --> 404 Page Not Found: Default/assets
ERROR - 2016-09-21 15:32:50 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:33:23 --> Config Class Initialized
INFO - 2016-09-21 15:33:23 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:23 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:23 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:23 --> URI Class Initialized
INFO - 2016-09-21 15:33:23 --> Router Class Initialized
INFO - 2016-09-21 15:33:23 --> Output Class Initialized
INFO - 2016-09-21 15:33:23 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:23 --> Input Class Initialized
INFO - 2016-09-21 15:33:23 --> Language Class Initialized
INFO - 2016-09-21 15:33:23 --> Loader Class Initialized
INFO - 2016-09-21 15:33:23 --> Helper loaded: url_helper
INFO - 2016-09-21 15:33:23 --> Helper loaded: form_helper
INFO - 2016-09-21 15:33:23 --> Helper loaded: html_helper
INFO - 2016-09-21 15:33:23 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:33:23 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:33:23 --> Database Driver Class Initialized
INFO - 2016-09-21 15:33:23 --> Parser Class Initialized
DEBUG - 2016-09-21 15:33:23 --> Session Class Initialized
INFO - 2016-09-21 15:33:23 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:33:23 --> Session routines successfully run
INFO - 2016-09-21 15:33:23 --> Form Validation Class Initialized
INFO - 2016-09-21 15:33:23 --> Controller Class Initialized
INFO - 2016-09-21 15:33:23 --> Model Class Initialized
DEBUG - 2016-09-21 15:33:23 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:33:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 15:33:28 --> Config Class Initialized
INFO - 2016-09-21 15:33:28 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:28 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:28 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:28 --> URI Class Initialized
INFO - 2016-09-21 15:33:28 --> Router Class Initialized
INFO - 2016-09-21 15:33:28 --> Output Class Initialized
INFO - 2016-09-21 15:33:28 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:28 --> Input Class Initialized
INFO - 2016-09-21 15:33:28 --> Language Class Initialized
INFO - 2016-09-21 15:33:28 --> Loader Class Initialized
INFO - 2016-09-21 15:33:28 --> Helper loaded: url_helper
INFO - 2016-09-21 15:33:28 --> Helper loaded: form_helper
INFO - 2016-09-21 15:33:28 --> Helper loaded: html_helper
INFO - 2016-09-21 15:33:28 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:33:28 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:33:28 --> Database Driver Class Initialized
INFO - 2016-09-21 15:33:28 --> Parser Class Initialized
DEBUG - 2016-09-21 15:33:28 --> Session Class Initialized
INFO - 2016-09-21 15:33:28 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:33:28 --> Session routines successfully run
INFO - 2016-09-21 15:33:28 --> Form Validation Class Initialized
INFO - 2016-09-21 15:33:28 --> Controller Class Initialized
INFO - 2016-09-21 15:33:28 --> Model Class Initialized
DEBUG - 2016-09-21 15:33:28 --> Pagination Class Initialized
INFO - 2016-09-21 15:33:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:33:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:33:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/list_color.php
INFO - 2016-09-21 15:33:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:33:28 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:33:28 --> Final output sent to browser
DEBUG - 2016-09-21 15:33:28 --> Total execution time: 0.4125
INFO - 2016-09-21 15:33:33 --> Config Class Initialized
INFO - 2016-09-21 15:33:33 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:33 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:33 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:33 --> URI Class Initialized
INFO - 2016-09-21 15:33:33 --> Router Class Initialized
INFO - 2016-09-21 15:33:33 --> Output Class Initialized
INFO - 2016-09-21 15:33:33 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:33 --> Input Class Initialized
INFO - 2016-09-21 15:33:33 --> Language Class Initialized
INFO - 2016-09-21 15:33:33 --> Loader Class Initialized
INFO - 2016-09-21 15:33:33 --> Helper loaded: url_helper
INFO - 2016-09-21 15:33:33 --> Helper loaded: form_helper
INFO - 2016-09-21 15:33:33 --> Helper loaded: html_helper
INFO - 2016-09-21 15:33:33 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:33:33 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:33:33 --> Database Driver Class Initialized
INFO - 2016-09-21 15:33:33 --> Parser Class Initialized
DEBUG - 2016-09-21 15:33:33 --> Session Class Initialized
INFO - 2016-09-21 15:33:33 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:33:33 --> Session routines successfully run
INFO - 2016-09-21 15:33:33 --> Form Validation Class Initialized
INFO - 2016-09-21 15:33:33 --> Controller Class Initialized
INFO - 2016-09-21 15:33:33 --> Model Class Initialized
DEBUG - 2016-09-21 15:33:33 --> Pagination Class Initialized
INFO - 2016-09-21 15:33:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:33:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:33:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/add_color.php
INFO - 2016-09-21 15:33:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:33:33 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:33:33 --> Final output sent to browser
DEBUG - 2016-09-21 15:33:33 --> Total execution time: 0.3474
INFO - 2016-09-21 15:33:33 --> Config Class Initialized
INFO - 2016-09-21 15:33:33 --> Hooks Class Initialized
INFO - 2016-09-21 15:33:33 --> Config Class Initialized
INFO - 2016-09-21 15:33:33 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:33:33 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:33 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:33 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:33 --> URI Class Initialized
INFO - 2016-09-21 15:33:33 --> URI Class Initialized
INFO - 2016-09-21 15:33:33 --> Router Class Initialized
INFO - 2016-09-21 15:33:33 --> Router Class Initialized
INFO - 2016-09-21 15:33:33 --> Output Class Initialized
INFO - 2016-09-21 15:33:33 --> Output Class Initialized
INFO - 2016-09-21 15:33:33 --> Security Class Initialized
INFO - 2016-09-21 15:33:33 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:33 --> Input Class Initialized
INFO - 2016-09-21 15:33:33 --> Input Class Initialized
INFO - 2016-09-21 15:33:33 --> Language Class Initialized
INFO - 2016-09-21 15:33:33 --> Language Class Initialized
ERROR - 2016-09-21 15:33:33 --> 404 Page Not Found: Default/assets
ERROR - 2016-09-21 15:33:33 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:33:34 --> Config Class Initialized
INFO - 2016-09-21 15:33:34 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:34 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:34 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:34 --> URI Class Initialized
INFO - 2016-09-21 15:33:34 --> Router Class Initialized
INFO - 2016-09-21 15:33:34 --> Output Class Initialized
INFO - 2016-09-21 15:33:34 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:34 --> Input Class Initialized
INFO - 2016-09-21 15:33:34 --> Language Class Initialized
INFO - 2016-09-21 15:33:34 --> Loader Class Initialized
INFO - 2016-09-21 15:33:34 --> Helper loaded: url_helper
INFO - 2016-09-21 15:33:34 --> Helper loaded: form_helper
INFO - 2016-09-21 15:33:34 --> Helper loaded: html_helper
INFO - 2016-09-21 15:33:34 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:33:34 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:33:34 --> Database Driver Class Initialized
INFO - 2016-09-21 15:33:34 --> Parser Class Initialized
DEBUG - 2016-09-21 15:33:34 --> Session Class Initialized
INFO - 2016-09-21 15:33:34 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:33:34 --> Session routines successfully run
INFO - 2016-09-21 15:33:34 --> Form Validation Class Initialized
INFO - 2016-09-21 15:33:35 --> Controller Class Initialized
INFO - 2016-09-21 15:33:35 --> Model Class Initialized
DEBUG - 2016-09-21 15:33:35 --> Pagination Class Initialized
INFO - 2016-09-21 15:33:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:33:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:33:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/list_color.php
INFO - 2016-09-21 15:33:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:33:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:33:35 --> Final output sent to browser
DEBUG - 2016-09-21 15:33:35 --> Total execution time: 0.3646
INFO - 2016-09-21 15:33:38 --> Config Class Initialized
INFO - 2016-09-21 15:33:38 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:38 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:38 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:38 --> URI Class Initialized
INFO - 2016-09-21 15:33:38 --> Router Class Initialized
INFO - 2016-09-21 15:33:38 --> Output Class Initialized
INFO - 2016-09-21 15:33:38 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:38 --> Input Class Initialized
INFO - 2016-09-21 15:33:38 --> Language Class Initialized
INFO - 2016-09-21 15:33:38 --> Loader Class Initialized
INFO - 2016-09-21 15:33:38 --> Helper loaded: url_helper
INFO - 2016-09-21 15:33:38 --> Helper loaded: form_helper
INFO - 2016-09-21 15:33:38 --> Helper loaded: html_helper
INFO - 2016-09-21 15:33:38 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:33:39 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:33:39 --> Database Driver Class Initialized
INFO - 2016-09-21 15:33:39 --> Parser Class Initialized
DEBUG - 2016-09-21 15:33:39 --> Session Class Initialized
INFO - 2016-09-21 15:33:39 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:33:39 --> Session routines successfully run
INFO - 2016-09-21 15:33:39 --> Form Validation Class Initialized
INFO - 2016-09-21 15:33:39 --> Controller Class Initialized
INFO - 2016-09-21 15:33:39 --> Model Class Initialized
DEBUG - 2016-09-21 15:33:39 --> Pagination Class Initialized
INFO - 2016-09-21 15:33:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:33:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:33:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/color/list_color.php
INFO - 2016-09-21 15:33:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:33:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:33:39 --> Final output sent to browser
DEBUG - 2016-09-21 15:33:39 --> Total execution time: 0.4040
INFO - 2016-09-21 15:33:45 --> Config Class Initialized
INFO - 2016-09-21 15:33:45 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:45 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:45 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:45 --> URI Class Initialized
INFO - 2016-09-21 15:33:45 --> Router Class Initialized
INFO - 2016-09-21 15:33:45 --> Output Class Initialized
INFO - 2016-09-21 15:33:45 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:45 --> Input Class Initialized
INFO - 2016-09-21 15:33:45 --> Language Class Initialized
INFO - 2016-09-21 15:33:45 --> Loader Class Initialized
INFO - 2016-09-21 15:33:45 --> Helper loaded: url_helper
INFO - 2016-09-21 15:33:45 --> Helper loaded: form_helper
INFO - 2016-09-21 15:33:45 --> Helper loaded: html_helper
INFO - 2016-09-21 15:33:45 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:33:45 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:33:45 --> Database Driver Class Initialized
INFO - 2016-09-21 15:33:45 --> Parser Class Initialized
DEBUG - 2016-09-21 15:33:45 --> Session Class Initialized
INFO - 2016-09-21 15:33:45 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:33:45 --> Session routines successfully run
INFO - 2016-09-21 15:33:45 --> Form Validation Class Initialized
INFO - 2016-09-21 15:33:45 --> Controller Class Initialized
INFO - 2016-09-21 15:33:45 --> Model Class Initialized
DEBUG - 2016-09-21 15:33:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:33:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
ERROR - 2016-09-21 15:33:46 --> Severity: Notice --> Undefined variable: site_version C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 79
ERROR - 2016-09-21 15:33:46 --> Severity: Notice --> Undefined variable: google_map_key C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 146
ERROR - 2016-09-21 15:33:46 --> Severity: Notice --> Undefined variable: default_longitude C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 153
ERROR - 2016-09-21 15:33:46 --> Severity: Notice --> Undefined variable: default_latitude C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 160
ERROR - 2016-09-21 15:33:46 --> Severity: Notice --> Undefined variable: order_cancellation_time C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 177
ERROR - 2016-09-21 15:33:46 --> Severity: Notice --> Undefined variable: order_close_time C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 182
ERROR - 2016-09-21 15:33:46 --> Severity: Notice --> Undefined variable: facebook_link C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 195
ERROR - 2016-09-21 15:33:46 --> Severity: Notice --> Undefined variable: twitter_link C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 202
ERROR - 2016-09-21 15:33:46 --> Severity: Notice --> Undefined variable: instagram_link C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 208
ERROR - 2016-09-21 15:33:46 --> Severity: Notice --> Undefined variable: skype_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\add_site.php 215
INFO - 2016-09-21 15:33:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/setting/add_site.php
INFO - 2016-09-21 15:33:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:33:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:33:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:33:46 --> Final output sent to browser
DEBUG - 2016-09-21 15:33:46 --> Total execution time: 0.4777
INFO - 2016-09-21 15:33:46 --> Config Class Initialized
INFO - 2016-09-21 15:33:46 --> Config Class Initialized
INFO - 2016-09-21 15:33:46 --> Hooks Class Initialized
INFO - 2016-09-21 15:33:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:33:46 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:46 --> URI Class Initialized
INFO - 2016-09-21 15:33:46 --> URI Class Initialized
INFO - 2016-09-21 15:33:46 --> Router Class Initialized
INFO - 2016-09-21 15:33:46 --> Router Class Initialized
INFO - 2016-09-21 15:33:46 --> Output Class Initialized
INFO - 2016-09-21 15:33:46 --> Output Class Initialized
INFO - 2016-09-21 15:33:46 --> Security Class Initialized
INFO - 2016-09-21 15:33:46 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:46 --> Input Class Initialized
INFO - 2016-09-21 15:33:46 --> Input Class Initialized
INFO - 2016-09-21 15:33:46 --> Language Class Initialized
INFO - 2016-09-21 15:33:46 --> Language Class Initialized
ERROR - 2016-09-21 15:33:46 --> 404 Page Not Found: Default/assets
ERROR - 2016-09-21 15:33:46 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:33:51 --> Config Class Initialized
INFO - 2016-09-21 15:33:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:51 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:51 --> URI Class Initialized
INFO - 2016-09-21 15:33:51 --> Router Class Initialized
INFO - 2016-09-21 15:33:51 --> Output Class Initialized
INFO - 2016-09-21 15:33:51 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:51 --> Input Class Initialized
INFO - 2016-09-21 15:33:51 --> Language Class Initialized
INFO - 2016-09-21 15:33:51 --> Loader Class Initialized
INFO - 2016-09-21 15:33:51 --> Helper loaded: url_helper
INFO - 2016-09-21 15:33:51 --> Helper loaded: form_helper
INFO - 2016-09-21 15:33:51 --> Helper loaded: html_helper
INFO - 2016-09-21 15:33:51 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:33:51 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:33:51 --> Database Driver Class Initialized
INFO - 2016-09-21 15:33:51 --> Parser Class Initialized
DEBUG - 2016-09-21 15:33:51 --> Session Class Initialized
INFO - 2016-09-21 15:33:51 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:33:51 --> Session routines successfully run
INFO - 2016-09-21 15:33:51 --> Form Validation Class Initialized
INFO - 2016-09-21 15:33:51 --> Controller Class Initialized
INFO - 2016-09-21 15:33:51 --> Model Class Initialized
INFO - 2016-09-21 15:33:51 --> Config Class Initialized
INFO - 2016-09-21 15:33:52 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:52 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:52 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:52 --> URI Class Initialized
INFO - 2016-09-21 15:33:52 --> Router Class Initialized
INFO - 2016-09-21 15:33:52 --> Output Class Initialized
INFO - 2016-09-21 15:33:52 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:52 --> Input Class Initialized
INFO - 2016-09-21 15:33:52 --> Language Class Initialized
INFO - 2016-09-21 15:33:52 --> Loader Class Initialized
INFO - 2016-09-21 15:33:52 --> Helper loaded: url_helper
INFO - 2016-09-21 15:33:52 --> Helper loaded: form_helper
INFO - 2016-09-21 15:33:52 --> Helper loaded: html_helper
INFO - 2016-09-21 15:33:52 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:33:52 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:33:52 --> Database Driver Class Initialized
INFO - 2016-09-21 15:33:52 --> Parser Class Initialized
DEBUG - 2016-09-21 15:33:52 --> Session Class Initialized
INFO - 2016-09-21 15:33:52 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:33:52 --> Session routines successfully run
INFO - 2016-09-21 15:33:52 --> Form Validation Class Initialized
INFO - 2016-09-21 15:33:52 --> Controller Class Initialized
INFO - 2016-09-21 15:33:52 --> Model Class Initialized
INFO - 2016-09-21 15:33:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:33:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:33:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2016-09-21 15:33:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:33:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:33:52 --> Final output sent to browser
DEBUG - 2016-09-21 15:33:52 --> Total execution time: 0.5147
INFO - 2016-09-21 15:33:55 --> Config Class Initialized
INFO - 2016-09-21 15:33:55 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:55 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:55 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:55 --> URI Class Initialized
INFO - 2016-09-21 15:33:55 --> Router Class Initialized
INFO - 2016-09-21 15:33:55 --> Output Class Initialized
INFO - 2016-09-21 15:33:55 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:56 --> Input Class Initialized
INFO - 2016-09-21 15:33:56 --> Language Class Initialized
INFO - 2016-09-21 15:33:56 --> Loader Class Initialized
INFO - 2016-09-21 15:33:56 --> Helper loaded: url_helper
INFO - 2016-09-21 15:33:56 --> Helper loaded: form_helper
INFO - 2016-09-21 15:33:56 --> Helper loaded: html_helper
INFO - 2016-09-21 15:33:56 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:33:56 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:33:56 --> Database Driver Class Initialized
INFO - 2016-09-21 15:33:56 --> Parser Class Initialized
DEBUG - 2016-09-21 15:33:56 --> Session Class Initialized
INFO - 2016-09-21 15:33:56 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:33:56 --> Session routines successfully run
INFO - 2016-09-21 15:33:56 --> Form Validation Class Initialized
INFO - 2016-09-21 15:33:56 --> Controller Class Initialized
INFO - 2016-09-21 15:33:56 --> Model Class Initialized
DEBUG - 2016-09-21 15:33:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:33:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:33:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:33:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/addEmailTemplate.php
INFO - 2016-09-21 15:33:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:33:56 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:33:56 --> Final output sent to browser
INFO - 2016-09-21 15:33:56 --> Config Class Initialized
DEBUG - 2016-09-21 15:33:56 --> Total execution time: 0.3689
INFO - 2016-09-21 15:33:56 --> Hooks Class Initialized
INFO - 2016-09-21 15:33:56 --> Config Class Initialized
DEBUG - 2016-09-21 15:33:56 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:56 --> Hooks Class Initialized
INFO - 2016-09-21 15:33:56 --> Utf8 Class Initialized
DEBUG - 2016-09-21 15:33:56 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:56 --> URI Class Initialized
INFO - 2016-09-21 15:33:56 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:56 --> URI Class Initialized
INFO - 2016-09-21 15:33:56 --> Router Class Initialized
INFO - 2016-09-21 15:33:56 --> Router Class Initialized
INFO - 2016-09-21 15:33:56 --> Output Class Initialized
INFO - 2016-09-21 15:33:56 --> Output Class Initialized
INFO - 2016-09-21 15:33:56 --> Security Class Initialized
INFO - 2016-09-21 15:33:56 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:56 --> Input Class Initialized
INFO - 2016-09-21 15:33:56 --> Input Class Initialized
INFO - 2016-09-21 15:33:56 --> Language Class Initialized
INFO - 2016-09-21 15:33:56 --> Language Class Initialized
ERROR - 2016-09-21 15:33:56 --> 404 Page Not Found: Default/plugins
ERROR - 2016-09-21 15:33:56 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:33:56 --> Config Class Initialized
INFO - 2016-09-21 15:33:56 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:33:56 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:33:56 --> Utf8 Class Initialized
INFO - 2016-09-21 15:33:56 --> URI Class Initialized
INFO - 2016-09-21 15:33:56 --> Router Class Initialized
INFO - 2016-09-21 15:33:56 --> Output Class Initialized
INFO - 2016-09-21 15:33:56 --> Security Class Initialized
DEBUG - 2016-09-21 15:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:33:56 --> Input Class Initialized
INFO - 2016-09-21 15:33:56 --> Language Class Initialized
ERROR - 2016-09-21 15:33:56 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:34:00 --> Config Class Initialized
INFO - 2016-09-21 15:34:00 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:34:00 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:34:00 --> Utf8 Class Initialized
INFO - 2016-09-21 15:34:00 --> URI Class Initialized
INFO - 2016-09-21 15:34:00 --> Router Class Initialized
INFO - 2016-09-21 15:34:00 --> Output Class Initialized
INFO - 2016-09-21 15:34:00 --> Security Class Initialized
DEBUG - 2016-09-21 15:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:34:00 --> Input Class Initialized
INFO - 2016-09-21 15:34:00 --> Language Class Initialized
INFO - 2016-09-21 15:34:00 --> Loader Class Initialized
INFO - 2016-09-21 15:34:00 --> Helper loaded: url_helper
INFO - 2016-09-21 15:34:00 --> Helper loaded: form_helper
INFO - 2016-09-21 15:34:00 --> Helper loaded: html_helper
INFO - 2016-09-21 15:34:00 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:34:00 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:34:00 --> Database Driver Class Initialized
INFO - 2016-09-21 15:34:00 --> Parser Class Initialized
DEBUG - 2016-09-21 15:34:00 --> Session Class Initialized
INFO - 2016-09-21 15:34:00 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:34:00 --> Session routines successfully run
INFO - 2016-09-21 15:34:00 --> Form Validation Class Initialized
INFO - 2016-09-21 15:34:00 --> Controller Class Initialized
INFO - 2016-09-21 15:34:00 --> Model Class Initialized
INFO - 2016-09-21 15:34:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:34:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:34:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2016-09-21 15:34:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:34:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:34:01 --> Final output sent to browser
DEBUG - 2016-09-21 15:34:01 --> Total execution time: 0.3600
INFO - 2016-09-21 15:34:02 --> Config Class Initialized
INFO - 2016-09-21 15:34:02 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:34:02 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:34:02 --> Utf8 Class Initialized
INFO - 2016-09-21 15:34:02 --> URI Class Initialized
INFO - 2016-09-21 15:34:02 --> Router Class Initialized
INFO - 2016-09-21 15:34:02 --> Output Class Initialized
INFO - 2016-09-21 15:34:02 --> Security Class Initialized
DEBUG - 2016-09-21 15:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:34:02 --> Input Class Initialized
INFO - 2016-09-21 15:34:02 --> Language Class Initialized
INFO - 2016-09-21 15:34:02 --> Loader Class Initialized
INFO - 2016-09-21 15:34:02 --> Helper loaded: url_helper
INFO - 2016-09-21 15:34:02 --> Helper loaded: form_helper
INFO - 2016-09-21 15:34:02 --> Helper loaded: html_helper
INFO - 2016-09-21 15:34:02 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:34:02 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:34:02 --> Database Driver Class Initialized
INFO - 2016-09-21 15:34:02 --> Parser Class Initialized
DEBUG - 2016-09-21 15:34:02 --> Session Class Initialized
INFO - 2016-09-21 15:34:02 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:34:02 --> Session routines successfully run
INFO - 2016-09-21 15:34:02 --> Form Validation Class Initialized
INFO - 2016-09-21 15:34:02 --> Controller Class Initialized
INFO - 2016-09-21 15:34:02 --> Model Class Initialized
DEBUG - 2016-09-21 15:34:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:34:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
ERROR - 2016-09-21 15:34:02 --> Severity: Notice --> Undefined variable: site_setting_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\payment_setting.php 46
ERROR - 2016-09-21 15:34:02 --> Severity: Notice --> Undefined variable: site_setting_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\setting\payment_setting.php 47
INFO - 2016-09-21 15:34:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/setting/payment_setting.php
INFO - 2016-09-21 15:34:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:34:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:34:02 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:34:02 --> Final output sent to browser
DEBUG - 2016-09-21 15:34:02 --> Total execution time: 0.4620
INFO - 2016-09-21 15:34:02 --> Config Class Initialized
INFO - 2016-09-21 15:34:02 --> Hooks Class Initialized
INFO - 2016-09-21 15:34:02 --> Config Class Initialized
INFO - 2016-09-21 15:34:02 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:34:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:34:02 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:34:02 --> Utf8 Class Initialized
INFO - 2016-09-21 15:34:02 --> Utf8 Class Initialized
INFO - 2016-09-21 15:34:02 --> URI Class Initialized
INFO - 2016-09-21 15:34:02 --> URI Class Initialized
INFO - 2016-09-21 15:34:02 --> Router Class Initialized
INFO - 2016-09-21 15:34:02 --> Router Class Initialized
INFO - 2016-09-21 15:34:02 --> Output Class Initialized
INFO - 2016-09-21 15:34:02 --> Output Class Initialized
INFO - 2016-09-21 15:34:02 --> Security Class Initialized
INFO - 2016-09-21 15:34:02 --> Security Class Initialized
DEBUG - 2016-09-21 15:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:34:02 --> Input Class Initialized
INFO - 2016-09-21 15:34:02 --> Input Class Initialized
INFO - 2016-09-21 15:34:02 --> Language Class Initialized
INFO - 2016-09-21 15:34:02 --> Language Class Initialized
ERROR - 2016-09-21 15:34:02 --> 404 Page Not Found: Default/assets
ERROR - 2016-09-21 15:34:02 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:34:04 --> Config Class Initialized
INFO - 2016-09-21 15:34:04 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:34:04 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:34:04 --> Utf8 Class Initialized
INFO - 2016-09-21 15:34:04 --> URI Class Initialized
INFO - 2016-09-21 15:34:05 --> Router Class Initialized
INFO - 2016-09-21 15:34:05 --> Output Class Initialized
INFO - 2016-09-21 15:34:05 --> Security Class Initialized
DEBUG - 2016-09-21 15:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:34:05 --> Input Class Initialized
INFO - 2016-09-21 15:34:05 --> Language Class Initialized
INFO - 2016-09-21 15:34:05 --> Loader Class Initialized
INFO - 2016-09-21 15:34:05 --> Helper loaded: url_helper
INFO - 2016-09-21 15:34:05 --> Helper loaded: form_helper
INFO - 2016-09-21 15:34:05 --> Helper loaded: html_helper
INFO - 2016-09-21 15:34:05 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:34:05 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:34:05 --> Database Driver Class Initialized
INFO - 2016-09-21 15:34:05 --> Parser Class Initialized
DEBUG - 2016-09-21 15:34:05 --> Session Class Initialized
INFO - 2016-09-21 15:34:05 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:34:05 --> Session routines successfully run
INFO - 2016-09-21 15:34:05 --> Form Validation Class Initialized
INFO - 2016-09-21 15:34:05 --> Controller Class Initialized
INFO - 2016-09-21 15:34:05 --> Model Class Initialized
INFO - 2016-09-21 15:34:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:34:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:34:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/setting/popup_setup.php
INFO - 2016-09-21 15:34:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:34:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:34:05 --> Final output sent to browser
DEBUG - 2016-09-21 15:34:05 --> Total execution time: 0.3767
INFO - 2016-09-21 15:34:05 --> Config Class Initialized
INFO - 2016-09-21 15:34:05 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:34:05 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:34:05 --> Utf8 Class Initialized
INFO - 2016-09-21 15:34:05 --> URI Class Initialized
INFO - 2016-09-21 15:34:05 --> Router Class Initialized
INFO - 2016-09-21 15:34:05 --> Output Class Initialized
INFO - 2016-09-21 15:34:05 --> Security Class Initialized
DEBUG - 2016-09-21 15:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:34:05 --> Input Class Initialized
INFO - 2016-09-21 15:34:05 --> Language Class Initialized
ERROR - 2016-09-21 15:34:05 --> 404 Page Not Found: Site_setting/assets
INFO - 2016-09-21 15:36:31 --> Config Class Initialized
INFO - 2016-09-21 15:36:31 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:36:31 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:36:31 --> Utf8 Class Initialized
INFO - 2016-09-21 15:36:31 --> URI Class Initialized
INFO - 2016-09-21 15:36:31 --> Router Class Initialized
INFO - 2016-09-21 15:36:32 --> Output Class Initialized
INFO - 2016-09-21 15:36:32 --> Security Class Initialized
DEBUG - 2016-09-21 15:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:36:32 --> Input Class Initialized
INFO - 2016-09-21 15:36:32 --> Language Class Initialized
INFO - 2016-09-21 15:36:32 --> Loader Class Initialized
INFO - 2016-09-21 15:36:32 --> Helper loaded: url_helper
INFO - 2016-09-21 15:36:32 --> Helper loaded: form_helper
INFO - 2016-09-21 15:36:32 --> Helper loaded: html_helper
INFO - 2016-09-21 15:36:32 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:36:32 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:36:32 --> Database Driver Class Initialized
INFO - 2016-09-21 15:36:32 --> Parser Class Initialized
DEBUG - 2016-09-21 15:36:32 --> Session Class Initialized
INFO - 2016-09-21 15:36:32 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:36:32 --> Session routines successfully run
INFO - 2016-09-21 15:36:32 --> Form Validation Class Initialized
INFO - 2016-09-21 15:36:32 --> Controller Class Initialized
INFO - 2016-09-21 15:36:32 --> Model Class Initialized
INFO - 2016-09-21 15:36:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:36:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:36:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/setting/popup_setup.php
INFO - 2016-09-21 15:36:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:36:32 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:36:32 --> Final output sent to browser
DEBUG - 2016-09-21 15:36:32 --> Total execution time: 0.3847
INFO - 2016-09-21 15:36:32 --> Config Class Initialized
INFO - 2016-09-21 15:36:32 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:36:32 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:36:32 --> Utf8 Class Initialized
INFO - 2016-09-21 15:36:32 --> URI Class Initialized
INFO - 2016-09-21 15:36:32 --> Router Class Initialized
INFO - 2016-09-21 15:36:32 --> Output Class Initialized
INFO - 2016-09-21 15:36:32 --> Security Class Initialized
DEBUG - 2016-09-21 15:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:36:32 --> Input Class Initialized
INFO - 2016-09-21 15:36:32 --> Language Class Initialized
ERROR - 2016-09-21 15:36:32 --> 404 Page Not Found: Site_setting/assets
INFO - 2016-09-21 15:36:50 --> Config Class Initialized
INFO - 2016-09-21 15:36:50 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:36:50 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:36:50 --> Utf8 Class Initialized
INFO - 2016-09-21 15:36:50 --> URI Class Initialized
INFO - 2016-09-21 15:36:50 --> Router Class Initialized
INFO - 2016-09-21 15:36:50 --> Output Class Initialized
INFO - 2016-09-21 15:36:50 --> Security Class Initialized
DEBUG - 2016-09-21 15:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:36:50 --> Input Class Initialized
INFO - 2016-09-21 15:36:50 --> Language Class Initialized
ERROR - 2016-09-21 15:36:50 --> 404 Page Not Found: Site_setting/assets
INFO - 2016-09-21 15:40:51 --> Config Class Initialized
INFO - 2016-09-21 15:40:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:40:51 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:40:51 --> Utf8 Class Initialized
INFO - 2016-09-21 15:40:51 --> URI Class Initialized
INFO - 2016-09-21 15:40:51 --> Router Class Initialized
INFO - 2016-09-21 15:40:51 --> Output Class Initialized
INFO - 2016-09-21 15:40:51 --> Security Class Initialized
DEBUG - 2016-09-21 15:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:40:51 --> Input Class Initialized
INFO - 2016-09-21 15:40:51 --> Language Class Initialized
INFO - 2016-09-21 15:40:51 --> Loader Class Initialized
INFO - 2016-09-21 15:40:51 --> Helper loaded: url_helper
INFO - 2016-09-21 15:40:51 --> Helper loaded: form_helper
INFO - 2016-09-21 15:40:51 --> Helper loaded: html_helper
INFO - 2016-09-21 15:40:51 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:40:51 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:40:51 --> Database Driver Class Initialized
INFO - 2016-09-21 15:40:51 --> Parser Class Initialized
DEBUG - 2016-09-21 15:40:51 --> Session Class Initialized
INFO - 2016-09-21 15:40:51 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:40:51 --> Session routines successfully run
INFO - 2016-09-21 15:40:51 --> Form Validation Class Initialized
INFO - 2016-09-21 15:40:51 --> Controller Class Initialized
INFO - 2016-09-21 15:40:51 --> Model Class Initialized
INFO - 2016-09-21 15:40:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:40:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:40:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/setting/popup_setup.php
INFO - 2016-09-21 15:40:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:40:51 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:40:51 --> Final output sent to browser
DEBUG - 2016-09-21 15:40:51 --> Total execution time: 0.4675
INFO - 2016-09-21 15:40:52 --> Config Class Initialized
INFO - 2016-09-21 15:40:52 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:40:52 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:40:52 --> Utf8 Class Initialized
INFO - 2016-09-21 15:40:52 --> URI Class Initialized
INFO - 2016-09-21 15:40:52 --> Router Class Initialized
INFO - 2016-09-21 15:40:52 --> Output Class Initialized
INFO - 2016-09-21 15:40:52 --> Security Class Initialized
DEBUG - 2016-09-21 15:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:40:52 --> Input Class Initialized
INFO - 2016-09-21 15:40:52 --> Language Class Initialized
ERROR - 2016-09-21 15:40:52 --> 404 Page Not Found: Site_setting/assets
INFO - 2016-09-21 15:41:11 --> Config Class Initialized
INFO - 2016-09-21 15:41:11 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:41:11 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:41:11 --> Utf8 Class Initialized
INFO - 2016-09-21 15:41:11 --> URI Class Initialized
INFO - 2016-09-21 15:41:11 --> Router Class Initialized
INFO - 2016-09-21 15:41:11 --> Output Class Initialized
INFO - 2016-09-21 15:41:11 --> Security Class Initialized
DEBUG - 2016-09-21 15:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:41:11 --> Input Class Initialized
INFO - 2016-09-21 15:41:11 --> Language Class Initialized
INFO - 2016-09-21 15:41:11 --> Loader Class Initialized
INFO - 2016-09-21 15:41:11 --> Helper loaded: url_helper
INFO - 2016-09-21 15:41:11 --> Helper loaded: form_helper
INFO - 2016-09-21 15:41:11 --> Helper loaded: html_helper
INFO - 2016-09-21 15:41:11 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:41:11 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:41:11 --> Database Driver Class Initialized
INFO - 2016-09-21 15:41:11 --> Parser Class Initialized
DEBUG - 2016-09-21 15:41:11 --> Session Class Initialized
INFO - 2016-09-21 15:41:11 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:41:11 --> Session routines successfully run
INFO - 2016-09-21 15:41:11 --> Form Validation Class Initialized
INFO - 2016-09-21 15:41:11 --> Controller Class Initialized
INFO - 2016-09-21 15:41:11 --> Model Class Initialized
DEBUG - 2016-09-21 15:41:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:41:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:41:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/changePassword.php
INFO - 2016-09-21 15:41:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:41:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:41:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:41:11 --> Final output sent to browser
DEBUG - 2016-09-21 15:41:11 --> Total execution time: 0.3821
INFO - 2016-09-21 15:41:11 --> Config Class Initialized
INFO - 2016-09-21 15:41:11 --> Hooks Class Initialized
INFO - 2016-09-21 15:41:11 --> Config Class Initialized
DEBUG - 2016-09-21 15:41:11 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:41:11 --> Hooks Class Initialized
INFO - 2016-09-21 15:41:11 --> Utf8 Class Initialized
DEBUG - 2016-09-21 15:41:11 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:41:11 --> URI Class Initialized
INFO - 2016-09-21 15:41:11 --> Utf8 Class Initialized
INFO - 2016-09-21 15:41:11 --> Router Class Initialized
INFO - 2016-09-21 15:41:11 --> URI Class Initialized
INFO - 2016-09-21 15:41:11 --> Output Class Initialized
INFO - 2016-09-21 15:41:11 --> Router Class Initialized
INFO - 2016-09-21 15:41:11 --> Security Class Initialized
INFO - 2016-09-21 15:41:11 --> Output Class Initialized
DEBUG - 2016-09-21 15:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:41:11 --> Security Class Initialized
INFO - 2016-09-21 15:41:11 --> Input Class Initialized
INFO - 2016-09-21 15:41:11 --> Language Class Initialized
DEBUG - 2016-09-21 15:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-21 15:41:11 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:41:11 --> Input Class Initialized
INFO - 2016-09-21 15:41:11 --> Language Class Initialized
ERROR - 2016-09-21 15:41:11 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:41:13 --> Config Class Initialized
INFO - 2016-09-21 15:41:13 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:41:13 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:41:13 --> Utf8 Class Initialized
INFO - 2016-09-21 15:41:13 --> URI Class Initialized
INFO - 2016-09-21 15:41:13 --> Router Class Initialized
INFO - 2016-09-21 15:41:13 --> Output Class Initialized
INFO - 2016-09-21 15:41:13 --> Security Class Initialized
DEBUG - 2016-09-21 15:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:41:13 --> Input Class Initialized
INFO - 2016-09-21 15:41:13 --> Language Class Initialized
INFO - 2016-09-21 15:41:13 --> Loader Class Initialized
INFO - 2016-09-21 15:41:13 --> Helper loaded: url_helper
INFO - 2016-09-21 15:41:13 --> Helper loaded: form_helper
INFO - 2016-09-21 15:41:13 --> Helper loaded: html_helper
INFO - 2016-09-21 15:41:13 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:41:13 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:41:13 --> Database Driver Class Initialized
INFO - 2016-09-21 15:41:13 --> Parser Class Initialized
DEBUG - 2016-09-21 15:41:13 --> Session Class Initialized
INFO - 2016-09-21 15:41:13 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:41:13 --> Session routines successfully run
INFO - 2016-09-21 15:41:13 --> Form Validation Class Initialized
INFO - 2016-09-21 15:41:13 --> Controller Class Initialized
INFO - 2016-09-21 15:41:13 --> Model Class Initialized
INFO - 2016-09-21 15:41:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:41:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:41:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/dashboard.php
INFO - 2016-09-21 15:41:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:41:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:41:14 --> Final output sent to browser
DEBUG - 2016-09-21 15:41:14 --> Total execution time: 0.4236
INFO - 2016-09-21 15:41:17 --> Config Class Initialized
INFO - 2016-09-21 15:41:17 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:41:17 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:41:17 --> Utf8 Class Initialized
INFO - 2016-09-21 15:41:17 --> URI Class Initialized
INFO - 2016-09-21 15:41:17 --> Router Class Initialized
INFO - 2016-09-21 15:41:17 --> Output Class Initialized
INFO - 2016-09-21 15:41:17 --> Security Class Initialized
DEBUG - 2016-09-21 15:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:41:17 --> Input Class Initialized
INFO - 2016-09-21 15:41:17 --> Language Class Initialized
INFO - 2016-09-21 15:41:17 --> Loader Class Initialized
INFO - 2016-09-21 15:41:17 --> Helper loaded: url_helper
INFO - 2016-09-21 15:41:17 --> Helper loaded: form_helper
INFO - 2016-09-21 15:41:17 --> Helper loaded: html_helper
INFO - 2016-09-21 15:41:17 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:41:17 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:41:17 --> Database Driver Class Initialized
INFO - 2016-09-21 15:41:17 --> Parser Class Initialized
DEBUG - 2016-09-21 15:41:17 --> Session Class Initialized
INFO - 2016-09-21 15:41:17 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:41:17 --> Session routines successfully run
INFO - 2016-09-21 15:41:17 --> Form Validation Class Initialized
INFO - 2016-09-21 15:41:17 --> Controller Class Initialized
INFO - 2016-09-21 15:41:17 --> Model Class Initialized
DEBUG - 2016-09-21 15:41:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:41:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:41:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/profile.php
INFO - 2016-09-21 15:41:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:41:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:41:17 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:41:17 --> Final output sent to browser
DEBUG - 2016-09-21 15:41:17 --> Total execution time: 0.3782
INFO - 2016-09-21 15:41:17 --> Config Class Initialized
INFO - 2016-09-21 15:41:17 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:41:17 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:41:17 --> Config Class Initialized
INFO - 2016-09-21 15:41:17 --> Utf8 Class Initialized
INFO - 2016-09-21 15:41:17 --> Hooks Class Initialized
INFO - 2016-09-21 15:41:17 --> URI Class Initialized
DEBUG - 2016-09-21 15:41:17 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:41:17 --> Router Class Initialized
INFO - 2016-09-21 15:41:17 --> Utf8 Class Initialized
INFO - 2016-09-21 15:41:17 --> URI Class Initialized
INFO - 2016-09-21 15:41:17 --> Output Class Initialized
INFO - 2016-09-21 15:41:17 --> Router Class Initialized
INFO - 2016-09-21 15:41:18 --> Security Class Initialized
INFO - 2016-09-21 15:41:18 --> Output Class Initialized
DEBUG - 2016-09-21 15:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:41:18 --> Security Class Initialized
INFO - 2016-09-21 15:41:18 --> Input Class Initialized
INFO - 2016-09-21 15:41:18 --> Language Class Initialized
DEBUG - 2016-09-21 15:41:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-21 15:41:18 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:41:18 --> Input Class Initialized
INFO - 2016-09-21 15:41:18 --> Language Class Initialized
ERROR - 2016-09-21 15:41:18 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:41:22 --> Config Class Initialized
INFO - 2016-09-21 15:41:22 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:41:22 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:41:22 --> Utf8 Class Initialized
INFO - 2016-09-21 15:41:22 --> URI Class Initialized
INFO - 2016-09-21 15:41:22 --> Router Class Initialized
INFO - 2016-09-21 15:41:22 --> Output Class Initialized
INFO - 2016-09-21 15:41:22 --> Security Class Initialized
DEBUG - 2016-09-21 15:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:41:22 --> Input Class Initialized
INFO - 2016-09-21 15:41:22 --> Language Class Initialized
INFO - 2016-09-21 15:41:22 --> Loader Class Initialized
INFO - 2016-09-21 15:41:23 --> Helper loaded: url_helper
INFO - 2016-09-21 15:41:23 --> Helper loaded: form_helper
INFO - 2016-09-21 15:41:23 --> Helper loaded: html_helper
INFO - 2016-09-21 15:41:23 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:41:23 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:41:23 --> Database Driver Class Initialized
INFO - 2016-09-21 15:41:23 --> Parser Class Initialized
DEBUG - 2016-09-21 15:41:23 --> Session Class Initialized
INFO - 2016-09-21 15:41:23 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:41:23 --> Session routines successfully run
INFO - 2016-09-21 15:41:23 --> Form Validation Class Initialized
INFO - 2016-09-21 15:41:23 --> Controller Class Initialized
INFO - 2016-09-21 15:41:23 --> Model Class Initialized
INFO - 2016-09-21 15:41:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:41:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:41:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/dashboard.php
INFO - 2016-09-21 15:41:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:41:23 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:41:23 --> Final output sent to browser
DEBUG - 2016-09-21 15:41:23 --> Total execution time: 0.3580
INFO - 2016-09-21 15:42:09 --> Config Class Initialized
INFO - 2016-09-21 15:42:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:42:09 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:42:09 --> Utf8 Class Initialized
INFO - 2016-09-21 15:42:09 --> URI Class Initialized
INFO - 2016-09-21 15:42:09 --> Router Class Initialized
INFO - 2016-09-21 15:42:09 --> Output Class Initialized
INFO - 2016-09-21 15:42:09 --> Security Class Initialized
DEBUG - 2016-09-21 15:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:42:09 --> Input Class Initialized
INFO - 2016-09-21 15:42:09 --> Language Class Initialized
INFO - 2016-09-21 15:42:09 --> Loader Class Initialized
INFO - 2016-09-21 15:42:09 --> Helper loaded: url_helper
INFO - 2016-09-21 15:42:09 --> Helper loaded: form_helper
INFO - 2016-09-21 15:42:09 --> Helper loaded: html_helper
INFO - 2016-09-21 15:42:09 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:42:09 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:42:09 --> Database Driver Class Initialized
INFO - 2016-09-21 15:42:09 --> Parser Class Initialized
DEBUG - 2016-09-21 15:42:09 --> Session Class Initialized
INFO - 2016-09-21 15:42:09 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:42:10 --> Session routines successfully run
INFO - 2016-09-21 15:42:10 --> Form Validation Class Initialized
INFO - 2016-09-21 15:42:10 --> Controller Class Initialized
INFO - 2016-09-21 15:42:10 --> Model Class Initialized
INFO - 2016-09-21 15:42:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:42:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:42:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/dashboard.php
INFO - 2016-09-21 15:42:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:42:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:42:10 --> Final output sent to browser
DEBUG - 2016-09-21 15:42:10 --> Total execution time: 0.3778
INFO - 2016-09-21 15:42:12 --> Config Class Initialized
INFO - 2016-09-21 15:42:12 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:42:12 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:42:12 --> Utf8 Class Initialized
INFO - 2016-09-21 15:42:12 --> URI Class Initialized
INFO - 2016-09-21 15:42:12 --> Router Class Initialized
INFO - 2016-09-21 15:42:12 --> Output Class Initialized
INFO - 2016-09-21 15:42:12 --> Security Class Initialized
DEBUG - 2016-09-21 15:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:42:12 --> Input Class Initialized
INFO - 2016-09-21 15:42:12 --> Language Class Initialized
INFO - 2016-09-21 15:42:12 --> Loader Class Initialized
INFO - 2016-09-21 15:42:12 --> Helper loaded: url_helper
INFO - 2016-09-21 15:42:12 --> Helper loaded: form_helper
INFO - 2016-09-21 15:42:12 --> Helper loaded: html_helper
INFO - 2016-09-21 15:42:12 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:42:12 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:42:12 --> Database Driver Class Initialized
INFO - 2016-09-21 15:42:12 --> Parser Class Initialized
DEBUG - 2016-09-21 15:42:12 --> Session Class Initialized
INFO - 2016-09-21 15:42:12 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:42:12 --> Session routines successfully run
INFO - 2016-09-21 15:42:12 --> Form Validation Class Initialized
INFO - 2016-09-21 15:42:12 --> Controller Class Initialized
INFO - 2016-09-21 15:42:12 --> Model Class Initialized
INFO - 2016-09-21 15:42:12 --> Config Class Initialized
INFO - 2016-09-21 15:42:12 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:42:12 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:42:12 --> Utf8 Class Initialized
INFO - 2016-09-21 15:42:12 --> URI Class Initialized
INFO - 2016-09-21 15:42:12 --> Router Class Initialized
INFO - 2016-09-21 15:42:12 --> Output Class Initialized
INFO - 2016-09-21 15:42:12 --> Security Class Initialized
DEBUG - 2016-09-21 15:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:42:12 --> Input Class Initialized
INFO - 2016-09-21 15:42:12 --> Language Class Initialized
INFO - 2016-09-21 15:42:12 --> Loader Class Initialized
INFO - 2016-09-21 15:42:12 --> Helper loaded: url_helper
INFO - 2016-09-21 15:42:12 --> Helper loaded: form_helper
INFO - 2016-09-21 15:42:12 --> Helper loaded: html_helper
INFO - 2016-09-21 15:42:12 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:42:12 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:42:12 --> Database Driver Class Initialized
INFO - 2016-09-21 15:42:12 --> Parser Class Initialized
DEBUG - 2016-09-21 15:42:12 --> Session Class Initialized
INFO - 2016-09-21 15:42:12 --> Helper loaded: string_helper
ERROR - 2016-09-21 15:42:12 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2016-09-21 15:42:12 --> Session routines successfully run
INFO - 2016-09-21 15:42:12 --> Form Validation Class Initialized
INFO - 2016-09-21 15:42:12 --> Controller Class Initialized
INFO - 2016-09-21 15:42:12 --> Model Class Initialized
INFO - 2016-09-21 15:42:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 15:42:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:42:12 --> Final output sent to browser
DEBUG - 2016-09-21 15:42:12 --> Total execution time: 0.3533
INFO - 2016-09-21 15:42:33 --> Config Class Initialized
INFO - 2016-09-21 15:42:33 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:42:33 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:42:33 --> Utf8 Class Initialized
INFO - 2016-09-21 15:42:33 --> URI Class Initialized
INFO - 2016-09-21 15:42:33 --> Router Class Initialized
INFO - 2016-09-21 15:42:33 --> Output Class Initialized
INFO - 2016-09-21 15:42:33 --> Security Class Initialized
DEBUG - 2016-09-21 15:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:42:33 --> Input Class Initialized
INFO - 2016-09-21 15:42:33 --> Language Class Initialized
INFO - 2016-09-21 15:42:33 --> Loader Class Initialized
INFO - 2016-09-21 15:42:33 --> Helper loaded: url_helper
INFO - 2016-09-21 15:42:33 --> Helper loaded: form_helper
INFO - 2016-09-21 15:42:34 --> Helper loaded: html_helper
INFO - 2016-09-21 15:42:34 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:42:34 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:42:34 --> Database Driver Class Initialized
INFO - 2016-09-21 15:42:34 --> Parser Class Initialized
DEBUG - 2016-09-21 15:42:34 --> Session Class Initialized
INFO - 2016-09-21 15:42:34 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:42:34 --> Session routines successfully run
INFO - 2016-09-21 15:42:34 --> Form Validation Class Initialized
INFO - 2016-09-21 15:42:34 --> Controller Class Initialized
INFO - 2016-09-21 15:42:34 --> Model Class Initialized
INFO - 2016-09-21 15:42:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 15:42:34 --> Config Class Initialized
INFO - 2016-09-21 15:42:34 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:42:34 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:42:34 --> Utf8 Class Initialized
INFO - 2016-09-21 15:42:34 --> URI Class Initialized
INFO - 2016-09-21 15:42:34 --> Router Class Initialized
INFO - 2016-09-21 15:42:34 --> Output Class Initialized
INFO - 2016-09-21 15:42:34 --> Security Class Initialized
DEBUG - 2016-09-21 15:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:42:34 --> Input Class Initialized
INFO - 2016-09-21 15:42:34 --> Language Class Initialized
INFO - 2016-09-21 15:42:34 --> Loader Class Initialized
INFO - 2016-09-21 15:42:34 --> Helper loaded: url_helper
INFO - 2016-09-21 15:42:34 --> Helper loaded: form_helper
INFO - 2016-09-21 15:42:34 --> Helper loaded: html_helper
INFO - 2016-09-21 15:42:34 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:42:34 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:42:34 --> Database Driver Class Initialized
INFO - 2016-09-21 15:42:34 --> Parser Class Initialized
DEBUG - 2016-09-21 15:42:34 --> Session Class Initialized
INFO - 2016-09-21 15:42:34 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:42:34 --> Session routines successfully run
INFO - 2016-09-21 15:42:34 --> Form Validation Class Initialized
INFO - 2016-09-21 15:42:34 --> Controller Class Initialized
DEBUG - 2016-09-21 15:42:34 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:42:34 --> Model Class Initialized
DEBUG - 2016-09-21 15:42:34 --> Pagination Class Initialized
INFO - 2016-09-21 15:42:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:42:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:42:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 15:42:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:42:34 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:42:34 --> Final output sent to browser
DEBUG - 2016-09-21 15:42:34 --> Total execution time: 0.4072
INFO - 2016-09-21 15:42:40 --> Config Class Initialized
INFO - 2016-09-21 15:42:40 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:42:40 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:42:40 --> Utf8 Class Initialized
INFO - 2016-09-21 15:42:40 --> URI Class Initialized
INFO - 2016-09-21 15:42:40 --> Router Class Initialized
INFO - 2016-09-21 15:42:40 --> Output Class Initialized
INFO - 2016-09-21 15:42:40 --> Security Class Initialized
DEBUG - 2016-09-21 15:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:42:40 --> Input Class Initialized
INFO - 2016-09-21 15:42:40 --> Language Class Initialized
INFO - 2016-09-21 15:42:40 --> Loader Class Initialized
INFO - 2016-09-21 15:42:40 --> Helper loaded: url_helper
INFO - 2016-09-21 15:42:40 --> Helper loaded: form_helper
INFO - 2016-09-21 15:42:40 --> Helper loaded: html_helper
INFO - 2016-09-21 15:42:40 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:42:40 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:42:41 --> Database Driver Class Initialized
INFO - 2016-09-21 15:42:41 --> Parser Class Initialized
DEBUG - 2016-09-21 15:42:41 --> Session Class Initialized
INFO - 2016-09-21 15:42:41 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:42:41 --> Session routines successfully run
INFO - 2016-09-21 15:42:41 --> Form Validation Class Initialized
INFO - 2016-09-21 15:42:41 --> Controller Class Initialized
DEBUG - 2016-09-21 15:42:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:42:41 --> Model Class Initialized
DEBUG - 2016-09-21 15:42:41 --> Pagination Class Initialized
INFO - 2016-09-21 15:42:41 --> Config Class Initialized
INFO - 2016-09-21 15:42:41 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:42:41 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:42:41 --> Utf8 Class Initialized
INFO - 2016-09-21 15:42:41 --> URI Class Initialized
INFO - 2016-09-21 15:42:41 --> Router Class Initialized
INFO - 2016-09-21 15:42:41 --> Output Class Initialized
INFO - 2016-09-21 15:42:41 --> Security Class Initialized
DEBUG - 2016-09-21 15:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:42:41 --> Input Class Initialized
INFO - 2016-09-21 15:42:41 --> Language Class Initialized
INFO - 2016-09-21 15:42:41 --> Loader Class Initialized
INFO - 2016-09-21 15:42:41 --> Helper loaded: url_helper
INFO - 2016-09-21 15:42:41 --> Helper loaded: form_helper
INFO - 2016-09-21 15:42:41 --> Helper loaded: html_helper
INFO - 2016-09-21 15:42:41 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:42:41 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:42:41 --> Database Driver Class Initialized
INFO - 2016-09-21 15:42:41 --> Parser Class Initialized
DEBUG - 2016-09-21 15:42:41 --> Session Class Initialized
INFO - 2016-09-21 15:42:41 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:42:41 --> Session routines successfully run
INFO - 2016-09-21 15:42:41 --> Form Validation Class Initialized
INFO - 2016-09-21 15:42:41 --> Controller Class Initialized
DEBUG - 2016-09-21 15:42:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:42:41 --> Model Class Initialized
DEBUG - 2016-09-21 15:42:41 --> Pagination Class Initialized
INFO - 2016-09-21 15:42:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:42:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:41 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:42:42 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2016-09-21 15:42:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2016-09-21 15:42:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:42:42 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:42:42 --> Final output sent to browser
DEBUG - 2016-09-21 15:42:42 --> Total execution time: 1.5393
INFO - 2016-09-21 15:42:48 --> Config Class Initialized
INFO - 2016-09-21 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:42:48 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:42:48 --> Utf8 Class Initialized
INFO - 2016-09-21 15:42:48 --> URI Class Initialized
INFO - 2016-09-21 15:42:48 --> Router Class Initialized
INFO - 2016-09-21 15:42:48 --> Output Class Initialized
INFO - 2016-09-21 15:42:48 --> Security Class Initialized
DEBUG - 2016-09-21 15:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:42:48 --> Input Class Initialized
INFO - 2016-09-21 15:42:48 --> Language Class Initialized
INFO - 2016-09-21 15:42:48 --> Loader Class Initialized
INFO - 2016-09-21 15:42:48 --> Helper loaded: url_helper
INFO - 2016-09-21 15:42:48 --> Helper loaded: form_helper
INFO - 2016-09-21 15:42:48 --> Helper loaded: html_helper
INFO - 2016-09-21 15:42:48 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:42:48 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:42:48 --> Database Driver Class Initialized
INFO - 2016-09-21 15:42:48 --> Parser Class Initialized
DEBUG - 2016-09-21 15:42:48 --> Session Class Initialized
INFO - 2016-09-21 15:42:48 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:42:48 --> Session routines successfully run
INFO - 2016-09-21 15:42:48 --> Form Validation Class Initialized
INFO - 2016-09-21 15:42:48 --> Controller Class Initialized
DEBUG - 2016-09-21 15:42:48 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:42:48 --> Model Class Initialized
DEBUG - 2016-09-21 15:42:48 --> Pagination Class Initialized
INFO - 2016-09-21 15:42:48 --> Config Class Initialized
INFO - 2016-09-21 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:42:48 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:42:48 --> Utf8 Class Initialized
INFO - 2016-09-21 15:42:48 --> URI Class Initialized
INFO - 2016-09-21 15:42:48 --> Router Class Initialized
INFO - 2016-09-21 15:42:48 --> Output Class Initialized
INFO - 2016-09-21 15:42:48 --> Security Class Initialized
DEBUG - 2016-09-21 15:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:42:48 --> Input Class Initialized
INFO - 2016-09-21 15:42:48 --> Language Class Initialized
INFO - 2016-09-21 15:42:48 --> Loader Class Initialized
INFO - 2016-09-21 15:42:48 --> Helper loaded: url_helper
INFO - 2016-09-21 15:42:48 --> Helper loaded: form_helper
INFO - 2016-09-21 15:42:48 --> Helper loaded: html_helper
INFO - 2016-09-21 15:42:48 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:42:48 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:42:48 --> Database Driver Class Initialized
INFO - 2016-09-21 15:42:48 --> Parser Class Initialized
DEBUG - 2016-09-21 15:42:48 --> Session Class Initialized
INFO - 2016-09-21 15:42:48 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:42:48 --> Session routines successfully run
INFO - 2016-09-21 15:42:48 --> Form Validation Class Initialized
INFO - 2016-09-21 15:42:48 --> Controller Class Initialized
DEBUG - 2016-09-21 15:42:48 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:42:48 --> Model Class Initialized
DEBUG - 2016-09-21 15:42:48 --> Pagination Class Initialized
INFO - 2016-09-21 15:42:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:42:48 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:42:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2016-09-21 15:42:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:42:50 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:42:50 --> Final output sent to browser
DEBUG - 2016-09-21 15:42:50 --> Total execution time: 2.3879
INFO - 2016-09-21 15:43:06 --> Config Class Initialized
INFO - 2016-09-21 15:43:06 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:43:06 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:43:06 --> Utf8 Class Initialized
INFO - 2016-09-21 15:43:06 --> URI Class Initialized
INFO - 2016-09-21 15:43:06 --> Router Class Initialized
INFO - 2016-09-21 15:43:06 --> Output Class Initialized
INFO - 2016-09-21 15:43:06 --> Security Class Initialized
DEBUG - 2016-09-21 15:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:43:06 --> Input Class Initialized
INFO - 2016-09-21 15:43:06 --> Language Class Initialized
INFO - 2016-09-21 15:43:06 --> Loader Class Initialized
INFO - 2016-09-21 15:43:06 --> Helper loaded: url_helper
INFO - 2016-09-21 15:43:06 --> Helper loaded: form_helper
INFO - 2016-09-21 15:43:06 --> Helper loaded: html_helper
INFO - 2016-09-21 15:43:06 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:43:06 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:43:06 --> Database Driver Class Initialized
INFO - 2016-09-21 15:43:06 --> Parser Class Initialized
DEBUG - 2016-09-21 15:43:06 --> Session Class Initialized
INFO - 2016-09-21 15:43:06 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:43:06 --> Session routines successfully run
INFO - 2016-09-21 15:43:06 --> Form Validation Class Initialized
INFO - 2016-09-21 15:43:06 --> Controller Class Initialized
INFO - 2016-09-21 15:43:06 --> Model Class Initialized
INFO - 2016-09-21 15:43:06 --> Config Class Initialized
INFO - 2016-09-21 15:43:07 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:43:07 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:43:07 --> Utf8 Class Initialized
INFO - 2016-09-21 15:43:07 --> URI Class Initialized
INFO - 2016-09-21 15:43:07 --> Router Class Initialized
INFO - 2016-09-21 15:43:07 --> Output Class Initialized
INFO - 2016-09-21 15:43:07 --> Security Class Initialized
DEBUG - 2016-09-21 15:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:43:07 --> Input Class Initialized
INFO - 2016-09-21 15:43:07 --> Language Class Initialized
INFO - 2016-09-21 15:43:07 --> Loader Class Initialized
INFO - 2016-09-21 15:43:07 --> Helper loaded: url_helper
INFO - 2016-09-21 15:43:07 --> Helper loaded: form_helper
INFO - 2016-09-21 15:43:07 --> Helper loaded: html_helper
INFO - 2016-09-21 15:43:07 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:43:07 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:43:07 --> Database Driver Class Initialized
INFO - 2016-09-21 15:43:07 --> Parser Class Initialized
DEBUG - 2016-09-21 15:43:07 --> Session Class Initialized
INFO - 2016-09-21 15:43:07 --> Helper loaded: string_helper
ERROR - 2016-09-21 15:43:07 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2016-09-21 15:43:07 --> Session routines successfully run
INFO - 2016-09-21 15:43:07 --> Form Validation Class Initialized
INFO - 2016-09-21 15:43:07 --> Controller Class Initialized
INFO - 2016-09-21 15:43:07 --> Model Class Initialized
INFO - 2016-09-21 15:43:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 15:43:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:43:07 --> Final output sent to browser
DEBUG - 2016-09-21 15:43:07 --> Total execution time: 0.3691
INFO - 2016-09-21 15:44:55 --> Config Class Initialized
INFO - 2016-09-21 15:44:55 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:44:55 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:44:55 --> Utf8 Class Initialized
INFO - 2016-09-21 15:44:55 --> URI Class Initialized
INFO - 2016-09-21 15:44:55 --> Router Class Initialized
INFO - 2016-09-21 15:44:55 --> Output Class Initialized
INFO - 2016-09-21 15:44:55 --> Security Class Initialized
DEBUG - 2016-09-21 15:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:44:55 --> Input Class Initialized
INFO - 2016-09-21 15:44:55 --> Language Class Initialized
INFO - 2016-09-21 15:44:55 --> Loader Class Initialized
INFO - 2016-09-21 15:44:55 --> Helper loaded: url_helper
INFO - 2016-09-21 15:44:55 --> Helper loaded: form_helper
INFO - 2016-09-21 15:44:55 --> Helper loaded: html_helper
INFO - 2016-09-21 15:44:55 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:44:55 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:44:55 --> Database Driver Class Initialized
INFO - 2016-09-21 15:44:55 --> Parser Class Initialized
DEBUG - 2016-09-21 15:44:55 --> Session Class Initialized
INFO - 2016-09-21 15:44:55 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:44:55 --> Session routines successfully run
INFO - 2016-09-21 15:44:55 --> Form Validation Class Initialized
INFO - 2016-09-21 15:44:55 --> Controller Class Initialized
INFO - 2016-09-21 15:44:55 --> Model Class Initialized
INFO - 2016-09-21 15:44:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 15:44:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:44:55 --> Final output sent to browser
DEBUG - 2016-09-21 15:44:55 --> Total execution time: 0.3524
INFO - 2016-09-21 15:45:08 --> Config Class Initialized
INFO - 2016-09-21 15:45:08 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:45:08 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:45:08 --> Utf8 Class Initialized
INFO - 2016-09-21 15:45:08 --> URI Class Initialized
INFO - 2016-09-21 15:45:08 --> Router Class Initialized
INFO - 2016-09-21 15:45:08 --> Output Class Initialized
INFO - 2016-09-21 15:45:08 --> Security Class Initialized
DEBUG - 2016-09-21 15:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:45:08 --> Input Class Initialized
INFO - 2016-09-21 15:45:08 --> Language Class Initialized
INFO - 2016-09-21 15:45:08 --> Loader Class Initialized
INFO - 2016-09-21 15:45:09 --> Helper loaded: url_helper
INFO - 2016-09-21 15:45:09 --> Helper loaded: form_helper
INFO - 2016-09-21 15:45:09 --> Helper loaded: html_helper
INFO - 2016-09-21 15:45:09 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:45:09 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:45:09 --> Database Driver Class Initialized
INFO - 2016-09-21 15:45:09 --> Parser Class Initialized
DEBUG - 2016-09-21 15:45:09 --> Session Class Initialized
INFO - 2016-09-21 15:45:09 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:45:09 --> Session routines successfully run
INFO - 2016-09-21 15:45:09 --> Form Validation Class Initialized
INFO - 2016-09-21 15:45:09 --> Controller Class Initialized
INFO - 2016-09-21 15:45:09 --> Model Class Initialized
INFO - 2016-09-21 15:45:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 15:46:00 --> Config Class Initialized
INFO - 2016-09-21 15:46:00 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:00 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:00 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:00 --> URI Class Initialized
INFO - 2016-09-21 15:46:00 --> Router Class Initialized
INFO - 2016-09-21 15:46:00 --> Output Class Initialized
INFO - 2016-09-21 15:46:00 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:00 --> Input Class Initialized
INFO - 2016-09-21 15:46:00 --> Language Class Initialized
INFO - 2016-09-21 15:46:00 --> Loader Class Initialized
INFO - 2016-09-21 15:46:00 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:00 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:01 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:01 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:01 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:01 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:01 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:01 --> Session Class Initialized
INFO - 2016-09-21 15:46:01 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:01 --> Session routines successfully run
INFO - 2016-09-21 15:46:01 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:01 --> Controller Class Initialized
INFO - 2016-09-21 15:46:01 --> Model Class Initialized
INFO - 2016-09-21 15:46:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 15:46:02 --> Config Class Initialized
INFO - 2016-09-21 15:46:02 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:02 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:02 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:02 --> URI Class Initialized
INFO - 2016-09-21 15:46:02 --> Router Class Initialized
INFO - 2016-09-21 15:46:02 --> Output Class Initialized
INFO - 2016-09-21 15:46:02 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:02 --> Input Class Initialized
INFO - 2016-09-21 15:46:02 --> Language Class Initialized
INFO - 2016-09-21 15:46:02 --> Loader Class Initialized
INFO - 2016-09-21 15:46:02 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:02 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:02 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:02 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:02 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:02 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:02 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:02 --> Session Class Initialized
INFO - 2016-09-21 15:46:02 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:02 --> Session routines successfully run
INFO - 2016-09-21 15:46:02 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:02 --> Controller Class Initialized
INFO - 2016-09-21 15:46:02 --> Model Class Initialized
INFO - 2016-09-21 15:46:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 15:46:03 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:46:03 --> Final output sent to browser
DEBUG - 2016-09-21 15:46:03 --> Total execution time: 0.3752
INFO - 2016-09-21 15:46:05 --> Config Class Initialized
INFO - 2016-09-21 15:46:05 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:05 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:05 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:05 --> URI Class Initialized
INFO - 2016-09-21 15:46:05 --> Router Class Initialized
INFO - 2016-09-21 15:46:05 --> Output Class Initialized
INFO - 2016-09-21 15:46:05 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:05 --> Input Class Initialized
INFO - 2016-09-21 15:46:05 --> Language Class Initialized
INFO - 2016-09-21 15:46:05 --> Loader Class Initialized
INFO - 2016-09-21 15:46:05 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:05 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:05 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:05 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:05 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:05 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:05 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:05 --> Session Class Initialized
INFO - 2016-09-21 15:46:05 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:05 --> Session routines successfully run
INFO - 2016-09-21 15:46:05 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:05 --> Controller Class Initialized
INFO - 2016-09-21 15:46:05 --> Model Class Initialized
INFO - 2016-09-21 15:46:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 15:46:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:46:05 --> Final output sent to browser
DEBUG - 2016-09-21 15:46:05 --> Total execution time: 0.4160
INFO - 2016-09-21 15:46:19 --> Config Class Initialized
INFO - 2016-09-21 15:46:19 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:19 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:19 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:19 --> URI Class Initialized
INFO - 2016-09-21 15:46:19 --> Router Class Initialized
INFO - 2016-09-21 15:46:19 --> Output Class Initialized
INFO - 2016-09-21 15:46:19 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:19 --> Input Class Initialized
INFO - 2016-09-21 15:46:19 --> Language Class Initialized
INFO - 2016-09-21 15:46:19 --> Loader Class Initialized
INFO - 2016-09-21 15:46:19 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:19 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:19 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:19 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:19 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:19 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:19 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:19 --> Session Class Initialized
INFO - 2016-09-21 15:46:19 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:19 --> Session routines successfully run
INFO - 2016-09-21 15:46:19 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:19 --> Controller Class Initialized
INFO - 2016-09-21 15:46:19 --> Model Class Initialized
INFO - 2016-09-21 15:46:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 15:46:19 --> Config Class Initialized
INFO - 2016-09-21 15:46:19 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:20 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:20 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:20 --> URI Class Initialized
INFO - 2016-09-21 15:46:20 --> Router Class Initialized
INFO - 2016-09-21 15:46:20 --> Output Class Initialized
INFO - 2016-09-21 15:46:20 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:20 --> Input Class Initialized
INFO - 2016-09-21 15:46:20 --> Language Class Initialized
INFO - 2016-09-21 15:46:20 --> Loader Class Initialized
INFO - 2016-09-21 15:46:20 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:20 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:20 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:20 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:20 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:20 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:20 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:20 --> Session Class Initialized
INFO - 2016-09-21 15:46:20 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:20 --> Session routines successfully run
INFO - 2016-09-21 15:46:20 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:20 --> Controller Class Initialized
DEBUG - 2016-09-21 15:46:20 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:46:20 --> Model Class Initialized
DEBUG - 2016-09-21 15:46:20 --> Pagination Class Initialized
INFO - 2016-09-21 15:46:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:46:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:46:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 15:46:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:46:20 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:46:20 --> Final output sent to browser
DEBUG - 2016-09-21 15:46:20 --> Total execution time: 0.4597
INFO - 2016-09-21 15:46:24 --> Config Class Initialized
INFO - 2016-09-21 15:46:24 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:24 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:24 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:24 --> URI Class Initialized
INFO - 2016-09-21 15:46:24 --> Router Class Initialized
INFO - 2016-09-21 15:46:24 --> Output Class Initialized
INFO - 2016-09-21 15:46:24 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:24 --> Input Class Initialized
INFO - 2016-09-21 15:46:24 --> Language Class Initialized
INFO - 2016-09-21 15:46:24 --> Loader Class Initialized
INFO - 2016-09-21 15:46:24 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:24 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:24 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:24 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:24 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:24 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:24 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:24 --> Session Class Initialized
INFO - 2016-09-21 15:46:24 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:24 --> Session routines successfully run
INFO - 2016-09-21 15:46:24 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:24 --> Controller Class Initialized
DEBUG - 2016-09-21 15:46:24 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:46:24 --> Model Class Initialized
DEBUG - 2016-09-21 15:46:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:46:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:46:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/addAdmin.php
INFO - 2016-09-21 15:46:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:46:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:46:25 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:46:25 --> Final output sent to browser
DEBUG - 2016-09-21 15:46:25 --> Total execution time: 0.4176
INFO - 2016-09-21 15:46:25 --> Config Class Initialized
INFO - 2016-09-21 15:46:25 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:25 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:25 --> Config Class Initialized
INFO - 2016-09-21 15:46:25 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:25 --> Hooks Class Initialized
INFO - 2016-09-21 15:46:25 --> URI Class Initialized
DEBUG - 2016-09-21 15:46:25 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:25 --> Router Class Initialized
INFO - 2016-09-21 15:46:25 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:25 --> URI Class Initialized
INFO - 2016-09-21 15:46:25 --> Output Class Initialized
INFO - 2016-09-21 15:46:25 --> Router Class Initialized
INFO - 2016-09-21 15:46:25 --> Security Class Initialized
INFO - 2016-09-21 15:46:25 --> Output Class Initialized
DEBUG - 2016-09-21 15:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:25 --> Security Class Initialized
INFO - 2016-09-21 15:46:25 --> Input Class Initialized
INFO - 2016-09-21 15:46:25 --> Language Class Initialized
DEBUG - 2016-09-21 15:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:25 --> Input Class Initialized
ERROR - 2016-09-21 15:46:25 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:46:25 --> Language Class Initialized
ERROR - 2016-09-21 15:46:25 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:46:41 --> Config Class Initialized
INFO - 2016-09-21 15:46:41 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:41 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:41 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:41 --> URI Class Initialized
INFO - 2016-09-21 15:46:41 --> Router Class Initialized
INFO - 2016-09-21 15:46:41 --> Output Class Initialized
INFO - 2016-09-21 15:46:41 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:41 --> Input Class Initialized
INFO - 2016-09-21 15:46:41 --> Language Class Initialized
INFO - 2016-09-21 15:46:41 --> Loader Class Initialized
INFO - 2016-09-21 15:46:41 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:41 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:41 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:41 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:41 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:41 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:41 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:41 --> Session Class Initialized
INFO - 2016-09-21 15:46:41 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:41 --> Session routines successfully run
INFO - 2016-09-21 15:46:41 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:41 --> Controller Class Initialized
DEBUG - 2016-09-21 15:46:41 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:46:41 --> Model Class Initialized
DEBUG - 2016-09-21 15:46:41 --> Pagination Class Initialized
INFO - 2016-09-21 15:46:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:46:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:46:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2016-09-21 15:46:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:46:41 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:46:41 --> Final output sent to browser
DEBUG - 2016-09-21 15:46:41 --> Total execution time: 0.4159
INFO - 2016-09-21 15:46:43 --> Config Class Initialized
INFO - 2016-09-21 15:46:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:43 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:43 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:43 --> URI Class Initialized
INFO - 2016-09-21 15:46:43 --> Router Class Initialized
INFO - 2016-09-21 15:46:43 --> Output Class Initialized
INFO - 2016-09-21 15:46:43 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:43 --> Input Class Initialized
INFO - 2016-09-21 15:46:43 --> Language Class Initialized
INFO - 2016-09-21 15:46:43 --> Loader Class Initialized
INFO - 2016-09-21 15:46:43 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:43 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:43 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:43 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:43 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:43 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:43 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:43 --> Session Class Initialized
INFO - 2016-09-21 15:46:43 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:43 --> Session routines successfully run
INFO - 2016-09-21 15:46:43 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:43 --> Controller Class Initialized
DEBUG - 2016-09-21 15:46:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:46:43 --> Model Class Initialized
DEBUG - 2016-09-21 15:46:43 --> Pagination Class Initialized
INFO - 2016-09-21 15:46:43 --> Config Class Initialized
INFO - 2016-09-21 15:46:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:43 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:43 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:43 --> URI Class Initialized
INFO - 2016-09-21 15:46:43 --> Router Class Initialized
INFO - 2016-09-21 15:46:43 --> Output Class Initialized
INFO - 2016-09-21 15:46:43 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:43 --> Input Class Initialized
INFO - 2016-09-21 15:46:43 --> Language Class Initialized
INFO - 2016-09-21 15:46:43 --> Loader Class Initialized
INFO - 2016-09-21 15:46:43 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:43 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:43 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:43 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:43 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:43 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:43 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:43 --> Session Class Initialized
INFO - 2016-09-21 15:46:43 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:43 --> Session routines successfully run
INFO - 2016-09-21 15:46:43 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:43 --> Controller Class Initialized
DEBUG - 2016-09-21 15:46:43 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:46:44 --> Model Class Initialized
DEBUG - 2016-09-21 15:46:44 --> Pagination Class Initialized
INFO - 2016-09-21 15:46:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:46:44 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:44 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:45 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2016-09-21 15:46:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2016-09-21 15:46:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:46:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:46:45 --> Final output sent to browser
DEBUG - 2016-09-21 15:46:45 --> Total execution time: 1.6569
INFO - 2016-09-21 15:46:46 --> Config Class Initialized
INFO - 2016-09-21 15:46:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:46 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:46 --> URI Class Initialized
INFO - 2016-09-21 15:46:46 --> Router Class Initialized
INFO - 2016-09-21 15:46:46 --> Output Class Initialized
INFO - 2016-09-21 15:46:46 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:46 --> Input Class Initialized
INFO - 2016-09-21 15:46:46 --> Language Class Initialized
INFO - 2016-09-21 15:46:46 --> Loader Class Initialized
INFO - 2016-09-21 15:46:46 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:46 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:46 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:46 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:46 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:46 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:46 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:46 --> Session Class Initialized
INFO - 2016-09-21 15:46:46 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:46 --> Session routines successfully run
INFO - 2016-09-21 15:46:46 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:46 --> Controller Class Initialized
DEBUG - 2016-09-21 15:46:46 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:46:46 --> Model Class Initialized
DEBUG - 2016-09-21 15:46:46 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:46:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-21 15:46:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:46:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2016-09-21 15:46:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2016-09-21 15:46:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:46:46 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:46:46 --> Final output sent to browser
DEBUG - 2016-09-21 15:46:46 --> Total execution time: 0.4746
INFO - 2016-09-21 15:46:46 --> Config Class Initialized
INFO - 2016-09-21 15:46:46 --> Hooks Class Initialized
INFO - 2016-09-21 15:46:46 --> Config Class Initialized
INFO - 2016-09-21 15:46:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:46:46 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:46 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:46 --> URI Class Initialized
INFO - 2016-09-21 15:46:46 --> URI Class Initialized
INFO - 2016-09-21 15:46:46 --> Router Class Initialized
INFO - 2016-09-21 15:46:46 --> Router Class Initialized
INFO - 2016-09-21 15:46:46 --> Output Class Initialized
INFO - 2016-09-21 15:46:46 --> Output Class Initialized
INFO - 2016-09-21 15:46:46 --> Security Class Initialized
INFO - 2016-09-21 15:46:46 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:46 --> Input Class Initialized
INFO - 2016-09-21 15:46:47 --> Input Class Initialized
INFO - 2016-09-21 15:46:47 --> Language Class Initialized
INFO - 2016-09-21 15:46:47 --> Language Class Initialized
ERROR - 2016-09-21 15:46:47 --> 404 Page Not Found: Default/assets
ERROR - 2016-09-21 15:46:47 --> 404 Page Not Found: Default/assets
INFO - 2016-09-21 15:46:47 --> Config Class Initialized
INFO - 2016-09-21 15:46:47 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:47 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:47 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:47 --> URI Class Initialized
INFO - 2016-09-21 15:46:47 --> Router Class Initialized
INFO - 2016-09-21 15:46:47 --> Output Class Initialized
INFO - 2016-09-21 15:46:47 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:47 --> Input Class Initialized
INFO - 2016-09-21 15:46:47 --> Language Class Initialized
INFO - 2016-09-21 15:46:47 --> Loader Class Initialized
INFO - 2016-09-21 15:46:47 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:47 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:47 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:47 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:47 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:47 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:47 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:47 --> Session Class Initialized
INFO - 2016-09-21 15:46:47 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:47 --> Session routines successfully run
INFO - 2016-09-21 15:46:47 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:47 --> Controller Class Initialized
DEBUG - 2016-09-21 15:46:47 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:46:47 --> Model Class Initialized
DEBUG - 2016-09-21 15:46:47 --> Pagination Class Initialized
ERROR - 2016-09-21 15:46:47 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2016-09-21 15:46:47 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2016-09-21 15:46:47 --> Final output sent to browser
DEBUG - 2016-09-21 15:46:47 --> Total execution time: 0.4120
INFO - 2016-09-21 15:46:53 --> Config Class Initialized
INFO - 2016-09-21 15:46:53 --> Config Class Initialized
INFO - 2016-09-21 15:46:53 --> Hooks Class Initialized
INFO - 2016-09-21 15:46:53 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:46:53 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:53 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:53 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:53 --> URI Class Initialized
INFO - 2016-09-21 15:46:53 --> URI Class Initialized
INFO - 2016-09-21 15:46:53 --> Router Class Initialized
INFO - 2016-09-21 15:46:53 --> Router Class Initialized
INFO - 2016-09-21 15:46:53 --> Output Class Initialized
INFO - 2016-09-21 15:46:53 --> Output Class Initialized
INFO - 2016-09-21 15:46:53 --> Security Class Initialized
INFO - 2016-09-21 15:46:53 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-21 15:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:53 --> Input Class Initialized
INFO - 2016-09-21 15:46:53 --> Input Class Initialized
INFO - 2016-09-21 15:46:53 --> Language Class Initialized
INFO - 2016-09-21 15:46:53 --> Language Class Initialized
INFO - 2016-09-21 15:46:53 --> Loader Class Initialized
INFO - 2016-09-21 15:46:53 --> Loader Class Initialized
INFO - 2016-09-21 15:46:53 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:53 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:53 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:53 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:53 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:53 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:53 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:53 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:53 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:53 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:53 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:53 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:53 --> Parser Class Initialized
INFO - 2016-09-21 15:46:53 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:53 --> Session Class Initialized
DEBUG - 2016-09-21 15:46:53 --> Session Class Initialized
INFO - 2016-09-21 15:46:53 --> Helper loaded: string_helper
INFO - 2016-09-21 15:46:53 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:53 --> Session routines successfully run
DEBUG - 2016-09-21 15:46:53 --> Session routines successfully run
INFO - 2016-09-21 15:46:53 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:53 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:53 --> Controller Class Initialized
INFO - 2016-09-21 15:46:53 --> Controller Class Initialized
DEBUG - 2016-09-21 15:46:53 --> Config file loaded: ../application/admin/config/s3.php
DEBUG - 2016-09-21 15:46:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:46:53 --> Model Class Initialized
INFO - 2016-09-21 15:46:53 --> Model Class Initialized
DEBUG - 2016-09-21 15:46:53 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:46:53 --> Pagination Class Initialized
INFO - 2016-09-21 15:46:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/ajax_company_list.php
INFO - 2016-09-21 15:46:53 --> Final output sent to browser
INFO - 2016-09-21 15:46:53 --> Final output sent to browser
DEBUG - 2016-09-21 15:46:53 --> Total execution time: 0.6704
DEBUG - 2016-09-21 15:46:53 --> Total execution time: 0.6589
INFO - 2016-09-21 15:46:57 --> Config Class Initialized
INFO - 2016-09-21 15:46:57 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:46:57 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:46:57 --> Utf8 Class Initialized
INFO - 2016-09-21 15:46:57 --> URI Class Initialized
INFO - 2016-09-21 15:46:57 --> Router Class Initialized
INFO - 2016-09-21 15:46:57 --> Output Class Initialized
INFO - 2016-09-21 15:46:57 --> Security Class Initialized
DEBUG - 2016-09-21 15:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:46:57 --> Input Class Initialized
INFO - 2016-09-21 15:46:57 --> Language Class Initialized
INFO - 2016-09-21 15:46:57 --> Loader Class Initialized
INFO - 2016-09-21 15:46:57 --> Helper loaded: url_helper
INFO - 2016-09-21 15:46:57 --> Helper loaded: form_helper
INFO - 2016-09-21 15:46:57 --> Helper loaded: html_helper
INFO - 2016-09-21 15:46:57 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:46:58 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:46:58 --> Database Driver Class Initialized
INFO - 2016-09-21 15:46:58 --> Parser Class Initialized
DEBUG - 2016-09-21 15:46:58 --> Session Class Initialized
INFO - 2016-09-21 15:46:58 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:46:58 --> Session routines successfully run
INFO - 2016-09-21 15:46:58 --> Form Validation Class Initialized
INFO - 2016-09-21 15:46:58 --> Controller Class Initialized
DEBUG - 2016-09-21 15:46:58 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2016-09-21 15:46:58 --> Model Class Initialized
DEBUG - 2016-09-21 15:46:58 --> Pagination Class Initialized
INFO - 2016-09-21 15:46:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2016-09-21 15:46:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2016-09-21 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2016-09-21 15:46:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2016-09-21 15:46:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2016-09-21 15:46:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:46:58 --> Final output sent to browser
DEBUG - 2016-09-21 15:46:58 --> Total execution time: 0.6379
INFO - 2016-09-21 15:48:54 --> Config Class Initialized
INFO - 2016-09-21 15:48:54 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:48:54 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:48:54 --> Utf8 Class Initialized
INFO - 2016-09-21 15:48:54 --> URI Class Initialized
INFO - 2016-09-21 15:48:54 --> Router Class Initialized
INFO - 2016-09-21 15:48:54 --> Output Class Initialized
INFO - 2016-09-21 15:48:54 --> Security Class Initialized
DEBUG - 2016-09-21 15:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:48:54 --> Input Class Initialized
INFO - 2016-09-21 15:48:54 --> Language Class Initialized
INFO - 2016-09-21 15:48:54 --> Loader Class Initialized
INFO - 2016-09-21 15:48:54 --> Helper loaded: url_helper
INFO - 2016-09-21 15:48:54 --> Helper loaded: form_helper
INFO - 2016-09-21 15:48:54 --> Helper loaded: html_helper
INFO - 2016-09-21 15:48:54 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:48:54 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:48:54 --> Database Driver Class Initialized
INFO - 2016-09-21 15:48:54 --> Parser Class Initialized
DEBUG - 2016-09-21 15:48:54 --> Session Class Initialized
INFO - 2016-09-21 15:48:54 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:48:54 --> Session routines successfully run
INFO - 2016-09-21 15:48:54 --> Form Validation Class Initialized
INFO - 2016-09-21 15:48:54 --> Controller Class Initialized
INFO - 2016-09-21 15:48:54 --> Model Class Initialized
INFO - 2016-09-21 15:48:54 --> Config Class Initialized
INFO - 2016-09-21 15:48:54 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:48:54 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:48:54 --> Utf8 Class Initialized
INFO - 2016-09-21 15:48:54 --> URI Class Initialized
INFO - 2016-09-21 15:48:54 --> Router Class Initialized
INFO - 2016-09-21 15:48:54 --> Output Class Initialized
INFO - 2016-09-21 15:48:54 --> Security Class Initialized
DEBUG - 2016-09-21 15:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:48:54 --> Input Class Initialized
INFO - 2016-09-21 15:48:54 --> Language Class Initialized
INFO - 2016-09-21 15:48:54 --> Loader Class Initialized
INFO - 2016-09-21 15:48:54 --> Helper loaded: url_helper
INFO - 2016-09-21 15:48:54 --> Helper loaded: form_helper
INFO - 2016-09-21 15:48:54 --> Helper loaded: html_helper
INFO - 2016-09-21 15:48:54 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:48:54 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:48:54 --> Database Driver Class Initialized
INFO - 2016-09-21 15:48:54 --> Parser Class Initialized
DEBUG - 2016-09-21 15:48:54 --> Session Class Initialized
INFO - 2016-09-21 15:48:54 --> Helper loaded: string_helper
ERROR - 2016-09-21 15:48:54 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2016-09-21 15:48:54 --> Session routines successfully run
INFO - 2016-09-21 15:48:54 --> Form Validation Class Initialized
INFO - 2016-09-21 15:48:54 --> Controller Class Initialized
INFO - 2016-09-21 15:48:55 --> Model Class Initialized
INFO - 2016-09-21 15:48:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 15:48:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:48:55 --> Final output sent to browser
DEBUG - 2016-09-21 15:48:55 --> Total execution time: 0.3940
INFO - 2016-09-21 15:49:14 --> Config Class Initialized
INFO - 2016-09-21 15:49:14 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:49:14 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:49:14 --> Utf8 Class Initialized
INFO - 2016-09-21 15:49:14 --> URI Class Initialized
INFO - 2016-09-21 15:49:14 --> Router Class Initialized
INFO - 2016-09-21 15:49:14 --> Output Class Initialized
INFO - 2016-09-21 15:49:14 --> Security Class Initialized
DEBUG - 2016-09-21 15:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:49:14 --> Input Class Initialized
INFO - 2016-09-21 15:49:14 --> Language Class Initialized
INFO - 2016-09-21 15:49:14 --> Loader Class Initialized
INFO - 2016-09-21 15:49:14 --> Helper loaded: url_helper
INFO - 2016-09-21 15:49:14 --> Helper loaded: form_helper
INFO - 2016-09-21 15:49:14 --> Helper loaded: html_helper
INFO - 2016-09-21 15:49:14 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:49:14 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:49:14 --> Database Driver Class Initialized
INFO - 2016-09-21 15:49:14 --> Parser Class Initialized
DEBUG - 2016-09-21 15:49:14 --> Session Class Initialized
INFO - 2016-09-21 15:49:14 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:49:14 --> Session routines successfully run
INFO - 2016-09-21 15:49:14 --> Form Validation Class Initialized
INFO - 2016-09-21 15:49:14 --> Controller Class Initialized
INFO - 2016-09-21 15:49:14 --> Model Class Initialized
INFO - 2016-09-21 15:49:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-21 15:49:17 --> Config Class Initialized
INFO - 2016-09-21 15:49:17 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:49:17 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:49:17 --> Utf8 Class Initialized
INFO - 2016-09-21 15:49:17 --> URI Class Initialized
INFO - 2016-09-21 15:49:17 --> Router Class Initialized
INFO - 2016-09-21 15:49:17 --> Output Class Initialized
INFO - 2016-09-21 15:49:17 --> Security Class Initialized
DEBUG - 2016-09-21 15:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:49:17 --> Input Class Initialized
INFO - 2016-09-21 15:49:17 --> Language Class Initialized
INFO - 2016-09-21 15:49:17 --> Loader Class Initialized
INFO - 2016-09-21 15:49:17 --> Helper loaded: url_helper
INFO - 2016-09-21 15:49:17 --> Helper loaded: form_helper
INFO - 2016-09-21 15:49:17 --> Helper loaded: html_helper
INFO - 2016-09-21 15:49:17 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:49:18 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:49:18 --> Database Driver Class Initialized
INFO - 2016-09-21 15:49:18 --> Parser Class Initialized
DEBUG - 2016-09-21 15:49:18 --> Session Class Initialized
INFO - 2016-09-21 15:49:18 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:49:18 --> Session routines successfully run
INFO - 2016-09-21 15:49:18 --> Form Validation Class Initialized
INFO - 2016-09-21 15:49:18 --> Controller Class Initialized
INFO - 2016-09-21 15:49:18 --> Model Class Initialized
INFO - 2016-09-21 15:49:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 15:49:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:49:18 --> Final output sent to browser
DEBUG - 2016-09-21 15:49:18 --> Total execution time: 0.3788
INFO - 2016-09-21 15:49:24 --> Config Class Initialized
INFO - 2016-09-21 15:49:24 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:49:24 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:49:24 --> Utf8 Class Initialized
INFO - 2016-09-21 15:49:24 --> URI Class Initialized
INFO - 2016-09-21 15:49:24 --> Router Class Initialized
INFO - 2016-09-21 15:49:24 --> Output Class Initialized
INFO - 2016-09-21 15:49:24 --> Security Class Initialized
DEBUG - 2016-09-21 15:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:49:24 --> Input Class Initialized
INFO - 2016-09-21 15:49:24 --> Language Class Initialized
INFO - 2016-09-21 15:49:24 --> Loader Class Initialized
INFO - 2016-09-21 15:49:24 --> Helper loaded: url_helper
INFO - 2016-09-21 15:49:24 --> Helper loaded: form_helper
INFO - 2016-09-21 15:49:24 --> Helper loaded: html_helper
INFO - 2016-09-21 15:49:24 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:49:24 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:49:24 --> Database Driver Class Initialized
INFO - 2016-09-21 15:49:24 --> Parser Class Initialized
DEBUG - 2016-09-21 15:49:24 --> Session Class Initialized
INFO - 2016-09-21 15:49:24 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:49:24 --> Session routines successfully run
INFO - 2016-09-21 15:49:24 --> Form Validation Class Initialized
INFO - 2016-09-21 15:49:24 --> Controller Class Initialized
INFO - 2016-09-21 15:49:24 --> Model Class Initialized
INFO - 2016-09-21 15:49:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2016-09-21 15:49:24 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2016-09-21 15:49:24 --> Final output sent to browser
DEBUG - 2016-09-21 15:49:24 --> Total execution time: 0.3663
INFO - 2016-09-21 15:49:36 --> Config Class Initialized
INFO - 2016-09-21 15:49:36 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:49:36 --> UTF-8 Support Enabled
INFO - 2016-09-21 15:49:36 --> Utf8 Class Initialized
INFO - 2016-09-21 15:49:36 --> URI Class Initialized
INFO - 2016-09-21 15:49:36 --> Router Class Initialized
INFO - 2016-09-21 15:49:36 --> Output Class Initialized
INFO - 2016-09-21 15:49:36 --> Security Class Initialized
DEBUG - 2016-09-21 15:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-21 15:49:36 --> Input Class Initialized
INFO - 2016-09-21 15:49:36 --> Language Class Initialized
INFO - 2016-09-21 15:49:36 --> Loader Class Initialized
INFO - 2016-09-21 15:49:36 --> Helper loaded: url_helper
INFO - 2016-09-21 15:49:36 --> Helper loaded: form_helper
INFO - 2016-09-21 15:49:36 --> Helper loaded: html_helper
INFO - 2016-09-21 15:49:36 --> Helper loaded: custom_helper
INFO - 2016-09-21 15:49:36 --> Helper loaded: cache_helper
INFO - 2016-09-21 15:49:36 --> Database Driver Class Initialized
INFO - 2016-09-21 15:49:36 --> Parser Class Initialized
DEBUG - 2016-09-21 15:49:36 --> Session Class Initialized
INFO - 2016-09-21 15:49:36 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:49:36 --> Session routines successfully run
INFO - 2016-09-21 15:49:36 --> Form Validation Class Initialized
INFO - 2016-09-21 15:49:36 --> Controller Class Initialized
INFO - 2016-09-21 15:49:36 --> Model Class Initialized
INFO - 2016-09-21 15:49:36 --> Language file loaded: language/english/form_validation_lang.php
