<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-11 09:07:54 --> Config Class Initialized
INFO - 2017-07-11 09:07:54 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:07:54 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:07:54 --> Utf8 Class Initialized
INFO - 2017-07-11 09:07:54 --> URI Class Initialized
DEBUG - 2017-07-11 09:07:54 --> No URI present. Default controller set.
INFO - 2017-07-11 09:07:54 --> Router Class Initialized
INFO - 2017-07-11 09:07:54 --> Output Class Initialized
INFO - 2017-07-11 09:07:54 --> Security Class Initialized
DEBUG - 2017-07-11 09:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:07:54 --> Input Class Initialized
INFO - 2017-07-11 09:07:54 --> Language Class Initialized
INFO - 2017-07-11 09:07:54 --> Loader Class Initialized
INFO - 2017-07-11 09:07:54 --> Helper loaded: url_helper
INFO - 2017-07-11 09:07:54 --> Helper loaded: form_helper
INFO - 2017-07-11 09:07:54 --> Helper loaded: html_helper
INFO - 2017-07-11 09:07:54 --> Helper loaded: custom_helper
INFO - 2017-07-11 09:07:54 --> Helper loaded: cache_helper
INFO - 2017-07-11 09:07:54 --> Database Driver Class Initialized
INFO - 2017-07-11 09:07:54 --> Parser Class Initialized
DEBUG - 2017-07-11 09:07:54 --> Session Class Initialized
INFO - 2017-07-11 09:07:54 --> Helper loaded: string_helper
ERROR - 2017-07-11 09:07:54 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-07-11 09:07:55 --> Session routines successfully run
INFO - 2017-07-11 09:07:55 --> Form Validation Class Initialized
INFO - 2017-07-11 09:07:55 --> Controller Class Initialized
INFO - 2017-07-11 09:07:55 --> Model Class Initialized
INFO - 2017-07-11 09:07:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-07-11 09:07:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 09:07:55 --> Final output sent to browser
DEBUG - 2017-07-11 09:07:55 --> Total execution time: 0.8270
INFO - 2017-07-11 09:07:56 --> Config Class Initialized
INFO - 2017-07-11 09:07:57 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:07:57 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:07:57 --> Utf8 Class Initialized
INFO - 2017-07-11 09:07:57 --> URI Class Initialized
INFO - 2017-07-11 09:07:57 --> Router Class Initialized
INFO - 2017-07-11 09:07:57 --> Output Class Initialized
INFO - 2017-07-11 09:07:57 --> Security Class Initialized
DEBUG - 2017-07-11 09:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:07:57 --> Input Class Initialized
INFO - 2017-07-11 09:07:57 --> Language Class Initialized
ERROR - 2017-07-11 09:07:57 --> 404 Page Not Found: Schedullo/admin
INFO - 2017-07-11 09:08:13 --> Config Class Initialized
INFO - 2017-07-11 09:08:14 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:08:14 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:08:14 --> Utf8 Class Initialized
INFO - 2017-07-11 09:08:14 --> URI Class Initialized
INFO - 2017-07-11 09:08:14 --> Router Class Initialized
INFO - 2017-07-11 09:08:14 --> Output Class Initialized
INFO - 2017-07-11 09:08:14 --> Security Class Initialized
DEBUG - 2017-07-11 09:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:08:14 --> Input Class Initialized
INFO - 2017-07-11 09:08:14 --> Language Class Initialized
ERROR - 2017-07-11 09:08:14 --> 404 Page Not Found: Schedullo/admin
INFO - 2017-07-11 09:08:46 --> Config Class Initialized
INFO - 2017-07-11 09:08:46 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:08:46 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:08:46 --> Utf8 Class Initialized
INFO - 2017-07-11 09:08:46 --> URI Class Initialized
DEBUG - 2017-07-11 09:08:46 --> No URI present. Default controller set.
INFO - 2017-07-11 09:08:46 --> Router Class Initialized
INFO - 2017-07-11 09:08:46 --> Output Class Initialized
INFO - 2017-07-11 09:08:46 --> Security Class Initialized
DEBUG - 2017-07-11 09:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:08:46 --> Input Class Initialized
INFO - 2017-07-11 09:08:47 --> Language Class Initialized
INFO - 2017-07-11 09:08:47 --> Loader Class Initialized
INFO - 2017-07-11 09:08:47 --> Helper loaded: url_helper
INFO - 2017-07-11 09:08:47 --> Helper loaded: form_helper
INFO - 2017-07-11 09:08:47 --> Helper loaded: html_helper
INFO - 2017-07-11 09:08:47 --> Helper loaded: custom_helper
INFO - 2017-07-11 09:08:47 --> Helper loaded: cache_helper
INFO - 2017-07-11 09:08:47 --> Database Driver Class Initialized
INFO - 2017-07-11 09:08:47 --> Parser Class Initialized
DEBUG - 2017-07-11 09:08:47 --> Session Class Initialized
INFO - 2017-07-11 09:08:47 --> Helper loaded: string_helper
DEBUG - 2017-07-11 09:08:47 --> Session routines successfully run
INFO - 2017-07-11 09:08:47 --> Form Validation Class Initialized
INFO - 2017-07-11 09:08:47 --> Controller Class Initialized
INFO - 2017-07-11 09:08:47 --> Model Class Initialized
INFO - 2017-07-11 09:08:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-07-11 09:08:47 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 09:08:47 --> Final output sent to browser
DEBUG - 2017-07-11 09:08:47 --> Total execution time: 0.5049
INFO - 2017-07-11 09:08:47 --> Config Class Initialized
INFO - 2017-07-11 09:08:47 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:08:47 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:08:47 --> Utf8 Class Initialized
INFO - 2017-07-11 09:08:47 --> URI Class Initialized
INFO - 2017-07-11 09:08:47 --> Router Class Initialized
INFO - 2017-07-11 09:08:47 --> Output Class Initialized
INFO - 2017-07-11 09:08:47 --> Security Class Initialized
DEBUG - 2017-07-11 09:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:08:47 --> Input Class Initialized
INFO - 2017-07-11 09:08:47 --> Language Class Initialized
ERROR - 2017-07-11 09:08:47 --> 404 Page Not Found: Default/assets
INFO - 2017-07-11 09:09:03 --> Config Class Initialized
INFO - 2017-07-11 09:09:03 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:09:03 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:09:03 --> Utf8 Class Initialized
INFO - 2017-07-11 09:09:03 --> URI Class Initialized
INFO - 2017-07-11 09:09:03 --> Router Class Initialized
INFO - 2017-07-11 09:09:03 --> Output Class Initialized
INFO - 2017-07-11 09:09:03 --> Security Class Initialized
DEBUG - 2017-07-11 09:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:09:03 --> Input Class Initialized
INFO - 2017-07-11 09:09:03 --> Language Class Initialized
INFO - 2017-07-11 09:09:03 --> Loader Class Initialized
INFO - 2017-07-11 09:09:03 --> Helper loaded: url_helper
INFO - 2017-07-11 09:09:03 --> Helper loaded: form_helper
INFO - 2017-07-11 09:09:03 --> Helper loaded: html_helper
INFO - 2017-07-11 09:09:03 --> Helper loaded: custom_helper
INFO - 2017-07-11 09:09:03 --> Helper loaded: cache_helper
INFO - 2017-07-11 09:09:03 --> Database Driver Class Initialized
INFO - 2017-07-11 09:09:03 --> Parser Class Initialized
DEBUG - 2017-07-11 09:09:03 --> Session Class Initialized
INFO - 2017-07-11 09:09:03 --> Helper loaded: string_helper
DEBUG - 2017-07-11 09:09:03 --> Session routines successfully run
INFO - 2017-07-11 09:09:03 --> Form Validation Class Initialized
INFO - 2017-07-11 09:09:03 --> Controller Class Initialized
INFO - 2017-07-11 09:09:03 --> Model Class Initialized
INFO - 2017-07-11 09:09:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-11 09:09:04 --> Config Class Initialized
INFO - 2017-07-11 09:09:04 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:09:04 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:09:04 --> Utf8 Class Initialized
INFO - 2017-07-11 09:09:04 --> URI Class Initialized
INFO - 2017-07-11 09:09:04 --> Router Class Initialized
INFO - 2017-07-11 09:09:04 --> Output Class Initialized
INFO - 2017-07-11 09:09:04 --> Security Class Initialized
DEBUG - 2017-07-11 09:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:09:04 --> Input Class Initialized
INFO - 2017-07-11 09:09:04 --> Language Class Initialized
INFO - 2017-07-11 09:09:04 --> Loader Class Initialized
INFO - 2017-07-11 09:09:04 --> Helper loaded: url_helper
INFO - 2017-07-11 09:09:04 --> Helper loaded: form_helper
INFO - 2017-07-11 09:09:04 --> Helper loaded: html_helper
INFO - 2017-07-11 09:09:04 --> Helper loaded: custom_helper
INFO - 2017-07-11 09:09:04 --> Helper loaded: cache_helper
INFO - 2017-07-11 09:09:04 --> Database Driver Class Initialized
INFO - 2017-07-11 09:09:04 --> Parser Class Initialized
DEBUG - 2017-07-11 09:09:04 --> Session Class Initialized
INFO - 2017-07-11 09:09:04 --> Helper loaded: string_helper
DEBUG - 2017-07-11 09:09:04 --> Session routines successfully run
INFO - 2017-07-11 09:09:04 --> Form Validation Class Initialized
INFO - 2017-07-11 09:09:04 --> Controller Class Initialized
DEBUG - 2017-07-11 09:09:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-07-11 09:09:04 --> Model Class Initialized
DEBUG - 2017-07-11 09:09:04 --> Pagination Class Initialized
INFO - 2017-07-11 09:09:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 09:09:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 09:09:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-07-11 09:09:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 09:09:04 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 09:09:04 --> Final output sent to browser
DEBUG - 2017-07-11 09:09:04 --> Total execution time: 0.8599
INFO - 2017-07-11 09:09:08 --> Config Class Initialized
INFO - 2017-07-11 09:09:08 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:09:08 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:09:08 --> Utf8 Class Initialized
INFO - 2017-07-11 09:09:08 --> URI Class Initialized
INFO - 2017-07-11 09:09:08 --> Router Class Initialized
INFO - 2017-07-11 09:09:08 --> Output Class Initialized
INFO - 2017-07-11 09:09:08 --> Security Class Initialized
DEBUG - 2017-07-11 09:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:09:08 --> Input Class Initialized
INFO - 2017-07-11 09:09:08 --> Language Class Initialized
INFO - 2017-07-11 09:09:08 --> Loader Class Initialized
INFO - 2017-07-11 09:09:08 --> Helper loaded: url_helper
INFO - 2017-07-11 09:09:08 --> Helper loaded: form_helper
INFO - 2017-07-11 09:09:08 --> Helper loaded: html_helper
INFO - 2017-07-11 09:09:08 --> Helper loaded: custom_helper
INFO - 2017-07-11 09:09:08 --> Helper loaded: cache_helper
INFO - 2017-07-11 09:09:08 --> Database Driver Class Initialized
INFO - 2017-07-11 09:09:08 --> Parser Class Initialized
DEBUG - 2017-07-11 09:09:08 --> Session Class Initialized
INFO - 2017-07-11 09:09:08 --> Helper loaded: string_helper
DEBUG - 2017-07-11 09:09:08 --> Session routines successfully run
INFO - 2017-07-11 09:09:08 --> Form Validation Class Initialized
INFO - 2017-07-11 09:09:08 --> Controller Class Initialized
INFO - 2017-07-11 09:09:08 --> Model Class Initialized
INFO - 2017-07-11 09:09:08 --> Config Class Initialized
INFO - 2017-07-11 09:09:08 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:09:08 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:09:08 --> Utf8 Class Initialized
INFO - 2017-07-11 09:09:08 --> URI Class Initialized
INFO - 2017-07-11 09:09:08 --> Router Class Initialized
INFO - 2017-07-11 09:09:08 --> Output Class Initialized
INFO - 2017-07-11 09:09:08 --> Security Class Initialized
DEBUG - 2017-07-11 09:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:09:08 --> Input Class Initialized
INFO - 2017-07-11 09:09:08 --> Language Class Initialized
INFO - 2017-07-11 09:09:08 --> Loader Class Initialized
INFO - 2017-07-11 09:09:08 --> Helper loaded: url_helper
INFO - 2017-07-11 09:09:08 --> Helper loaded: form_helper
INFO - 2017-07-11 09:09:08 --> Helper loaded: html_helper
INFO - 2017-07-11 09:09:08 --> Helper loaded: custom_helper
INFO - 2017-07-11 09:09:08 --> Helper loaded: cache_helper
INFO - 2017-07-11 09:09:08 --> Database Driver Class Initialized
INFO - 2017-07-11 09:09:08 --> Parser Class Initialized
DEBUG - 2017-07-11 09:09:08 --> Session Class Initialized
INFO - 2017-07-11 09:09:08 --> Helper loaded: string_helper
DEBUG - 2017-07-11 09:09:08 --> Session routines successfully run
INFO - 2017-07-11 09:09:08 --> Form Validation Class Initialized
INFO - 2017-07-11 09:09:08 --> Controller Class Initialized
INFO - 2017-07-11 09:09:08 --> Model Class Initialized
INFO - 2017-07-11 09:09:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 09:09:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 09:09:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2017-07-11 09:09:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 09:09:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 09:09:09 --> Final output sent to browser
DEBUG - 2017-07-11 09:09:09 --> Total execution time: 0.4773
INFO - 2017-07-11 09:09:17 --> Config Class Initialized
INFO - 2017-07-11 09:09:17 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:09:17 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:09:17 --> Utf8 Class Initialized
INFO - 2017-07-11 09:09:17 --> URI Class Initialized
INFO - 2017-07-11 09:09:17 --> Router Class Initialized
INFO - 2017-07-11 09:09:17 --> Output Class Initialized
INFO - 2017-07-11 09:09:17 --> Security Class Initialized
DEBUG - 2017-07-11 09:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:09:17 --> Input Class Initialized
INFO - 2017-07-11 09:09:17 --> Language Class Initialized
INFO - 2017-07-11 09:09:17 --> Loader Class Initialized
INFO - 2017-07-11 09:09:17 --> Helper loaded: url_helper
INFO - 2017-07-11 09:09:18 --> Helper loaded: form_helper
INFO - 2017-07-11 09:09:18 --> Helper loaded: html_helper
INFO - 2017-07-11 09:09:18 --> Helper loaded: custom_helper
INFO - 2017-07-11 09:09:18 --> Helper loaded: cache_helper
INFO - 2017-07-11 09:09:18 --> Database Driver Class Initialized
INFO - 2017-07-11 09:09:18 --> Parser Class Initialized
DEBUG - 2017-07-11 09:09:18 --> Session Class Initialized
INFO - 2017-07-11 09:09:18 --> Helper loaded: string_helper
DEBUG - 2017-07-11 09:09:18 --> Session routines successfully run
INFO - 2017-07-11 09:09:18 --> Form Validation Class Initialized
INFO - 2017-07-11 09:09:18 --> Controller Class Initialized
INFO - 2017-07-11 09:09:18 --> Model Class Initialized
DEBUG - 2017-07-11 09:09:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-11 09:09:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 09:09:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 09:09:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/addEmailTemplate.php
INFO - 2017-07-11 09:09:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 09:09:18 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 09:09:18 --> Final output sent to browser
DEBUG - 2017-07-11 09:09:18 --> Total execution time: 0.3172
INFO - 2017-07-11 09:09:29 --> Config Class Initialized
INFO - 2017-07-11 09:09:29 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:09:29 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:09:29 --> Utf8 Class Initialized
INFO - 2017-07-11 09:09:29 --> URI Class Initialized
INFO - 2017-07-11 09:09:29 --> Router Class Initialized
INFO - 2017-07-11 09:09:29 --> Output Class Initialized
INFO - 2017-07-11 09:09:29 --> Security Class Initialized
DEBUG - 2017-07-11 09:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:09:29 --> Input Class Initialized
INFO - 2017-07-11 09:09:29 --> Language Class Initialized
INFO - 2017-07-11 09:09:29 --> Loader Class Initialized
INFO - 2017-07-11 09:09:29 --> Helper loaded: url_helper
INFO - 2017-07-11 09:09:29 --> Helper loaded: form_helper
INFO - 2017-07-11 09:09:29 --> Helper loaded: html_helper
INFO - 2017-07-11 09:09:29 --> Helper loaded: custom_helper
INFO - 2017-07-11 09:09:29 --> Helper loaded: cache_helper
INFO - 2017-07-11 09:09:29 --> Database Driver Class Initialized
INFO - 2017-07-11 09:09:29 --> Parser Class Initialized
DEBUG - 2017-07-11 09:09:29 --> Session Class Initialized
INFO - 2017-07-11 09:09:29 --> Helper loaded: string_helper
DEBUG - 2017-07-11 09:09:29 --> Session routines successfully run
INFO - 2017-07-11 09:09:29 --> Form Validation Class Initialized
INFO - 2017-07-11 09:09:29 --> Controller Class Initialized
INFO - 2017-07-11 09:09:29 --> Model Class Initialized
INFO - 2017-07-11 09:09:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 09:09:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 09:09:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2017-07-11 09:09:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 09:09:29 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 09:09:29 --> Final output sent to browser
DEBUG - 2017-07-11 09:09:29 --> Total execution time: 0.5382
INFO - 2017-07-11 09:09:36 --> Config Class Initialized
INFO - 2017-07-11 09:09:36 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:09:36 --> UTF-8 Support Enabled
INFO - 2017-07-11 09:09:36 --> Utf8 Class Initialized
INFO - 2017-07-11 09:09:36 --> URI Class Initialized
INFO - 2017-07-11 09:09:36 --> Router Class Initialized
INFO - 2017-07-11 09:09:36 --> Output Class Initialized
INFO - 2017-07-11 09:09:37 --> Security Class Initialized
DEBUG - 2017-07-11 09:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 09:09:37 --> Input Class Initialized
INFO - 2017-07-11 09:09:37 --> Language Class Initialized
INFO - 2017-07-11 09:09:37 --> Loader Class Initialized
INFO - 2017-07-11 09:09:37 --> Helper loaded: url_helper
INFO - 2017-07-11 09:09:37 --> Helper loaded: form_helper
INFO - 2017-07-11 09:09:37 --> Helper loaded: html_helper
INFO - 2017-07-11 09:09:37 --> Helper loaded: custom_helper
INFO - 2017-07-11 09:09:37 --> Helper loaded: cache_helper
INFO - 2017-07-11 09:09:37 --> Database Driver Class Initialized
INFO - 2017-07-11 09:09:37 --> Parser Class Initialized
DEBUG - 2017-07-11 09:09:37 --> Session Class Initialized
INFO - 2017-07-11 09:09:37 --> Helper loaded: string_helper
DEBUG - 2017-07-11 09:09:37 --> Session routines successfully run
INFO - 2017-07-11 09:09:37 --> Form Validation Class Initialized
INFO - 2017-07-11 09:09:37 --> Controller Class Initialized
INFO - 2017-07-11 09:09:37 --> Model Class Initialized
DEBUG - 2017-07-11 09:09:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-11 09:09:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 09:09:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 09:09:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/addEmailTemplate.php
INFO - 2017-07-11 09:09:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 09:09:37 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 09:09:37 --> Final output sent to browser
DEBUG - 2017-07-11 09:09:37 --> Total execution time: 0.2189
INFO - 2017-07-11 10:42:19 --> Config Class Initialized
INFO - 2017-07-11 10:42:19 --> Hooks Class Initialized
DEBUG - 2017-07-11 10:42:21 --> UTF-8 Support Enabled
INFO - 2017-07-11 10:42:21 --> Utf8 Class Initialized
INFO - 2017-07-11 10:42:21 --> URI Class Initialized
INFO - 2017-07-11 10:42:21 --> Router Class Initialized
INFO - 2017-07-11 10:42:21 --> Output Class Initialized
INFO - 2017-07-11 10:42:22 --> Security Class Initialized
DEBUG - 2017-07-11 10:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 10:42:22 --> Input Class Initialized
INFO - 2017-07-11 10:42:22 --> Language Class Initialized
INFO - 2017-07-11 10:42:23 --> Loader Class Initialized
INFO - 2017-07-11 10:42:23 --> Helper loaded: url_helper
INFO - 2017-07-11 10:42:23 --> Helper loaded: form_helper
INFO - 2017-07-11 10:42:24 --> Helper loaded: html_helper
INFO - 2017-07-11 10:42:24 --> Helper loaded: custom_helper
INFO - 2017-07-11 10:42:24 --> Helper loaded: cache_helper
INFO - 2017-07-11 10:42:25 --> Database Driver Class Initialized
INFO - 2017-07-11 10:42:25 --> Parser Class Initialized
DEBUG - 2017-07-11 10:42:25 --> Session Class Initialized
INFO - 2017-07-11 10:42:25 --> Helper loaded: string_helper
DEBUG - 2017-07-11 10:42:25 --> Session routines successfully run
INFO - 2017-07-11 10:42:25 --> Form Validation Class Initialized
INFO - 2017-07-11 10:42:25 --> Controller Class Initialized
INFO - 2017-07-11 10:42:25 --> Model Class Initialized
DEBUG - 2017-07-11 10:42:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-11 10:42:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 10:42:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 10:42:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/addEmailTemplate.php
INFO - 2017-07-11 10:42:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 10:42:26 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 10:42:26 --> Final output sent to browser
DEBUG - 2017-07-11 10:42:26 --> Total execution time: 7.4845
INFO - 2017-07-11 10:42:47 --> Config Class Initialized
INFO - 2017-07-11 10:42:47 --> Hooks Class Initialized
DEBUG - 2017-07-11 10:42:47 --> UTF-8 Support Enabled
INFO - 2017-07-11 10:42:47 --> Utf8 Class Initialized
INFO - 2017-07-11 10:42:47 --> URI Class Initialized
INFO - 2017-07-11 10:42:47 --> Router Class Initialized
INFO - 2017-07-11 10:42:47 --> Output Class Initialized
INFO - 2017-07-11 10:42:47 --> Security Class Initialized
DEBUG - 2017-07-11 10:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 10:42:47 --> Input Class Initialized
INFO - 2017-07-11 10:42:47 --> Language Class Initialized
INFO - 2017-07-11 10:42:47 --> Loader Class Initialized
INFO - 2017-07-11 10:42:47 --> Helper loaded: url_helper
INFO - 2017-07-11 10:42:47 --> Helper loaded: form_helper
INFO - 2017-07-11 10:42:47 --> Helper loaded: html_helper
INFO - 2017-07-11 10:42:47 --> Helper loaded: custom_helper
INFO - 2017-07-11 10:42:47 --> Helper loaded: cache_helper
INFO - 2017-07-11 10:42:47 --> Database Driver Class Initialized
INFO - 2017-07-11 10:42:47 --> Parser Class Initialized
DEBUG - 2017-07-11 10:42:47 --> Session Class Initialized
INFO - 2017-07-11 10:42:47 --> Helper loaded: string_helper
DEBUG - 2017-07-11 10:42:47 --> Session routines successfully run
INFO - 2017-07-11 10:42:47 --> Form Validation Class Initialized
INFO - 2017-07-11 10:42:47 --> Controller Class Initialized
INFO - 2017-07-11 10:42:47 --> Model Class Initialized
INFO - 2017-07-11 10:42:52 --> Config Class Initialized
INFO - 2017-07-11 10:42:52 --> Hooks Class Initialized
DEBUG - 2017-07-11 10:42:52 --> UTF-8 Support Enabled
INFO - 2017-07-11 10:42:52 --> Utf8 Class Initialized
INFO - 2017-07-11 10:42:52 --> URI Class Initialized
INFO - 2017-07-11 10:42:53 --> Router Class Initialized
INFO - 2017-07-11 10:42:53 --> Output Class Initialized
INFO - 2017-07-11 10:42:53 --> Security Class Initialized
DEBUG - 2017-07-11 10:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 10:42:53 --> Input Class Initialized
INFO - 2017-07-11 10:42:53 --> Language Class Initialized
INFO - 2017-07-11 10:42:53 --> Loader Class Initialized
INFO - 2017-07-11 10:42:53 --> Helper loaded: url_helper
INFO - 2017-07-11 10:42:53 --> Helper loaded: form_helper
INFO - 2017-07-11 10:42:53 --> Helper loaded: html_helper
INFO - 2017-07-11 10:42:53 --> Helper loaded: custom_helper
INFO - 2017-07-11 10:42:53 --> Helper loaded: cache_helper
INFO - 2017-07-11 10:42:53 --> Database Driver Class Initialized
INFO - 2017-07-11 10:42:53 --> Parser Class Initialized
DEBUG - 2017-07-11 10:42:53 --> Session Class Initialized
INFO - 2017-07-11 10:42:53 --> Helper loaded: string_helper
ERROR - 2017-07-11 10:42:53 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-07-11 10:42:53 --> Session routines successfully run
INFO - 2017-07-11 10:42:53 --> Form Validation Class Initialized
INFO - 2017-07-11 10:42:53 --> Controller Class Initialized
INFO - 2017-07-11 10:42:53 --> Model Class Initialized
INFO - 2017-07-11 10:42:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-07-11 10:42:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 10:42:53 --> Final output sent to browser
DEBUG - 2017-07-11 10:42:53 --> Total execution time: 0.2811
INFO - 2017-07-11 10:43:01 --> Config Class Initialized
INFO - 2017-07-11 10:43:01 --> Hooks Class Initialized
DEBUG - 2017-07-11 10:43:01 --> UTF-8 Support Enabled
INFO - 2017-07-11 10:43:01 --> Utf8 Class Initialized
INFO - 2017-07-11 10:43:01 --> URI Class Initialized
INFO - 2017-07-11 10:43:01 --> Router Class Initialized
INFO - 2017-07-11 10:43:01 --> Output Class Initialized
INFO - 2017-07-11 10:43:01 --> Security Class Initialized
DEBUG - 2017-07-11 10:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 10:43:01 --> Input Class Initialized
INFO - 2017-07-11 10:43:01 --> Language Class Initialized
ERROR - 2017-07-11 10:43:01 --> 404 Page Not Found: Default/assets
INFO - 2017-07-11 14:56:38 --> Config Class Initialized
INFO - 2017-07-11 14:56:38 --> Hooks Class Initialized
DEBUG - 2017-07-11 14:56:38 --> UTF-8 Support Enabled
INFO - 2017-07-11 14:56:38 --> Utf8 Class Initialized
INFO - 2017-07-11 14:56:38 --> URI Class Initialized
DEBUG - 2017-07-11 14:56:38 --> No URI present. Default controller set.
INFO - 2017-07-11 14:56:38 --> Router Class Initialized
INFO - 2017-07-11 14:56:38 --> Output Class Initialized
INFO - 2017-07-11 14:56:38 --> Security Class Initialized
DEBUG - 2017-07-11 14:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 14:56:38 --> Input Class Initialized
INFO - 2017-07-11 14:56:38 --> Language Class Initialized
INFO - 2017-07-11 14:56:38 --> Loader Class Initialized
INFO - 2017-07-11 14:56:38 --> Helper loaded: url_helper
INFO - 2017-07-11 14:56:38 --> Helper loaded: form_helper
INFO - 2017-07-11 14:56:38 --> Helper loaded: html_helper
INFO - 2017-07-11 14:56:38 --> Helper loaded: custom_helper
INFO - 2017-07-11 14:56:38 --> Helper loaded: cache_helper
INFO - 2017-07-11 14:56:38 --> Database Driver Class Initialized
INFO - 2017-07-11 14:56:38 --> Parser Class Initialized
DEBUG - 2017-07-11 14:56:38 --> Session Class Initialized
INFO - 2017-07-11 14:56:38 --> Helper loaded: string_helper
ERROR - 2017-07-11 14:56:38 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-07-11 14:56:38 --> Session routines successfully run
INFO - 2017-07-11 14:56:38 --> Form Validation Class Initialized
INFO - 2017-07-11 14:56:38 --> Controller Class Initialized
INFO - 2017-07-11 14:56:39 --> Model Class Initialized
INFO - 2017-07-11 14:56:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-07-11 14:56:39 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 14:56:39 --> Final output sent to browser
DEBUG - 2017-07-11 14:56:39 --> Total execution time: 1.4146
INFO - 2017-07-11 14:56:39 --> Config Class Initialized
INFO - 2017-07-11 14:56:39 --> Hooks Class Initialized
DEBUG - 2017-07-11 14:56:39 --> UTF-8 Support Enabled
INFO - 2017-07-11 14:56:39 --> Utf8 Class Initialized
INFO - 2017-07-11 14:56:39 --> URI Class Initialized
INFO - 2017-07-11 14:56:39 --> Router Class Initialized
INFO - 2017-07-11 14:56:39 --> Output Class Initialized
INFO - 2017-07-11 14:56:39 --> Security Class Initialized
DEBUG - 2017-07-11 14:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 14:56:39 --> Input Class Initialized
INFO - 2017-07-11 14:56:39 --> Language Class Initialized
ERROR - 2017-07-11 14:56:39 --> 404 Page Not Found: Default/assets
INFO - 2017-07-11 14:56:53 --> Config Class Initialized
INFO - 2017-07-11 14:56:53 --> Hooks Class Initialized
DEBUG - 2017-07-11 14:56:53 --> UTF-8 Support Enabled
INFO - 2017-07-11 14:56:53 --> Utf8 Class Initialized
INFO - 2017-07-11 14:56:53 --> URI Class Initialized
INFO - 2017-07-11 14:56:53 --> Router Class Initialized
INFO - 2017-07-11 14:56:53 --> Output Class Initialized
INFO - 2017-07-11 14:56:53 --> Security Class Initialized
DEBUG - 2017-07-11 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 14:56:53 --> Input Class Initialized
INFO - 2017-07-11 14:56:53 --> Language Class Initialized
INFO - 2017-07-11 14:56:53 --> Loader Class Initialized
INFO - 2017-07-11 14:56:53 --> Helper loaded: url_helper
INFO - 2017-07-11 14:56:53 --> Helper loaded: form_helper
INFO - 2017-07-11 14:56:53 --> Helper loaded: html_helper
INFO - 2017-07-11 14:56:53 --> Helper loaded: custom_helper
INFO - 2017-07-11 14:56:53 --> Helper loaded: cache_helper
INFO - 2017-07-11 14:56:53 --> Database Driver Class Initialized
INFO - 2017-07-11 14:56:53 --> Parser Class Initialized
DEBUG - 2017-07-11 14:56:53 --> Session Class Initialized
INFO - 2017-07-11 14:56:53 --> Helper loaded: string_helper
DEBUG - 2017-07-11 14:56:53 --> Session routines successfully run
INFO - 2017-07-11 14:56:53 --> Form Validation Class Initialized
INFO - 2017-07-11 14:56:53 --> Controller Class Initialized
INFO - 2017-07-11 14:56:53 --> Model Class Initialized
INFO - 2017-07-11 14:56:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-11 14:56:53 --> Config Class Initialized
INFO - 2017-07-11 14:56:53 --> Hooks Class Initialized
DEBUG - 2017-07-11 14:56:53 --> UTF-8 Support Enabled
INFO - 2017-07-11 14:56:53 --> Utf8 Class Initialized
INFO - 2017-07-11 14:56:53 --> URI Class Initialized
INFO - 2017-07-11 14:56:53 --> Router Class Initialized
INFO - 2017-07-11 14:56:53 --> Output Class Initialized
INFO - 2017-07-11 14:56:53 --> Security Class Initialized
DEBUG - 2017-07-11 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 14:56:53 --> Input Class Initialized
INFO - 2017-07-11 14:56:53 --> Language Class Initialized
INFO - 2017-07-11 14:56:53 --> Loader Class Initialized
INFO - 2017-07-11 14:56:53 --> Helper loaded: url_helper
INFO - 2017-07-11 14:56:53 --> Helper loaded: form_helper
INFO - 2017-07-11 14:56:53 --> Helper loaded: html_helper
INFO - 2017-07-11 14:56:53 --> Helper loaded: custom_helper
INFO - 2017-07-11 14:56:53 --> Helper loaded: cache_helper
INFO - 2017-07-11 14:56:53 --> Database Driver Class Initialized
INFO - 2017-07-11 14:56:53 --> Parser Class Initialized
DEBUG - 2017-07-11 14:56:53 --> Session Class Initialized
INFO - 2017-07-11 14:56:53 --> Helper loaded: string_helper
DEBUG - 2017-07-11 14:56:53 --> Session routines successfully run
INFO - 2017-07-11 14:56:53 --> Form Validation Class Initialized
INFO - 2017-07-11 14:56:53 --> Controller Class Initialized
DEBUG - 2017-07-11 14:56:53 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-07-11 14:56:53 --> Model Class Initialized
DEBUG - 2017-07-11 14:56:53 --> Pagination Class Initialized
INFO - 2017-07-11 14:56:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 14:56:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 14:56:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-07-11 14:56:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 14:56:54 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 14:56:54 --> Final output sent to browser
DEBUG - 2017-07-11 14:56:54 --> Total execution time: 0.9193
INFO - 2017-07-11 14:56:58 --> Config Class Initialized
INFO - 2017-07-11 14:56:58 --> Hooks Class Initialized
DEBUG - 2017-07-11 14:56:58 --> UTF-8 Support Enabled
INFO - 2017-07-11 14:56:58 --> Utf8 Class Initialized
INFO - 2017-07-11 14:56:58 --> URI Class Initialized
INFO - 2017-07-11 14:56:58 --> Router Class Initialized
INFO - 2017-07-11 14:56:58 --> Output Class Initialized
INFO - 2017-07-11 14:56:58 --> Security Class Initialized
DEBUG - 2017-07-11 14:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 14:56:58 --> Input Class Initialized
INFO - 2017-07-11 14:56:58 --> Language Class Initialized
INFO - 2017-07-11 14:56:58 --> Loader Class Initialized
INFO - 2017-07-11 14:56:58 --> Helper loaded: url_helper
INFO - 2017-07-11 14:56:59 --> Helper loaded: form_helper
INFO - 2017-07-11 14:56:59 --> Helper loaded: html_helper
INFO - 2017-07-11 14:56:59 --> Helper loaded: custom_helper
INFO - 2017-07-11 14:56:59 --> Helper loaded: cache_helper
INFO - 2017-07-11 14:56:59 --> Database Driver Class Initialized
INFO - 2017-07-11 14:56:59 --> Parser Class Initialized
DEBUG - 2017-07-11 14:56:59 --> Session Class Initialized
INFO - 2017-07-11 14:56:59 --> Helper loaded: string_helper
DEBUG - 2017-07-11 14:56:59 --> Session routines successfully run
INFO - 2017-07-11 14:56:59 --> Form Validation Class Initialized
INFO - 2017-07-11 14:56:59 --> Controller Class Initialized
INFO - 2017-07-11 14:56:59 --> Model Class Initialized
INFO - 2017-07-11 14:56:59 --> Config Class Initialized
INFO - 2017-07-11 14:56:59 --> Hooks Class Initialized
DEBUG - 2017-07-11 14:56:59 --> UTF-8 Support Enabled
INFO - 2017-07-11 14:56:59 --> Utf8 Class Initialized
INFO - 2017-07-11 14:56:59 --> URI Class Initialized
INFO - 2017-07-11 14:56:59 --> Router Class Initialized
INFO - 2017-07-11 14:56:59 --> Output Class Initialized
INFO - 2017-07-11 14:56:59 --> Security Class Initialized
DEBUG - 2017-07-11 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 14:56:59 --> Input Class Initialized
INFO - 2017-07-11 14:56:59 --> Language Class Initialized
INFO - 2017-07-11 14:56:59 --> Loader Class Initialized
INFO - 2017-07-11 14:56:59 --> Helper loaded: url_helper
INFO - 2017-07-11 14:56:59 --> Helper loaded: form_helper
INFO - 2017-07-11 14:56:59 --> Helper loaded: html_helper
INFO - 2017-07-11 14:56:59 --> Helper loaded: custom_helper
INFO - 2017-07-11 14:56:59 --> Helper loaded: cache_helper
INFO - 2017-07-11 14:56:59 --> Database Driver Class Initialized
INFO - 2017-07-11 14:56:59 --> Parser Class Initialized
DEBUG - 2017-07-11 14:56:59 --> Session Class Initialized
INFO - 2017-07-11 14:56:59 --> Helper loaded: string_helper
DEBUG - 2017-07-11 14:56:59 --> Session routines successfully run
INFO - 2017-07-11 14:56:59 --> Form Validation Class Initialized
INFO - 2017-07-11 14:56:59 --> Controller Class Initialized
INFO - 2017-07-11 14:56:59 --> Model Class Initialized
INFO - 2017-07-11 14:56:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 14:56:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 14:56:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2017-07-11 14:56:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 14:56:59 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 14:56:59 --> Final output sent to browser
DEBUG - 2017-07-11 14:56:59 --> Total execution time: 0.4547
INFO - 2017-07-11 14:57:06 --> Config Class Initialized
INFO - 2017-07-11 14:57:06 --> Hooks Class Initialized
DEBUG - 2017-07-11 14:57:06 --> UTF-8 Support Enabled
INFO - 2017-07-11 14:57:06 --> Utf8 Class Initialized
INFO - 2017-07-11 14:57:06 --> URI Class Initialized
INFO - 2017-07-11 14:57:06 --> Router Class Initialized
INFO - 2017-07-11 14:57:06 --> Output Class Initialized
INFO - 2017-07-11 14:57:06 --> Security Class Initialized
DEBUG - 2017-07-11 14:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 14:57:06 --> Input Class Initialized
INFO - 2017-07-11 14:57:06 --> Language Class Initialized
INFO - 2017-07-11 14:57:06 --> Loader Class Initialized
INFO - 2017-07-11 14:57:06 --> Helper loaded: url_helper
INFO - 2017-07-11 14:57:06 --> Helper loaded: form_helper
INFO - 2017-07-11 14:57:06 --> Helper loaded: html_helper
INFO - 2017-07-11 14:57:06 --> Helper loaded: custom_helper
INFO - 2017-07-11 14:57:06 --> Helper loaded: cache_helper
INFO - 2017-07-11 14:57:06 --> Database Driver Class Initialized
INFO - 2017-07-11 14:57:07 --> Parser Class Initialized
DEBUG - 2017-07-11 14:57:07 --> Session Class Initialized
INFO - 2017-07-11 14:57:07 --> Helper loaded: string_helper
DEBUG - 2017-07-11 14:57:07 --> Session routines successfully run
INFO - 2017-07-11 14:57:07 --> Form Validation Class Initialized
INFO - 2017-07-11 14:57:07 --> Controller Class Initialized
INFO - 2017-07-11 14:57:07 --> Model Class Initialized
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 14:57:07 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
INFO - 2017-07-11 14:57:07 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/EmailTemplatelistAjax.php
INFO - 2017-07-11 14:57:10 --> Config Class Initialized
INFO - 2017-07-11 14:57:10 --> Hooks Class Initialized
DEBUG - 2017-07-11 14:57:10 --> UTF-8 Support Enabled
INFO - 2017-07-11 14:57:10 --> Utf8 Class Initialized
INFO - 2017-07-11 14:57:10 --> URI Class Initialized
INFO - 2017-07-11 14:57:10 --> Router Class Initialized
INFO - 2017-07-11 14:57:10 --> Output Class Initialized
INFO - 2017-07-11 14:57:10 --> Security Class Initialized
DEBUG - 2017-07-11 14:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 14:57:10 --> Input Class Initialized
INFO - 2017-07-11 14:57:10 --> Language Class Initialized
INFO - 2017-07-11 14:57:10 --> Loader Class Initialized
INFO - 2017-07-11 14:57:10 --> Helper loaded: url_helper
INFO - 2017-07-11 14:57:10 --> Helper loaded: form_helper
INFO - 2017-07-11 14:57:10 --> Helper loaded: html_helper
INFO - 2017-07-11 14:57:10 --> Helper loaded: custom_helper
INFO - 2017-07-11 14:57:10 --> Helper loaded: cache_helper
INFO - 2017-07-11 14:57:10 --> Database Driver Class Initialized
INFO - 2017-07-11 14:57:10 --> Parser Class Initialized
DEBUG - 2017-07-11 14:57:10 --> Session Class Initialized
INFO - 2017-07-11 14:57:10 --> Helper loaded: string_helper
DEBUG - 2017-07-11 14:57:10 --> Session routines successfully run
INFO - 2017-07-11 14:57:10 --> Form Validation Class Initialized
INFO - 2017-07-11 14:57:10 --> Controller Class Initialized
INFO - 2017-07-11 14:57:10 --> Model Class Initialized
DEBUG - 2017-07-11 14:57:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-07-11 14:57:10 --> Severity: Notice --> Undefined index: sandgrid_id C:\xampp\htdocs\schedullo\application\admin\controllers\EmailTemplate.php 409
INFO - 2017-07-11 14:57:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 14:57:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 14:57:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/addEmailTemplate.php
INFO - 2017-07-11 14:57:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 14:57:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 14:57:10 --> Final output sent to browser
DEBUG - 2017-07-11 14:57:10 --> Total execution time: 0.3978
INFO - 2017-07-11 15:00:53 --> Config Class Initialized
INFO - 2017-07-11 15:00:53 --> Hooks Class Initialized
DEBUG - 2017-07-11 15:00:53 --> UTF-8 Support Enabled
INFO - 2017-07-11 15:00:53 --> Utf8 Class Initialized
INFO - 2017-07-11 15:00:53 --> URI Class Initialized
INFO - 2017-07-11 15:00:53 --> Router Class Initialized
INFO - 2017-07-11 15:00:53 --> Output Class Initialized
INFO - 2017-07-11 15:00:53 --> Security Class Initialized
DEBUG - 2017-07-11 15:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 15:00:53 --> Input Class Initialized
INFO - 2017-07-11 15:00:53 --> Language Class Initialized
INFO - 2017-07-11 15:00:53 --> Loader Class Initialized
INFO - 2017-07-11 15:00:53 --> Helper loaded: url_helper
INFO - 2017-07-11 15:00:53 --> Helper loaded: form_helper
INFO - 2017-07-11 15:00:53 --> Helper loaded: html_helper
INFO - 2017-07-11 15:00:53 --> Helper loaded: custom_helper
INFO - 2017-07-11 15:00:53 --> Helper loaded: cache_helper
INFO - 2017-07-11 15:00:53 --> Database Driver Class Initialized
INFO - 2017-07-11 15:00:53 --> Parser Class Initialized
DEBUG - 2017-07-11 15:00:53 --> Session Class Initialized
INFO - 2017-07-11 15:00:53 --> Helper loaded: string_helper
DEBUG - 2017-07-11 15:00:53 --> Session routines successfully run
INFO - 2017-07-11 15:00:53 --> Form Validation Class Initialized
INFO - 2017-07-11 15:00:53 --> Controller Class Initialized
INFO - 2017-07-11 15:00:53 --> Model Class Initialized
INFO - 2017-07-11 15:00:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 15:00:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 15:00:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2017-07-11 15:00:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 15:00:53 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 15:00:53 --> Final output sent to browser
DEBUG - 2017-07-11 15:00:53 --> Total execution time: 0.2247
INFO - 2017-07-11 15:00:55 --> Config Class Initialized
INFO - 2017-07-11 15:00:55 --> Hooks Class Initialized
DEBUG - 2017-07-11 15:00:55 --> UTF-8 Support Enabled
INFO - 2017-07-11 15:00:55 --> Utf8 Class Initialized
INFO - 2017-07-11 15:00:55 --> URI Class Initialized
INFO - 2017-07-11 15:00:55 --> Router Class Initialized
INFO - 2017-07-11 15:00:55 --> Output Class Initialized
INFO - 2017-07-11 15:00:55 --> Security Class Initialized
DEBUG - 2017-07-11 15:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 15:00:55 --> Input Class Initialized
INFO - 2017-07-11 15:00:55 --> Language Class Initialized
INFO - 2017-07-11 15:00:55 --> Loader Class Initialized
INFO - 2017-07-11 15:00:55 --> Helper loaded: url_helper
INFO - 2017-07-11 15:00:55 --> Helper loaded: form_helper
INFO - 2017-07-11 15:00:55 --> Helper loaded: html_helper
INFO - 2017-07-11 15:00:55 --> Helper loaded: custom_helper
INFO - 2017-07-11 15:00:55 --> Helper loaded: cache_helper
INFO - 2017-07-11 15:00:55 --> Database Driver Class Initialized
INFO - 2017-07-11 15:00:55 --> Parser Class Initialized
DEBUG - 2017-07-11 15:00:55 --> Session Class Initialized
INFO - 2017-07-11 15:00:55 --> Helper loaded: string_helper
DEBUG - 2017-07-11 15:00:55 --> Session routines successfully run
INFO - 2017-07-11 15:00:55 --> Form Validation Class Initialized
INFO - 2017-07-11 15:00:55 --> Controller Class Initialized
INFO - 2017-07-11 15:00:55 --> Model Class Initialized
INFO - 2017-07-11 15:00:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 15:00:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 15:00:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2017-07-11 15:00:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 15:00:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 15:00:55 --> Final output sent to browser
DEBUG - 2017-07-11 15:00:55 --> Total execution time: 0.2634
INFO - 2017-07-11 15:01:00 --> Config Class Initialized
INFO - 2017-07-11 15:01:00 --> Hooks Class Initialized
DEBUG - 2017-07-11 15:01:00 --> UTF-8 Support Enabled
INFO - 2017-07-11 15:01:00 --> Utf8 Class Initialized
INFO - 2017-07-11 15:01:00 --> URI Class Initialized
INFO - 2017-07-11 15:01:00 --> Router Class Initialized
INFO - 2017-07-11 15:01:00 --> Output Class Initialized
INFO - 2017-07-11 15:01:00 --> Security Class Initialized
DEBUG - 2017-07-11 15:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 15:01:00 --> Input Class Initialized
INFO - 2017-07-11 15:01:00 --> Language Class Initialized
INFO - 2017-07-11 15:01:00 --> Loader Class Initialized
INFO - 2017-07-11 15:01:00 --> Helper loaded: url_helper
INFO - 2017-07-11 15:01:00 --> Helper loaded: form_helper
INFO - 2017-07-11 15:01:00 --> Helper loaded: html_helper
INFO - 2017-07-11 15:01:00 --> Helper loaded: custom_helper
INFO - 2017-07-11 15:01:00 --> Helper loaded: cache_helper
INFO - 2017-07-11 15:01:00 --> Database Driver Class Initialized
INFO - 2017-07-11 15:01:00 --> Parser Class Initialized
DEBUG - 2017-07-11 15:01:00 --> Session Class Initialized
INFO - 2017-07-11 15:01:00 --> Helper loaded: string_helper
DEBUG - 2017-07-11 15:01:00 --> Session routines successfully run
INFO - 2017-07-11 15:01:00 --> Form Validation Class Initialized
INFO - 2017-07-11 15:01:00 --> Controller Class Initialized
INFO - 2017-07-11 15:01:00 --> Model Class Initialized
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
INFO - 2017-07-11 15:01:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/EmailTemplatelistAjax.php
INFO - 2017-07-11 15:01:06 --> Config Class Initialized
INFO - 2017-07-11 15:01:06 --> Hooks Class Initialized
DEBUG - 2017-07-11 15:01:06 --> UTF-8 Support Enabled
INFO - 2017-07-11 15:01:06 --> Utf8 Class Initialized
INFO - 2017-07-11 15:01:06 --> URI Class Initialized
INFO - 2017-07-11 15:01:06 --> Router Class Initialized
INFO - 2017-07-11 15:01:06 --> Output Class Initialized
INFO - 2017-07-11 15:01:06 --> Security Class Initialized
DEBUG - 2017-07-11 15:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 15:01:06 --> Input Class Initialized
INFO - 2017-07-11 15:01:06 --> Language Class Initialized
INFO - 2017-07-11 15:01:06 --> Loader Class Initialized
INFO - 2017-07-11 15:01:06 --> Helper loaded: url_helper
INFO - 2017-07-11 15:01:06 --> Helper loaded: form_helper
INFO - 2017-07-11 15:01:06 --> Helper loaded: html_helper
INFO - 2017-07-11 15:01:06 --> Helper loaded: custom_helper
INFO - 2017-07-11 15:01:06 --> Helper loaded: cache_helper
INFO - 2017-07-11 15:01:06 --> Database Driver Class Initialized
INFO - 2017-07-11 15:01:06 --> Parser Class Initialized
DEBUG - 2017-07-11 15:01:06 --> Session Class Initialized
INFO - 2017-07-11 15:01:06 --> Helper loaded: string_helper
DEBUG - 2017-07-11 15:01:06 --> Session routines successfully run
INFO - 2017-07-11 15:01:06 --> Form Validation Class Initialized
INFO - 2017-07-11 15:01:06 --> Controller Class Initialized
INFO - 2017-07-11 15:01:06 --> Model Class Initialized
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:01:06 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
INFO - 2017-07-11 15:01:06 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/EmailTemplatelistAjax.php
INFO - 2017-07-11 15:06:51 --> Config Class Initialized
INFO - 2017-07-11 15:06:51 --> Hooks Class Initialized
DEBUG - 2017-07-11 15:06:51 --> UTF-8 Support Enabled
INFO - 2017-07-11 15:06:51 --> Utf8 Class Initialized
INFO - 2017-07-11 15:06:51 --> URI Class Initialized
INFO - 2017-07-11 15:06:51 --> Router Class Initialized
INFO - 2017-07-11 15:06:51 --> Output Class Initialized
INFO - 2017-07-11 15:06:51 --> Security Class Initialized
DEBUG - 2017-07-11 15:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 15:06:51 --> Input Class Initialized
INFO - 2017-07-11 15:06:51 --> Language Class Initialized
INFO - 2017-07-11 15:06:51 --> Loader Class Initialized
INFO - 2017-07-11 15:06:51 --> Helper loaded: url_helper
INFO - 2017-07-11 15:06:51 --> Helper loaded: form_helper
INFO - 2017-07-11 15:06:51 --> Helper loaded: html_helper
INFO - 2017-07-11 15:06:51 --> Helper loaded: custom_helper
INFO - 2017-07-11 15:06:51 --> Helper loaded: cache_helper
INFO - 2017-07-11 15:06:51 --> Database Driver Class Initialized
INFO - 2017-07-11 15:06:51 --> Parser Class Initialized
DEBUG - 2017-07-11 15:06:51 --> Session Class Initialized
INFO - 2017-07-11 15:06:51 --> Helper loaded: string_helper
DEBUG - 2017-07-11 15:06:51 --> Session routines successfully run
INFO - 2017-07-11 15:06:51 --> Form Validation Class Initialized
INFO - 2017-07-11 15:06:51 --> Controller Class Initialized
INFO - 2017-07-11 15:06:51 --> Model Class Initialized
INFO - 2017-07-11 15:06:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 15:06:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 15:06:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/listEmailTemplate.php
INFO - 2017-07-11 15:06:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 15:06:52 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 15:06:52 --> Final output sent to browser
DEBUG - 2017-07-11 15:06:52 --> Total execution time: 0.3080
INFO - 2017-07-11 15:06:57 --> Config Class Initialized
INFO - 2017-07-11 15:06:57 --> Hooks Class Initialized
DEBUG - 2017-07-11 15:06:57 --> UTF-8 Support Enabled
INFO - 2017-07-11 15:06:57 --> Utf8 Class Initialized
INFO - 2017-07-11 15:06:57 --> URI Class Initialized
INFO - 2017-07-11 15:06:57 --> Router Class Initialized
INFO - 2017-07-11 15:06:57 --> Output Class Initialized
INFO - 2017-07-11 15:06:57 --> Security Class Initialized
DEBUG - 2017-07-11 15:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 15:06:57 --> Input Class Initialized
INFO - 2017-07-11 15:06:57 --> Language Class Initialized
INFO - 2017-07-11 15:06:57 --> Loader Class Initialized
INFO - 2017-07-11 15:06:57 --> Helper loaded: url_helper
INFO - 2017-07-11 15:06:57 --> Helper loaded: form_helper
INFO - 2017-07-11 15:06:57 --> Helper loaded: html_helper
INFO - 2017-07-11 15:06:57 --> Helper loaded: custom_helper
INFO - 2017-07-11 15:06:57 --> Helper loaded: cache_helper
INFO - 2017-07-11 15:06:57 --> Database Driver Class Initialized
INFO - 2017-07-11 15:06:57 --> Parser Class Initialized
DEBUG - 2017-07-11 15:06:57 --> Session Class Initialized
INFO - 2017-07-11 15:06:57 --> Helper loaded: string_helper
DEBUG - 2017-07-11 15:06:57 --> Session routines successfully run
INFO - 2017-07-11 15:06:57 --> Form Validation Class Initialized
INFO - 2017-07-11 15:06:57 --> Controller Class Initialized
INFO - 2017-07-11 15:06:57 --> Model Class Initialized
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:57 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 32
ERROR - 2017-07-11 15:06:58 --> Severity: Notice --> Undefined property: stdClass::$EmailTemplate_id C:\xampp\htdocs\schedullo\application\admin\views\default\layout\EmailTemplate\EmailTemplatelistAjax.php 39
INFO - 2017-07-11 15:06:58 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/EmailTemplatelistAjax.php
INFO - 2017-07-11 15:07:00 --> Config Class Initialized
INFO - 2017-07-11 15:07:00 --> Hooks Class Initialized
DEBUG - 2017-07-11 15:07:00 --> UTF-8 Support Enabled
INFO - 2017-07-11 15:07:00 --> Utf8 Class Initialized
INFO - 2017-07-11 15:07:00 --> URI Class Initialized
INFO - 2017-07-11 15:07:00 --> Router Class Initialized
INFO - 2017-07-11 15:07:00 --> Output Class Initialized
INFO - 2017-07-11 15:07:00 --> Security Class Initialized
DEBUG - 2017-07-11 15:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-11 15:07:00 --> Input Class Initialized
INFO - 2017-07-11 15:07:00 --> Language Class Initialized
INFO - 2017-07-11 15:07:00 --> Loader Class Initialized
INFO - 2017-07-11 15:07:00 --> Helper loaded: url_helper
INFO - 2017-07-11 15:07:00 --> Helper loaded: form_helper
INFO - 2017-07-11 15:07:00 --> Helper loaded: html_helper
INFO - 2017-07-11 15:07:00 --> Helper loaded: custom_helper
INFO - 2017-07-11 15:07:00 --> Helper loaded: cache_helper
INFO - 2017-07-11 15:07:00 --> Database Driver Class Initialized
INFO - 2017-07-11 15:07:00 --> Parser Class Initialized
DEBUG - 2017-07-11 15:07:00 --> Session Class Initialized
INFO - 2017-07-11 15:07:00 --> Helper loaded: string_helper
DEBUG - 2017-07-11 15:07:00 --> Session routines successfully run
INFO - 2017-07-11 15:07:00 --> Form Validation Class Initialized
INFO - 2017-07-11 15:07:00 --> Controller Class Initialized
INFO - 2017-07-11 15:07:00 --> Model Class Initialized
DEBUG - 2017-07-11 15:07:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-07-11 15:07:00 --> Severity: Notice --> Undefined index: sandgrid_id C:\xampp\htdocs\schedullo\application\admin\controllers\EmailTemplate.php 409
INFO - 2017-07-11 15:07:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-07-11 15:07:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-07-11 15:07:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/EmailTemplate/addEmailTemplate.php
INFO - 2017-07-11 15:07:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-07-11 15:07:00 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-07-11 15:07:00 --> Final output sent to browser
DEBUG - 2017-07-11 15:07:00 --> Total execution time: 0.2828
