<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-04-28 09:18:45 --> Config Class Initialized
INFO - 2017-04-28 09:18:45 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:18:45 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:18:45 --> Utf8 Class Initialized
INFO - 2017-04-28 09:18:45 --> URI Class Initialized
DEBUG - 2017-04-28 09:18:45 --> No URI present. Default controller set.
INFO - 2017-04-28 09:18:45 --> Router Class Initialized
INFO - 2017-04-28 09:18:45 --> Output Class Initialized
INFO - 2017-04-28 09:18:45 --> Security Class Initialized
DEBUG - 2017-04-28 09:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:18:45 --> Input Class Initialized
INFO - 2017-04-28 09:18:45 --> Language Class Initialized
INFO - 2017-04-28 09:18:45 --> Loader Class Initialized
INFO - 2017-04-28 09:18:45 --> Helper loaded: url_helper
INFO - 2017-04-28 09:18:45 --> Helper loaded: form_helper
INFO - 2017-04-28 09:18:45 --> Helper loaded: html_helper
INFO - 2017-04-28 09:18:45 --> Helper loaded: custom_helper
INFO - 2017-04-28 09:18:45 --> Helper loaded: cache_helper
INFO - 2017-04-28 09:18:45 --> Database Driver Class Initialized
INFO - 2017-04-28 09:18:45 --> Parser Class Initialized
DEBUG - 2017-04-28 09:18:45 --> Session Class Initialized
INFO - 2017-04-28 09:18:45 --> Helper loaded: string_helper
ERROR - 2017-04-28 09:18:45 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-28 09:18:45 --> Session routines successfully run
INFO - 2017-04-28 09:18:45 --> Form Validation Class Initialized
INFO - 2017-04-28 09:18:45 --> Controller Class Initialized
INFO - 2017-04-28 09:18:45 --> Model Class Initialized
INFO - 2017-04-28 09:18:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-28 09:18:45 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-28 09:18:45 --> Final output sent to browser
DEBUG - 2017-04-28 09:18:45 --> Total execution time: 0.4278
INFO - 2017-04-28 09:18:57 --> Config Class Initialized
INFO - 2017-04-28 09:18:57 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:18:57 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:18:57 --> Utf8 Class Initialized
INFO - 2017-04-28 09:18:57 --> URI Class Initialized
INFO - 2017-04-28 09:18:57 --> Router Class Initialized
INFO - 2017-04-28 09:18:57 --> Output Class Initialized
INFO - 2017-04-28 09:18:57 --> Security Class Initialized
DEBUG - 2017-04-28 09:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:18:57 --> Input Class Initialized
INFO - 2017-04-28 09:18:57 --> Language Class Initialized
INFO - 2017-04-28 09:18:57 --> Loader Class Initialized
INFO - 2017-04-28 09:18:57 --> Helper loaded: url_helper
INFO - 2017-04-28 09:18:57 --> Helper loaded: form_helper
INFO - 2017-04-28 09:18:57 --> Helper loaded: html_helper
INFO - 2017-04-28 09:18:57 --> Helper loaded: custom_helper
INFO - 2017-04-28 09:18:57 --> Helper loaded: cache_helper
INFO - 2017-04-28 09:18:57 --> Database Driver Class Initialized
INFO - 2017-04-28 09:18:58 --> Parser Class Initialized
DEBUG - 2017-04-28 09:18:58 --> Session Class Initialized
INFO - 2017-04-28 09:18:58 --> Helper loaded: string_helper
ERROR - 2017-04-28 09:18:58 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-28 09:18:58 --> Session routines successfully run
INFO - 2017-04-28 09:18:58 --> Form Validation Class Initialized
INFO - 2017-04-28 09:18:58 --> Controller Class Initialized
INFO - 2017-04-28 09:18:58 --> Model Class Initialized
INFO - 2017-04-28 09:18:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-04-28 09:19:04 --> Config Class Initialized
INFO - 2017-04-28 09:19:04 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:19:04 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:19:04 --> Utf8 Class Initialized
INFO - 2017-04-28 09:19:04 --> URI Class Initialized
INFO - 2017-04-28 09:19:04 --> Router Class Initialized
INFO - 2017-04-28 09:19:04 --> Output Class Initialized
INFO - 2017-04-28 09:19:04 --> Security Class Initialized
DEBUG - 2017-04-28 09:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:19:04 --> Input Class Initialized
INFO - 2017-04-28 09:19:04 --> Language Class Initialized
INFO - 2017-04-28 09:19:04 --> Loader Class Initialized
INFO - 2017-04-28 09:19:04 --> Helper loaded: url_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: form_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: html_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: custom_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: cache_helper
INFO - 2017-04-28 09:19:04 --> Database Driver Class Initialized
INFO - 2017-04-28 09:19:04 --> Parser Class Initialized
DEBUG - 2017-04-28 09:19:04 --> Session Class Initialized
INFO - 2017-04-28 09:19:04 --> Helper loaded: string_helper
DEBUG - 2017-04-28 09:19:04 --> Session routines successfully run
INFO - 2017-04-28 09:19:04 --> Form Validation Class Initialized
INFO - 2017-04-28 09:19:04 --> Controller Class Initialized
INFO - 2017-04-28 09:19:04 --> Model Class Initialized
INFO - 2017-04-28 09:19:04 --> Config Class Initialized
INFO - 2017-04-28 09:19:04 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:19:04 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:19:04 --> Utf8 Class Initialized
INFO - 2017-04-28 09:19:04 --> URI Class Initialized
INFO - 2017-04-28 09:19:04 --> Router Class Initialized
INFO - 2017-04-28 09:19:04 --> Output Class Initialized
INFO - 2017-04-28 09:19:04 --> Security Class Initialized
DEBUG - 2017-04-28 09:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:19:04 --> Input Class Initialized
INFO - 2017-04-28 09:19:04 --> Language Class Initialized
INFO - 2017-04-28 09:19:04 --> Loader Class Initialized
INFO - 2017-04-28 09:19:04 --> Helper loaded: url_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: form_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: html_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: custom_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: cache_helper
INFO - 2017-04-28 09:19:04 --> Database Driver Class Initialized
INFO - 2017-04-28 09:19:04 --> Parser Class Initialized
DEBUG - 2017-04-28 09:19:04 --> Session Class Initialized
INFO - 2017-04-28 09:19:04 --> Helper loaded: string_helper
DEBUG - 2017-04-28 09:19:04 --> Session routines successfully run
INFO - 2017-04-28 09:19:04 --> Form Validation Class Initialized
INFO - 2017-04-28 09:19:04 --> Controller Class Initialized
INFO - 2017-04-28 09:19:04 --> Model Class Initialized
INFO - 2017-04-28 09:19:04 --> Config Class Initialized
INFO - 2017-04-28 09:19:04 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:19:04 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:19:04 --> Utf8 Class Initialized
INFO - 2017-04-28 09:19:04 --> URI Class Initialized
INFO - 2017-04-28 09:19:04 --> Router Class Initialized
INFO - 2017-04-28 09:19:04 --> Output Class Initialized
INFO - 2017-04-28 09:19:04 --> Security Class Initialized
DEBUG - 2017-04-28 09:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:19:04 --> Input Class Initialized
INFO - 2017-04-28 09:19:04 --> Language Class Initialized
INFO - 2017-04-28 09:19:04 --> Loader Class Initialized
INFO - 2017-04-28 09:19:04 --> Helper loaded: url_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: form_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: html_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: custom_helper
INFO - 2017-04-28 09:19:04 --> Helper loaded: cache_helper
INFO - 2017-04-28 09:19:04 --> Database Driver Class Initialized
INFO - 2017-04-28 09:19:04 --> Parser Class Initialized
DEBUG - 2017-04-28 09:19:04 --> Session Class Initialized
INFO - 2017-04-28 09:19:04 --> Helper loaded: string_helper
DEBUG - 2017-04-28 09:19:04 --> Session routines successfully run
INFO - 2017-04-28 09:19:04 --> Form Validation Class Initialized
INFO - 2017-04-28 09:19:04 --> Controller Class Initialized
DEBUG - 2017-04-28 09:19:04 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 09:19:04 --> Model Class Initialized
DEBUG - 2017-04-28 09:19:05 --> Pagination Class Initialized
INFO - 2017-04-28 09:19:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-28 09:19:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-28 09:19:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/admin/listAdmin.php
INFO - 2017-04-28 09:19:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-28 09:19:05 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-28 09:19:05 --> Final output sent to browser
DEBUG - 2017-04-28 09:19:05 --> Total execution time: 0.3754
INFO - 2017-04-28 09:19:09 --> Config Class Initialized
INFO - 2017-04-28 09:19:09 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:19:09 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:19:09 --> Utf8 Class Initialized
INFO - 2017-04-28 09:19:09 --> URI Class Initialized
INFO - 2017-04-28 09:19:09 --> Router Class Initialized
INFO - 2017-04-28 09:19:09 --> Output Class Initialized
INFO - 2017-04-28 09:19:09 --> Security Class Initialized
DEBUG - 2017-04-28 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:19:09 --> Input Class Initialized
INFO - 2017-04-28 09:19:09 --> Language Class Initialized
INFO - 2017-04-28 09:19:09 --> Loader Class Initialized
INFO - 2017-04-28 09:19:09 --> Helper loaded: url_helper
INFO - 2017-04-28 09:19:09 --> Helper loaded: form_helper
INFO - 2017-04-28 09:19:09 --> Helper loaded: html_helper
INFO - 2017-04-28 09:19:09 --> Helper loaded: custom_helper
INFO - 2017-04-28 09:19:09 --> Helper loaded: cache_helper
INFO - 2017-04-28 09:19:09 --> Database Driver Class Initialized
INFO - 2017-04-28 09:19:09 --> Parser Class Initialized
DEBUG - 2017-04-28 09:19:09 --> Session Class Initialized
INFO - 2017-04-28 09:19:09 --> Helper loaded: string_helper
DEBUG - 2017-04-28 09:19:09 --> Session routines successfully run
INFO - 2017-04-28 09:19:09 --> Form Validation Class Initialized
INFO - 2017-04-28 09:19:09 --> Controller Class Initialized
DEBUG - 2017-04-28 09:19:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 09:19:09 --> Model Class Initialized
DEBUG - 2017-04-28 09:19:09 --> Pagination Class Initialized
INFO - 2017-04-28 09:19:09 --> Config Class Initialized
INFO - 2017-04-28 09:19:09 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:19:09 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:19:09 --> Utf8 Class Initialized
INFO - 2017-04-28 09:19:09 --> URI Class Initialized
INFO - 2017-04-28 09:19:09 --> Router Class Initialized
INFO - 2017-04-28 09:19:09 --> Output Class Initialized
INFO - 2017-04-28 09:19:09 --> Security Class Initialized
DEBUG - 2017-04-28 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:19:09 --> Input Class Initialized
INFO - 2017-04-28 09:19:09 --> Language Class Initialized
INFO - 2017-04-28 09:19:09 --> Loader Class Initialized
INFO - 2017-04-28 09:19:09 --> Helper loaded: url_helper
INFO - 2017-04-28 09:19:09 --> Helper loaded: form_helper
INFO - 2017-04-28 09:19:09 --> Helper loaded: html_helper
INFO - 2017-04-28 09:19:09 --> Helper loaded: custom_helper
INFO - 2017-04-28 09:19:09 --> Helper loaded: cache_helper
INFO - 2017-04-28 09:19:09 --> Database Driver Class Initialized
INFO - 2017-04-28 09:19:09 --> Parser Class Initialized
DEBUG - 2017-04-28 09:19:09 --> Session Class Initialized
INFO - 2017-04-28 09:19:09 --> Helper loaded: string_helper
DEBUG - 2017-04-28 09:19:09 --> Session routines successfully run
INFO - 2017-04-28 09:19:09 --> Form Validation Class Initialized
INFO - 2017-04-28 09:19:09 --> Controller Class Initialized
DEBUG - 2017-04-28 09:19:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 09:19:09 --> Model Class Initialized
DEBUG - 2017-04-28 09:19:09 --> Pagination Class Initialized
INFO - 2017-04-28 09:19:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-28 09:19:09 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-28 09:19:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/company/list_company.php
INFO - 2017-04-28 09:19:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-28 09:19:12 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-28 09:19:12 --> Final output sent to browser
DEBUG - 2017-04-28 09:19:12 --> Total execution time: 3.2029
INFO - 2017-04-28 09:19:55 --> Config Class Initialized
INFO - 2017-04-28 09:19:55 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:19:55 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:19:55 --> Utf8 Class Initialized
INFO - 2017-04-28 09:19:55 --> URI Class Initialized
INFO - 2017-04-28 09:19:55 --> Router Class Initialized
INFO - 2017-04-28 09:19:55 --> Output Class Initialized
INFO - 2017-04-28 09:19:55 --> Security Class Initialized
DEBUG - 2017-04-28 09:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:19:55 --> Input Class Initialized
INFO - 2017-04-28 09:19:55 --> Language Class Initialized
INFO - 2017-04-28 09:19:55 --> Loader Class Initialized
INFO - 2017-04-28 09:19:55 --> Helper loaded: url_helper
INFO - 2017-04-28 09:19:55 --> Helper loaded: form_helper
INFO - 2017-04-28 09:19:55 --> Helper loaded: html_helper
INFO - 2017-04-28 09:19:55 --> Helper loaded: custom_helper
INFO - 2017-04-28 09:19:55 --> Helper loaded: cache_helper
INFO - 2017-04-28 09:19:55 --> Database Driver Class Initialized
INFO - 2017-04-28 09:19:55 --> Parser Class Initialized
DEBUG - 2017-04-28 09:19:55 --> Session Class Initialized
INFO - 2017-04-28 09:19:55 --> Helper loaded: string_helper
DEBUG - 2017-04-28 09:19:55 --> Session routines successfully run
INFO - 2017-04-28 09:19:55 --> Form Validation Class Initialized
INFO - 2017-04-28 09:19:55 --> Controller Class Initialized
DEBUG - 2017-04-28 09:19:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 09:19:55 --> Model Class Initialized
DEBUG - 2017-04-28 09:19:55 --> Pagination Class Initialized
INFO - 2017-04-28 09:19:55 --> Config Class Initialized
INFO - 2017-04-28 09:19:55 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:19:55 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:19:55 --> Utf8 Class Initialized
INFO - 2017-04-28 09:19:55 --> URI Class Initialized
INFO - 2017-04-28 09:19:55 --> Router Class Initialized
INFO - 2017-04-28 09:19:55 --> Output Class Initialized
INFO - 2017-04-28 09:19:55 --> Security Class Initialized
DEBUG - 2017-04-28 09:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:19:55 --> Input Class Initialized
INFO - 2017-04-28 09:19:55 --> Language Class Initialized
INFO - 2017-04-28 09:19:55 --> Loader Class Initialized
INFO - 2017-04-28 09:19:55 --> Helper loaded: url_helper
INFO - 2017-04-28 09:19:55 --> Helper loaded: form_helper
INFO - 2017-04-28 09:19:55 --> Helper loaded: html_helper
INFO - 2017-04-28 09:19:55 --> Helper loaded: custom_helper
INFO - 2017-04-28 09:19:55 --> Helper loaded: cache_helper
INFO - 2017-04-28 09:19:55 --> Database Driver Class Initialized
INFO - 2017-04-28 09:19:55 --> Parser Class Initialized
DEBUG - 2017-04-28 09:19:55 --> Session Class Initialized
INFO - 2017-04-28 09:19:55 --> Helper loaded: string_helper
DEBUG - 2017-04-28 09:19:55 --> Session routines successfully run
INFO - 2017-04-28 09:19:55 --> Form Validation Class Initialized
INFO - 2017-04-28 09:19:55 --> Controller Class Initialized
DEBUG - 2017-04-28 09:19:55 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 09:19:55 --> Model Class Initialized
DEBUG - 2017-04-28 09:19:55 --> Pagination Class Initialized
INFO - 2017-04-28 09:19:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-28 09:19:55 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-28 09:19:55 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:55 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:55 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:55 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:55 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:56 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:58 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:19:59 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:19:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:19:59 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:19:59 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:19:59 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:20:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:20:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:20:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:20:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:20:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:20:00 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:20:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:20:00 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:20:00 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:20:00 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-04-28 09:20:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-04-28 09:20:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-28 09:20:01 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-28 09:20:01 --> Final output sent to browser
DEBUG - 2017-04-28 09:20:01 --> Total execution time: 5.7513
INFO - 2017-04-28 09:20:08 --> Config Class Initialized
INFO - 2017-04-28 09:20:08 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:20:08 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:20:08 --> Utf8 Class Initialized
INFO - 2017-04-28 09:20:08 --> URI Class Initialized
INFO - 2017-04-28 09:20:08 --> Router Class Initialized
INFO - 2017-04-28 09:20:08 --> Output Class Initialized
INFO - 2017-04-28 09:20:08 --> Security Class Initialized
DEBUG - 2017-04-28 09:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:20:08 --> Input Class Initialized
INFO - 2017-04-28 09:20:08 --> Language Class Initialized
INFO - 2017-04-28 09:20:08 --> Loader Class Initialized
INFO - 2017-04-28 09:20:08 --> Helper loaded: url_helper
INFO - 2017-04-28 09:20:08 --> Helper loaded: form_helper
INFO - 2017-04-28 09:20:08 --> Helper loaded: html_helper
INFO - 2017-04-28 09:20:08 --> Helper loaded: custom_helper
INFO - 2017-04-28 09:20:08 --> Helper loaded: cache_helper
INFO - 2017-04-28 09:20:08 --> Database Driver Class Initialized
INFO - 2017-04-28 09:20:08 --> Parser Class Initialized
DEBUG - 2017-04-28 09:20:08 --> Session Class Initialized
INFO - 2017-04-28 09:20:08 --> Helper loaded: string_helper
DEBUG - 2017-04-28 09:20:08 --> Session routines successfully run
INFO - 2017-04-28 09:20:08 --> Form Validation Class Initialized
INFO - 2017-04-28 09:20:08 --> Controller Class Initialized
DEBUG - 2017-04-28 09:20:08 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 09:20:08 --> Model Class Initialized
DEBUG - 2017-04-28 09:20:08 --> Pagination Class Initialized
DEBUG - 2017-04-28 09:20:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-04-28 09:20:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-28 09:20:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-28 09:20:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-04-28 09:20:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-28 09:20:08 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-28 09:20:08 --> Final output sent to browser
DEBUG - 2017-04-28 09:20:08 --> Total execution time: 0.2624
INFO - 2017-04-28 09:20:08 --> Config Class Initialized
INFO - 2017-04-28 09:20:08 --> Config Class Initialized
INFO - 2017-04-28 09:20:08 --> Hooks Class Initialized
INFO - 2017-04-28 09:20:08 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:20:08 --> UTF-8 Support Enabled
DEBUG - 2017-04-28 09:20:08 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:20:08 --> Utf8 Class Initialized
INFO - 2017-04-28 09:20:08 --> Utf8 Class Initialized
INFO - 2017-04-28 09:20:08 --> URI Class Initialized
INFO - 2017-04-28 09:20:08 --> Router Class Initialized
INFO - 2017-04-28 09:20:08 --> URI Class Initialized
INFO - 2017-04-28 09:20:08 --> Output Class Initialized
INFO - 2017-04-28 09:20:08 --> Router Class Initialized
INFO - 2017-04-28 09:20:08 --> Security Class Initialized
INFO - 2017-04-28 09:20:08 --> Output Class Initialized
DEBUG - 2017-04-28 09:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:20:08 --> Security Class Initialized
INFO - 2017-04-28 09:20:08 --> Input Class Initialized
INFO - 2017-04-28 09:20:08 --> Language Class Initialized
DEBUG - 2017-04-28 09:20:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-04-28 09:20:08 --> 404 Page Not Found: Default/assets
INFO - 2017-04-28 09:20:08 --> Input Class Initialized
INFO - 2017-04-28 09:20:08 --> Language Class Initialized
ERROR - 2017-04-28 09:20:08 --> 404 Page Not Found: Default/assets
INFO - 2017-04-28 09:20:08 --> Config Class Initialized
INFO - 2017-04-28 09:20:08 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:20:08 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:20:08 --> Utf8 Class Initialized
INFO - 2017-04-28 09:20:08 --> URI Class Initialized
INFO - 2017-04-28 09:20:08 --> Router Class Initialized
INFO - 2017-04-28 09:20:08 --> Output Class Initialized
INFO - 2017-04-28 09:20:08 --> Security Class Initialized
DEBUG - 2017-04-28 09:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:20:08 --> Input Class Initialized
INFO - 2017-04-28 09:20:09 --> Language Class Initialized
ERROR - 2017-04-28 09:20:09 --> 404 Page Not Found: Default/assets
INFO - 2017-04-28 09:20:09 --> Config Class Initialized
INFO - 2017-04-28 09:20:09 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:20:09 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:20:09 --> Utf8 Class Initialized
INFO - 2017-04-28 09:20:09 --> URI Class Initialized
INFO - 2017-04-28 09:20:09 --> Router Class Initialized
INFO - 2017-04-28 09:20:09 --> Output Class Initialized
INFO - 2017-04-28 09:20:09 --> Security Class Initialized
DEBUG - 2017-04-28 09:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:20:09 --> Input Class Initialized
INFO - 2017-04-28 09:20:09 --> Language Class Initialized
ERROR - 2017-04-28 09:20:09 --> 404 Page Not Found: Default/assets
INFO - 2017-04-28 09:20:09 --> Config Class Initialized
INFO - 2017-04-28 09:20:09 --> Hooks Class Initialized
DEBUG - 2017-04-28 09:20:09 --> UTF-8 Support Enabled
INFO - 2017-04-28 09:20:09 --> Utf8 Class Initialized
INFO - 2017-04-28 09:20:09 --> URI Class Initialized
INFO - 2017-04-28 09:20:09 --> Router Class Initialized
INFO - 2017-04-28 09:20:09 --> Output Class Initialized
INFO - 2017-04-28 09:20:09 --> Security Class Initialized
DEBUG - 2017-04-28 09:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 09:20:09 --> Input Class Initialized
INFO - 2017-04-28 09:20:09 --> Language Class Initialized
INFO - 2017-04-28 09:20:09 --> Loader Class Initialized
INFO - 2017-04-28 09:20:09 --> Helper loaded: url_helper
INFO - 2017-04-28 09:20:09 --> Helper loaded: form_helper
INFO - 2017-04-28 09:20:09 --> Helper loaded: html_helper
INFO - 2017-04-28 09:20:09 --> Helper loaded: custom_helper
INFO - 2017-04-28 09:20:09 --> Helper loaded: cache_helper
INFO - 2017-04-28 09:20:09 --> Database Driver Class Initialized
INFO - 2017-04-28 09:20:09 --> Parser Class Initialized
DEBUG - 2017-04-28 09:20:09 --> Session Class Initialized
INFO - 2017-04-28 09:20:09 --> Helper loaded: string_helper
DEBUG - 2017-04-28 09:20:09 --> Session routines successfully run
INFO - 2017-04-28 09:20:09 --> Form Validation Class Initialized
INFO - 2017-04-28 09:20:09 --> Controller Class Initialized
DEBUG - 2017-04-28 09:20:09 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 09:20:09 --> Model Class Initialized
DEBUG - 2017-04-28 09:20:09 --> Pagination Class Initialized
ERROR - 2017-04-28 09:20:09 --> Severity: Warning --> Missing argument 1 for User::get_staff() C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 907
ERROR - 2017-04-28 09:20:09 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\schedullo\application\admin\controllers\User.php 910
INFO - 2017-04-28 09:20:09 --> Final output sent to browser
DEBUG - 2017-04-28 09:20:09 --> Total execution time: 0.2072
INFO - 2017-04-28 10:29:13 --> Config Class Initialized
INFO - 2017-04-28 10:29:13 --> Hooks Class Initialized
DEBUG - 2017-04-28 10:29:13 --> UTF-8 Support Enabled
INFO - 2017-04-28 10:29:13 --> Utf8 Class Initialized
INFO - 2017-04-28 10:29:13 --> URI Class Initialized
INFO - 2017-04-28 10:29:13 --> Router Class Initialized
INFO - 2017-04-28 10:29:13 --> Output Class Initialized
INFO - 2017-04-28 10:29:13 --> Security Class Initialized
DEBUG - 2017-04-28 10:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 10:29:13 --> Input Class Initialized
INFO - 2017-04-28 10:29:13 --> Language Class Initialized
INFO - 2017-04-28 10:29:13 --> Loader Class Initialized
INFO - 2017-04-28 10:29:13 --> Helper loaded: url_helper
INFO - 2017-04-28 10:29:13 --> Helper loaded: form_helper
INFO - 2017-04-28 10:29:13 --> Helper loaded: html_helper
INFO - 2017-04-28 10:29:13 --> Helper loaded: custom_helper
INFO - 2017-04-28 10:29:13 --> Helper loaded: cache_helper
INFO - 2017-04-28 10:29:13 --> Database Driver Class Initialized
INFO - 2017-04-28 10:29:13 --> Parser Class Initialized
DEBUG - 2017-04-28 10:29:13 --> Session Class Initialized
INFO - 2017-04-28 10:29:13 --> Helper loaded: string_helper
DEBUG - 2017-04-28 10:29:13 --> Session routines successfully run
INFO - 2017-04-28 10:29:13 --> Form Validation Class Initialized
INFO - 2017-04-28 10:29:13 --> Controller Class Initialized
DEBUG - 2017-04-28 10:29:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 10:29:13 --> Model Class Initialized
DEBUG - 2017-04-28 10:29:13 --> Pagination Class Initialized
INFO - 2017-04-28 10:29:13 --> Config Class Initialized
INFO - 2017-04-28 10:29:13 --> Hooks Class Initialized
DEBUG - 2017-04-28 10:29:13 --> UTF-8 Support Enabled
INFO - 2017-04-28 10:29:13 --> Utf8 Class Initialized
INFO - 2017-04-28 10:29:13 --> URI Class Initialized
INFO - 2017-04-28 10:29:13 --> Router Class Initialized
INFO - 2017-04-28 10:29:13 --> Output Class Initialized
INFO - 2017-04-28 10:29:13 --> Security Class Initialized
DEBUG - 2017-04-28 10:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 10:29:13 --> Input Class Initialized
INFO - 2017-04-28 10:29:13 --> Language Class Initialized
INFO - 2017-04-28 10:29:13 --> Loader Class Initialized
INFO - 2017-04-28 10:29:13 --> Helper loaded: url_helper
INFO - 2017-04-28 10:29:13 --> Helper loaded: form_helper
INFO - 2017-04-28 10:29:13 --> Helper loaded: html_helper
INFO - 2017-04-28 10:29:13 --> Helper loaded: custom_helper
INFO - 2017-04-28 10:29:13 --> Helper loaded: cache_helper
INFO - 2017-04-28 10:29:13 --> Database Driver Class Initialized
INFO - 2017-04-28 10:29:13 --> Parser Class Initialized
DEBUG - 2017-04-28 10:29:13 --> Session Class Initialized
INFO - 2017-04-28 10:29:13 --> Helper loaded: string_helper
DEBUG - 2017-04-28 10:29:13 --> Session routines successfully run
INFO - 2017-04-28 10:29:13 --> Form Validation Class Initialized
INFO - 2017-04-28 10:29:13 --> Controller Class Initialized
DEBUG - 2017-04-28 10:29:13 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 10:29:13 --> Model Class Initialized
DEBUG - 2017-04-28 10:29:13 --> Pagination Class Initialized
INFO - 2017-04-28 10:29:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-28 10:29:13 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
ERROR - 2017-04-28 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:14 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:15 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:16 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:17 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:17 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:17 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:17 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:17 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:21 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:22 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:22 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:22 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:22 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:22 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
ERROR - 2017-04-28 10:29:22 --> Severity: Notice --> Undefined property: stdClass::$user_type C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 299
ERROR - 2017-04-28 10:29:22 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 304
ERROR - 2017-04-28 10:29:22 --> Severity: Notice --> Undefined property: stdClass::$city C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 305
ERROR - 2017-04-28 10:29:22 --> Severity: Notice --> Undefined property: stdClass::$state C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 306
ERROR - 2017-04-28 10:29:22 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\schedullo\application\admin\views\default\layout\user\list_user.php 307
INFO - 2017-04-28 10:29:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/list_user.php
INFO - 2017-04-28 10:29:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-28 10:29:22 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-28 10:29:22 --> Final output sent to browser
DEBUG - 2017-04-28 10:29:22 --> Total execution time: 9.3723
INFO - 2017-04-28 10:29:35 --> Config Class Initialized
INFO - 2017-04-28 10:29:35 --> Hooks Class Initialized
DEBUG - 2017-04-28 10:29:35 --> UTF-8 Support Enabled
INFO - 2017-04-28 10:29:35 --> Utf8 Class Initialized
INFO - 2017-04-28 10:29:35 --> URI Class Initialized
INFO - 2017-04-28 10:29:35 --> Router Class Initialized
INFO - 2017-04-28 10:29:35 --> Output Class Initialized
INFO - 2017-04-28 10:29:35 --> Security Class Initialized
DEBUG - 2017-04-28 10:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 10:29:35 --> Input Class Initialized
INFO - 2017-04-28 10:29:35 --> Language Class Initialized
INFO - 2017-04-28 10:29:35 --> Loader Class Initialized
INFO - 2017-04-28 10:29:35 --> Helper loaded: url_helper
INFO - 2017-04-28 10:29:35 --> Helper loaded: form_helper
INFO - 2017-04-28 10:29:35 --> Helper loaded: html_helper
INFO - 2017-04-28 10:29:35 --> Helper loaded: custom_helper
INFO - 2017-04-28 10:29:35 --> Helper loaded: cache_helper
INFO - 2017-04-28 10:29:35 --> Database Driver Class Initialized
INFO - 2017-04-28 10:29:35 --> Parser Class Initialized
DEBUG - 2017-04-28 10:29:35 --> Session Class Initialized
INFO - 2017-04-28 10:29:35 --> Helper loaded: string_helper
DEBUG - 2017-04-28 10:29:35 --> Session routines successfully run
INFO - 2017-04-28 10:29:35 --> Form Validation Class Initialized
INFO - 2017-04-28 10:29:35 --> Controller Class Initialized
DEBUG - 2017-04-28 10:29:35 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 10:29:35 --> Model Class Initialized
DEBUG - 2017-04-28 10:29:35 --> Pagination Class Initialized
INFO - 2017-04-28 10:29:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/header.php
INFO - 2017-04-28 10:29:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/sidebar.php
INFO - 2017-04-28 10:29:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/user/add_user.php
INFO - 2017-04-28 10:29:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/footer.php
INFO - 2017-04-28 10:29:35 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-28 10:29:35 --> Final output sent to browser
DEBUG - 2017-04-28 10:29:35 --> Total execution time: 0.2517
INFO - 2017-04-28 10:29:36 --> Config Class Initialized
INFO - 2017-04-28 10:29:36 --> Hooks Class Initialized
INFO - 2017-04-28 10:29:36 --> Config Class Initialized
INFO - 2017-04-28 10:29:36 --> Hooks Class Initialized
DEBUG - 2017-04-28 10:29:36 --> UTF-8 Support Enabled
INFO - 2017-04-28 10:29:36 --> Utf8 Class Initialized
DEBUG - 2017-04-28 10:29:36 --> UTF-8 Support Enabled
INFO - 2017-04-28 10:29:36 --> Utf8 Class Initialized
INFO - 2017-04-28 10:29:36 --> URI Class Initialized
INFO - 2017-04-28 10:29:36 --> URI Class Initialized
INFO - 2017-04-28 10:29:36 --> Router Class Initialized
INFO - 2017-04-28 10:29:36 --> Router Class Initialized
INFO - 2017-04-28 10:29:36 --> Output Class Initialized
INFO - 2017-04-28 10:29:36 --> Output Class Initialized
INFO - 2017-04-28 10:29:36 --> Security Class Initialized
INFO - 2017-04-28 10:29:36 --> Security Class Initialized
DEBUG - 2017-04-28 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 10:29:36 --> Input Class Initialized
DEBUG - 2017-04-28 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 10:29:36 --> Input Class Initialized
INFO - 2017-04-28 10:29:36 --> Language Class Initialized
INFO - 2017-04-28 10:29:36 --> Language Class Initialized
ERROR - 2017-04-28 10:29:36 --> 404 Page Not Found: Default/assets
ERROR - 2017-04-28 10:29:36 --> 404 Page Not Found: Default/assets
INFO - 2017-04-28 10:29:36 --> Config Class Initialized
INFO - 2017-04-28 10:29:36 --> Hooks Class Initialized
DEBUG - 2017-04-28 10:29:36 --> UTF-8 Support Enabled
INFO - 2017-04-28 10:29:36 --> Utf8 Class Initialized
INFO - 2017-04-28 10:29:36 --> URI Class Initialized
INFO - 2017-04-28 10:29:36 --> Router Class Initialized
INFO - 2017-04-28 10:29:36 --> Output Class Initialized
INFO - 2017-04-28 10:29:36 --> Security Class Initialized
DEBUG - 2017-04-28 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 10:29:36 --> Input Class Initialized
INFO - 2017-04-28 10:29:36 --> Language Class Initialized
ERROR - 2017-04-28 10:29:36 --> 404 Page Not Found: Default/assets
INFO - 2017-04-28 10:29:36 --> Config Class Initialized
INFO - 2017-04-28 10:29:36 --> Hooks Class Initialized
DEBUG - 2017-04-28 10:29:36 --> UTF-8 Support Enabled
INFO - 2017-04-28 10:29:36 --> Utf8 Class Initialized
INFO - 2017-04-28 10:29:36 --> URI Class Initialized
INFO - 2017-04-28 10:29:36 --> Router Class Initialized
INFO - 2017-04-28 10:29:36 --> Output Class Initialized
INFO - 2017-04-28 10:29:36 --> Security Class Initialized
DEBUG - 2017-04-28 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 10:29:36 --> Input Class Initialized
INFO - 2017-04-28 10:29:36 --> Language Class Initialized
ERROR - 2017-04-28 10:29:36 --> 404 Page Not Found: Default/assets
INFO - 2017-04-28 10:29:36 --> Config Class Initialized
INFO - 2017-04-28 10:29:36 --> Hooks Class Initialized
DEBUG - 2017-04-28 10:29:36 --> UTF-8 Support Enabled
INFO - 2017-04-28 10:29:36 --> Utf8 Class Initialized
INFO - 2017-04-28 10:29:36 --> URI Class Initialized
INFO - 2017-04-28 10:29:36 --> Router Class Initialized
INFO - 2017-04-28 10:29:36 --> Output Class Initialized
INFO - 2017-04-28 10:29:36 --> Security Class Initialized
DEBUG - 2017-04-28 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 10:29:36 --> Input Class Initialized
INFO - 2017-04-28 10:29:36 --> Language Class Initialized
INFO - 2017-04-28 10:29:36 --> Loader Class Initialized
INFO - 2017-04-28 10:29:36 --> Helper loaded: url_helper
INFO - 2017-04-28 10:29:36 --> Helper loaded: form_helper
INFO - 2017-04-28 10:29:36 --> Helper loaded: html_helper
INFO - 2017-04-28 10:29:36 --> Helper loaded: custom_helper
INFO - 2017-04-28 10:29:36 --> Helper loaded: cache_helper
INFO - 2017-04-28 10:29:36 --> Database Driver Class Initialized
INFO - 2017-04-28 10:29:36 --> Parser Class Initialized
DEBUG - 2017-04-28 10:29:36 --> Session Class Initialized
INFO - 2017-04-28 10:29:36 --> Helper loaded: string_helper
DEBUG - 2017-04-28 10:29:36 --> Session routines successfully run
INFO - 2017-04-28 10:29:36 --> Form Validation Class Initialized
INFO - 2017-04-28 10:29:36 --> Controller Class Initialized
DEBUG - 2017-04-28 10:29:36 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 10:29:36 --> Model Class Initialized
DEBUG - 2017-04-28 10:29:36 --> Pagination Class Initialized
INFO - 2017-04-28 10:29:36 --> Final output sent to browser
DEBUG - 2017-04-28 10:29:36 --> Total execution time: 0.1772
INFO - 2017-04-28 10:39:10 --> Config Class Initialized
INFO - 2017-04-28 10:39:10 --> Hooks Class Initialized
DEBUG - 2017-04-28 10:39:10 --> UTF-8 Support Enabled
INFO - 2017-04-28 10:39:10 --> Utf8 Class Initialized
INFO - 2017-04-28 10:39:10 --> URI Class Initialized
DEBUG - 2017-04-28 10:39:10 --> No URI present. Default controller set.
INFO - 2017-04-28 10:39:10 --> Router Class Initialized
INFO - 2017-04-28 10:39:10 --> Output Class Initialized
INFO - 2017-04-28 10:39:10 --> Security Class Initialized
DEBUG - 2017-04-28 10:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 10:39:10 --> Input Class Initialized
INFO - 2017-04-28 10:39:10 --> Language Class Initialized
INFO - 2017-04-28 10:39:10 --> Loader Class Initialized
INFO - 2017-04-28 10:39:10 --> Helper loaded: url_helper
INFO - 2017-04-28 10:39:10 --> Helper loaded: form_helper
INFO - 2017-04-28 10:39:10 --> Helper loaded: html_helper
INFO - 2017-04-28 10:39:10 --> Helper loaded: custom_helper
INFO - 2017-04-28 10:39:10 --> Helper loaded: cache_helper
INFO - 2017-04-28 10:39:10 --> Database Driver Class Initialized
INFO - 2017-04-28 10:39:10 --> Parser Class Initialized
DEBUG - 2017-04-28 10:39:10 --> Session Class Initialized
INFO - 2017-04-28 10:39:10 --> Helper loaded: string_helper
ERROR - 2017-04-28 10:39:10 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-28 10:39:10 --> Session routines successfully run
INFO - 2017-04-28 10:39:10 --> Form Validation Class Initialized
INFO - 2017-04-28 10:39:10 --> Controller Class Initialized
INFO - 2017-04-28 10:39:10 --> Model Class Initialized
INFO - 2017-04-28 10:39:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-28 10:39:10 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-28 10:39:10 --> Final output sent to browser
DEBUG - 2017-04-28 10:39:10 --> Total execution time: 0.2151
INFO - 2017-04-28 10:39:11 --> Config Class Initialized
INFO - 2017-04-28 10:39:11 --> Hooks Class Initialized
DEBUG - 2017-04-28 10:39:11 --> UTF-8 Support Enabled
INFO - 2017-04-28 10:39:11 --> Utf8 Class Initialized
INFO - 2017-04-28 10:39:11 --> URI Class Initialized
INFO - 2017-04-28 10:39:11 --> Router Class Initialized
INFO - 2017-04-28 10:39:11 --> Output Class Initialized
INFO - 2017-04-28 10:39:11 --> Security Class Initialized
DEBUG - 2017-04-28 10:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 10:39:11 --> Input Class Initialized
INFO - 2017-04-28 10:39:11 --> Language Class Initialized
INFO - 2017-04-28 10:39:11 --> Loader Class Initialized
INFO - 2017-04-28 10:39:11 --> Helper loaded: url_helper
INFO - 2017-04-28 10:39:11 --> Helper loaded: form_helper
INFO - 2017-04-28 10:39:11 --> Helper loaded: html_helper
INFO - 2017-04-28 10:39:11 --> Helper loaded: custom_helper
INFO - 2017-04-28 10:39:11 --> Helper loaded: cache_helper
INFO - 2017-04-28 10:39:11 --> Database Driver Class Initialized
INFO - 2017-04-28 10:39:11 --> Parser Class Initialized
DEBUG - 2017-04-28 10:39:11 --> Session Class Initialized
INFO - 2017-04-28 10:39:11 --> Helper loaded: string_helper
ERROR - 2017-04-28 10:39:11 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-28 10:39:11 --> Session routines successfully run
INFO - 2017-04-28 10:39:11 --> Form Validation Class Initialized
INFO - 2017-04-28 10:39:11 --> Controller Class Initialized
DEBUG - 2017-04-28 10:39:11 --> Config file loaded: ../application/admin/config/s3.php
INFO - 2017-04-28 10:39:11 --> Model Class Initialized
DEBUG - 2017-04-28 10:39:11 --> Pagination Class Initialized
INFO - 2017-04-28 10:39:11 --> Config Class Initialized
INFO - 2017-04-28 10:39:11 --> Hooks Class Initialized
DEBUG - 2017-04-28 10:39:11 --> UTF-8 Support Enabled
INFO - 2017-04-28 10:39:11 --> Utf8 Class Initialized
INFO - 2017-04-28 10:39:11 --> URI Class Initialized
INFO - 2017-04-28 10:39:11 --> Router Class Initialized
INFO - 2017-04-28 10:39:11 --> Output Class Initialized
INFO - 2017-04-28 10:39:11 --> Security Class Initialized
DEBUG - 2017-04-28 10:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 10:39:11 --> Input Class Initialized
INFO - 2017-04-28 10:39:11 --> Language Class Initialized
INFO - 2017-04-28 10:39:11 --> Loader Class Initialized
INFO - 2017-04-28 10:39:11 --> Helper loaded: url_helper
INFO - 2017-04-28 10:39:11 --> Helper loaded: form_helper
INFO - 2017-04-28 10:39:11 --> Helper loaded: html_helper
INFO - 2017-04-28 10:39:11 --> Helper loaded: custom_helper
INFO - 2017-04-28 10:39:11 --> Helper loaded: cache_helper
INFO - 2017-04-28 10:39:11 --> Database Driver Class Initialized
INFO - 2017-04-28 10:39:11 --> Parser Class Initialized
DEBUG - 2017-04-28 10:39:11 --> Session Class Initialized
INFO - 2017-04-28 10:39:11 --> Helper loaded: string_helper
ERROR - 2017-04-28 10:39:11 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-28 10:39:11 --> Session routines successfully run
INFO - 2017-04-28 10:39:11 --> Form Validation Class Initialized
INFO - 2017-04-28 10:39:11 --> Controller Class Initialized
INFO - 2017-04-28 10:39:11 --> Model Class Initialized
INFO - 2017-04-28 10:39:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-28 10:39:11 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-28 10:39:11 --> Final output sent to browser
DEBUG - 2017-04-28 10:39:11 --> Total execution time: 0.2316
INFO - 2017-04-28 12:52:42 --> Config Class Initialized
INFO - 2017-04-28 12:52:42 --> Hooks Class Initialized
DEBUG - 2017-04-28 12:52:42 --> UTF-8 Support Enabled
INFO - 2017-04-28 12:52:42 --> Utf8 Class Initialized
INFO - 2017-04-28 12:52:42 --> URI Class Initialized
INFO - 2017-04-28 12:52:42 --> Router Class Initialized
INFO - 2017-04-28 12:52:42 --> Output Class Initialized
INFO - 2017-04-28 12:52:42 --> Security Class Initialized
DEBUG - 2017-04-28 12:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 12:52:42 --> Input Class Initialized
INFO - 2017-04-28 12:52:42 --> Language Class Initialized
INFO - 2017-04-28 12:52:42 --> Loader Class Initialized
INFO - 2017-04-28 12:52:42 --> Helper loaded: url_helper
INFO - 2017-04-28 12:52:42 --> Helper loaded: form_helper
INFO - 2017-04-28 12:52:42 --> Helper loaded: html_helper
INFO - 2017-04-28 12:52:42 --> Helper loaded: custom_helper
INFO - 2017-04-28 12:52:42 --> Helper loaded: cache_helper
INFO - 2017-04-28 12:52:42 --> Database Driver Class Initialized
INFO - 2017-04-28 12:52:42 --> Parser Class Initialized
DEBUG - 2017-04-28 12:52:42 --> Session Class Initialized
INFO - 2017-04-28 12:52:42 --> Helper loaded: string_helper
ERROR - 2017-04-28 12:52:42 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-28 12:52:42 --> Session routines successfully run
INFO - 2017-04-28 12:52:42 --> Form Validation Class Initialized
INFO - 2017-04-28 12:52:42 --> Controller Class Initialized
INFO - 2017-04-28 12:52:42 --> Model Class Initialized
INFO - 2017-04-28 12:52:42 --> Config Class Initialized
INFO - 2017-04-28 12:52:42 --> Hooks Class Initialized
DEBUG - 2017-04-28 12:52:42 --> UTF-8 Support Enabled
INFO - 2017-04-28 12:52:42 --> Utf8 Class Initialized
INFO - 2017-04-28 12:52:42 --> URI Class Initialized
INFO - 2017-04-28 12:52:42 --> Router Class Initialized
INFO - 2017-04-28 12:52:42 --> Output Class Initialized
INFO - 2017-04-28 12:52:42 --> Security Class Initialized
DEBUG - 2017-04-28 12:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 12:52:42 --> Input Class Initialized
INFO - 2017-04-28 12:52:42 --> Language Class Initialized
INFO - 2017-04-28 12:52:42 --> Loader Class Initialized
INFO - 2017-04-28 12:52:42 --> Helper loaded: url_helper
INFO - 2017-04-28 12:52:42 --> Helper loaded: form_helper
INFO - 2017-04-28 12:52:42 --> Helper loaded: html_helper
INFO - 2017-04-28 12:52:42 --> Helper loaded: custom_helper
INFO - 2017-04-28 12:52:42 --> Helper loaded: cache_helper
INFO - 2017-04-28 12:52:42 --> Database Driver Class Initialized
INFO - 2017-04-28 12:52:42 --> Parser Class Initialized
DEBUG - 2017-04-28 12:52:42 --> Session Class Initialized
INFO - 2017-04-28 12:52:42 --> Helper loaded: string_helper
ERROR - 2017-04-28 12:52:43 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-28 12:52:43 --> Session routines successfully run
INFO - 2017-04-28 12:52:43 --> Form Validation Class Initialized
INFO - 2017-04-28 12:52:43 --> Controller Class Initialized
INFO - 2017-04-28 12:52:43 --> Model Class Initialized
INFO - 2017-04-28 12:52:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-28 12:52:43 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-28 12:52:43 --> Final output sent to browser
DEBUG - 2017-04-28 12:52:43 --> Total execution time: 0.5943
INFO - 2017-04-28 15:29:13 --> Config Class Initialized
INFO - 2017-04-28 15:29:13 --> Hooks Class Initialized
DEBUG - 2017-04-28 15:29:13 --> UTF-8 Support Enabled
INFO - 2017-04-28 15:29:13 --> Utf8 Class Initialized
INFO - 2017-04-28 15:29:13 --> URI Class Initialized
INFO - 2017-04-28 15:29:13 --> Router Class Initialized
INFO - 2017-04-28 15:29:13 --> Output Class Initialized
INFO - 2017-04-28 15:29:13 --> Security Class Initialized
DEBUG - 2017-04-28 15:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-28 15:29:13 --> Input Class Initialized
INFO - 2017-04-28 15:29:13 --> Language Class Initialized
INFO - 2017-04-28 15:29:13 --> Loader Class Initialized
INFO - 2017-04-28 15:29:13 --> Helper loaded: url_helper
INFO - 2017-04-28 15:29:13 --> Helper loaded: form_helper
INFO - 2017-04-28 15:29:13 --> Helper loaded: html_helper
INFO - 2017-04-28 15:29:13 --> Helper loaded: custom_helper
INFO - 2017-04-28 15:29:13 --> Helper loaded: cache_helper
INFO - 2017-04-28 15:29:14 --> Database Driver Class Initialized
INFO - 2017-04-28 15:29:14 --> Parser Class Initialized
DEBUG - 2017-04-28 15:29:14 --> Session Class Initialized
INFO - 2017-04-28 15:29:14 --> Helper loaded: string_helper
ERROR - 2017-04-28 15:29:14 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2017-04-28 15:29:14 --> Session routines successfully run
INFO - 2017-04-28 15:29:14 --> Form Validation Class Initialized
INFO - 2017-04-28 15:29:14 --> Controller Class Initialized
INFO - 2017-04-28 15:29:14 --> Model Class Initialized
INFO - 2017-04-28 15:29:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/layout/common/login.php
INFO - 2017-04-28 15:29:14 --> File loaded: C:\xampp\htdocs\schedullo\admin\../application/admin/views/default/template.php
INFO - 2017-04-28 15:29:14 --> Final output sent to browser
DEBUG - 2017-04-28 15:29:14 --> Total execution time: 1.1236
