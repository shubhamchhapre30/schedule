<?php
	//$fbs = facebook_setting();


	//echo  $fbs->facebook_api_key;  
	//echo  $fbs->facebook_secret_key;

	//$config['facebook_api_key'] = $fbs->facebook_api_key;
	//$config['facebook_secret_key'] = $fbs->facebook_secret_key;
	
	
	$config['facebook_api_key'] = '428176620608507';
	$config['facebook_secret_key'] = '34007214152b3645b8d37732f931969c';
	
?>