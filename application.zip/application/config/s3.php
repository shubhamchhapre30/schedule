<?php
/*
| -------------------------------------------------------------------
| Amazon S3 Configuration
| -------------------------------------------------------------------
*/

$config["accessKey"] = "AKIAIKLUOLUR4CJ4WSTA";
$config["secretKey"] = "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";
$config["s3_display_url"] = "https://s3-ap-southeast-2.amazonaws.com/static.schedullo.com/";
$config["bucket_name"] = "static.schedullo.com";
$config["useSSL"] = TRUE;
