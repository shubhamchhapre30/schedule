<?php


$config['APP_ID'] = '428176620608507';
	$config['APP_SECRET'] = '34007214152b3645b8d37732f931969c';
?>
