<?php
$payment_setting = payment_setting();

	$config['API_key'] = $payment_setting->API_key;
	$config['subdomain'] = $payment_setting->subdomain;
	$config['API_key_pass'] = 'x';
        $config['addon_subscription_id'] = '373187';
	
?>