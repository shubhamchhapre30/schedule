<?php


$twe=twitter_setting();






	$config['tweet_consumer_key'] = $twe->consumer_key;
	$config['tweet_consumer_secret'] = $twe->consumer_secret;


	//$config['tweet_consumer_key'] = "TgeQNnvHfOB5f3OY8R5wIg";
	///$config['tweet_consumer_secret'] = "mTdMQMZmCsBu5eVXrldYuLlmWS9wT6f3oxsbZGFs";


?>