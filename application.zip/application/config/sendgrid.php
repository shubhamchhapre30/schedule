<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$config['sendgrid_api_key'] = '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';
$config['sendgrid_api_url'] = 'https://api.sendgrid.com/';
$config['sendgrid_welcome_template_id'] = '05a1149a-e438-4632-9cdf-d81592fd43ef';
$config['sendgrid_daily_summary_template_id'] = 'ee2b68ca-8fce-4a88-b98a-63019092d3e8';
$config['sendgrid_schedullo_from']='info@schedullo.com';
$config['sendgrid_schedullo_from_name']='Schedullo';

