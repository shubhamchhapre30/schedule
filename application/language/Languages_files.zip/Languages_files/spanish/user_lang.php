<?php
	
	//$lang['user.first_name'] = 'Dalalma';
	
	//==========Client Profile PAge======================
	$lang['user.client_profile_title'] = 'Tus Datos De Contacto';
	//==========End of Client Profile PAge======================
	
	//==========Client Address PAge======================
	$lang['user.client_address_title'] = 'TU DIRECCIÓN DE ENTREGA';
	//==========End of Client Address PAge======================
	
	//==========Client Dashboard Tab menu======================
	$lang['user.client_dashboard_orders'] = 'Tus Pedidos';
	$lang['user.client_dashboard_data'] = ' Tus Datos';
	$lang['user.client_dashboard_address'] = 'Tu Direccíon';
	$lang['user.client_dashboard_profile'] = 'Tu Perfil';
	$lang['user.client_dashboard_feedinghabits'] = 'Tus Hábitos Alimenticios';
	$lang['user.client_dashboard_buy'] = 'Comprar';
	//==========End of Client Dashboard Tab menu======================
		
	//===============Client Calendar page=====================================
	$lang['user.order_title'] = 'TUS PEDIDOS';
	//===============End of Client Calendar page=====================================
	
	//===============Feed Back page=====================================
	$lang['user.client_feedback'] = 'Feedback';
	$lang['user.client_feedback_title'] = 'NOS GUSTA TU FEEDBACK';
	$lang['user.client_feedback_text'] = 'Ayúdanos a mejorar el servicio';
	$lang['user.client_feedback_foodquality'] = '¿Cómo evalúas la calidad de la comida?';
	$lang['user.client_feedback_price'] = '¿Y la calidad precio?';
	$lang['user.client_feedback_servicedelivery'] = '¿Cómo evalúas el servicio de entrega?';
	$lang['user.client_feedback_recommend'] = '¿Cuánto nos recomendarías a un amigo?';
	$lang['user.client_feedback_where_knowus'] = '¿Dónde nos conociste?';
	$lang['user.client_feedback_recommendation_friend'] = 'Recomendación de un amigo';	
	$lang['user.client_feedback_traves_labour'] = 'A Traves del Trabajo';	
	$lang['user.client_feedback_menu'] = 'Algún feedback en particular sobre el menú que contrataste';
	$lang['user.client_feedback_suggestion'] = ' Déjanos saber cualquier comentario, sugerencia o quejas que tu tengas';	
	$lang['user.client_contact'] = 'Contacta Con Nosotros';
	
	$lang['user.Liamanos_the_number'] = 'Llámanos al numero';
	$lang['user.EMAIL'] = 'Correo electrónico';
	$lang['user.Write_to'] = 'Escribenos a';
	
	
	$lang['user.btn_save_changes'] = 'ENVIAR FEEDBACK';
	//===============End of Feed Back page=====================================
	
	//Customer_Report_Profile.php
	$lang['user.Customer_Report_Profile'] = 'Tu Perfil';
	
	
	
	$lang['user.Let_us_know_cuale_are_your_habits_alimentcios'] = '1) Dinos cuáles son tus hábitos alimenticios';
	$lang['user.Since_you_did_a_Diet_Cuana_and_baseada_that'] = '2) ¿Alguna vez has estado en un programa de alimentación? ¿cuando y basado en qué?';
	$lang['user.Intolerances_dyed_them'] = '¿Tienes algunas intolerancias alimenticias?';
	$lang['user.What'] = '¿Cuáles?';
	$lang['user.Conoscimento_dyed_them_some_entermedades'] = ' ¿Tienes conocimiento de algunas enfermedades?';
	$lang['user.What_1'] = 'Si si, cuáles?';
	$lang['user.You_Diabetico_a'] = ' ¿Eres diabético/diabética?';
	$lang['user.You_have_lactosio_intolerance'] = '¿Tienes intolerancia a la lactosa?';
	$lang['user.Your_bowel_habits'] = 'Tus hábitos intestinales?';
	
	$lang['user.What_is_the_date_of_last_menstrual_period'] = '¿Cuál es la fecha de tu última menstruación?';
	$lang['user.Haces_Deportes_regularments'] = '¿Haces deportes regularmente?';
	$lang['user.Tell_us_how_often_you_consume_the_following_foods'] = 'Dinos con que frecuencia comes los siguientes alimentos';
	
	
?>