<?php
	
	//$lang['user.first_name'] = 'Details';
	
	//==========Client Profile PAge======================
	$lang['user.client_profile_title'] = 'Your Contact Data';
	//==========End of Client Profile PAge======================
	
	//==========Client Address PAge======================
	$lang['user.client_address_title'] = 'YOUR DELIVERY ADDRESS';
	//==========End of Client Address PAge======================
	
	//==========Client Dashboard Tab menu======================
	$lang['user.client_dashboard_orders'] = 'Your orders';
	$lang['user.client_dashboard_data'] = 'Your Data';
	$lang['user.client_dashboard_address'] = 'Your Address';
	$lang['user.client_dashboard_profile'] = 'Your Profile';
	$lang['user.client_dashboard_feedinghabits'] = 'Feeding Habits';
	$lang['user.client_dashboard_buy'] = 'Buy';
	//==========End of Client Dashboard Tab menu======================
	
	//===============Client Calendar page=====================================
	$lang['user.order_title'] = 'YOUR ORDERS';
	//===============End of Client Calendar page=====================================
	
	//===============Feed Back page=====================================
	$lang['user.client_feedback'] = 'Feedback';
	$lang['user.client_feedback_title'] = 'WE LIKE YOUR FEEDBACK';
	$lang['user.client_feedback_text'] = 'Help us improve the service ... and win a voucher for a free meal!!';
	$lang['user.client_feedback_foodquality'] = 'How do you evaluate the quality of our food?';
	$lang['user.client_feedback_price'] = 'Value for money?”';
	$lang['user.client_feedback_servicedelivery'] = 'How do you evaluate the delivery service?';
	$lang['user.client_feedback_recommend'] = 'How much would you recommend us to a friend?';
	$lang['user.client_feedback_where_knowus'] = 'How did you know about us?';
	$lang['user.client_feedback_recommendation_friend'] = 'Recommendation from a friend';
	$lang['user.client_feedback_traves_labour'] = 'At the workplace';	
	$lang['user.client_feedback_menu'] = 'Any particular feedback about the menu you bought?';
	$lang['user.client_feedback_suggestion'] = 'Let us know about any comments, suggestions or if you have any complaint';	
	$lang['user.client_contact'] = 'CONTACT';
	
	$lang['user.Liamanos_the_number'] = 'Call us at this number';
	$lang['user.EMAIL'] = 'EMAIL';
	$lang['user.Write_to'] = 'WRITE TO';
	$lang['user.btn_save_changes'] = 'SEND FEEDBACK';
	//===============End of Feed Back page=====================================

	//Customer_Report_Profile.php
	$lang['user.Customer_Report_Profile'] = 'Customer Report Profile';
	
	
	$lang['user.Let_us_know_cuale_are_your_habits_alimentcios'] = '1) Let us know what your eating habits are';
	$lang['user.Since_you_did_a_Diet_Cuana_and_baseada_that'] = '2) have you ever been on a diet? When and based on what?';
	$lang['user.Intolerances_dyed_them'] = 'Do you have food intolerances?';
	$lang['user.What'] = 'Which ones?';
	$lang['user.Conoscimento_dyed_them_some_entermedades'] = 'Do you have knowledge of some diseases?';
	$lang['user.What_1'] = 'If yes, which ones?';
	$lang['user.You_Diabetico_a'] = 'Are you diabetic / diabetic?';
	$lang['user.You_have_lactosio_intolerance'] = 'Are you lactose intolerant?';
	$lang['user.Your_bowel_habits'] = 'Your bowel habits?';
	
	$lang['user.What_is_the_date_of_last_menstrual_period'] = 'What is the date of your last period?';
	$lang['user.Haces_Deportes_regularments'] = 'Do you play sports regularly?';
	$lang['user.Tell_us_how_often_you_consume_the_following_foods'] = 'Tell us how often you eat the following foods';

	
?>